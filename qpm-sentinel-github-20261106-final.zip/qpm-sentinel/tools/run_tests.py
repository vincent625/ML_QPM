#!/usr/bin/env python3
"""Run the packaged, synthetic/self-contained software tests without CSA data."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
for name in ["OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"]:
    os.environ.setdefault(name, "1")
os.environ.setdefault("MPLBACKEND", "Agg")
for folder in [ROOT/"pipeline", ROOT/"tests"/"upstream", ROOT/"tests", ROOT/"tools"]:
    sys.path.insert(0, str(folder))


def source_snapshot(root=ROOT):
    """Fingerprint executable source, test code, policies and requirements."""
    root = Path(root)
    paths = []
    for name in ["pipeline", "tests", "tools", "examples"]:
        paths.extend((root/name).rglob("*.py"))
    paths.extend((root/"configs").rglob("*.json"))
    paths.extend((root/"pipeline").rglob("*.json"))
    paths.extend((root/"pipeline").rglob("*requirements*.txt"))
    paths.extend(root.glob("requirements*.txt"))
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(paths)) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pattern", default="test_*.py")
    parser.add_argument("--report", type=Path, default=ROOT/"validation"/"tests.json")
    args = parser.parse_args()
    if args.pattern != "test_*.py" and args.report.resolve() == (ROOT/"validation"/"tests.json").resolve():
        parser.error("Partial test selections require a separate --report path")
    started = time.monotonic()
    before = source_snapshot()
    suites = []
    test_files = []
    for folder in [ROOT/"tests"/"upstream", ROOT/"tests"]:
        if folder.is_dir():
            test_files.extend(str(p.relative_to(ROOT)) for p in sorted(folder.glob(args.pattern)))
            suites.append(unittest.TestLoader().discover(str(folder), pattern=args.pattern,
                                                        top_level_dir=str(folder)))
    suite = unittest.TestSuite(suites)
    if suite.countTestCases() == 0:
        raise SystemExit("No packaged tests found")
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=1).run(suite)
    after = source_snapshot()
    source_unchanged = before == after
    packages = ["numpy", "pandas", "scipy", "scikit-learn", "matplotlib", "pyarrow", "joblib", "Pillow"]
    record = {
        "status": "passed" if result.wasSuccessful() and source_unchanged else "failed",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "python_version": sys.version.split()[0],
        "dependencies": {p: importlib.metadata.version(p) for p in packages},
        "tests_run": result.testsRun,
        "failures": [case.id() for case, _ in result.failures],
        "errors": [case.id() for case, _ in result.errors],
        "skipped": [{"test": case.id(), "reason": reason} for case, reason in result.skipped],
        "elapsed_seconds": round(time.monotonic()-started, 3),
        "test_files": test_files,
        "pattern": args.pattern,
        "full_suite": args.pattern == "test_*.py",
        "source_unchanged_during_tests": source_unchanged,
        "tested_source_sha256": after,
        "scope": "software unit/regression tests; not scientific, clinical or delivered-volume validation",
        "production_csa_or_model_assets_required": False,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(record, indent=2)+"\n")
    print(json.dumps({key: record[key] for key in ["status", "tests_run", "failures", "errors", "elapsed_seconds"]}, indent=2))
    raise SystemExit(0 if record["status"] == "passed" else 1)


if __name__ == "__main__":
    main()

