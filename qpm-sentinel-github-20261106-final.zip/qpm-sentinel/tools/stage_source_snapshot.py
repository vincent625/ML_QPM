#!/usr/bin/env python3
"""Stage an allowlisted internal source snapshot without copying CSA data.

Only files named in MODULES, TESTS and CONFIGS are read. Portability changes
are explicit and recorded alongside original/staged hashes. Originals remain
untouched. Run this tool before making independent edits to staged sources.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import re


MODULES = """analyze_additional_dropout_steps analyze_csa analyze_dna_rna_barcode_balance
analyze_qpm_volume_diagnostics audit_expanded_reference_bank build_expanded_reference_bank
build_qualified_reference_bank collect_csa compare_qpm_classes_operations compare_qpm_models
csa_low_performance_diagnostics csa_root_cause_hypotheses find_qpm_failure_examples
forecast_10m_eight_runs forecast_next_run_csa outcome_reference plot_dropout_workflow_curves
prepare_all_qpm_volumes qpm_all_volume_inference qpm_barcode_reference qpm_baseline_comparison
qpm_cohort_publication qpm_cross_instrument_reference qpm_diagnostic_extensions qpm_dropout_plugin
qpm_internal_comparison qpm_nominal_volume_inference qpm_reference_bank qpm_reference_qualification
qpm_run_metadata qpm_same_run_curves qpm_trace_quality qpm_waveform_reference retrain_qpm_volume_models
run_flagged_qpm_batch run_manual_csa_plugin screen_all_csa_runs stage_downloaded_csa
train_all_qpm_volumes train_expanded_csa_outcomes train_multimodal_csa workflow_fingerprint_pilot
release_all_qpm_volume audit_qpm_volume_scope validate_all_qpm_volumes report_all_qpm_volumes
plot_qpm_accuracy_by_volume""".split()
TESTS = """test_csa_root_cause_hypotheses test_csa_low_performance_diagnostics
test_csa_low_performance_batch test_top5_csa_metrics test_qpm_diagnostic_routing test_qpm_er72
test_qpm_five_evidence test_qpm_parallel_baselines test_qpm_reference_qualification
test_qpm_run_metadata test_qpm_same_run_curves test_qpm_sparse_display test_qpm_outcome_first_layout
test_qpm_all_volume_inference test_qpm_nominal_plugin_integration test_qpm_volume_expanded
test_all_qpm_volumes test_expanded_csa_outcomes test_expanded_reference_bank test_flagged_qpm_batch
test_gx8_model_registration test_qpm_cohort_publication test_all_csa_run_screen
test_forecast_next_run_csa test_forecast_10m_eight_runs test_qpm_accuracy_by_volume""".split()
CONFIGS = ["qpm_dropout_plugin_config.json", "outcome_reference_policy.json",
           "qpm_waveform_reference_policy.json"]
SUPPORT = ["qpm_dropout_plugin_requirements.txt", "QPM_ALL_OPERATIONS_VOLUME_README.md"]


def sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def literal_assignment(source: str, name: str):
    for node in ast.parse(source).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError(f"Missing literal assignment {name}")


def replace_once(text: str, before: str, after: str) -> str:
    if text.count(before) != 1:
        raise ValueError(f"Upstream drift: expected exactly one match for {before[:90]!r}")
    return text.replace(before, after, 1)


def portable(name: str, text: str) -> tuple[str, list[str]]:
    changes = []
    if name == "collect_csa.py":
        text, count = re.subn(r"TARGETS = \(\n.*?SSH_JUMP_HOST: str \| None = None", 
                              "# No instrument or jump host is embedded in the distribution.\n"
                              "TARGETS: tuple[str, ...] = ()\nSSH_JUMP_HOST: str | None = None", text, count=1, flags=re.S)
        if count != 1:
            raise ValueError("Upstream collector target declaration changed")
        text = replace_once(text, 'if SSH_JUMP_HOST and target.split("@", 1)[1] in JUMP_INSTRUMENTS:', 'if SSH_JUMP_HOST:')
        text = replace_once(text, "global SSH_JUMP_HOST, SSH_CONTROL_DIRECTORY", "global TARGETS, SSH_JUMP_HOST, SSH_CONTROL_DIRECTORY")
        text = replace_once(text, '"--targets", nargs="+", choices=ALLOWED_TARGETS,', '"--targets", nargs="+", required=True,')
        text = replace_once(text, 'help="Optional approved target subset; inventory results are merged by host."',
                            'help="Explicit user@host targets authorized by your organization; no default network targets."')
        text = replace_once(text, 'parser.add_argument("--jump-host", choices=ALLOWED_JUMP_HOSTS,', 'parser.add_argument("--jump-host",')
        text = replace_once(text, 'help="Approved ProxyJump route for instruments 0083 and 0087 only."',
                            'help="Optional explicit user@host ProxyJump route for the supplied targets."')
        text = replace_once(text, "    SSH_JUMP_HOST = args.jump_host", 
                            "    for target in [*args.targets, *([args.jump_host] if args.jump_host else [])]:\n"
                            "        if not re.fullmatch(r'[A-Za-z0-9_.-]+@[A-Za-z0-9_.-]+', target):\n"
                            "            parser.error('Targets must be explicit user@host SSH names without shell metacharacters')\n"
                            "    TARGETS = tuple(args.targets)\n    SSH_JUMP_HOST = args.jump_host")
        changes += ["Removed baked instrument/jump-host inventory; --targets required (network disabled by default)",
                    "Optional explicit ProxyJump applies only to supplied targets; SSH read-only operations unchanged"]
    elif name == "screen_all_csa_runs.py":
        text, count = re.subn(r"MANUAL_DEFAULT=Path\('[^']+'\)",
            "MANUAL_DEFAULT=Path(__file__).resolve().parent.parent / 'private_data' / 'manual_reports'", text, count=1)
        if count != 1:
            raise ValueError("Screen manual default declaration changed")
        changes.append("Replaced personal manual-report default with repository-relative private_data/manual_reports")
    elif name == "csa_low_performance_diagnostics.py":
        text = replace_once(text, "import json\n", "import json\nimport os\n")
        text = replace_once(text, 'STUDY = ROOT / "expanded_csa_outcomes_20261027_gx8_v2"',
            'STUDY = Path(os.environ.get("QPM_CSA_MODEL_STUDY", ROOT.parent / "private_artifacts" / "outcome_models"))')
        changes.append("CSA model study configurable by QPM_CSA_MODEL_STUDY, default private_artifacts/outcome_models")
    elif name == "build_qualified_reference_bank.py":
        before = '            json.loads((output / "reference_bank_regression_tests.json").read_text())["code_sha256"].items()))'
        after = ('            json.loads((output / "reference_bank_regression_tests.json").read_text())["code_sha256"].items()),\n'
                 '        regression_matches_current_tests=all(\n'
                 '            sha256(Path(__file__).resolve().parent.parent/"tests"/"upstream"/name) == value\n'
                 '            for name,value in json.loads((output / "reference_bank_regression_tests.json").read_text())["test_sha256"].items()))')
        text = replace_once(text, before, after)
        changes.append("Qualified-bank validation checks relocated test hashes separately from runtime source hashes")
    elif name == "audit_expanded_reference_bank.py":
        text, count = re.subn(r"REGRESSION_MODULES = \[.*?\]\nCODE_FILES =", 
                             "REGRESSION_MODULES = " + repr(TESTS) + "\nCODE_FILES =", text, count=1, flags=re.S)
        if count != 1:
            raise ValueError("Bank regression module declaration changed")
        text = replace_once(text, '    *[m+".py" for m in REGRESSION_MODULES]]', '    ]')
        text, count = re.subn(r"CODE_FILES = \[.*?\]\n\n\ndef regression_tests", 
                             "CODE_FILES = " + repr([m+".py" for m in MODULES]+SUPPORT) + "\n\n\ndef regression_tests",
                             text, count=1, flags=re.S)
        if count != 1:
            raise ValueError("Bank runtime fingerprint declaration changed")
        text = replace_once(text, "def regression_tests(bank):\n    suite=", 
            "def regression_tests(bank):\n    import sys\n"
            "    test_root = Path(__file__).resolve().parent.parent / 'tests' / 'upstream'\n"
            "    if str(test_root) not in sys.path:\n        sys.path.insert(0, str(test_root))\n    suite=")
        text = replace_once(text, '    write_json(Path(bank)/"reference_bank_regression_tests.json",record)',
            '    record["test_sha256"] = {name+".py": sha256(test_root/(name+".py")) for name in REGRESSION_MODULES}\n'
            '    write_json(Path(bank)/"reference_bank_regression_tests.json",record)')
        check = '        "regression_matches_current_code": all(sha256(Path(__file__).parent/name)==value for name,value in regression["code_sha256"].items()),'
        text = replace_once(text, check,
            check+'\n        "regression_matches_current_tests": bool(regression.get("test_sha256")) and all('\
            'sha256(Path(__file__).resolve().parent.parent/"tests"/"upstream"/name)==value '\
            'for name,value in regression["test_sha256"].items()),')
        changes += ["Bank build uses the 26 verified self-contained synthetic regression modules in tests/upstream",
                    "All 47 runtime modules/support files fingerprinted, with test source hashes recorded and validated separately; no external report fixtures required"]
    elif name == "run_flagged_qpm_batch.py":
        text = replace_once(text, '    plan["code_sha256"] = {name:file_sha256(Path(__file__).parent/name) for name in dependencies}',
            '    # Runtime snapshot excludes test sources now stored under tests/upstream.\n'
            '    dependencies = [name for name in dependencies if not name.startswith("test_")]\n'
            '    plan["code_sha256"] = {name:file_sha256(Path(__file__).parent/name) for name in dependencies}')
        changes.append("Batch runtime snapshot fingerprints runtime/support files, not relocated upstream test files")
    elif name == "test_csa_low_performance_batch.py":
        text = replace_once(text, 'code = Path(__file__).parent / "csa_low_performance_diagnostics.py"',
                            'code = Path(__import__("csa_low_performance_diagnostics").__file__)')
        changes.append("Synthetic cache fixture resolves the installed runtime module, not its relocated test directory")

    if "private, resumable yanzhu snapshot" in text:
        text = text.replace("private, resumable yanzhu snapshot", "private, resumable local snapshot")
        changes.append("Removed personal name from explanatory docstring")
    if "verified yanzhu copies" in text:
        text = text.replace("verified yanzhu copies", "verified local copies")
        changes.append("Removed personal name from explanatory docstring")
    redacted = re.sub(r"\b(gnxs-[A-Za-z0-9]+)\.(?:ads\.invitrogen\.net|itw)\b", r"\1.example.internal", text, flags=re.I)
    if redacted != text:
        changes.append("Replaced internal DNS domains in synthetic examples with example.internal")
        text = redacted
    if name.endswith(".md"):
        redacted = re.sub(r"/rhome/[^/\s]+/ML_HP/\.conda-env/bin/python", "python", text)
        if redacted != text:
            changes.append("Replaced personal interpreter path with portable python command in historical documentation")
            text = redacted
        redacted = re.sub(r"/rhome/[^/\s]+/ML_CSA", "<WORKSPACE>", text)
        if redacted != text:
            changes.append("Redacted original absolute workspace paths in historical support documentation")
            text = redacted
        text = "<!-- Historical internal study documentation; current entry point is the repository README. -->\n\n" + text
        changes.append("Marked original support README as historical reference documentation")
    if name.endswith(".py"):
        ast.parse(text)
    return text, changes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="Original parsed-project source directory")
    parser.add_argument("--destination", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--overwrite", action="store_true", help="Replace only the explicitly allowlisted staged files")
    args = parser.parse_args()
    source, destination = args.source.resolve(), args.destination.resolve()
    if source == destination or source in destination.parents or destination in source.parents:
        raise ValueError("Original source and repository staging directory must be separate trees")
    records = []
    entries = [(m+".py", "pipeline/"+m+".py") for m in MODULES]
    entries += [(m+".py", "tests/upstream/"+m+".py") for m in TESTS]
    entries += [(name, "configs/"+name) for name in CONFIGS]
    entries += [(name, "pipeline/"+name) for name in SUPPORT]
    for filename, relative in entries:
        original = source/filename
        payload = original.read_bytes()
        text, changes = portable(filename, payload.decode("utf-8"))
        target = destination/relative
        if target.exists() and target.read_text() != text and not args.overwrite:
            raise FileExistsError(f"Staged file differs: {relative}; preserve changes or explicitly pass --overwrite")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
        records.append(dict(source_basename=filename, staged_path=relative,
                            source_sha256=sha(payload), staged_sha256=sha(target.read_bytes()),
                            portability_changes=changes))
        if original.read_bytes() != payload:
            raise ValueError(f"Original source changed while staging {filename}")
    policy_source = source/"qpm_reference_qualification.py"
    policy = literal_assignment(policy_source.read_text(), "DEFAULT_POLICY")
    target = destination/"configs/reference_qualification_policy.json"
    target.write_text(json.dumps(policy, indent=2)+"\n")
    records.append(dict(source_basename=policy_source.name, staged_path="configs/reference_qualification_policy.json",
                        source_sha256=sha(policy_source.read_bytes()), staged_sha256=sha(target.read_bytes()),
                        portability_changes=["Serialized the unchanged source DEFAULT_POLICY as a portable configuration example"]))
    for name in CONFIGS:
        # Existing replay helpers expect baseline policy examples beside the executable modules.
        payload = (destination/"configs"/name).read_bytes()
        target = destination/"pipeline"/name
        target.write_bytes(payload)
        records.append(dict(source_basename=name, staged_path="pipeline/"+name,
                            source_sha256=sha((source/name).read_bytes()), staged_sha256=sha(payload),
                            portability_changes=["Runtime policy duplicate required by original reference-build helpers"]))
    (destination/"docs").mkdir(exist_ok=True)
    manifest = dict(status="staged", upstream_version="qpm-barcode-dropout-plugin-0.18.0-low-read-hypotheses",
                    scope="private_internal_source_snapshot", modules=len(MODULES), synthetic_test_modules=len(TESTS),
                    original_sources_modified=False, raw_csa_data_copied=False, embedded_network_targets=False,
                    tests_require_real_archives_or_reference_banks=False, files=records,
                    excluded_test_families=["publication-figure tests requiring frozen result tables",
                        "release/report validators requiring the original historical reference bank or report tree"],
                    scientific_thresholds_or_feature_policy_changed=False)
    (destination/"docs/source_snapshot_manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
    print(json.dumps({k:v for k,v in manifest.items() if k != "files"}, indent=2))


if __name__ == "__main__":
    main()
