#!/usr/bin/env python3
"""Read-only, non-deserializing preflight for approved private QPM assets.

Default output contains counts/error codes, not local paths or run identifiers.
No archive extraction, model loading, reference rebuilding or registry rewriting
is performed. Hash consistency is not a substitute for trusting the asset source.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import importlib
import inspect
import json
from pathlib import Path
import sys

REPOSITORY = Path(__file__).resolve().parents[1]
VERSION = "private-asset-preflight-v1"


class Audit:
    def __init__(self):
        self.errors = Counter()
        self.details = []
        self.digests = {}

    def issue(self, code, *, path=None, component="assets"):
        self.errors[code] += 1
        entry = dict(code=code, component=component)
        if path is not None:
            entry["sensitive_local_path"] = str(path)
        self.details.append(entry)

    def sha(self, path):
        path = Path(path)
        if path not in self.digests:
            digest = hashlib.sha256()
            with path.open("rb") as handle:
                for block in iter(lambda: handle.read(2**20), b""):
                    digest.update(block)
            self.digests[path] = digest.hexdigest()
        return self.digests[path]

    def read_json(self, path, component):
        try:
            value = json.loads(Path(path).read_text())
            if not isinstance(value, dict):
                raise ValueError("object required")
            return value
        except (OSError, ValueError, TypeError):
            self.issue("missing_or_invalid_json", path=path, component=component)
            return {}


def safe_member(root, name):
    """A manifest cannot instruct this tool to read a file outside its root."""
    root = Path(root).resolve()
    name = Path(name)
    if name.is_absolute() or ".." in name.parts:
        raise ValueError("manifest traversal")
    result = (root/name).resolve()
    if not result.is_relative_to(root):
        raise ValueError("manifest symlink escape")
    return result


def check_bank(audit, bank):
    manifest = audit.read_json(bank/"reference_bank_manifest.json", "bank")
    records = manifest.get("artifacts", {})
    passed = manifest.get("validation_status") == "passed" and isinstance(records, dict) and bool(records)
    if not passed:
        audit.issue("bank_manifest_not_validated_or_empty", component="bank")
    checked = matched = checked_bytes = 0
    for name, record in records.items() if isinstance(records, dict) else []:
        checked += 1
        try:
            path = safe_member(bank, name)
            if not path.is_file():
                raise FileNotFoundError
            size = path.stat().st_size
            if not isinstance(record, dict) or size != record.get("size_bytes"):
                audit.issue("bank_artifact_size_mismatch", path=path, component="bank")
                passed = False
                continue
            checked_bytes += size
            if audit.sha(path) != record.get("sha256"):
                audit.issue("bank_artifact_hash_mismatch", path=path, component="bank")
                passed = False
            else:
                matched += 1
        except ValueError:
            passed = False
            audit.issue("unsafe_manifest_member", component="bank")
        except OSError:
            passed = False
            audit.issue("bank_artifact_missing_or_unreadable", component="bank")
    return manifest, dict(ready=passed, listed_artifacts=checked, matched_artifacts=matched,
                          checked_bytes=checked_bytes, unlisted_files_certified=False)


def check_parsers(audit, bank, pipeline):
    result = dict(checked=False, context_matches=False, trace_quality_matches=False)
    context = audit.read_json(bank/"qpm_physical_operation_context_manifest.json", "context_cache")
    quality = audit.read_json(bank/"qpm_trace_quality_manifest.json", "quality_cache")
    try:
        pipeline = Path(pipeline).resolve()
        if pipeline != (REPOSITORY/"pipeline").resolve():
            audit.issue("only_packaged_pipeline_can_be_preflighted", component="parser")
            return result, context, quality
        if str(pipeline) not in sys.path:
            sys.path.insert(0, str(pipeline))
        physical = importlib.import_module("qpm_waveform_reference")
        trace = importlib.import_module("qpm_trace_quality")
        current = physical.digest([
            physical.CONTEXT_PARSER_VERSION, str(physical.OP_RE.pattern), str(physical.SEND_RE.pattern), physical.TABLES,
            inspect.getsource(physical.parse_command_context), inspect.getsource(physical.definition_maps),
            inspect.getsource(physical.extract_archive),
        ])
        trace_digest = hashlib.sha256((
            trace.VERSION+inspect.getsource(trace.TraceQualityTracker)+inspect.getsource(trace.extract_quality)
            +inspect.getsource(trace.parse_trace_quality)
            +str([trace.OP_RE.pattern, trace.SEND_RE.pattern, trace.REPLY_RE.pattern,
                  trace.CHANNEL_RE.pattern, trace.ER72_RE.pattern])
        ).encode()).hexdigest()
        result.update(checked=True, context_matches=current == context.get("parser_sha256")
                      and context.get("parser_version") == physical.CONTEXT_PARSER_VERSION,
                      trace_quality_matches=trace_digest == quality.get("parser_sha256"))
        if not result["context_matches"]:
            audit.issue("physical_context_parser_fingerprint_mismatch", component="parser")
        if not result["trace_quality_matches"]:
            audit.issue("trace_quality_parser_fingerprint_mismatch", component="parser")
    except (ImportError, OSError, ValueError, AttributeError, TypeError):
        audit.issue("parser_fingerprint_check_unavailable", component="parser")
    return result, context, quality


def check_archives(audit, bank, context, quality, *, verify_hashes=False):
    result = dict(required=0, available=0, missing=0, changed_signatures=0, quality_cache_rebuild_required=0,
                  hashes_recomputed=0, archive_contents_extracted=False, ready=False)
    try:
        import pyarrow.parquet as pq
        identifiers = set(pq.read_table(bank/"qpm_operation_waveforms.parquet", columns=["archive_id"],
                                        use_threads=False).column("archive_id").to_pylist())
        with (bank/"csa_transfer_manifest.csv").open(newline="") as stream:
            rows = list(csv.DictReader(stream))
    except (ImportError, OSError, ValueError, KeyError):
        audit.issue("archive_inventory_check_unavailable", component="archives")
        return result
    unique = {}
    for row in rows:
        if row.get("archive_id") in identifiers:
            unique.setdefault(row["archive_id"], row)
    result["required"] = len(identifiers)
    missing_rows = identifiers-set(unique)
    for _ in missing_rows:
        audit.issue("archive_missing_transfer_record", component="archives")
        result["missing"] += 1
    expected_context = context.get("input_signatures", {})
    expected_quality = quality.get("input_signatures", {})
    quality_sources = {row.get("archive_id"): row for row in quality.get("archives", [])}
    for identifier, row in unique.items():
        path = Path(row.get("local_path", ""))
        try:
            if not path.is_file():
                raise FileNotFoundError
            stat = path.stat()
            result["available"] += 1
            signature = [row.get("sha256"), stat.st_size, stat.st_mtime_ns]
            if expected_context.get(identifier) != signature or expected_quality.get(identifier) != signature:
                result["changed_signatures"] += 1
                audit.issue("archive_signature_requires_cache_rebuild", path=path, component="archives")
            if quality_sources.get(identifier, {}).get("status") != "parsed":
                result["quality_cache_rebuild_required"] += 1
                audit.issue("archive_quality_cache_requires_rebuild", path=path, component="archives")
            if verify_hashes:
                result["hashes_recomputed"] += 1
                if audit.sha(path) != row.get("sha256"):
                    audit.issue("raw_archive_hash_mismatch", path=path, component="archives")
        except OSError:
            result["missing"] += 1
            audit.issue("raw_archive_missing_or_unreadable", path=path, component="archives")
    archive_codes = [key for key in audit.errors if key.startswith(("archive_", "raw_archive_"))]
    result["ready"] = bool(identifiers) and not any(audit.errors[key] for key in archive_codes)
    result["default_signature_basis"] = "recorded_sha256_plus_current_size_and_mtime; raw bytes not rehashed unless requested"
    return result


def check_volume(audit, bank, study_override=None):
    registry = audit.read_json(bank/"qpm_nominal_volume_model.json", "volume")
    result = dict(ready=False, sealed_files_checked=0, model_payloads_checked=0,
                  models_deserialized=False, training_scope_or_prediction_validated=False)
    if not registry:
        return result
    if registry.get("label_basis") != "nominal_command_not_measured_delivery" or registry.get("actual_volume_prediction_validated") is not False:
        audit.issue("volume_registry_scope_metadata_invalid", component="volume")
        return result
    registered = Path(registry.get("study_path", ""))
    study = Path(study_override) if study_override is not None else registered
    errors_before = sum(audit.errors.values())
    if not registered.is_absolute() or not study.is_dir():
        audit.issue("registered_volume_study_unavailable", component="volume")
        return result
    if study.resolve() != registered.resolve():
        audit.issue("volume_registry_relocation_required", component="volume")
    log = audit.read_json(study/"analysis_run_log.json", "volume")
    seal = audit.read_json(study/"artifact_validation.json", "volume")
    if log.get("format_version") != "all-operations-nominal-v1" or seal.get("status") != "passed":
        audit.issue("volume_study_not_validated_expected_format", component="volume")
        return result
    for filename, pin in [("analysis_run_log.json", registry.get("analysis_run_log_sha256")),
                           ("artifact_validation.json", registry.get("artifact_validation_sha256"))]:
        try:
            if audit.sha(study/filename) != pin:
                audit.issue("volume_registry_hash_mismatch", component="volume")
        except OSError:
            audit.issue("registered_volume_file_unreadable", component="volume")
    sealed = seal.get("artifact_sha256", {})
    required = {"analysis_run_log.json", "training_run_membership.parquet", "inference_context_scope.parquet", "model_performance.csv"}
    if not isinstance(sealed, dict) or not required <= set(sealed):
        audit.issue("volume_seal_missing_required_files", component="volume")
        return result
    for name, expected in sealed.items():
        try:
            path = safe_member(study, name)
            result["sealed_files_checked"] += 1
            if audit.sha(path) != expected:
                audit.issue("volume_sealed_artifact_hash_mismatch", path=path, component="volume")
        except (OSError, ValueError, TypeError):
            audit.issue("volume_sealed_artifact_unavailable_or_unsafe", component="volume")
    model_records = log.get("models", [])
    if not model_records:
        audit.issue("volume_registry_has_no_models", component="volume")
    for record in model_records:
        try:
            path = safe_member(study, record["path"])
            result["model_payloads_checked"] += 1
            if audit.sha(path) != record.get("sha256"):
                audit.issue("volume_payload_hash_mismatch", path=path, component="volume")
        except (OSError, ValueError, TypeError, KeyError):
            audit.issue("volume_payload_unavailable_or_unsafe", component="volume")
    result["ready"] = result["model_payloads_checked"] > 0 and sum(audit.errors.values()) == errors_before
    result["trust_limit"] = "Hash agreement establishes integrity only; use models exclusively from an approved trusted source."
    return result


def check_outcome(audit, study, inventory):
    if study is None:
        return dict(requested=False, ready=False)
    study = Path(study)
    minimum = ["training_dataset.parquet", "feature_rankings.csv", "component_importance.csv",
               "model_training_log.json", "model_settings.json", "strict_policy_review.json"]
    found = 0
    for name in minimum:
        if (study/name).is_file():
            found += 1
        else:
            audit.issue("outcome_metric_asset_missing", path=study/name, component="outcome")
    inventory_ok = inventory is not None and Path(inventory).is_file()
    if not inventory_ok:
        audit.issue("plugin_inventory_missing_for_rawtrace_comparability", component="outcome")
    return dict(requested=True, ready=found == len(minimum) and inventory_ok,
                required_files_found=found, required_files=len(minimum), plugin_inventory_available=inventory_ok,
                result_scope="metric/reference availability only; not calibrated fault prediction",
                frozen_study_validation_repeated=False)


def run_preflight(bank, *, pipeline=None, volume_study=None, outcome_study=None,
                  plugin_inventory=None, verify_raw_hashes=False):
    audit = Audit()
    bank = Path(bank)
    manifest, bank_result = check_bank(audit, bank)
    parser, context, quality = check_parsers(audit, bank, pipeline or REPOSITORY/"pipeline")
    archives = check_archives(audit, bank, context, quality, verify_hashes=verify_raw_hashes)
    volume = check_volume(audit, bank, volume_study)
    outcome = check_outcome(audit, outcome_study, plugin_inventory)
    history_ready = (bank_result["ready"] and parser["checked"] and parser["context_matches"]
                     and parser["trace_quality_matches"] and archives["ready"])
    summary = dict(version=VERSION, status="ready_for_supplied_asset_paths" if not audit.errors else "attention_required",
                   historical_reference_assets_ready=bool(history_ready), volume_assets_integrity_ready=volume["ready"],
                   csa_metric_assets_ready=outcome["ready"],
                   checks=dict(bank=bank_result, parsers=parser, archives=archives, nominal_volume=volume, outcome_metrics=outcome),
                   error_counts=dict(sorted(audit.errors.items())), private_paths_in_default_output=False,
                   supplied_asset_files_modified=False, no_models_deserialized=True,
                   limitations=["No scientific validation, case-level inference approval or clinical suitability is established.",
                                "Hash integrity does not authenticate an untrusted model supplier.",
                                "Do not load unknown pickle/joblib payloads; deserialization can execute code.",
                                "Derived reference tables do not replace the approved raw-CSA store required by current loaders."])
    return summary, audit.details


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bank", type=Path, required=True)
    parser.add_argument("--volume-study", type=Path, help="Check an intended relocation; a differing registry path remains unresolved.")
    parser.add_argument("--outcome-study", type=Path)
    parser.add_argument("--plugin-inventory", type=Path)
    parser.add_argument("--verify-raw-hashes", action="store_true", help="Optional full read of all required raw archives; can be expensive.")
    parser.add_argument("--details-output", type=Path,
                        help="Optional SENSITIVE diagnostic path file, outside this repository only; never overwritten.")
    args = parser.parse_args()
    if args.details_output is not None and args.details_output.resolve().is_relative_to(REPOSITORY.resolve()):
        parser.error("Sensitive details must be written outside the repository.")
    summary, details = run_preflight(args.bank, volume_study=args.volume_study,
        outcome_study=args.outcome_study, plugin_inventory=args.plugin_inventory, verify_raw_hashes=args.verify_raw_hashes)
    if args.details_output is not None:
        args.details_output.parent.mkdir(parents=True, exist_ok=True)
        try:
            with args.details_output.open("x") as stream:
                json.dump(dict(notice="SENSITIVE LOCAL PATHS: DO NOT COMMIT OR PUBLISH", details=details), stream, indent=2)
        except FileExistsError:
            parser.error("Details output already exists; choose a new filename.")
    print(json.dumps(summary, indent=2, allow_nan=False))
    raise SystemExit(0 if summary["status"] == "ready_for_supplied_asset_paths" else 2)


if __name__ == "__main__":
    main()
