#!/usr/bin/env python3
"""Validate the Git-upload source package; never print matched secret values."""
from __future__ import annotations

import argparse
import ast
import fnmatch
import hashlib
import json
import os
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_ROOTS = {
    ".git", ".venv", "venv", "outputs", "data", "local_data", "private_data",
    "archives", "reference_banks", "private_assets", "private_artifacts", "models",
    "reports", "dist", "build",
}
EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
PRIVATE_SUFFIXES = (".txz", ".tar.xz", ".tar.gz", ".tgz", ".zip", ".parquet",
                    ".joblib", ".pkl", ".pickle", ".bam", ".bai", ".cram", ".crai",
                    ".sqlite", ".sqlite3", ".pem", ".key", ".p12", ".pfx", ".partial",
                    ".npy", ".npz", ".h5", ".hdf5", ".onnx", ".pt", ".pth")
PRIVATE_NAME_PATTERNS = ["*.fastq*", "*.fq*", "*.vcf*", "*.sqlite*",
                         "id_rsa*", "id_ed25519*", "*.local.json"]
PRIVATE_NAMES = {"known_hosts", "ssh_config", "active_reference_bank.json"}
TEXT_SUFFIXES = {".py", ".md", ".txt", ".json", ".csv", ".svg", ".cff", ".toml", ".yaml", ".yml", ".sh"}
REQUIRED = [
    "README.md", "requirements.txt", "NOTICE.md", "SECURITY.md", ".gitignore",
    "pipeline/qpm_dropout_plugin.py", "configs/qpm_dropout_plugin_config.json",
    "examples/run_synthetic_demo.py", "tools/run_tests.py", "tools/render_results.py",
    "docs/model_card.md", "docs/privacy.md", "docs/private_assets.md", "docs/usage.md",
    "docs/data/source_provenance.json", "docs/source_snapshot_manifest.json",
    *[f"docs/assets/{name}.png" for name in
      ["cohort_overview", "outcome_models", "qpm_volume_models", "diagnostic_features"]],
]
SENSITIVE_PATTERNS = {
    "private_key_material": re.compile("-----BEGIN " + r"(?:[A-Z]+ )?PRIVATE KEY-----"),
    "github_token_shape": re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{24,}\b"),
    "github_pat_shape": re.compile(r"\bgithub_pat_[A-Za-z0-9_]{30,}\b"),
    "aws_access_key_shape": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "machine_specific_home_path": re.compile(r"/(?:rhome|home)/[A-Za-z0-9_.-]+"),
    "internal_instrument_address": re.compile(r"\b[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.(?:itw|cbd)\b|\b[A-Za-z0-9-]+\.ads\.invitrogen\.net\b", re.I),
    "private_ipv4_address": re.compile(r"\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b"),
}


def ignored(relative: Path):
    return (relative.parts[0] in EXCLUDED_ROOTS or bool(set(relative.parts) & EXCLUDED_PARTS)
            or relative.name.endswith(".pyc") or relative.name in {".DS_Store", ".coverage"})


def files_for_upload(root=ROOT):
    root = Path(root)
    # Prune before walking: private stores can be huge and need not be inspected.
    for directory, folders, names in os.walk(root, followlinks=False):
        current = Path(directory)
        retained = []
        for name in sorted(folders):
            path = current/name
            relative = path.relative_to(root)
            if ignored(relative):
                continue
            if path.is_symlink():
                raise ValueError(f"Symlink is not permitted in upload package: {relative.as_posix()}")
            retained.append(name)
        folders[:] = retained
        for name in sorted(names):
            path = current/name
            relative = path.relative_to(root)
            if ignored(relative):
                continue
            if path.is_symlink():
                raise ValueError(f"Symlink is not permitted in upload package: {relative.as_posix()}")
            if path.is_file():
                yield path


def forbidden_upload_file(relative):
    relative = Path(relative)
    name = relative.name.lower()
    return (name.endswith(PRIVATE_SUFFIXES) or name.startswith(".env")
            or name in PRIVATE_NAMES
            or any(fnmatch.fnmatchcase(name, pattern) for pattern in PRIVATE_NAME_PATTERNS)
            or (relative.suffix.lower() == ".csv" and relative.parts[:2] != ("docs", "data")))


def scan_text(text, relative):
    findings = []
    for category, pattern in SENSITIVE_PATTERNS.items():
        for match in pattern.finditer(text):
            findings.append({"file": str(relative), "line": text.count("\n", 0, match.start())+1,
                             "category": category})
    return findings


def markdown_links(root, path):
    errors = []
    text = path.read_text()
    for target in re.findall(r"!?\[[^\]]*\]\(([^)]+)\)", text):
        target = target.strip().split(" \"", 1)[0].strip("<>")
        if not target or target.startswith("#") or urlsplit(target).scheme:
            continue
        target = unquote(target.split("#", 1)[0].split("?", 1)[0])
        destination = (path.parent/target).resolve()
        if not destination.is_relative_to(root.resolve()):
            errors.append({"file": path.relative_to(root).as_posix(), "target": target, "reason": "outside_repository"})
        elif not destination.exists():
            errors.append({"file": path.relative_to(root).as_posix(), "target": target, "reason": "missing"})
    return errors


def validate(root=ROOT):
    root = Path(root)
    missing = [p for p in REQUIRED if not (root/p).is_file()]
    findings, forbidden, syntax_errors, broken_links, large_files = [], [], [], [], []
    files = list(files_for_upload(root))
    for path in files:
        relative = path.relative_to(root).as_posix()
        if forbidden_upload_file(Path(relative)):
            forbidden.append(relative)
        if path.stat().st_size > 20*1024**2:
            large_files.append(relative)
        if path.suffix.lower() in TEXT_SUFFIXES or path.name == ".gitignore":
            text = path.read_text(encoding="utf-8")
            findings.extend(scan_text(text, relative))
            if path.suffix == ".py":
                try:
                    ast.parse(text, filename=relative)
                except SyntaxError as exc:
                    syntax_errors.append({"file": relative, "line": exc.lineno, "error": exc.msg})
        if path.suffix == ".md" and (path.parent == root or "docs" in path.relative_to(root).parts[:1]):
            broken_links.extend(markdown_links(root, path))
    failed = bool(missing or findings or forbidden or syntax_errors or broken_links or large_files)
    return {
        "status": "failed" if failed else "passed", "files_checked": len(files),
        "total_upload_bytes": sum(p.stat().st_size for p in files),
        "missing_required_files": missing, "sensitive_pattern_findings": findings,
        "forbidden_private_asset_files": forbidden, "large_files_over_review_threshold": large_files,
        "python_syntax_errors": syntax_errors, "broken_document_links": broken_links,
        "automated_check_not_publication_approval": True,
        "matched_secret_values_not_recorded": True,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--report", type=Path, default=ROOT/"validation"/"package_validation.json")
    args = parser.parse_args()
    try:
        result = validate(args.root)
    except (ValueError, UnicodeDecodeError) as exc:
        result = {"status": "failed", "error": str(exc)}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["status"] == "passed" else 1)


if __name__ == "__main__":
    main()

