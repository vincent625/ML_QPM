#!/usr/bin/env python3
"""Render README figures from bundled frozen aggregate tables; never fit models.

Run from any working directory: python tools/render_results.py
All source data are resolved relative to this repository, with no private paths.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyBboxPatch
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "docs/data"
PALETTE = {"ink": "#243C45", "teal": "#268B82", "blue": "#457B9D",
           "purple": "#7A648E", "coral": "#D7664B", "gray": "#89918F", "pale": "#E8F3EF"}
STYLE = {"font.family": "DejaVu Sans", "font.size": 10, "pdf.fonttype": 42,
         "ps.fonttype": 42, "svg.fonttype": "none", "text.color": PALETTE["ink"],
         "svg.hashsalt": "qpm-sentinel-doc-results-v1",
         "axes.labelcolor": PALETTE["ink"], "xtick.color": PALETTE["ink"], "ytick.color": PALETTE["ink"],
         "axes.spines.top": False, "axes.spines.right": False, "axes.spines.left": False}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_bounds(fig):
    from matplotlib.text import Text
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    outside = []
    for item in fig.findobj(Text):
        if item.get_visible() and item.get_text():
            box = item.get_window_extent(renderer)
            if box.x0 < bounds.x0-1 or box.y0 < bounds.y0-1 or box.x1 > bounds.x1+1 or box.y1 > bounds.y1+1:
                outside.append(item.get_text())
    if outside:
        raise ValueError("Off-page figure labels: "+repr(outside))


def save(fig, name, output):
    check_bounds(fig)
    for suffix in ["png", "svg"]:
        kwargs = {"metadata": {"Date": None, "Creator": "QPM Sentinel aggregate renderer"}} if suffix == "svg" else {}
        fig.savefig(output / f"{name}.{suffix}", dpi=180, facecolor="white", **kwargs)
    plt.close(fig)


def clean_axis(ax):
    ax.set_axisbelow(True)
    ax.grid(axis="x", color="#E5ECE8", lw=.7)
    ax.spines["bottom"].set_color(PALETTE["gray"])
    ax.tick_params(axis="y", length=0)


def cohort_figure(summary, output):
    fig = plt.figure(figsize=(12, 6.2), layout="constrained")
    gs = fig.add_gridspec(3, 4, height_ratios=[1.0, 1.55, .26])
    metrics = [("2,630", "CSA entries screened"), ("1,789", "Independent physical runs"),
               ("43", "Instruments screened"), ("763", "Scope reports completed")]
    for i, (number, label) in enumerate(metrics):
        ax = fig.add_subplot(gs[0, i])
        ax.set_axis_off()
        ax.add_patch(FancyBboxPatch((.02, .07), .96, .78, boxstyle="round,pad=.02,rounding_size=.04",
                                   transform=ax.transAxes, facecolor=PALETTE["pale"], edgecolor="none"))
        ax.text(.08, .64, number, transform=ax.transAxes, fontsize=29, weight="bold", color=PALETTE["teal"])
        ax.text(.08, .28, label, transform=ax.transAxes, fontsize=10.2)
    ax = fig.add_subplot(gs[1, :2])
    labels = ["Outcome-qualified reference runs", "Qualified runs with usable QPM", "Runs with ≥1 screening flag"]
    values = [summary["outcome_qualified_reference_runs"], summary["usable_qpm_reference_runs"], summary["flagged_physical_runs"]]
    y = np.arange(3)
    ax.barh(y, values, height=.55, color=[PALETTE["blue"], PALETTE["teal"], PALETTE["coral"]])
    ax.set_yticks(y, labels, fontsize=9.4)
    ax.invert_yaxis()
    ax.set_xlim(0, 1060)
    ax.set_xticks([0, 250, 500, 750, 1000])
    for pos, value in enumerate(values): ax.text(value+12, pos, f"{value:,}", va="center", weight="bold")
    ax.set_title("Reference source pool and flagged runs", loc="left", fontsize=12, weight="bold")
    ax.set_xlabel("Independent physical runs")
    clean_axis(ax)
    ax = fig.add_subplot(gs[1, 2:])
    chips = summary["usable_qpm_reference_runs_by_chip"]
    vals = list(chips.values())
    y = np.arange(len(chips))
    ax.barh(y, vals, color=PALETTE["teal"], height=.55)
    ax.set_yticks(y, list(chips), fontsize=10)
    ax.invert_yaxis()
    ax.set_xlim(0, 330)
    ax.set_xticks([0, 100, 200, 300])
    for pos, value in enumerate(vals): ax.text(value+5, pos, str(value), va="center", weight="bold")
    ax.set_title("Usable QPM sources by chip\n910 physical runs · 40 instruments", loc="left", fontsize=11.2, weight="bold")
    ax.set_xlabel("Independent physical runs")
    clean_axis(ax)
    foot = fig.add_subplot(gs[2, :]); foot.set_axis_off()
    foot.text(0, .80, "37 archive entries unparsed · 0 processing failures in 763 earlier scope reports—not zero diagnostic errors.", fontsize=9)
    foot.text(0, .20, "Archive entries ≠ independent runs ≠ lane/scope reports. Qualification does not certify fault-free runs; each operation uses its own compatible subset.", fontsize=8.5, color=PALETTE["gray"])
    fig.suptitle("QPM Sentinel: screened evidence base and reference sources", x=.015, ha="left", fontsize=17, weight="bold")
    save(fig, "cohort_overview", output)


def outcomes_figure(frame, output):
    subset = frame[frame.validation_scheme.eq("leave_one_instrument_out")]
    models = ["median_baseline", "context_only_elastic_net", "elastic_net", "extra_trees"]
    labels = ["Median baseline", "Context-only Elastic Net", "Full diagnostic Elastic Net", "Full diagnostic Extra Trees"]
    colors = [PALETTE["gray"], PALETTE["blue"], PALETTE["teal"], PALETTE["coral"]]
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.4), layout="constrained")
    for ax, outcome, unit, divisor, title in zip(axes,
        ["total_reads", "mean_read_length_bp"], ["MAE (million reads)", "MAE (base pairs)"],
        [1e6, 1.], ["a  Total reads", "b  Mean raw read length"]):
        rows = subset[subset.outcome.eq(outcome)].set_index("model").loc[models]
        y = np.arange(len(models)); values = rows.mae.to_numpy()/divisor
        ax.barh(y, values, color=colors, height=.57)
        ax.set_yticks(y, labels, fontsize=10)
        ax.invert_yaxis()
        ax.set_xlim(0, values.max()*1.18)
        ax.set_xticks([0, 10, 20, 30])
        for pos, value in enumerate(values): ax.text(value+values.max()*.018, pos, f"{value:.2f}", va="center", weight="bold", fontsize=11)
        ax.set_xlabel(unit+" · lower is better")
        n = int(rows.n_physical_runs.iloc[0]); scopes = int(rows.n_observations.iloc[0]); inst = int(rows.instruments.iloc[0])
        ax.set_title(title+f"\n{n:,} runs · {scopes:,} observations\n{inst} instruments", loc="left", fontsize=11.2, weight="bold", pad=12)
        clean_axis(ax)
    fig.suptitle("Retrospective outcome prediction on held-out instruments", x=.015, ha="left", fontsize=17, weight="bold")
    fig.supxlabel("Full models use same-run context + during/post-run diagnostic features—not future-run forecasting or causal tuning effects.\nCompared with context-only Elastic Net: 7.7% lower read-count MAE and 14.6% lower read-length MAE.", fontsize=9.2, color=PALETTE["gray"])
    save(fig, "outcome_models", output)


def volume_figure(frame, tasks, output):
    matrix = frame.set_index("task_id")
    tasks = tasks.set_index("task_id").loc[matrix.index]
    labels = []
    for task, row in tasks.iterrows():
        operation = "aspiration" if row.operation == "aspirate" else "dispense"
        values = json.loads(row.volumes_ul)
        assert len(set(values)) == 5
        labels.append(f"LC{int(row.liquid_class_index)} · {operation}\n"+", ".join(f"{v:g}" for v in values)+" µL")
    short = {"Majority baseline": "Majority", "Context-only control": "Context only", "Robust template": "Robust template",
             "Logistic regression": "Logistic", "Linear SVM": "Linear SVM", "PCA + logistic": "PCA + logistic",
             "Extra Trees": "Extra Trees", "Nested-selected procedure": "Nested-selected"}
    values = matrix.to_numpy(float)*100
    fig, ax = plt.subplots(figsize=(12, 6.3), layout="constrained")
    cmap = LinearSegmentedColormap.from_list("qpm_nature_teal", ["#FAFBFA", "#C7E1DC", PALETTE["teal"], PALETTE["ink"]])
    image = ax.imshow(values, vmin=0, vmax=100, cmap=cmap, aspect="auto")
    ax.set_xticks(range(matrix.shape[1]), [short.get(c, c) for c in matrix.columns], rotation=32, ha="right", fontsize=10)
    ax.set_yticks(range(6), labels, fontsize=10)
    for r in range(6):
        for c in range(8):
            ax.text(c, r, f"{values[r,c]:.1f}", ha="center", va="center", fontsize=11, color="white" if values[r,c]>70 else PALETTE["ink"])
    selected = matrix.columns.get_loc("Nested-selected procedure")
    ax.add_patch(plt.Rectangle((selected-.5, -.5), 1, 6, fill=False, edgecolor=PALETTE["coral"], lw=1.8))
    ax.set_title("Programmed-volume classification on unseen instruments\nPIP2 · 450 physical runs per task · 43 instruments · five nominal classes per row", loc="left", fontsize=13, weight="bold", pad=15)
    fig.colorbar(image, ax=ax, label="Balanced accuracy (%)", shrink=.85, pad=.02)
    fig.supxlabel("Cells summarize all five commanded volume classes in each row. Nested-selected uses training-only model selection.\nThis is nominal-volume recognition—not independently measured delivered volume.", fontsize=9, color=PALETTE["gray"])
    save(fig, "qpm_volume_models", output)


def importance_figure(frame, output):
    frame = frame.sort_values("audited_rank")
    label_map = {1:"RawTrace image-median spread", 2:"Analyzed lane count [context]",
        3:"Merged in-range pixel-count proxy †", 4:"Edge-region pixel-count spread †",
        5:"RawTrace image-q90 spread", 6:"Chip minor revision [context]",
        7:"RawTrace image-entropy spread", 8:"Lane-3 resequencing argument [context]",
        9:"Logged in-range pixel count †", 10:"AutoCal horizontal image gradient"}
    group_colors = {"RawTrace":PALETTE["blue"], "ChipDiagnostics":PALETTE["purple"],
                    "AutoCal":"#BE7C46", "CSA metadata / context":PALETTE["gray"]}
    fig, ax = plt.subplots(figsize=(11.8, 6.8), layout="constrained")
    for position, row in enumerate(frame.itertuples()):
        color = group_colors[row.source_category]
        ax.plot([row.importance_ci_low_million_reads, row.importance_ci_high_million_reads], [position, position], color=color, lw=2.2)
        ax.scatter([row.heldout_mae_increase_million_reads], [position], marker="D", s=42, color=color, edgecolor="white", lw=.6, zorder=3)
        ax.text(8.65, position, f"{row.heldout_mae_increase_million_reads:.2f}", ha="right", va="center", fontsize=10, weight="bold", color=color)
    ax.set_yticks(range(10), [f"#{int(r.audited_rank):02d}  "+label_map[int(r.audited_rank)] for r in frame.itertuples()], fontsize=10)
    for tick, row in zip(ax.get_yticklabels(), frame.itertuples()): tick.set_color(group_colors[row.source_category])
    ax.set_ylim(9.6, -.6); ax.set_xlim(-.10, 8.95)
    ax.set_xticks([0, 2, 4, 6, 8])
    ax.axvline(0, color=PALETTE["gray"], ls=":", lw=.8)
    ax.set_xlabel("Held-out MAE increase after feature permutation (million reads)")
    ax.set_title("Top individual predictors in the total-read diagnostic model\nFive physical-run-grouped Elastic Net outer folds · frozen permutation results", loc="left", fontsize=13, weight="bold", pad=15)
    clean_axis(ax)
    fig.supxlabel("Blue: RawTrace · purple: ChipDiagnostics · orange: AutoCal · gray: metadata/context. Intervals are exploratory across five outer folds.\nImportance is predictive dependence—not causal impact or reads lost. † Count/geometry health or loading interpretation is withheld.\nRawTrace uses rendered-image proxies—not calibrated signal amplitude or SNR.", fontsize=8.8, color=PALETTE["gray"])
    save(fig, "diagnostic_features", output)


def barcode_workflow_figure(points, summary, output):
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 5.6), layout="constrained",
                             gridspec_kw={"width_ratios": [.83, 1.20, 1.20]})
    ax = axes[0]
    counts = [summary["apparent_dropout_paths"], summary["partial_imbalance_paths"], summary["surviving_paths"]]
    assert counts == [11, 1, 12] and sum(counts) == summary["sample_paths"] == 24
    ax.bar([0, 1, 2], counts, color=[PALETTE["coral"], "#D7A24A", PALETTE["teal"]], width=.64)
    ax.set_xticks([0, 1, 2], ["Apparent\ndropout", "Partial\nimbalance", "Surviving"], fontsize=9)
    ax.set_ylim(0, 13.5); ax.set_yticks([0, 4, 8, 12])
    ax.set_ylabel("DNA sample paths")
    ax.set_title("a  Outcome screen\n24 DNA sample paths", loc="left", fontsize=11.3, weight="bold", pad=12)
    for x, value in enumerate(counts):
        ax.text(x, value+.25, str(value), ha="center", fontsize=12, weight="bold")
    ax.set_axisbelow(True); ax.grid(axis="y", color="#E5ECE8", lw=.7)
    ax.spines["bottom"].set_color(PALETTE["gray"])
    step_lookup = {item["step"]:item for item in summary["steps"]}
    specifications = [
        ("earliest_qualifying_20ul_aspiration", "b  Adapter ligation · 20 µL aspiration\nReaction well → barcode\nEarliest qualifying · within-run AUC 1.00"),
        ("later_25ul_recovery", "c  Barcode recovery · 25 µL aspiration\nFrom assigned barcode wells\nLater support · within-run AUC 0.958"),
    ]
    for ax, (step, title) in zip(axes[1:], specifications):
        metadata = step_lookup[step]
        assert metadata["historical_reference_used"] is False
        for group, color, style, label in [
            ("affected", PALETTE["coral"], "-", "Affected paths (12)"),
            ("surviving", PALETTE["teal"], "--", "Surviving paths (12)"),
        ]:
            subset = points[points.step.eq(step) & points.path_group.eq(group)].sort_values("normalized_operation_progress_pct")
            assert len(subset) == 32 and subset.n_paths.eq(12).all()
            x = subset.normalized_operation_progress_pct.to_numpy()
            ax.fill_between(x, subset.qpm_p25_raw_counts.to_numpy(), subset.qpm_p75_raw_counts.to_numpy(),
                            color=color, alpha=.16, linewidth=0)
            ax.plot(x, subset.qpm_median_raw_counts.to_numpy(), color=color, ls=style, lw=2.5, label=label)
        ax.set_title(title, loc="left", fontsize=10.9, weight="bold", pad=12)
        ax.set_xlim(0, 100); ax.set_xticks([0, 25, 50, 75, 100])
        ax.set_xlabel("Normalized operation progress (%)", fontsize=9)
        ax.set_ylabel("Baseline-centered QPM (raw counts)", fontsize=9)
        ax.set_axisbelow(True); ax.grid(color="#E5ECE8", lw=.7)
        ax.spines["bottom"].set_color(PALETTE["gray"])
        ax.legend(frameon=False, loc="best", fontsize=9)
    fig.suptitle("Observed barcode-path differences align with workflow QPM evidence\nDe-identified same-run example · 12 affected and 12 surviving DNA paths",
                 x=.015, ha="left", fontsize=15, weight="bold")
    fig.supxlabel("Lines: group medians · bands: pointwise 25th–75th percentiles · 32 normalized progress points · PIP1 / LC42 · no historical reference used.\nAUC is post-hoc within-run score separation—not held-out diagnostic sensitivity. Earliest qualifying does not establish the first fault or causal origin.",
                  fontsize=8.6, color=PALETTE["gray"])
    save(fig, "barcode_workflow_example", output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"docs/assets")
    args = parser.parse_args()
    output = args.output.resolve(); output.mkdir(parents=True, exist_ok=True)
    source_paths = sorted(DATA.glob("*.csv"))+sorted(DATA.glob("*.json"))
    before = {p.name:digest(p) for p in source_paths}
    provenance = json.loads((DATA/"source_provenance.json").read_text())
    for name, expected in provenance["exported_tables_sha256"].items():
        if digest(DATA/name) != expected:
            raise ValueError("Bundled aggregate source changed: "+name)
    summary = json.loads((DATA/"cohort_summary.json").read_text())
    with plt.rc_context(STYLE):
        cohort_figure(summary, output)
        outcomes_figure(pd.read_csv(DATA/"outcome_model_performance.csv"), output)
        volume_figure(pd.read_csv(DATA/"qpm_volume_classification.csv"), pd.read_csv(DATA/"qpm_classification_tasks.csv"), output)
        importance_figure(pd.read_csv(DATA/"diagnostic_feature_importance.csv"), output)
        barcode_workflow_figure(pd.read_csv(DATA/"barcode_workflow_group_summaries.csv"),
                                json.loads((DATA/"barcode_workflow_example_summary.json").read_text()), output)
    assert all(digest(DATA/name) == value for name,value in before.items())
    figure_names = ["cohort_overview", "outcome_models", "qpm_volume_models", "diagnostic_features", "barcode_workflow_example"]
    outputs = [output/f"{name}.{suffix}" for name in figure_names for suffix in ["png", "svg"]]
    validation = {"status":"passed", "models_trained":False, "metrics_recomputed":False,
        "renderer_sha256":digest(Path(__file__)),
        "source_table_hashes":before, "output_sha256":{p.name:digest(p) for p in outputs},
        "no_run_sample_or_patient_identifiers":True, "corporate_template_or_logos_used":False,
        "figures":figure_names}
    (output/"render_validation.json").write_text(json.dumps(validation, indent=2)+"\n")
    print(json.dumps({"status":"passed", "figures":len(outputs)//2, "output":str(output)}, indent=2))


if __name__ == "__main__":
    main()
