#!/usr/bin/env python3
"""Build a checked Git-upload ZIP; exclude production data and local outputs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from validate_package import ROOT, files_for_upload, validate
from run_tests import source_snapshot


def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT.parent/"qpm-sentinel-github-20261106.zip")
    args = parser.parse_args()
    if args.output.resolve().is_relative_to(ROOT.resolve()):
        raise SystemExit("Write the release ZIP outside the source repository")
    result = validate(ROOT)
    if result["status"] != "passed":
        raise SystemExit("Package validation failed; run tools/validate_package.py for details")
    if args.output.exists():
        raise SystemExit("Output already exists; choose a new output name to preserve it")
    test_report = ROOT/"validation"/"tests.json"
    if not test_report.is_file():
        raise SystemExit("Run tools/run_tests.py successfully before packaging")
    tested = json.loads(test_report.read_text())
    if (tested.get("status") != "passed" or tested.get("full_suite") is not True
            or tested.get("source_unchanged_during_tests") is not True):
        raise SystemExit("A successful full-suite test run is required before packaging")
    if tested.get("tested_source_sha256") != source_snapshot():
        raise SystemExit("Source/configuration changed since testing; rerun the full suite")
    files = [p for p in files_for_upload(ROOT) if p.name != "MANIFEST.sha256"]
    manifest = "".join(f"{sha(p)}  {p.relative_to(ROOT).as_posix()}\n" for p in files)
    manifest_path = ROOT/"MANIFEST.sha256"
    manifest_path.write_text(manifest)
    files.append(manifest_path)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    partial = args.output.with_name(args.output.name+".partial")
    if partial.exists():
        raise SystemExit("Partial output already exists; choose a new output name")
    with zipfile.ZipFile(partial, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for path in sorted(files):
            relative = Path("qpm-sentinel")/path.relative_to(ROOT)
            entry = zipfile.ZipInfo(relative.as_posix(), date_time=(2026, 11, 6, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            package.writestr(entry, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(partial) as package:
        if package.testzip() is not None:
            raise SystemExit("ZIP integrity check failed")
        for line in manifest.splitlines():
            expected, relative = line.split("  ", 1)
            actual = hashlib.sha256(package.read("qpm-sentinel/"+relative)).hexdigest()
            if actual != expected:
                raise SystemExit(f"ZIP content hash mismatch: {relative}")
    partial.rename(args.output)
    record = {"status": "passed", "archive": args.output.name, "files": len(files),
              "size_bytes": args.output.stat().st_size, "sha256": sha(args.output),
              "raw_csa_or_production_model_assets_included": False,
              "source_files_match_manifest_and_zip": True}
    args.output.with_suffix(args.output.suffix+".json").write_text(json.dumps(record, indent=2)+"\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()

