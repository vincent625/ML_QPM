#!/usr/bin/env python3
"""Audit additional QPM steps aligned with two barcode-dropout patterns.

The scan maps QPM operations to the same failed and surviving barcode paths
used in the prior B/C and E/F panels.  It evaluates same-operation,
same-volume comparisons, excludes the already displayed operations, and
distinguishes upstream candidates from downstream persistence.

QPM values are baseline-centered raw sensor counts.  They are not calibrated
pressure or delivered-volume measurements, and retrospective alignment does
not establish causality.
"""

from __future__ import annotations

import ast
from itertools import combinations
from pathlib import Path
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "qpm_failure_examples"
SCORES = OUT / "dna_rna_dropout_qpm_scores.csv"
BARCODE_MAP = OUT / "dropout_barcode_well_mapping.csv"

RUN1 = "obs_fef8b0992599"
RUN2 = "obs_32eade743d80"

COLORS = {
    "ink": "#264653",
    "teal": "#2A9D8F",
    "gold": "#E9C46A",
    "orange": "#F4A261",
    "coral": "#E76F51",
    "blue": "#457B9D",
    "rna": "#8F5D8A",
    "gray": "#8A918B",
    "grid": "#D9DED9",
    "paper": "#FCFCF8",
    "pale_teal": "#E8F3EF",
}


CASES = {
    RUN1: {
        "run_label": "Run 1",
        "material": "DNA",
        "outcome": "DNA orders 6–9 dropped; orders 1–4 survived",
        "failed_label": "failed DNA block 2",
        "survivor_label": "surviving DNA block 1",
        "anchor_start": 232,
        "anchor_end": 277,
        "reaction_locations": {
            "pcr_a1": ("survivor", 1),
            "pcr_b1": ("survivor", 2),
            "pcr_c1": ("survivor", 3),
            "pcr_d1": ("survivor", 4),
            "pcr_g1": ("failed", 6),
            "pcr_h1": ("failed", 7),
            "pcr_a2": ("failed", 8),
            "pcr_b2": ("failed", 9),
        },
        "already_shown": {
            ("UDG transfer to DNA reaction well", "aspirate"),
            ("UDG transfer to DNA reaction well", "dispense"),
        },
    },
    RUN2: {
        "run_label": "Run 2",
        "material": "RNA",
        "outcome": "RNA orders 11–14 dropped; orders 16–19 survived",
        "failed_label": "failed RNA block 3",
        "survivor_label": "surviving RNA block 4",
        "anchor_start": 654,
        "anchor_end": 711,
        "reaction_locations": {
            "pcr_a9": ("failed", 11),
            "pcr_b9": ("failed", 12),
            "pcr_c9": ("failed", 13),
            "pcr_d9": ("failed", 14),
            "pcr_g9": ("survivor", 16),
            "pcr_h9": ("survivor", 17),
            "pcr_a10": ("survivor", 18),
            "pcr_b10": ("survivor", 19),
        },
        "already_shown": {
            ("Adapter-ligation reaction-well aspiration", "aspirate"),
            ("Adapter-ligation barcode-well dispense", "dispense"),
        },
    },
}


FAMILY_PATTERNS = [
    (r"udg_dispense_ffpe_dna_template", "DNA-template dispense into UDG reaction"),
    (r"udg_transfer_5u_l_from_udg_", "UDG transfer to DNA reaction well"),
    (r"rt_transfer_15ul_from_rt_reaction", "RT branch-split transfer"),
    (r"target_amp_transfer_21u_l_of_dna_at_mastermix", "DNA target-amplification mastermix transfer"),
    (r"target_amp_transfer_15u_l_of_rna_at_mastermix", "RNA target-amplification mastermix transfer"),
    (r"partial_digestion_transfer", "Partial-digestion reagent transfer"),
    (r"ligate_adapters_aspirate_all_digested_sample_and_oil", "Adapter-ligation reaction-well aspiration"),
    (r"ligate_adapters_dispense_digested_sample_to_barcode", "Adapter-ligation barcode-well dispense"),
    (r"ligate_adapters_aspirate_digested_sample_and_resuspended_barcode", "Adapter-ligation barcode-well recovery aspiration"),
    (r"ligate_adapters_dispense_all_digested_sample_with_resuspended_barcode", "Adapter-ligation return dispense to reaction well"),
    (r"ligate_adapters_transfer_9u_l_from_la_mastermix", "Ligation-mastermix addition"),
    (r"function_transfer_25u_l_of_oil", "Oil-overlay transfer"),
    (r"function_mixing_of_ampliseq_reaction", "Reaction-well mixing"),
    (r"ampure_transferring_.*from_at_reaction", "AMPure cleanup transfer out of reaction well"),
    (r"ampure_transferring_52ul_eluted_library", "AMPure eluted-library return to reaction well"),
    (r"pcrplate_rinse_out_serially_dispense", "PCR-well rinse dispense"),
    (r"pcrplate_rinse_out_aspirate", "PCR-well rinse aspiration"),
    (r"equalizer_transfer_12ul_eq_capture", "Equalizer-capture addition"),
    (r"equalizer_pool_27", "Equalizer pooling aspiration"),
]


def parse_profile(value: object) -> np.ndarray:
    if isinstance(value, (list, tuple, np.ndarray)):
        return np.asarray(value, dtype=float)
    return np.asarray(ast.literal_eval(str(value)), dtype=float)


def family_name(process_step: object) -> str:
    text = str(process_step).lower()
    for pattern, label in FAMILY_PATTERNS:
        if re.search(pattern, text):
            return label
    cleaned = re.sub(r"_[0-9a-f]{10,16}$", "", text)
    cleaned = re.sub(r"(?:well|position)_?\d+", "well_N", cleaned)
    cleaned = re.sub(r"(?:ctrl|oil|capture|switch|mastermix)_?\d+", r"\g<0>_N", cleaned)
    cleaned = re.sub(r"\d+", "N", cleaned)
    cleaned = re.sub(r"_+", " ", cleaned).strip()
    if cleaned in {"", "unnamed"}:
        return "Unresolved/unnamed operation"
    return "Other: " + cleaned[:82]


def build_location_map(
    observation_id: str,
    barcode_mapping: pd.DataFrame,
) -> dict[str, dict[str, object]]:
    case = CASES[observation_id]
    result: dict[str, dict[str, object]] = {}
    for location, (status, order) in case["reaction_locations"].items():
        result[location] = {
            "path_status": status,
            "planned_order": order,
            "location_scope": "reaction_well",
        }

    selected = barcode_mapping[
        barcode_mapping["observation_id"].eq(observation_id)
        & barcode_mapping["material_type"].eq(case["material"])
        & ~barcode_mapping["is_control"].astype(bool)
    ].copy()
    for row in selected.itertuples(index=False):
        location = "barcode_" + str(row.barcode_plate_well).lower()
        result[location] = {
            "path_status": "failed" if bool(row.apparent_dropout) else "survivor",
            "planned_order": int(row.planned_order),
            "location_scope": "barcode_well",
        }
    return result


def map_case_operations(
    observation_id: str,
    scores: pd.DataFrame,
    barcode_mapping: pd.DataFrame,
) -> pd.DataFrame:
    run = scores[scores["observation_id"].eq(observation_id)].copy()
    run = run.sort_values("operation_index")
    locations = build_location_map(observation_id, barcode_mapping)

    assignments: dict[int, dict[str, object]] = {}
    for row in run.itertuples(index=False):
        metadata = locations.get(str(row.location))
        if metadata is None:
            continue
        assignments[int(row.operation_index)] = {
            **metadata,
            "mapping_scope": "direct_path_location",
        }

    # Add the paired source/destination phase only when it is an unambiguous,
    # adjacent operation with the same step, volume, liquid class, and pipette.
    direct_indices = list(assignments)
    indexed = run.set_index("operation_index", drop=False)
    for operation_index in direct_indices:
        row = indexed.loc[operation_index]
        if isinstance(row, pd.DataFrame):
            continue
        wanted = "aspirate" if row["operation"] == "dispense" else "dispense"
        if row["operation"] not in {"aspirate", "dispense"}:
            continue
        direction = -1 if wanted == "aspirate" else 1
        candidates = run[
            run["operation"].eq(wanted)
            & run["process_step"].eq(row["process_step"])
            & run["pipette"].eq(row["pipette"])
            & run["programmed_volume_ul"].eq(row["programmed_volume_ul"])
            & run["liquid_class_index"].eq(row["liquid_class_index"])
            & ((run["operation_index"] - operation_index) * direction > 0)
            & ((run["operation_index"] - operation_index).abs() <= 2)
        ]
        if len(candidates) != 1:
            continue
        paired_index = int(candidates.iloc[0]["operation_index"])
        proposed = {
            **assignments[operation_index],
            "mapping_scope": "paired_same_transfer",
        }
        if paired_index in assignments:
            existing = assignments[paired_index]
            if (
                existing["path_status"] != proposed["path_status"]
                or existing["planned_order"] != proposed["planned_order"]
            ):
                continue
        else:
            assignments[paired_index] = proposed

    rows = []
    for operation_index, metadata in assignments.items():
        row = indexed.loc[operation_index]
        if isinstance(row, pd.DataFrame):
            continue
        values = row.to_dict()
        values.update(metadata)
        rows.append(values)
    mapped = pd.DataFrame(rows).sort_values("operation_index")
    mapped["run_label"] = CASES[observation_id]["run_label"]
    mapped["material_scope"] = CASES[observation_id]["material"]
    mapped["family"] = mapped["process_step"].map(family_name)
    mapped["absolute_log_amplitude_ratio"] = np.abs(
        np.log(mapped["amplitude_ratio_to_reference"].clip(lower=1e-9))
    )

    # Split repeated generic operations into chronological batches. Within a
    # single 8-path pass, like-for-like operations are at most ~14 QPM indices
    # apart; a gap above 20 indicates a later workflow pass.
    key_columns = ["family", "operation", "programmed_volume_ul", "liquid_class_index"]
    batch = pd.Series(index=mapped.index, dtype="Int64")
    for _, group in mapped.groupby(key_columns, dropna=False, sort=False):
        ordered = group.sort_values("operation_index")
        numbers = ordered["operation_index"].diff().fillna(0).gt(20).cumsum() + 1
        batch.loc[ordered.index] = numbers.astype(int).values
    mapped["batch"] = batch.astype(int)
    mapped["group_id"] = (
        mapped["observation_id"].astype(str)
        + " | "
        + mapped["family"].astype(str)
        + " | "
        + mapped["operation"].astype(str)
        + " | "
        + mapped["programmed_volume_ul"].astype(str)
        + "uL | LC"
        + mapped["liquid_class_index"].astype(str)
        + " | batch"
        + mapped["batch"].astype(str)
    )
    return mapped


def exact_permutation_p(values: np.ndarray, failed: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    failed = np.asarray(failed, dtype=bool)
    n_failed = int(failed.sum())
    observed = float(values[failed].mean() - values[~failed].mean())
    indices = range(len(values))
    differences = []
    for chosen in combinations(indices, n_failed):
        mask = np.zeros(len(values), dtype=bool)
        mask[list(chosen)] = True
        differences.append(float(values[mask].mean() - values[~mask].mean()))
    differences_array = np.asarray(differences)
    return float(np.mean(np.abs(differences_array) >= abs(observed) - 1e-12))


def auc_score(failed_values: np.ndarray, survivor_values: np.ndarray) -> float:
    comparisons = []
    for failed in failed_values:
        for survivor in survivor_values:
            comparisons.append(1.0 if failed > survivor else 0.5 if failed == survivor else 0.0)
    return float(np.mean(comparisons))


def bh_adjust(values: pd.Series) -> pd.Series:
    result = pd.Series(np.nan, index=values.index, dtype=float)
    valid = values.dropna().sort_values()
    if valid.empty:
        return result
    n = len(valid)
    adjusted = valid.to_numpy() * n / np.arange(1, n + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    result.loc[valid.index] = np.minimum(adjusted, 1.0)
    return result


def summarize_groups(mapped: pd.DataFrame) -> pd.DataFrame:
    rows = []
    metric_columns = [
        "qpm_shape_score",
        "outside_90pct_envelope_fraction",
        "absolute_log_amplitude_ratio",
    ]
    for group_id, group in mapped.groupby("group_id", sort=False):
        group = group.drop_duplicates("operation_index").copy()
        failed_mask = group["path_status"].eq("failed").to_numpy()
        n_failed = int(failed_mask.sum())
        n_survivor = int((~failed_mask).sum())
        base = group.iloc[0]
        record: dict[str, object] = {
            "observation_id": base["observation_id"],
            "run_label": base["run_label"],
            "material_scope": base["material_scope"],
            "group_id": group_id,
            "family": base["family"],
            "operation": base["operation"],
            "programmed_volume_ul": base["programmed_volume_ul"],
            "liquid_class_index": base["liquid_class_index"],
            "batch": int(base["batch"]),
            "first_operation_index": int(group["operation_index"].min()),
            "last_operation_index": int(group["operation_index"].max()),
            "first_event_time": group["event_time"].min(),
            "last_event_time": group["event_time"].max(),
            "n_failed": n_failed,
            "n_survivor": n_survivor,
            "reference_n_min": int(group["reference_physical_runs"].min()),
            "mapping_scopes": ";".join(sorted(group["mapping_scope"].unique())),
        }
        case = CASES[str(base["observation_id"])]
        if (
            str(base["observation_id"]) == RUN1
            and str(base["family"]) == "Reaction-well mixing"
            and int(group["operation_index"].min()) == 234
        ):
            relationship = "same_UDG_cycle_after_B_C"
        elif (
            str(base["observation_id"]) == RUN2
            and str(base["family"]) in {
                "Adapter-ligation barcode-well recovery aspiration",
                "Adapter-ligation return dispense to reaction well",
            }
        ):
            relationship = "same_adapter_cycle_after_E_F"
        elif group["operation_index"].max() < case["anchor_start"]:
            relationship = "upstream_of_displayed_anchor"
        elif group["operation_index"].min() > case["anchor_end"]:
            if str(base["observation_id"]) == RUN2 and group["operation_index"].min() <= 721:
                relationship = "downstream_same_adapter_cycle"
            else:
                relationship = "downstream_persistence"
        else:
            relationship = "overlaps_displayed_anchor_interval"
        record["temporal_relationship"] = relationship

        for metric in metric_columns:
            record[f"failed_median_{metric}"] = (
                float(group.loc[failed_mask, metric].median()) if n_failed else np.nan
            )
            record[f"survivor_median_{metric}"] = (
                float(group.loc[~failed_mask, metric].median()) if n_survivor else np.nan
            )

        already = (str(base["family"]), str(base["operation"])) in case["already_shown"]
        record["already_displayed"] = already
        if n_failed < 4 or n_survivor < 4:
            record.update(
                {
                    "eligible_same_operation_comparison": False,
                    "deviation_auc": np.nan,
                    "exact_permutation_p": np.nan,
                    "composite_effect": np.nan,
                    "metrics_more_deviant_in_failed": np.nan,
                    "alignment_label": "insufficient_same_operation_paths",
                }
            )
            rows.append(record)
            continue

        ranked = group[metric_columns].rank(method="average", pct=True)
        group["composite_deviation"] = ranked.mean(axis=1)
        failed_values = group.loc[failed_mask, "composite_deviation"].to_numpy()
        survivor_values = group.loc[~failed_mask, "composite_deviation"].to_numpy()
        auc = auc_score(failed_values, survivor_values)
        p_value = exact_permutation_p(
            group["composite_deviation"].to_numpy(), failed_mask
        )
        effect = float(np.median(failed_values) - np.median(survivor_values))
        directions = sum(
            record[f"failed_median_{metric}"] > record[f"survivor_median_{metric}"]
            for metric in metric_columns
        )
        if already:
            label = "already_displayed"
        elif auc >= 0.875 and p_value <= 0.06 and directions >= 2:
            label = "strong_additional_alignment"
        elif auc >= 0.75 and p_value <= 0.12 and directions >= 2:
            label = "moderate_additional_alignment"
        elif auc >= 0.65 and effect > 0 and directions >= 2:
            label = "weak_or_mixed_alignment"
        else:
            label = "not_dropout_selective"
        record.update(
            {
                "eligible_same_operation_comparison": True,
                "deviation_auc": auc,
                "exact_permutation_p": p_value,
                "composite_effect": effect,
                "metrics_more_deviant_in_failed": int(directions),
                "alignment_label": label,
            }
        )
        rows.append(record)

    summary = pd.DataFrame(rows)
    eligible = summary["eligible_same_operation_comparison"].astype(bool)
    summary.loc[eligible, "bh_fdr_q"] = (
        summary.loc[eligible]
        .groupby("observation_id", group_keys=False)["exact_permutation_p"]
        .apply(bh_adjust)
    )
    summary["step_label"] = (
        summary["family"]
        + " — "
        + summary["operation"].str.capitalize()
        + " ("
        + summary["programmed_volume_ul"].map(lambda value: f"{value:g} µL")
        + ")"
    )
    return summary.sort_values(
        ["observation_id", "first_operation_index", "family", "operation"]
    ).reset_index(drop=True)


def short_label(row: pd.Series) -> str:
    family = str(row["family"])
    contextual_labels = {
        (RUN1, 234): "Post-UDG reaction-well mix",
        (RUN1, 412): "Post-DNA-AT reaction-well mix",
        (RUN1, 564): "Partial-digestion reaction-well mix",
        (RUN1, 844): "Post-ligation-mastermix reaction-well mix",
        (RUN2, 340): "Post-RNA-AT reaction-well mix",
        (RUN2, 492): "Partial-digestion reaction-well mix",
        (RUN2, 772): "Post-ligation-mastermix reaction-well mix",
    }
    context_key = (str(row["observation_id"]), int(row["first_operation_index"]))
    if context_key in contextual_labels:
        family = contextual_labels[context_key]
    replacements = {
        "DNA target-amplification mastermix transfer": "DNA AT mastermix",
        "RNA target-amplification mastermix transfer": "RNA AT mastermix",
        "Adapter-ligation barcode-well recovery aspiration": "Barcode recovery aspiration",
        "Adapter-ligation return dispense to reaction well": "Return dispense to reaction well",
        "Adapter-ligation reaction-well aspiration": "Adapter source aspiration",
        "Adapter-ligation barcode-well dispense": "Barcode-well dispense",
        "AMPure cleanup transfer out of reaction well": "AMPure transfer out",
        "AMPure eluted-library return to reaction well": "AMPure return",
        "Partial-digestion reagent transfer": "Partial digestion",
        "Reaction-well mixing": "Reaction-well mixing",
        "Equalizer-capture addition": "Equalizer capture",
        "Equalizer pooling aspiration": "Equalizer pooling",
    }
    family = replacements.get(family, family.replace("Other: ", ""))
    return f"{family} · {str(row['operation'])[:3]} · {row['programmed_volume_ul']:g} µL"


def style_axis(ax: plt.Axes) -> None:
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color=COLORS["grid"], lw=0.5, alpha=0.75)
    ax.tick_params(length=2.6, width=0.6)


def plot_scan_summary(ax: plt.Axes, rows: pd.DataFrame, case: dict[str, object]) -> None:
    eligible = rows[
        rows["eligible_same_operation_comparison"].astype(bool)
        & ~rows["already_displayed"].astype(bool)
    ].copy()
    eligible = eligible.sort_values(
        ["first_operation_index", "deviation_auc"], ascending=[True, False]
    )
    if len(eligible) > 11:
        positive = eligible[eligible["alignment_label"].isin(
            ["strong_additional_alignment", "moderate_additional_alignment"]
        )]
        context = eligible.drop(positive.index).sort_values(
            "deviation_auc", ascending=False
        ).head(max(0, 11 - len(positive)))
        eligible = pd.concat([positive, context]).drop_duplicates().sort_values(
            "first_operation_index"
        ).tail(11)
    y = np.arange(len(eligible))
    color_map = {
        "strong_additional_alignment": COLORS["coral"],
        "moderate_additional_alignment": COLORS["orange"],
        "weak_or_mixed_alignment": COLORS["gold"],
        "not_dropout_selective": COLORS["gray"],
    }
    colors = eligible["alignment_label"].map(color_map).fillna(COLORS["gray"])
    ax.scatter(eligible["deviation_auc"], y, c=colors, s=34, edgecolor="white", lw=0.5, zorder=3)
    for yi, (_, row) in zip(y, eligible.iterrows()):
        ax.plot([0.5, row["deviation_auc"]], [yi, yi], color=COLORS["grid"], lw=0.8, zorder=1)
    ax.axvline(0.5, color=COLORS["ink"], lw=0.8, ls="--")
    ax.axvline(0.75, color=COLORS["gold"], lw=0.8, ls=":")
    ax.set_xlim(0.35, 1.03)
    ax.set_xticks([0.5, 0.75, 1.0])
    ax.set_xlabel("Failed-path deviation AUC")
    ax.set_yticks(y)
    ax.set_yticklabels([short_label(row) for _, row in eligible.iterrows()], fontsize=5.6)
    ax.invert_yaxis()
    ax.set_title(
        f"{case['run_label']} scan · {case['outcome']}",
        loc="left",
        fontsize=7.8,
        fontweight="bold",
        color=COLORS["ink"],
    )
    style_axis(ax)


def plot_residual_waveforms(
    ax: plt.Axes,
    operations: pd.DataFrame,
    row: pd.Series,
    case: dict[str, object],
) -> None:
    group = operations[operations["group_id"].eq(row["group_id"])].drop_duplicates(
        "operation_index"
    )
    residuals: dict[str, list[np.ndarray]] = {"failed": [], "survivor": []}
    for operation in group.itertuples(index=False):
        observed = parse_profile(operation.observed_profile)
        reference = parse_profile(operation.reference_median_profile)
        residual = observed - reference
        status = str(operation.path_status)
        residuals[status].append(residual)
        color = COLORS["coral"] if status == "failed" else COLORS["teal"]
        ax.plot(
            np.linspace(0, 100, len(residual)),
            residual,
            color=color,
            lw=0.9,
            alpha=0.43,
            zorder=2,
        )
    for status, curves in residuals.items():
        if not curves:
            continue
        median = np.nanmedian(np.vstack(curves), axis=0)
        color = COLORS["coral"] if status == "failed" else COLORS["teal"]
        ax.plot(
            np.linspace(0, 100, len(median)),
            median,
            color=color,
            lw=2.0,
            alpha=0.98,
            zorder=4,
        )
    ax.axhline(0, color=COLORS["ink"], lw=0.9, ls="--", zorder=1)
    ax.set_xlim(0, 100)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_xlabel("Normalized operation progress (%)")
    ax.set_ylabel("Observed − matched reference\n(raw sensor counts)")
    relationship = str(row["temporal_relationship"]).replace("_", " ")
    ax.set_title(
        short_label(row) + "\n" + relationship,
        loc="left",
        fontsize=7.1,
        fontweight="bold",
        color=COLORS["ink"],
    )
    q_value = row["bh_fdr_q"]
    q_text = "NA" if pd.isna(q_value) else f"{q_value:.3f}"
    ax.text(
        0.02,
        0.035,
        f"AUC {row['deviation_auc']:.2f} · exact p {row['exact_permutation_p']:.3f} · BH q {q_text}\n"
        f"failed/survivor n={int(row['n_failed'])}/{int(row['n_survivor'])} · refs ≥{int(row['reference_n_min'])}",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=5.2,
        color=COLORS["ink"],
        bbox={"boxstyle": "round,pad=0.24", "fc": "white", "ec": COLORS["grid"], "alpha": 0.92},
        zorder=10,
    )
    style_axis(ax)


def select_waveforms(summary: pd.DataFrame, observation_id: str, n: int = 3) -> pd.DataFrame:
    # Pre-specified presentation panels. This avoids selecting whichever
    # waveform happens to have the largest score in the same data used for the
    # audit, and gives one localization panel plus later persistence panels.
    preferred = {
        RUN1: [
            (234, "Reaction-well mixing", "aspirate", 40.0),
            (410, "DNA target-amplification mastermix transfer", "aspirate", 21.0),
            (1082, "AMPure cleanup transfer out of reaction well", "aspirate", 71.0),
        ],
        RUN2: [
            (492, "Reaction-well mixing", "aspirate", 40.0),
            (657, "Adapter-ligation barcode-well recovery aspiration", "aspirate", 25.0),
            (1022, "AMPure cleanup transfer out of reaction well", "aspirate", 71.0),
        ],
    }
    chosen_indices: list[int] = []
    for first_index, family, operation, volume in preferred[observation_id]:
        match = summary[
            summary["observation_id"].eq(observation_id)
            & summary["first_operation_index"].eq(first_index)
            & summary["family"].eq(family)
            & summary["operation"].eq(operation)
            & np.isclose(summary["programmed_volume_ul"], volume)
        ]
        if not match.empty:
            chosen_indices.append(int(match.index[0]))
    if len(chosen_indices) == n:
        return summary.loc[chosen_indices].sort_values("first_operation_index")

    candidates = summary[
        summary["observation_id"].eq(observation_id)
        & summary["alignment_label"].isin(
            ["strong_additional_alignment", "moderate_additional_alignment"]
        )
        & ~summary["already_displayed"].astype(bool)
    ].copy()
    if candidates.empty:
        candidates = summary[
            summary["observation_id"].eq(observation_id)
            & summary["alignment_label"].eq("weak_or_mixed_alignment")
            & ~summary["already_displayed"].astype(bool)
        ].copy()
    candidates = candidates.sort_values(
        ["deviation_auc", "exact_permutation_p", "metrics_more_deviant_in_failed"],
        ascending=[False, True, False],
    )

    # Prefer distinct workflow families before showing both phases of one step.
    selected = []
    used_families: set[str] = set()
    for index, row in candidates.iterrows():
        if row["family"] in used_families:
            continue
        selected.append(index)
        used_families.add(str(row["family"]))
        if len(selected) == n:
            break
    if len(selected) < n:
        for index in candidates.index:
            if index not in selected:
                selected.append(index)
            if len(selected) == n:
                break
    return summary.loc[selected].sort_values("first_operation_index")


def make_figure(
    summary: pd.DataFrame,
    mapped: pd.DataFrame,
) -> tuple[Path, Path, pd.DataFrame]:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 6.2,
            "axes.labelsize": 5.9,
            "xtick.labelsize": 5.2,
            "ytick.labelsize": 5.2,
            "axes.linewidth": 0.65,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig = plt.figure(figsize=(18.0, 10.2), facecolor=COLORS["paper"])
    grid = fig.add_gridspec(
        2,
        4,
        left=0.155,
        right=0.985,
        bottom=0.145,
        top=0.855,
        width_ratios=[1.22, 1.0, 1.0, 1.0],
        hspace=0.58,
        wspace=0.30,
    )
    axes = np.empty((2, 4), dtype=object)
    selected_frames = []
    for row_index, observation_id in enumerate([RUN1, RUN2]):
        case = CASES[observation_id]
        axes[row_index, 0] = fig.add_subplot(grid[row_index, 0])
        run_summary = summary[summary["observation_id"].eq(observation_id)]
        plot_scan_summary(axes[row_index, 0], run_summary, case)
        chosen = select_waveforms(summary, observation_id, n=3)
        selected_frames.append(chosen)
        for column in range(1, 4):
            axes[row_index, column] = fig.add_subplot(grid[row_index, column])
            if column - 1 >= len(chosen):
                axes[row_index, column].axis("off")
                continue
            selected_row = chosen.iloc[column - 1]
            plot_residual_waveforms(
                axes[row_index, column], mapped, selected_row, case
            )

    for label, ax in zip("ABCDEFGH", axes.ravel()):
        if not ax.axison:
            continue
        ax.text(
            -0.10,
            1.12,
            label,
            transform=ax.transAxes,
            fontsize=8.2,
            fontweight="bold",
            va="top",
            color=COLORS["ink"],
            clip_on=False,
        )

    fig.suptitle(
        "Path-aligned QPM signatures beyond the originally displayed transfers",
        x=0.5,
        y=0.982,
        fontsize=15.0,
        fontweight="bold",
        color=COLORS["ink"],
    )
    fig.text(
        0.5,
        0.947,
        "Failed and surviving barcode paths were compared at the same operation, volume, liquid class, and temporal batch; original B/C and E/F operations were excluded from selection.",
        ha="center",
        va="top",
        fontsize=7.8,
        color=COLORS["ink"],
    )
    fig.legend(
        handles=[
            Line2D([0], [0], color=COLORS["coral"], lw=2.0, label="failed-path median"),
            Line2D([0], [0], color=COLORS["coral"], lw=0.9, alpha=0.43, label="individual failed path"),
            Line2D([0], [0], color=COLORS["teal"], lw=2.0, label="surviving-path median"),
            Line2D([0], [0], color=COLORS["teal"], lw=0.9, alpha=0.43, label="individual surviving path"),
            Line2D([0], [0], color=COLORS["ink"], lw=0.9, ls="--", label="matched-reference residual = 0"),
            Line2D([0], [0], marker="o", color="none", markerfacecolor=COLORS["coral"], label="screen-positive alignment"),
            Line2D([0], [0], marker="o", color="none", markerfacecolor=COLORS["orange"], label="borderline alignment"),
            Line2D([0], [0], marker="o", color="none", markerfacecolor=COLORS["gray"], label="not selective"),
        ],
        loc="lower center",
        bbox_to_anchor=(0.5, 0.079),
        ncol=8,
        frameon=False,
        fontsize=6.1,
        columnspacing=1.25,
        handlelength=2.0,
    )
    fig.text(
        0.5,
        0.035,
        "Interpretation: Run 1 has no earlier selective QPM divergence than B/C; its other panels are immediate confirmation or later persistence. "
        "Run 2 partial-digestion mixing is earlier than E/F; recovery and AMPure panels are later.\n"
        "No added step passes 5% scan-wide FDR in the non-control 4-v-4 audit; these are diagnostic hypotheses, not causal proof.",
        ha="center",
        va="bottom",
        fontsize=6.2,
        color=COLORS["ink"],
        bbox={"boxstyle": "round,pad=0.42", "fc": COLORS["pale_teal"], "ec": COLORS["teal"], "lw": 0.7},
    )
    png = OUT / "additional_dropout_aligned_step_waveforms.png"
    pdf = OUT / "additional_dropout_aligned_step_waveforms.pdf"
    fig.savefig(png, dpi=300, facecolor=COLORS["paper"])
    fig.savefig(pdf, dpi=300, facecolor=COLORS["paper"])
    plt.close(fig)
    selected = pd.concat(selected_frames, ignore_index=True)
    return png, pdf, selected


def main() -> None:
    scores = pd.read_csv(SCORES)
    barcode_mapping = pd.read_csv(BARCODE_MAP)
    mapped = pd.concat(
        [
            map_case_operations(observation_id, scores, barcode_mapping)
            for observation_id in [RUN1, RUN2]
        ],
        ignore_index=True,
    )
    summary = summarize_groups(mapped)
    summary_path = OUT / "additional_dropout_step_scan.csv"
    operations_path = OUT / "additional_dropout_step_mapped_operations.csv"
    summary.to_csv(summary_path, index=False)
    mapped.to_csv(operations_path, index=False)
    png, pdf, selected = make_figure(summary, mapped)
    selected_path = OUT / "additional_dropout_waveform_selection.csv"
    selected.to_csv(selected_path, index=False)
    print(f"Wrote {summary_path}")
    print(f"Wrote {operations_path}")
    print(f"Wrote {selected_path}")
    print(f"Wrote {png}")
    print(f"Wrote {pdf}")


if __name__ == "__main__":
    main()
