<!-- Historical internal study documentation; current entry point is the repository README. -->

# All-operation QPM nominal-volume models

This update expands the old capped PIP2/class-49/55/61 study to every trainable
full-definition/channel/operation/source-unit group in the CSA collection behind
the reference bank. It uses the stored 32-point operation profiles, not a new
full-rate extraction. All trainable events are retained, with physical-run and
within-run nominal-level weighting. Exact repeated export events are removed.

**These models recognize programmed-volume signatures. There are no independent
measured-delivery labels. A nominal-equivalent difference is not an actual
over/under-aspiration or dispense amount and must not establish a root cause.**

## Frozen study and activation

Study: `<WORKSPACE>/genexus_csa_project/qpm_volume_all_operations_20261027_v2`

Source bank: `<WORKSPACE>/reference_banks/20261027_gx7_gx8_qualified`

New bank: `<WORKSPACE>/reference_banks/20261027_all_qpm_volume`

Activation is explicit and only follows independent study validation, software
regressions, and four manual-case replays. The source bank and old studies are
preserved; the reference populations and chip/lane cutoffs do not change.

## Reproduce in a NEW output directory

Use `python` with
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1`. Run the following entry points in order:

1. `prepare_all_qpm_volumes.py --bank SOURCE_BANK --output NEW_STUDY`
2. `train_all_qpm_volumes.py --study NEW_STUDY --workers 8`
3. `validate_all_qpm_volumes.py --study NEW_STUDY`
4. `report_all_qpm_volumes.py --study NEW_STUDY`
5. `release_all_qpm_volume.py --source SOURCE_BANK --output NEW_BANK --study NEW_STUDY`
6. `refresh_expanded_bank_reports.py --bank NEW_BANK --output NEW_REPORTS --workers 4`
7. Audit the replay and software release, then call the existing explicit bank
   activation function. Do not activate an unvalidated or modified snapshot.

The training source is hash-pinned. Fold checkpoints are reused only when the
code hash, dataset hash and prediction-file hash agree. Do not edit the training
source during a run. Avoid changing a sealed study; use a new output directory.

## Model evaluation

- Ridge, Elastic Net and constrained Extra Trees; training-median and
  geometry/stage-only median controls.
- Physical-run outer folds, all feasible held-out instruments, and strict
  acquisition-time chronological testing.
- Two-fold physical-run inner model-family selection; preprocessing stays
  inside training folds. The final model family is also chosen by grouped CV.
- Every task metric gives each physical run equal weight. Overall summaries
  are task macro averages, not millions of independent observations.
- Continuous-volume MAE/RMSE/MAPE and agreement within 5%/10% of nominal.
  Nearest-volume-level accuracy is derived from continuous predictions and
  training-fold levels, not a separately trained classifier.
- Bootstrap uncertainty resamples physical-run fixed held-out errors, not the
  complete model selection/fitting process. It is not a prediction interval.

## Plugin inference

The new registry is recognized automatically by `qpm_nominal_volume_inference.py`.
It dispatches to `qpm_all_volume_inference.py`; older validated registries retain
their old scoped inference behavior.

The plugin attempts every quality-cleared target operation from raw profile
samples, never the normalized cross-instrument comparison curve. It requires:

- Matching full liquid-class definition, pipette, operation and exact source
  unit identity. Numeric LC IDs are not enough.
- Verified command association and complete geometry/command settings.
- At least eight training physical runs at the exact nominal-volume/context.
- Positive paired median-baseline gain lower bounds in all three validation
  schemes. This does not certify superiority to a context-only explanation.
- A target physical run absent from final-model training.
- A prediction within the trained observed nominal range.

Er72, insufficient validation, unsupported context, training overlap and missing
data produce explicit abstention reasons. In-training runs are not graded by
their final-fit model; consult the study's held-out predictions instead.

Historical evidence panels show command, nominal-equivalent estimate, signed
nominal-signature delta and task-level unseen-instrument MAE when supported.
Same-run panels show path-group medians; they do not pretend one operation's
volume estimate is the group's measurement. Every individual operation and
abstention reason is in `qpm_volume_proxies.csv`.

The baseline comparison, barcode outcome calls, earliest-step chronology and
non-causal interpretation remain separate from nominal-volume recognition.

## A newly supplied CSA

The existing ingestion entry point resolves the active bank:

```
python run_manual_csa_plugin.py \
  --input-dir NEW_CSA_DIRECTORY --out NEW_RESULT_DIRECTORY --stage all \
  --baseline <WORKSPACE>/genexus_csa_project
```

Use a fresh result directory and never add target archives to model training
before evaluating them. No remote instrument writes or setting changes occur.
