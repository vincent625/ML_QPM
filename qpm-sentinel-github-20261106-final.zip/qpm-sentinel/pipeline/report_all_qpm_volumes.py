#!/usr/bin/env python3
"""Presentation and full audit views of the all-operation volume experiment."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import html
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd

from validate_all_qpm_volumes import sha

COLORS = dict(ink="#264653",teal="#218c80",gold="#d8b25c",coral="#df7356",blue="#477f9d",plum="#8d628d",gray="#8c9690",paper="#f7f9f3")
MODEL_ORDER = ["Median baseline","Context-only median","Ridge","Elastic Net","Extra Trees","Nested-selected procedure"]
SCHEMES = ["grouped_run","unseen_instrument","chronological"]
SCHEME_NAMES = dict(grouped_run="Unseen physical runs",unseen_instrument="Unseen instruments",chronological="Newer runs")


def short_task(row):
    aliases=json.loads(row.liquid_class_indices) if isinstance(row.liquid_class_indices,str) else row.liquid_class_indices
    return "LC"+"/".join(str(v) for v in aliases)+" · "+row.pipette+" · "+("ASP" if row.operation=="aspirate" else "DSP")


def table(frame):
    return frame.to_html(index=False,border=0,float_format=lambda v:f"{v:,.3f}",escape=True)


def collapse_run_errors(sums):
    """One vote per physical run over its full operation mix, across tasks."""
    pooled=sums.groupby(["scheme","model","physical_run_id"],sort=False).sum(numeric_only=True).reset_index()
    rows=[]
    for (scheme,model),group in pooled.groupby(["scheme","model"],sort=False):
        mean=lambda key:float((group[key]/group.waveforms).mean())
        rows.append(dict(scheme=scheme,model=model,test_waveforms=int(group.waveforms.sum()),test_physical_runs=len(group),
            mae_ul=mean("absolute_error"),rmse_ul=np.sqrt(mean("squared_error")),mape_pct=100*mean("relative_error"),
            within_5pct=mean("inside_5pct"),within_10pct=mean("inside_10pct"),nominal_level_accuracy=mean("correct_level")))
    return pd.DataFrame(rows)


def pooled_run_metrics(root,seal_hash):
    output=root/"all_operations_run_balanced_performance.csv"
    receipt=root/"pooled_metrics_provenance.json"
    if output.exists() and receipt.exists():
        cached=json.loads(receipt.read_text())
        if cached["artifact_validation_sha256"]==seal_hash and cached["csv_sha256"]==sha(output):
            return pd.read_csv(output)
        raise ValueError("Pooled metric cache differs from validated study")
    parts=[]
    paths=sorted((root/"tasks").glob("*/predictions_*.parquet"))
    for i,path in enumerate(paths):
        data=pd.read_parquet(path,columns=["physical_run_id","model","scheme","programmed_volume_ul","predicted_volume_ul","nearest_training_level_ul"])
        error=np.abs(data.predicted_volume_ul.to_numpy()-data.programmed_volume_ul.to_numpy())
        y=data.programmed_volume_ul.to_numpy()
        local=data[["physical_run_id","model","scheme"]].copy()
        local["waveforms"]=1
        local["absolute_error"],local["squared_error"],local["relative_error"]=error,error**2,error/y
        local["inside_5pct"],local["inside_10pct"]=error<=.05*y,error<=.1*y
        local["correct_level"]=np.isclose(y,data.nearest_training_level_ul.to_numpy(),atol=1e-6,rtol=0)
        parts.append(local.groupby(["scheme","model","physical_run_id"],sort=False).sum().reset_index())
        if (i+1)%400==0:print(f"Pooled metrics: {i+1}/{len(paths)} prediction files",flush=True)
    result=collapse_run_errors(pd.concat(parts,ignore_index=True))
    expected=pd.read_csv(root/"model_performance.csv").groupby(["scheme","model"]).test_waveforms.sum()
    assert all(row.test_waveforms==expected.loc[(row.scheme,row.model)] for row in result.itertuples())
    result.to_csv(output,index=False)
    receipt.write_text(json.dumps(dict(artifact_validation_sha256=seal_hash,csv_sha256=sha(output),prediction_files=len(paths),
        weighting="each physical run one vote over its held-out operation mix across the separately modeled tasks"),indent=2))
    return result


def render(root):
    seal=json.loads((root/"artifact_validation.json").read_text())
    assert seal["status"]=="passed"
    assert seal["artifact_sha256"]["analysis_run_log.json"]==sha(root/"analysis_run_log.json")
    log=json.loads((root/"analysis_run_log.json").read_text())
    prep=log["input_audit"]
    membership=pd.read_parquet(root/"training_run_membership.parquet")
    training_runs=membership.physical_run_id.nunique()
    source_manifest=json.loads((Path(prep['source_bank'])/'reference_bank_manifest.json').read_text())
    performance=pd.read_csv(root/"model_performance.csv")
    tasks=pd.read_csv(root/"all_task_coverage.csv")
    tasks["label"]=tasks.apply(short_task,axis=1)
    task_lookup=tasks.set_index("task_id")
    qualified={row["task_id"] for row in log["models"] if row["deployment_eligible"]}
    metrics=["mae_ul","mape_pct","within_5pct","within_10pct","nominal_level_accuracy","nominal_level_balanced_accuracy","mae_improvement_over_baseline_pct"]
    aggregate=performance.groupby(["scheme","model"],sort=False).agg(**{key:(key,"mean") for key in metrics},tasks=("task_id","nunique")).reset_index()
    aggregate.to_csv(root/"model_comparison_task_macro.csv",index=False)
    pooled=pooled_run_metrics(root,sha(root/"artifact_validation.json"))
    # Task macro averages give every definition/channel/direction one vote;
    # individual reported task metrics already give physical runs equal votes.
    selected=performance[performance.model.eq("Nested-selected procedure")].copy()
    selected=selected.merge(tasks[["task_id","label","waveforms","physical_runs","instruments","observed_volume_levels"]],on="task_id",validate="many_to_one")
    selected["plugin_deployment_eligible"]=selected.task_id.isin(qualified)
    selected.to_csv(root/"selected_procedure_all_tasks.csv",index=False)
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"text.color":COLORS["ink"],"axes.labelcolor":COLORS["ink"],
        "axes.titlecolor":COLORS["ink"],"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42,"ps.fonttype":42,"svg.fonttype":"none"})
    fig,axes=plt.subplots(2,2,figsize=(15,10),layout="constrained")
    fig.set_facecolor(COLORS["paper"])
    fig.suptitle("QPM waveform → programmed-volume signature\nAll audited operations · independent-run validation · not measured delivery",fontsize=20,fontweight="bold")
    ax=axes[0,0]
    train=tasks[tasks.trainable].groupby(["pipette","operation"]).waveforms.sum()
    bars=ax.barh([f"{p} {o.upper()}" for p,o in train.index],train.to_numpy()/1000,color=[COLORS["blue"],COLORS["teal"],COLORS["plum"],COLORS["gold"]])
    for bar,n in zip(bars,train):ax.text(bar.get_width()+2,bar.get_y()+bar.get_height()/2,f"{n:,}",va="center",fontsize=10)
    ax.set(title=f"A  All {prep['trainable_waveforms']:,} trainable waveforms used",xlabel="Unique operation waveforms (thousands)",xlim=(0,train.max()/1000*1.22))
    ax.text(0,-.25,f"{prep['trainable_tasks']} model tasks · {training_runs:,} training physical runs · {prep['instruments']} instruments\n{prep['untrainable_waveforms']:,} audited waveforms not trainable; no events capped",transform=ax.transAxes,fontsize=9)
    ax=axes[0,1]
    external=aggregate[aggregate.scheme.eq("unseen_instrument")].set_index("model").reindex(MODEL_ORDER)
    operation_mix=pooled[pooled.scheme.eq("unseen_instrument")].set_index("model").reindex(MODEL_ORDER)
    names=["Median","Context only","Ridge","Elastic Net","Extra Trees","Nested choice"]
    positions=np.arange(len(names))
    bars=ax.barh(positions-.18,100*operation_mix.within_10pct,height=.34,color=COLORS['teal'],label='Full operation mix · one vote/run')
    bars2=ax.barh(positions+.18,100*external.within_10pct,height=.34,color=COLORS['plum'],label='Task macro · one vote/task')
    for group,values in [(bars,100*operation_mix.within_10pct),(bars2,100*external.within_10pct)]:
        for bar,value in zip(group,values):ax.text(value+.8,bar.get_y()+bar.get_height()/2,f"{value:.1f}",va="center",fontsize=8)
    ax.set(yticks=positions,yticklabels=names,title="B  Predictions within ±10% of nominal volume",xlabel="Unseen-instrument agreement (%)",xlim=(0,105))
    ax.invert_yaxis()
    ax.set_ylim(len(names)-.5,-1.45)
    ax.legend(fontsize=8,loc='upper right')
    ax.text(0,-.22,"Tolerance agreement, not independently measured-volume accuracy.\nNested choice selects the model inside each outer training fold.",transform=ax.transAxes,fontsize=9)
    ax=axes[1,0]
    # Representative core classes, largest full-definition cohort per direction.
    core=[]
    for lc in [49,55,61]:
        for op in ["aspirate","dispense"]:
            mask=tasks.liquid_class_indices.map(lambda text:lc in json.loads(text)) & tasks.pipette.eq("PIP2") & tasks.operation.eq(op) & tasks.trainable
            subset=tasks[mask].sort_values("waveforms",ascending=False)
            if len(subset):core.append(subset.iloc[0].task_id)
    core=list(dict.fromkeys(core))
    heat=performance[performance.scheme.eq("unseen_instrument")&performance.task_id.isin(core)&performance.model.isin(["Ridge","Elastic Net","Extra Trees"])]
    matrix=heat.pivot(index="task_id",columns="model",values="mae_ul").reindex(index=core,columns=["Ridge","Elastic Net","Extra Trees"])
    cmap=LinearSegmentedColormap.from_list("sage",["#edf5e4",COLORS["gold"],COLORS["teal"]])
    image=ax.imshow(np.log1p(matrix.to_numpy()),cmap=cmap,aspect="auto")
    ax.set(xticks=np.arange(3),xticklabels=matrix.columns,yticks=np.arange(len(core)),yticklabels=[task_lookup.loc[t].label for t in core],title="C  Core-class unseen-instrument MAE (µL)")
    for i in range(len(core)):
        for j in range(3):ax.text(j,i,f"{matrix.iloc[i,j]:.1f}",ha="center",va="center",color=COLORS["ink"],bbox=dict(facecolor="white",alpha=.75,edgecolor="none",pad=1))
    ax.text(0,-.18,"Largest full-definition cohort per PIP2 class/direction.\nDifferent volume ranges: compare models within rows, not across rows.",transform=ax.transAxes,fontsize=9)
    ax=axes[1,1]
    pivot=selected.pivot(index="task_id",columns="scheme",values="within_10pct")
    valid=pivot.dropna(subset=["grouped_run","unseen_instrument"])
    deploy=valid.index.isin(qualified)
    ax.scatter(100*valid.grouped_run[~deploy],100*valid.unseen_instrument[~deploy],s=45,marker="x",color=COLORS["coral"],label="Not deployment-qualified",alpha=.8)
    ax.scatter(100*valid.grouped_run[deploy],100*valid.unseen_instrument[deploy],s=45,color=COLORS["teal"],label="Passes three validation gates",alpha=.8)
    ax.plot([0,100],[0,100],ls="--",lw=1,color=COLORS["gray"])
    ax.set(xlim=(-3,103),ylim=(-3,103),xlabel="Unseen-run agreement within ±10% (%)",ylabel="Unseen-instrument agreement within ±10% (%)",title=f"D  Generalization varies by task · {len(qualified)}/{len(log['models'])} qualify")
    ax.legend(fontsize=8,loc="upper left")
    fig.savefig(root/"qpm_all_volume_summary.png",dpi=220,facecolor=fig.get_facecolor())
    fig.savefig(root/"qpm_all_volume_summary.pdf",facecolor=fig.get_facecolor())
    plt.close(fig)
    # Held-out response plots for every task. Point reduction is DISPLAY ONLY;
    # every prediction was included in the metrics and every trainable event fit.
    with PdfPages(root/"all_task_heldout_response_plots.pdf") as pdf:
        for task in tasks.loc[tasks.trainable].sort_values("waveforms",ascending=False).task_id:
            folder=root/"tasks"/task
            paths=sorted(folder.glob("predictions_unseen_instrument_*.parquet"))
            if not paths:continue
            parts=[pd.read_parquet(p,filters=[("model","=","Nested-selected procedure")],columns=["physical_run_id","programmed_volume_ul","predicted_volume_ul"]) for p in paths]
            data=pd.concat(parts,ignore_index=True)
            display=data.sample(n=min(4000,len(data)),random_state=log["random_seed"])
            f,axs=plt.subplots(1,2,figsize=(11,4.6),layout="constrained")
            title=task_lookup.loc[task].label
            f.suptitle(title+" · unseen-instrument predictions",fontweight="bold")
            axs[0].scatter(display.programmed_volume_ul,display.predicted_volume_ul,s=4,alpha=.25,color=COLORS["teal"])
            lo,hi=data.programmed_volume_ul.min(),data.programmed_volume_ul.max()
            axs[0].plot([lo,hi],[lo,hi],ls="--",color=COLORS["ink"],lw=1)
            axs[0].set(xlabel="Programmed nominal volume (µL)",ylabel="Predicted nominal-volume signature (µL)")
            axs[1].scatter(display.programmed_volume_ul,display.predicted_volume_ul-display.programmed_volume_ul,s=4,alpha=.25,color=COLORS["plum"])
            axs[1].axhline(0,ls="--",color=COLORS["ink"],lw=1)
            axs[1].set(xlabel="Programmed nominal volume (µL)",ylabel="Prediction minus nominal volume (µL)")
            f.supxlabel(f"Metrics use all {len(data):,} held-out events; at most 4,000 points displayed. No measured delivery labels.",fontsize=9)
            pdf.savefig(f);plt.close(f)
    core_results=performance[performance.scheme.eq("unseen_instrument")&performance.task_id.isin(core)].merge(tasks[["task_id","label","observed_volume_levels"]],on="task_id")
    core_results.to_csv(root/"core_class_model_comparison.csv",index=False)
    counts=pd.DataFrame([dict(stage="Source collection archives",count=source_manifest["source_archives"]),dict(stage="Primary run/lane CSA observations in bank",count=source_manifest["observations"]),
        dict(stage="Retained audited QPM source archives",count=len(prep["archive_hashes"])),dict(stage="Unique physical runs contributing trainable waveforms",count=training_runs),
        dict(stage="Source operations",count=prep["total_operations"]),dict(stage="Positive-volume QPM present",count=prep["qpm_available_positive_volume_operations"]),
        dict(stage="Er72 operations excluded",count=prep["er72_operations_excluded"]),dict(stage="Verified physical configuration",count=prep["physical_definition_and_unit_checked_operations"]),
        dict(stage="Exact duplicate exports removed",count=prep["duplicate_export_operations"]),dict(stage="Unique audited operations",count=prep["unique_audited_operations"]),
        dict(stage="All events in trainable tasks",count=prep["trainable_waveforms"]),dict(stage="Untrainable groups retained in inventory",count=prep["untrainable_waveforms"])])
    display_aggregate=aggregate.copy()
    for c in ["within_5pct","within_10pct","nominal_level_accuracy","nominal_level_balanced_accuracy"]:display_aggregate[c]*=100
    display_pooled=pooled.copy()
    for c in ["within_5pct","within_10pct","nominal_level_accuracy"]:display_pooled[c]*=100
    task_table=selected[selected.scheme.eq("unseen_instrument")].sort_values("waveforms",ascending=False)
    display_tasks=task_table[["label","task_id","waveforms","physical_runs","instruments","observed_volume_levels","mae_ul","mae_ci_low","mae_ci_high","within_10pct","nominal_level_accuracy","mae_improvement_over_baseline_pct","plugin_deployment_eligible"]].copy()
    display_tasks[["within_10pct","nominal_level_accuracy"]]*=100
    report=f'''<!doctype html><html><head><meta charset="utf-8"><title>All-operation QPM volume models</title><style>
body{{font:16px system-ui;line-height:1.5;color:{COLORS['ink']};background:{COLORS['paper']};max-width:1600px;margin:32px auto;padding:0 22px}}h1,h2{{color:{COLORS['ink']}}}section{{background:white;padding:22px;margin:18px 0;border-radius:9px;overflow:auto}}img{{max-width:100%}}table{{border-collapse:collapse;font-size:12px}}th,td{{padding:8px;text-align:left;border-bottom:1px solid #dbe3d7}}a{{color:{COLORS['teal']}}}.warning{{border-left:5px solid {COLORS['coral']};padding:16px;background:#fff2e8}}
</style></head><body><h1>QPM waveform volume recognition: all audited operations</h1>
<p>{prep['trainable_waveforms']:,} waveforms · {len(log['models'])} trained tasks · {training_runs:,} training physical runs · {prep['instruments']} instruments · validated {html.escape(seal['validated_utc'])}</p>
<p class="warning"><strong>Programmed-volume recognition, not actual-volume measurement.</strong> The labels are nominal instrument commands. These CSA data cannot establish a physical over/under-aspiration or dispense amount without independent measured-volume calibration. No instrument setting is modified.</p>
<section><h2>Presentation summary</h2><img src="qpm_all_volume_summary.png" alt="Four-panel coverage, model comparison, core-class error and held-out generalization summary"><p><a href="qpm_all_volume_summary.pdf">Presentation PDF</a> · <a href="all_task_heldout_response_plots.pdf">Every task: held-out response and residual plots</a></p></section>
<section><h2>Exactly what “all available” means</h2>{table(counts)}<p>Uses all stored 32-point operation profiles from the full CSA collection behind the baseline, including both good and poor outcome runs—not only healthy-reference-eligible runs. This is not full-rate debug re-extraction. No event, run, nominal-level, liquid-definition, or instrument cap. Distinct raw operations are retained; exact repeated raw events in sibling exports are deduplicated.</p><p>All {prep['definition_channel_operation_unit_tasks']} full liquid-definition × pipette × operation × source-unit groups are inventoried. Training requires at least 16 physical runs and two nominal volumes. Single-volume or under-replicated tasks remain unresolved; no artificial importance or accuracy is assigned. Numeric liquid-class IDs are aliases only when their full configuration fingerprints agree. Unknown physical pressure units are never converted to psi/kPa.</p></section>
<section><h2>Models and safeguards</h2><p>Ridge, Elastic Net, and constrained Extra Trees, compared with a training-median baseline and a geometry/stage-only context baseline. Waveform models receive only 32 baseline-centered profile values—never the programmed volume, operation number, instrument ID, or step name. Each physical run has equal training weight, and nominal levels within a run share its weight.</p><p>Five outer physical-run folds; every feasible leave-one-instrument-out fold; strict newest-20% acquisition-time holdout. Two-fold inner physical-run validation chooses the model family inside each outer fold. All preprocessing is fitted within training folds. Er72 traces, unresolved quality/configuration and repeated exports are excluded before training.</p><p>Task metrics give each physical run equal evaluation weight. Volume ranges, operation frequencies and numbers of levels differ substantially. Therefore both summaries are shown: <strong>full operation mix</strong> averages each physical run's errors across its held-out operations in all tasks, then gives runs equal votes; <strong>task macro</strong> gives every task equal weight regardless of size. Neither treats millions of events as independent samples. All {len(log['models'])} tasks are evaluated, including {len(log['models'])-len(qualified)} not deployment-qualified. These are separate task models, not one universal model. Chronological cutoffs are defined within each task.</p><p>A nearest-level accuracy assigns the continuous regression output to a volume level seen in the training fold—it is not a separately trained classification model and has no universal chance baseline.</p><h3>Full operation mix, physical-run balanced</h3>{table(display_pooled)}<h3>Task macro averages</h3>{table(display_aggregate)}<p><a href="all_operations_run_balanced_performance.csv">Full operation-mix metrics CSV</a> · <a href="model_comparison_task_macro.csv">Task-macro metrics CSV</a> · <a href="model_performance.csv">Every task/model/validation result</a> · <a href="per_instrument_performance.csv">Per-instrument results</a> · <a href="nested_model_selections.csv">Inner model choices</a></p></section>
<section><h2>Every task: unseen-instrument results</h2><p>{len(qualified)}/{len(log['models'])} tasks pass the three-scheme deployment gate: positive paired improvement over the median baseline with a bootstrap lower bound above zero in all three schemes. This gate does not certify actual delivery or superiority over a context-only explanation. Plugin inference additionally requires at least eight training physical runs with the exact nominal level, geometry, command settings and unit, and refuses any target physical run present in model training. No extrapolation outside the observed nominal range.</p><p>Within-10% and nearest-level values are percentages. Bootstrap intervals describe aggregate task MAE on fixed held-out predictions; they do not refit model selection and are not individual-operation confidence intervals.</p>{table(display_tasks)}<p><a href="selected_procedure_all_tasks.csv">All validation schemes for selected procedure</a> · <a href="all_task_coverage.csv">All trainable and untrainable tasks</a> · <a href="all_volume_level_coverage.csv">Every nominal level's independent-run coverage</a></p></section>
<section><h2>Interpretation and next experiment</h2><p>The study tests whether QPM waveform structure carries programmed-volume information across runs and instruments. It does not establish why a barcode failed, validate a sensor as a volume meter, or make a causal tuning recommendation. Geometry/workflow confounding and raw-count sensor differences can remain. A complex waveform can be anomalous without its nominal-volume equivalent being a delivered-volume deficit.</p><p>The next validation is an engineering-approved, blocked transfer calibration: independently measure aspirated/dispensed volume at conservative approved levels, include controlled under/over-transfer and fault challenges, keep entire instruments and days held out, and test interval coverage and failure sensitivity. Only that study can justify physical over/under-transfer quantities.</p><p>Earlier five-volume PIP2-only studies used a much narrower cohort. Their scores are not directly comparable with this broad, uncapped task inventory.</p></section>
<section><h2>Provenance</h2><p><a href="preparation_audit.json">Input archive hashes and exclusions</a> · <a href="analysis_run_log.json">Training settings, source version and warnings</a> · <a href="artifact_validation.json">Independent artifact and metric validation</a></p><p>Random seed {log['random_seed']}; {seal['verified_outer_folds']} checked outer folds. {len(prep['archive_hashes'])} archive hashes contributed retained QPM events. Training duration {log['execution_seconds']/60:.1f} minutes.</p></section></body></html>'''
    (root/"qpm_all_volume_report.html").write_text(report)
    names=["qpm_all_volume_report.html","qpm_all_volume_summary.png","qpm_all_volume_summary.pdf","all_task_heldout_response_plots.pdf",
        "model_comparison_task_macro.csv","selected_procedure_all_tasks.csv","core_class_model_comparison.csv",
        "all_operations_run_balanced_performance.csv","pooled_metrics_provenance.json"]
    (root/"report_validation.json").write_text(json.dumps(dict(status="passed",created_utc=datetime.now(timezone.utc).isoformat(),
        artifact_validation_sha256=sha(root/"artifact_validation.json"),renderer_sha256=sha(Path(__file__)),
        artifact_sha256={name:sha(root/name) for name in names}),indent=2))
    print(json.dumps(dict(report=str(root/"qpm_all_volume_report.html"),summary=str(root/"qpm_all_volume_summary.png"),deployment_eligible_tasks=len(qualified))),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--study",type=Path,required=True)
    render(p.parse_args().study.resolve())
