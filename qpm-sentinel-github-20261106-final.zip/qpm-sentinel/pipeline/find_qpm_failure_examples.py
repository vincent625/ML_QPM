#!/usr/bin/env python3
"""Find exploratory CSA failure examples that co-occur with unusual QPM waves.

The analysis is intentionally diagnostic.  It never labels a QPM waveform as a
root cause and it does not expose sample names.  Planned barcode pools are
represented by deterministic hashes, and QPM traces are compared with matched
references from other physical runs.
"""

from __future__ import annotations

from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import re
import tarfile
import zipfile

import numpy as np
import pandas as pd
import pyarrow.parquet as pq


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "qpm_failure_examples"
OUT.mkdir(exist_ok=True)

ID_COLS = [
    "observation_id",
    "physical_run_id",
    "instrument_id",
    "chip_lane",
    "run_start_time",
    "archive_id",
]
OUTCOMES = ["total_reads", "mean_read_length_bp", "raw_read_accuracy_pct"]
CONTEXT_COLS = [
    "global.analysis_application_type",
    "global.analysis_panel_technology",
    "ion_params_00.chip_info_chip_type",
]
PROFILE_POINTS = 32
MIN_REFERENCE_RUNS = 8
BARCODE_RE = re.compile(r"(?i)(ion[_-]?(?:hd)?dual[_-]?\d{4})")
READ_COUNT_RE = re.compile(r"_(ion_(?:hd)?dual_\d{4})_read_count$")


def normalize_barcode(value: str) -> str:
    value = re.sub(r"(?i)^ion[_-]?hddual[_-]?", "ion_hddual_", value)
    value = re.sub(r"(?i)^ion[_-]?dual[_-]?", "ion_dual_", value)
    return value.lower().replace("-", "_")


def is_control_value(value: object) -> bool:
    text = "" if value is None else str(value).strip().lower()
    return any(term in text for term in ("ntc", "no template", "control"))


def read_root_analysis_samples(path: str) -> dict:
    """Read only the root CSA/analysisSamples.json member."""
    archive = Path(path)
    if zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as zf:
            candidates = [
                name
                for name in zf.namelist()
                if name == "CSA/analysisSamples.json"
                or name.endswith("/CSA/analysisSamples.json")
            ]
            if not candidates:
                raise KeyError("root analysisSamples.json not found")
            name = sorted(candidates, key=lambda item: item.count("/"))[0]
            return json.loads(zf.read(name))

    # Streaming mode stops as soon as the shallow root member is reached and
    # avoids decompressing the complete xz tar archive.
    with tarfile.open(archive, mode="r|*") as tf:
        fallback = None
        for member in tf:
            name = member.name.lstrip("./")
            if name == "CSA/analysisSamples.json" or name.endswith("/CSA/analysisSamples.json"):
                handle = tf.extractfile(member)
                if handle is None:
                    continue
                document = json.load(handle)
                if name == "CSA/analysisSamples.json":
                    return document
                if fallback is None:
                    fallback = document
            # Root metadata occurs near the beginning.  Do not scan large
            # output/plugin trees after a usable fallback was found.
            if fallback is not None and member.offset > 16_000_000:
                return fallback
        if fallback is not None:
            return fallback
    raise KeyError("root analysisSamples.json not found")


def safe_pool_plan(archive_id: str, document: dict) -> list[dict]:
    merged = document.get("mergedBarcodeIds") or []
    barcodes = document.get("barcodeIds") or []
    planned = merged if any(str(item).strip() for item in merged) else barcodes
    sample_types = document.get("sampleTypes") or []
    external_ids = document.get("sampleExternalIds") or []
    sample_names = document.get("sampleNames") or []
    controls = document.get("controlNames") or []

    pools: dict[tuple[str, ...], dict] = {}
    for index, raw_key in enumerate(planned):
        found = [normalize_barcode(item) for item in BARCODE_RE.findall(str(raw_key))]
        tokens = tuple(dict.fromkeys(found))
        if not tokens:
            continue
        raw_control_values = []
        for values in (sample_types, external_ids, sample_names, controls):
            if index < len(values):
                raw_control_values.append(values[index])
        control_flag = any(is_control_value(value) for value in raw_control_values)
        if tokens not in pools:
            digest = hashlib.sha256(
                f"{archive_id}|{'|'.join(tokens)}".encode("utf-8")
            ).hexdigest()[:12]
            pools[tokens] = {
                "archive_id": archive_id,
                "pool_id": f"pool_{digest}",
                "pool_order": len(pools) + 1,
                "barcode_tokens": list(tokens),
                "is_control": bool(control_flag),
            }
        else:
            pools[tokens]["is_control"] = bool(pools[tokens]["is_control"] or control_flag)
    return list(pools.values())


def extract_plan_row(row: dict) -> tuple[list[dict], dict | None]:
    try:
        document = read_root_analysis_samples(row["local_path"])
        return safe_pool_plan(row["archive_id"], document), None
    except Exception as exc:  # Archive-level parse failure is recorded, not fatal.
        return [], {
            "archive_id": row["archive_id"],
            "local_path": row["local_path"],
            "error": f"{type(exc).__name__}: {exc}",
        }


def extract_all_plans(primary: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    plan_rows: list[dict] = []
    failures: list[dict] = []
    records = primary[["archive_id", "local_path"]].to_dict("records")
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(extract_plan_row, row): row for row in records}
        for completed, future in enumerate(as_completed(futures), start=1):
            pools, failure = future.result()
            plan_rows.extend(pools)
            if failure is not None:
                failures.append(failure)
            if completed % 25 == 0 or completed == len(records):
                print(f"planned-pool metadata: {completed}/{len(records)} archives")
    return pd.DataFrame(plan_rows), pd.DataFrame(failures)


def load_run_data() -> tuple[pd.DataFrame, dict[str, list[str]]]:
    schema_columns = pq.read_schema(ROOT / "csa_ml_dataset.parquet").names
    count_columns: dict[str, list[str]] = defaultdict(list)
    for column in schema_columns:
        match = READ_COUNT_RE.search(column)
        if match and "ionstats_basecaller.read_group_metrics" in column:
            count_columns[match.group(1)].append(column)
    requested = ID_COLS + OUTCOMES + CONTEXT_COLS
    requested += [column for columns in count_columns.values() for column in columns]
    requested = list(dict.fromkeys(column for column in requested if column in schema_columns))
    runs = pd.read_parquet(ROOT / "csa_ml_dataset.parquet", columns=requested)
    return runs, dict(count_columns)


def barcode_count_table(runs: pd.DataFrame, count_columns: dict[str, list[str]]) -> pd.DataFrame:
    counts = pd.DataFrame({"archive_id": runs["archive_id"]})
    for barcode, columns in count_columns.items():
        counts[barcode] = runs[columns].apply(pd.to_numeric, errors="coerce").sum(
            axis=1, min_count=1
        )
    return counts.set_index("archive_id")


def build_pool_metrics(
    runs: pd.DataFrame, plan: pd.DataFrame, barcode_counts: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame]:
    run_lookup = runs.set_index("archive_id", drop=False)
    pool_rows = []
    for item in plan.itertuples(index=False):
        if item.archive_id not in barcode_counts.index or item.archive_id not in run_lookup.index:
            continue
        tokens = item.barcode_tokens
        token_values = [barcode_counts.at[item.archive_id, token] for token in tokens]
        numeric = [float(value) for value in token_values if pd.notna(value)]
        read_count = float(np.sum(numeric)) if numeric else np.nan
        run = run_lookup.loc[item.archive_id]
        pool_rows.append(
            {
                **{column: run[column] for column in ID_COLS},
                "pool_id": item.pool_id,
                "pool_order": int(item.pool_order),
                "is_control": bool(item.is_control),
                "barcode_component_count": len(tokens),
                "read_count": read_count,
                "source_file": "CSA/analysisSamples.json + CSA/outputs/BaseCallingActor-00/ionstats_basecaller.json",
            }
        )
    pools = pd.DataFrame(pool_rows)
    if pools.empty:
        return pools, pd.DataFrame()

    summaries = []
    for observation_id, group in pools.groupby("observation_id", sort=False):
        noncontrol = group[(~group["is_control"]) & group["read_count"].notna()].copy()
        counts = noncontrol["read_count"].to_numpy(float)
        if len(counts):
            median = float(np.median(counts))
            minimum = float(np.min(counts))
            maximum = float(np.max(counts))
            mad = float(np.median(np.abs(counts - median)))
            threshold = max(100.0, 0.15 * median)
            dropout_count = int(np.sum(counts < threshold))
            min_to_median = minimum / median if median > 0 else np.nan
            max_to_median = maximum / median if median > 0 else np.nan
            max_to_min = maximum / max(minimum, 1.0)
            robust_cv = 1.4826 * mad / median if median > 0 else np.nan
            probabilities = counts / counts.sum() if counts.sum() > 0 else np.full(len(counts), np.nan)
            if np.all(np.isfinite(probabilities)) and len(counts) > 1:
                entropy = -float(np.sum(probabilities * np.log(np.maximum(probabilities, 1e-12))))
                evenness = float(np.exp(entropy) / len(counts))
            else:
                evenness = np.nan
        else:
            median = minimum = maximum = mad = threshold = np.nan
            dropout_count = 0
            min_to_median = max_to_median = max_to_min = robust_cv = evenness = np.nan
        base = group.iloc[0]
        summaries.append(
            {
                **{column: base[column] for column in ID_COLS},
                "n_planned_pools": int(len(group)),
                "n_noncontrol_pools": int(len(noncontrol)),
                "n_control_pools": int(group["is_control"].sum()),
                "noncontrol_total_reads": float(np.sum(counts)) if len(counts) else np.nan,
                "noncontrol_median_reads": median,
                "noncontrol_min_reads": minimum,
                "noncontrol_max_reads": maximum,
                "dropout_threshold_reads": threshold,
                "apparent_dropout_pool_count": dropout_count,
                "min_to_median_ratio": min_to_median,
                "max_to_median_ratio": max_to_median,
                "max_to_min_ratio": max_to_min,
                "robust_cv": robust_cv,
                "shannon_evenness": evenness,
                "interpretation": "read-count balance among planned non-control pools; intended unequal pooling is not available",
            }
        )
    summary = pd.DataFrame(summaries)
    pools = pools.merge(
        summary[["observation_id", "noncontrol_median_reads"]], on="observation_id", how="left"
    )
    pools["relative_to_noncontrol_median"] = (
        pools["read_count"] / pools["noncontrol_median_reads"]
    )
    return pools, summary


def add_context_percentiles(runs: pd.DataFrame) -> pd.DataFrame:
    data = runs[ID_COLS + OUTCOMES + CONTEXT_COLS].copy()
    for column in CONTEXT_COLS:
        data[column] = data[column].fillna("unknown").astype(str)
    levels = [
        ["instrument_id"] + CONTEXT_COLS,
        ["instrument_id", CONTEXT_COLS[0]],
        ["instrument_id"],
    ]
    for outcome in OUTCOMES:
        percentile = pd.Series(np.nan, index=data.index, dtype=float)
        reference_n = pd.Series(np.nan, index=data.index, dtype=float)
        reference_level = pd.Series("", index=data.index, dtype=object)
        for level_columns in levels:
            missing = percentile.isna() & data[outcome].notna()
            if not missing.any():
                break
            # Build each fallback reference distribution from the full eligible
            # cohort, then assign only observations that still need a percentile.
            # Otherwise observations assigned at a more specific level would be
            # incorrectly removed from the broader reference population.
            groups = data.groupby(level_columns, dropna=False)[outcome]
            for _, index in groups.groups.items():
                valid = data.loc[index, outcome].dropna()
                if len(valid) < 8:
                    continue
                assign_index = valid.index[percentile.loc[valid.index].isna()]
                if len(assign_index) == 0:
                    continue
                ranks = valid.rank(method="average", pct=True)
                percentile.loc[assign_index] = ranks.loc[assign_index]
                reference_n.loc[assign_index] = len(valid)
                reference_level.loc[assign_index] = "+".join(level_columns)
        data[f"{outcome}_context_percentile"] = percentile
        data[f"{outcome}_reference_n"] = reference_n
        data[f"{outcome}_reference_level"] = reference_level

    percentile_columns = [f"{outcome}_context_percentile" for outcome in OUTCOMES]
    data["low_outcome_count_10pct"] = (data[percentile_columns] <= 0.10).sum(axis=1)
    data["minimum_outcome_percentile"] = data[percentile_columns].min(axis=1, skipna=True)
    data["low_performance_severity"] = 1.0 - data[percentile_columns].mean(axis=1, skipna=True)
    return data


def select_seed_candidates(
    pool_summary: pd.DataFrame, performance: pd.DataFrame, spatial: pd.DataFrame
) -> pd.DataFrame:
    seeds = []

    eligible_pool = pool_summary[pool_summary["n_noncontrol_pools"] >= 3].copy()
    dropout = eligible_pool.sort_values(
        ["min_to_median_ratio", "noncontrol_min_reads"], ascending=[True, True]
    ).head(15)
    for row in dropout.itertuples(index=False):
        severity = 1.0 - min(float(row.min_to_median_ratio), 1.0)
        seeds.append(
            {
                "observation_id": row.observation_id,
                "failure_type": "sample_dropout",
                "failure_severity": severity,
                "failure_metric": "min_to_median_ratio",
                "failure_value": row.min_to_median_ratio,
                "failure_detail": f"minimum planned-pool reads {row.noncontrol_min_reads:.0f}; median {row.noncontrol_median_reads:.0f}",
            }
        )

    imbalance = eligible_pool[eligible_pool["apparent_dropout_pool_count"] == 0].sort_values(
        ["max_to_min_ratio", "shannon_evenness"], ascending=[False, True]
    ).head(15)
    for row in imbalance.itertuples(index=False):
        severity = min(np.log2(max(float(row.max_to_min_ratio), 1.0)) / 4.0, 1.0)
        seeds.append(
            {
                "observation_id": row.observation_id,
                "failure_type": "pool_imbalance",
                "failure_severity": severity,
                "failure_metric": "max_to_min_ratio",
                "failure_value": row.max_to_min_ratio,
                "failure_detail": f"maximum/minimum planned-pool reads {row.max_to_min_ratio:.2f}×; evenness {row.shannon_evenness:.3f}",
            }
        )

    spatial_top = spatial.sort_values(
        ["anomaly_percentile", "knn_distance"], ascending=[False, False]
    ).head(15)
    for row in spatial_top.itertuples(index=False):
        seeds.append(
            {
                "observation_id": row.observation_id,
                "failure_type": "spatial_uniformity",
                "failure_severity": float(row.anomaly_percentile),
                "failure_metric": "spatial_anomaly_percentile",
                "failure_value": row.anomaly_percentile,
                "failure_detail": f"spatial anomaly percentile {row.anomaly_percentile:.3f}; top deviations {row.top_deviation_features}",
            }
        )

    perf_top = performance.sort_values(
        ["low_outcome_count_10pct", "minimum_outcome_percentile", "low_performance_severity"],
        ascending=[False, True, False],
    ).head(20)
    for row in perf_top.itertuples(index=False):
        seeds.append(
            {
                "observation_id": row.observation_id,
                "failure_type": "performance_variation",
                "failure_severity": float(row.low_performance_severity),
                "failure_metric": "minimum_context_outcome_percentile",
                "failure_value": row.minimum_outcome_percentile,
                "failure_detail": f"{int(row.low_outcome_count_10pct)} outcome(s) in the lowest context-matched decile",
            }
        )
    return pd.DataFrame(seeds).drop_duplicates(["observation_id", "failure_type"])


def load_qpm_profiles() -> tuple[pd.DataFrame, pd.DataFrame, list[str]]:
    columns = [
        "observation_id",
        "physical_run_id",
        "instrument_id",
        "archive_id",
        "chip_lane",
        "operation_id",
        "operation_index",
        "operation",
        "pipette",
        "programmed_volume_ul",
        "event_time",
        "workflow_stage",
        "process_step",
        "source_file",
        "pressure_unit",
        "liquid_class_index",
        "loc",
        "qpm_available",
        "qpm_profile",
    ]
    qpm = pd.read_parquet(ROOT / "qpm_operation_waveforms.parquet", columns=columns)
    qpm = qpm[
        qpm["qpm_available"].fillna(False)
        & qpm["operation"].isin(["aspirate", "dispense"])
        & qpm["programmed_volume_ul"].gt(0)
        & qpm["liquid_class_index"].notna()
        & qpm["qpm_profile"].map(lambda value: isinstance(value, (list, np.ndarray)) and len(value) == PROFILE_POINTS)
    ].copy()
    matrix = np.vstack(qpm["qpm_profile"].map(np.asarray))
    matrix = matrix - np.median(matrix[:, :3], axis=1, keepdims=True)
    profile_columns = [f"profile_{index:02d}" for index in range(PROFILE_POINTS)]
    qpm[profile_columns] = matrix
    qpm["liquid_class_index"] = qpm["liquid_class_index"].round().astype(int)
    qpm["programmed_volume_ul"] = qpm["programmed_volume_ul"].round(3)
    for column in ["workflow_stage", "process_step", "loc", "pipette"]:
        qpm[column] = qpm[column].fillna("unknown").astype(str)

    aggregate_keys = [
        "observation_id",
        "physical_run_id",
        "instrument_id",
        "chip_lane",
        "operation",
        "pipette",
        "programmed_volume_ul",
        "liquid_class_index",
        "workflow_stage",
        "process_step",
        "loc",
    ]
    aggregate = qpm.groupby(aggregate_keys, dropna=False, sort=False)[profile_columns].median().reset_index()
    return qpm, aggregate, profile_columns


def score_candidate_qpm(
    qpm: pd.DataFrame,
    aggregate: pd.DataFrame,
    profile_columns: list[str],
    candidate_ids: set[str],
) -> pd.DataFrame:
    levels = [
        (
            "instrument_class_operation_volume_stage_step_location",
            [
                "instrument_id",
                "liquid_class_index",
                "operation",
                "pipette",
                "programmed_volume_ul",
                "workflow_stage",
                "process_step",
                "loc",
            ],
        ),
        (
            "instrument_class_operation_volume_stage",
            [
                "instrument_id",
                "liquid_class_index",
                "operation",
                "pipette",
                "programmed_volume_ul",
                "workflow_stage",
            ],
        ),
        (
            "instrument_class_operation_volume",
            [
                "instrument_id",
                "liquid_class_index",
                "operation",
                "pipette",
                "programmed_volume_ul",
            ],
        ),
        (
            "cross_instrument_class_operation_volume",
            ["liquid_class_index", "operation", "pipette", "programmed_volume_ul"],
        ),
    ]
    lookup = []
    for name, columns in levels:
        lookup.append((name, columns, aggregate.groupby(columns, dropna=False, sort=False).indices))

    scored = []
    candidates = qpm[qpm["observation_id"].isin(candidate_ids)]
    print(f"candidate QPM operations to score: {len(candidates):,}")
    for row_index, row in candidates.iterrows():
        reference_indices = None
        reference_level = None
        for name, columns, index_map in lookup:
            key_values = tuple(row[column] for column in columns)
            key = key_values[0] if len(key_values) == 1 else key_values
            indices = index_map.get(key)
            if indices is None:
                continue
            reference = aggregate.iloc[indices]
            reference = reference[reference["physical_run_id"] != row["physical_run_id"]]
            if reference["physical_run_id"].nunique() >= MIN_REFERENCE_RUNS:
                reference_indices = reference.index.to_numpy()
                reference_level = name
                break
        if reference_indices is None:
            continue

        reference = aggregate.loc[reference_indices]
        # One reference profile per physical run prevents sibling lanes from
        # receiving disproportionate weight.
        reference_matrix = (
            reference.groupby("physical_run_id", sort=False)[profile_columns]
            .median()
            .to_numpy(float)
        )
        observed = row[profile_columns].to_numpy(float)
        median = np.median(reference_matrix, axis=0)
        q05 = np.quantile(reference_matrix, 0.05, axis=0)
        q95 = np.quantile(reference_matrix, 0.95, axis=0)
        mad = np.median(np.abs(reference_matrix - median), axis=0)
        amplitude_floor = max(float(np.median(np.ptp(reference_matrix, axis=1))) * 0.02, 1.0)
        scale = np.maximum(1.4826 * mad, amplitude_floor)
        observed_score = float(np.sqrt(np.mean(np.square(np.clip((observed - median) / scale, -10, 10)))))
        reference_scores = np.sqrt(
            np.mean(np.square(np.clip((reference_matrix - median) / scale, -10, 10)), axis=1)
        )
        percentile = float((np.sum(reference_scores <= observed_score) + 1) / (len(reference_scores) + 1))
        outside_fraction = float(np.mean((observed < q05) | (observed > q95)))
        observed_amplitude = float(np.ptp(observed))
        reference_amplitude = float(np.median(np.ptp(reference_matrix, axis=1)))
        amplitude_ratio = observed_amplitude / reference_amplitude if reference_amplitude > 0 else np.nan
        relevant_pool_step = bool(
            re.search(
                r"sample|pool|equaliz|library|ligat|amplicon|amplif|transfer",
                f"{row['workflow_stage']} {row['process_step']} {row['loc']}",
                flags=re.IGNORECASE,
            )
        )
        if amplitude_ratio < 0.65:
            morphology = "attenuated_waveform"
        elif amplitude_ratio > 1.50:
            morphology = "amplified_waveform"
        elif outside_fraction >= 0.25:
            morphology = "shape_deviation"
        else:
            morphology = "subtle_or_mixed_deviation"
        scored.append(
            {
                "observation_id": row["observation_id"],
                "physical_run_id": row["physical_run_id"],
                "instrument_id": row["instrument_id"],
                "chip_lane": row["chip_lane"],
                "operation_id": row["operation_id"],
                "operation_index": row["operation_index"],
                "operation": row["operation"],
                "pipette": row["pipette"],
                "programmed_volume_ul": row["programmed_volume_ul"],
                "liquid_class_index": row["liquid_class_index"],
                "workflow_stage": row["workflow_stage"],
                "process_step": row["process_step"],
                "location": row["loc"],
                "event_time": row["event_time"],
                "source_file": row["source_file"],
                "pressure_unit": row["pressure_unit"],
                "matched_reference_level": reference_level,
                "reference_physical_runs": len(reference_matrix),
                "qpm_shape_score": observed_score,
                "qpm_anomaly_percentile": percentile,
                "outside_90pct_envelope_fraction": outside_fraction,
                "amplitude_ratio_to_reference": amplitude_ratio,
                "waveform_morphology": morphology,
                "pool_transfer_relevant_step": relevant_pool_step,
                "observed_profile": json.dumps(observed.tolist()),
                "reference_median_profile": json.dumps(median.tolist()),
                "reference_q05_profile": json.dumps(q05.tolist()),
                "reference_q95_profile": json.dumps(q95.tolist()),
            }
        )
    return pd.DataFrame(scored)


def select_examples(
    seeds: pd.DataFrame,
    qpm_scores: pd.DataFrame,
    pool_summary: pd.DataFrame,
    performance: pd.DataFrame,
    spatial: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if qpm_scores.empty:
        return pd.DataFrame(), pd.DataFrame()
    combined_rows = []
    for seed in seeds.itertuples(index=False):
        trace_options = qpm_scores[qpm_scores["observation_id"] == seed.observation_id].copy()
        if seed.failure_type in {"sample_dropout", "pool_imbalance"}:
            relevant = trace_options[trace_options["pool_transfer_relevant_step"]]
            if not relevant.empty:
                trace_options = relevant
        if trace_options.empty:
            continue
        trace = trace_options.sort_values(
            ["qpm_anomaly_percentile", "outside_90pct_envelope_fraction", "qpm_shape_score"],
            ascending=[False, False, False],
        ).iloc[0]
        row = seed._asdict()
        row.update(trace.to_dict())
        row["joint_evidence_score"] = 0.55 * float(seed.failure_severity) + 0.45 * float(
            trace["qpm_anomaly_percentile"]
        )
        combined_rows.append(row)
    combined = pd.DataFrame(combined_rows)
    if combined.empty:
        return combined, pd.DataFrame()

    # A run contains many operations, so selecting on its single most extreme
    # trace is vulnerable to a multiple-comparison artifact. Quantify the
    # run-wide burden of matched QPM anomalies and use that burden for grading.
    burden = (
        qpm_scores.groupby("observation_id")
        .agg(
            qpm_operations_scored=("qpm_anomaly_percentile", "size"),
            qpm_extreme_fraction_95=(
                "qpm_anomaly_percentile", lambda values: float((values >= 0.95).mean())
            ),
            qpm_extreme_fraction_99=(
                "qpm_anomaly_percentile", lambda values: float((values >= 0.99).mean())
            ),
            qpm_median_anomaly_percentile=("qpm_anomaly_percentile", "median"),
        )
        .reset_index()
    )
    burden["qpm_extreme_fraction_95_candidate_percentile"] = burden[
        "qpm_extreme_fraction_95"
    ].rank(method="average", pct=True)
    combined = combined.merge(burden, on="observation_id", how="left")
    combined["joint_evidence_score"] = (
        0.55 * combined["failure_severity"]
        + 0.45 * combined["qpm_extreme_fraction_95_candidate_percentile"]
    )

    outcome_columns = ID_COLS + OUTCOMES + [
        f"{outcome}_context_percentile" for outcome in OUTCOMES
    ] + ["low_outcome_count_10pct", "minimum_outcome_percentile"]
    combined = combined.merge(
        performance[outcome_columns].drop_duplicates("observation_id"),
        on="observation_id",
        how="left",
        suffixes=("", "_outcome"),
    )
    combined = combined.merge(
        pool_summary[
            [
                "observation_id",
                "n_noncontrol_pools",
                "apparent_dropout_pool_count",
                "min_to_median_ratio",
                "max_to_min_ratio",
                "shannon_evenness",
            ]
        ],
        on="observation_id",
        how="left",
    )
    combined = combined.merge(
        spatial[["observation_id", "anomaly_percentile", "top_deviation_features"]],
        on="observation_id",
        how="left",
        suffixes=("", "_spatial"),
    )

    selected_rows = []
    used_observations: set[str] = set()
    for failure_type in [
        "sample_dropout",
        "pool_imbalance",
        "spatial_uniformity",
        "performance_variation",
    ]:
        choices = combined[combined["failure_type"] == failure_type].copy()
        if failure_type == "sample_dropout":
            # Keep the most obvious dropout pattern even when QPM support is
            # weak; the evidence grade below must communicate that mismatch.
            choices = choices.sort_values(
                ["failure_severity", "qpm_extreme_fraction_95_candidate_percentile"],
                ascending=[False, False],
            )
        else:
            choices = choices.sort_values(
                ["joint_evidence_score", "qpm_extreme_fraction_95_candidate_percentile"],
                ascending=[False, False],
            )
        distinct = choices[~choices["observation_id"].isin(used_observations)]
        if not distinct.empty:
            chosen = distinct.iloc[0]
        elif not choices.empty:
            chosen = choices.iloc[0]
        else:
            continue
        used_observations.add(chosen["observation_id"])
        burden_percentile = float(chosen["qpm_extreme_fraction_95_candidate_percentile"])
        burden_fraction = float(chosen["qpm_extreme_fraction_95"])
        if burden_percentile >= 0.75 and burden_fraction >= 0.10:
            relationship = "strong_diagnostic_copattern"
        elif burden_percentile >= 0.50:
            relationship = "moderate_diagnostic_copattern"
        else:
            relationship = "weak_or_mixed_copattern"
        chosen = chosen.copy()
        chosen["relationship_label"] = relationship
        chosen["causal_interpretation"] = "hypothesis-generating only; controlled transfer ground truth required"
        selected_rows.append(chosen)
    return combined, pd.DataFrame(selected_rows)


def main() -> None:
    duplicate = pd.read_csv(ROOT / "duplicate_archives.csv")
    manifest = pd.read_csv(ROOT / "csa_transfer_manifest.csv")
    retained = duplicate[duplicate["retained_primary"].astype(str).str.lower().eq("true")]
    primary = retained[["archive_id", "observation_id"]].merge(
        manifest[["archive_id", "local_path", "container_format", "state"]],
        on="archive_id",
        how="left",
    )
    primary = primary[primary["state"].isin(["transferred", "already_present"])].copy()

    runs, count_columns = load_run_data()
    plan, failures = extract_all_plans(primary)
    barcode_counts = barcode_count_table(runs, count_columns)
    pools, pool_summary = build_pool_metrics(runs, plan, barcode_counts)
    performance = add_context_percentiles(runs)
    spatial = pd.read_csv(ROOT / "spatial_anomaly_scores.csv")
    seeds = select_seed_candidates(pool_summary, performance, spatial)

    qpm, aggregate, profile_columns = load_qpm_profiles()
    candidate_ids = set(seeds["observation_id"])
    qpm_scores = score_candidate_qpm(qpm, aggregate, profile_columns, candidate_ids)
    candidates, selected = select_examples(
        seeds, qpm_scores, pool_summary, performance, spatial
    )

    pools.to_csv(OUT / "planned_pool_read_counts.csv", index=False)
    pool_summary.to_csv(OUT / "pool_balance_metrics.csv", index=False)
    performance.to_csv(OUT / "performance_context_percentiles.csv", index=False)
    failures.to_csv(OUT / "planned_pool_parse_failures.csv", index=False)
    seeds.to_csv(OUT / "candidate_seed_metrics.csv", index=False)
    qpm_scores.to_csv(OUT / "candidate_qpm_operation_scores.csv", index=False)
    candidates.to_csv(OUT / "candidate_failure_qpm_matches.csv", index=False)
    selected.to_csv(OUT / "selected_examples.csv", index=False)

    summary = {
        "retained_archives": int(len(primary)),
        "archives_with_planned_pool_metadata": int(plan["archive_id"].nunique()) if not plan.empty else 0,
        "planned_pool_parse_failures": int(len(failures)),
        "observations_with_pool_balance_metrics": int(len(pool_summary)),
        "spatial_observations": int(len(spatial)),
        "candidate_observations_scored_for_qpm": int(len(candidate_ids)),
        "candidate_qpm_operations_with_matched_references": int(len(qpm_scores)),
        "selected_examples": selected[
            [
                "failure_type",
                "observation_id",
                "relationship_label",
                "failure_metric",
                "failure_value",
                "qpm_anomaly_percentile",
                "qpm_operations_scored",
                "qpm_extreme_fraction_95",
                "qpm_extreme_fraction_95_candidate_percentile",
                "operation",
                "programmed_volume_ul",
                "liquid_class_index",
                "matched_reference_level",
                "reference_physical_runs",
            ]
        ].to_dict("records")
        if not selected.empty
        else [],
        "limitations": [
            "Planned unequal pool proportions are not available; read-count imbalance is not automatically a liquid-transfer failure.",
            "QPM values are unresolved sensor counts, not calibrated pressure or delivered volume.",
            "Examples are selected for co-occurrence and cannot establish causality.",
            "True under/over-transfer requires controlled gravimetric or dye-based ground truth.",
        ],
    }
    (OUT / "analysis_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
