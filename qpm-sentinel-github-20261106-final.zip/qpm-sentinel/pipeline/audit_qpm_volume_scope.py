#!/usr/bin/env python3
"""Coverage-only audit of all verified QPM class/channel/operation tasks."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from retrain_qpm_volume_models import load_audited


def audit_scope(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    keys = ["liquid_class_index", "pipette", "operation", "liquid_class_fingerprint"]
    volumes = frame.groupby(keys + ["programmed_volume_ul"], dropna=False).agg(
        physical_runs=("physical_run_id", "nunique"), instruments=("instrument_id", "nunique"),
        waveforms=("operation_id", "size")).reset_index()
    host = frame.groupby(keys + ["programmed_volume_ul", "instrument_id"], dropna=False).physical_run_id.nunique().reset_index(name="instrument_physical_runs")
    host["instrument_has_eight_runs"] = host.instrument_physical_runs.ge(8)
    adequate = host.groupby(keys + ["programmed_volume_ul"], dropna=False).instrument_has_eight_runs.sum().reset_index(name="instruments_with_eight_runs")
    volumes = volumes.merge(adequate, on=keys + ["programmed_volume_ul"], validate="one_to_one")
    volumes["supported_nominal_level"] = volumes.physical_runs.ge(100) & volumes.instruments.ge(3) & volumes.instruments_with_eight_runs.ge(3)
    tasks = []
    for values, group in volumes.groupby(keys, dropna=False):
        levels = sorted(group.loc[group.supported_nominal_level, "programmed_volume_ul"].tolist())
        tasks.append(dict(zip(keys, values), observed_volume_levels=len(group),
                          supported_volume_levels=len(levels), supported_volumes_ul=json.dumps(levels),
                          eligible_three_or_more_levels=len(levels) >= 3,
                          reason="coverage_only_eligible_not_trained_unless_in_study_scope" if len(levels) >= 3 else "insufficient_supported_nominal_volume_variation"))
    return pd.DataFrame(tasks), volumes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    frame, audit = load_audited(args.project)
    tasks, volumes = audit_scope(frame)
    tasks.to_csv(args.output / "all_qpm_volume_task_coverage.csv", index=False)
    volumes.to_csv(args.output / "all_qpm_volume_level_coverage.csv", index=False)
    (args.output / "input_audit.json").write_text(json.dumps(audit, indent=2))
    print(tasks[tasks.liquid_class_index.eq(47)].to_string(index=False))
    print("Coverage-eligible tasks:", int(tasks.eligible_three_or_more_levels.sum()))
    print("Coverage-only audit complete:", args.output)


if __name__ == "__main__":
    main()
