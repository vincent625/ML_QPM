#!/usr/bin/env python3
"""Lineage-aware QPM barcode-dropout diagnostic plugin.

The MVP operates on a parsed CSA project. It diagnoses one physical-run/lane
observation at a time, using same-run surviving barcode paths as the primary
contrast and optional leave-target-run-out historical QPM templates for context.

It is deliberately diagnostic: a QPM divergence is an association and failure
localization hypothesis, not proof of delivered-volume error or root cause.
"""

from __future__ import annotations

import argparse
import ast
import base64
from datetime import datetime, timezone
import hashlib
import html
from itertools import combinations
import json
import math
from pathlib import Path
import re
import sys
import textwrap
import time
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd
from outcome_reference import build_outcome_benchmark, write_benchmark
from qpm_waveform_reference import load_profiles, scan_references, write_reference_audit, PROFILE_COLUMNS
from qpm_cross_instrument_reference import (REFERENCE_FIELDS, COVERAGE_FIELDS, normalize_shape,
                                          overlay_by_operation, scan_cross_instrument_fallback)
from qpm_internal_comparison import (METRICS as INTERNAL_METRICS, collapse_paths, deviation_scores,
                                     energy_distance, independent_path_ids, internal_operation_frame,
                                     permutation_test, waveform_distances)
from qpm_barcode_reference import (VERSION as BARCODE_REFERENCE_VERSION, EVIDENCE_COLUMNS as BARCODE_REFERENCE_COLUMNS,
                                  SUMMARY_COLUMNS as BARCODE_REFERENCE_SUMMARY_COLUMNS,
                                  build_barcode_reference_fallback, fallback_payload, reference_curve, reference_unit, report_route)
from qpm_diagnostic_extensions import (
    diagnostic_trigger, shared_reference_scan, add_volume_proxies, volume_annotation,
)
from qpm_baseline_comparison import (write_comparison, html_section as baseline_html_section,
                                     EVIDENCE_WAVEFORM_SLOTS, later_evidence, select_path_reference_display)
from qpm_trace_quality import VERSION as TRACE_QUALITY_VERSION, QUALITY_FIELDS, eligible_waveforms
from qpm_reference_qualification import load_reference_qualification, classify_barcode_outcomes
from qpm_run_metadata import build_run_metadata, run_metadata_html
from qpm_same_run_curves import (build_same_run_curves, html_section as same_run_curves_html,
                                 VERSION as SAME_RUN_CURVES_VERSION)
from csa_low_performance_diagnostics import (
    VERSION as CSA_DIAGNOSTIC_VERSION,
    build_low_performance_diagnostics, html_section as csa_low_performance_html,
)


VERSION = "qpm-barcode-dropout-plugin-0.18.0-low-read-hypotheses"
SEED = 1729

PALETTE = {
    "ink": "#264653",
    "teal": "#2A9D8F",
    "gold": "#E9C46A",
    "orange": "#F4A261",
    "coral": "#E76F51",
    "blue": "#457B9D",
    "rna": "#8F5D8A",
    "gray": "#8A918B",
    "grid": "#D9DED9",
    "paper": "#FCFCF8",
    "pale_teal": "#E8F3EF",
    "pale_gold": "#FBF2D8",
    "pale_coral": "#FBE6DF",
}

DEFAULT_CONFIG: dict[str, Any] = {
    "dropout_ratio_to_material_median": 0.15,
    "partial_imbalance_ratio_to_material_median": 0.40,
    "absolute_dropout_read_floor": 100.0,
    "minimum_failed_paths": 3,
    "minimum_surviving_paths": 3,
    "minimum_reference_physical_runs": 8,
    "positive_auc": 0.875,
    "borderline_auc": 0.75,
    "maximum_permutation_p": 0.10,
    "maximum_failed_survivor_time_gap_minutes": 45.0,
    "operation_batch_gap_indices": 45,
    "same_transaction_gap_indices": 12,
    "maximum_auc_rows_in_figure": 12,
    "support_waveform_panels": 4,  # Legacy field; report layout now always has five evidence slots.
    "outcome_reference_policy_overrides": {},
    "waveform_reference_policy_overrides": {},
    "overrepresentation_ratio_to_survivor_median": 2.5,
    "low_performance_reference": "q05",
    "shared_reference_minimum_percentile": 0.95,
    "shared_reference_minimum_outside_fraction": 0.25,
    "enable_volume_proxy": True,
    "minimum_volume_training_runs_per_level": 8,
    "internal_permutation_count": 2000,
    "enable_csa_low_performance_diagnostics": True,
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def json_ready(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if pd.isna(value) if not isinstance(value, (list, dict, tuple, np.ndarray)) else False:
        return None
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_profile(value: object) -> np.ndarray:
    if isinstance(value, np.ndarray):
        return value.astype(float)
    if isinstance(value, list):
        return np.asarray(value, dtype=float)
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return np.array([], dtype=float)
    return np.asarray(ast.literal_eval(str(value)), dtype=float)


def bool_series(values: pd.Series) -> pd.Series:
    if values.dtype == bool:
        return values
    return values.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def load_config(path: Path | None) -> dict[str, Any]:
    config = dict(DEFAULT_CONFIG)
    if path is not None:
        supplied = json.loads(path.read_text(encoding="utf-8"))
        unknown = sorted(set(supplied) - set(config))
        if unknown:
            raise ValueError(f"unknown configuration keys: {', '.join(unknown)}")
        config.update(supplied)
    if config["low_performance_reference"] not in {"q05", "median"}:
        raise ValueError("low_performance_reference must be q05 or median")
    if not isinstance(config["enable_csa_low_performance_diagnostics"], bool):
        raise ValueError("enable_csa_low_performance_diagnostics must be boolean")
    count = config["internal_permutation_count"]
    if isinstance(count, bool) or not isinstance(count, int) or not 100 <= count <= 100000:
        raise ValueError("internal_permutation_count must be an integer between 100 and 100000")
    for key in ["minimum_failed_paths", "minimum_surviving_paths"]:
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, int) or value < 3:
            raise ValueError(f"{key} must be an integer of at least three independent paths")
    return config


def resolve_observation(
    project: Path,
    observation_id: str | None,
    archive_id: str | None,
    run_name: str | None,
) -> str:
    barcodes = pd.read_csv(
        project / "qpm_failure_examples" / "dna_rna_barcode_counts.csv",
        usecols=["observation_id", "archive_id", "run_name"],
        dtype=str,
    ).drop_duplicates()
    if observation_id:
        matches = barcodes[barcodes["observation_id"].eq(observation_id)]
    elif archive_id:
        matches = barcodes[barcodes["archive_id"].eq(archive_id)]
    elif run_name:
        exact = barcodes[barcodes["run_name"].eq(run_name)]
        matches = exact if len(exact) else barcodes[
            barcodes["run_name"].str.contains(re.escape(run_name), case=False, na=False)
        ]
    else:
        raise ValueError("provide --observation-id, --archive-id, or --run-name")
    ids = sorted(matches["observation_id"].unique())
    if len(ids) != 1:
        raise ValueError(f"run selector resolved to {len(ids)} observations: {ids[:8]}")
    return ids[0]


def locate_archive(project: Path, archive_id: str) -> tuple[Path, dict[str, Any]]:
    manifest = pd.read_csv(project / "csa_transfer_manifest.csv", dtype={"archive_id": str})
    row = manifest[manifest["archive_id"].eq(str(archive_id))]
    if row.empty:
        raise KeyError(f"archive {archive_id} not found in transfer manifest")
    record = row.iloc[0].to_dict()
    path = Path(str(record["local_path"]))
    if not path.is_file():
        raise FileNotFoundError(path)
    return path, record


def build_barcode_lineage(
    project: Path,
    observation_id: str,
    config: dict[str, Any],
) -> tuple[pd.DataFrame, list[str], Path, dict[str, Any]]:
    warnings: list[str] = []
    source = pd.read_csv(project / "qpm_failure_examples" / "dna_rna_barcode_counts.csv")
    target = source[source["observation_id"].eq(observation_id)].copy()
    if target.empty:
        # A low-throughput run can still be investigated with historical QPM
        # when its sample/barcode table is absent. Absence is never a clean
        # barcode outcome and must not prevent the shared-path investigation.
        core = pd.read_parquet(project / "csa_ml_dataset.parquet")
        retained = core.loc[core.observation_id.eq(observation_id)]
        if len(retained) != 1:
            raise KeyError(f"no unique retained observation for {observation_id}")
        archive_ids = retained["archive_id"].dropna().astype(str).unique()
        warnings.append("Barcode outcomes are unavailable: sample dropout/imbalance is unresolved. Historical QPM can still investigate recorded low performance; no sample-specific cause can be localized.")
    else:
        archive_ids = target["archive_id"].dropna().astype(str).unique()
    target["is_control"] = bool_series(target["is_control"])
    target["read_count"] = pd.to_numeric(target["read_count"], errors="coerce")
    if len(archive_ids) != 1:
        raise ValueError(f"expected one retained archive for {observation_id}; found {archive_ids}")
    archive_path, manifest_record = locate_archive(project, archive_ids[0])

    # Import the validated privacy-safe positional mapper from the project.
    sys.path.insert(0, str(project))
    from plot_dropout_workflow_curves import positional_mapping

    try:
        mapping = positional_mapping(observation_id, archive_path)
        target = target.merge(
            mapping,
            on=["observation_id", "planned_order"],
            how="left",
            validate="many_to_one",
        )
    except Exception as exc:
        warnings.append(f"positional mapping unresolved: {type(exc).__name__}: {exc}")
        for column in [
            "workflow_block",
            "within_block_order",
            "planned_material_type",
            "barcode_plate_well",
            "sample_plate_well",
            "primer_pool_position",
            "positional_join_validated",
            "mapping_source",
        ]:
            target[column] = pd.NA

    # Share the exact material-aware screen with historical eligibility, so
    # references cannot silently use a different definition of imbalance.
    target = classify_barcode_outcomes(target, config)
    target["qpm_barcode_location"] = (
        "barcode_" + target["barcode_plate_well"].fillna("").astype(str).str.lower()
    )
    target["qpm_sample_locations"] = target["sample_plate_well"].fillna("").astype(str).str.lower()
    return target, warnings, archive_path, manifest_record


def infer_block_hint(process_step: object) -> tuple[int | None, str | None]:
    text = str(process_step).lower()
    patterns = [
        (r"dnainline_ctrl_([1-4])", "DNA"),
        (r"rnainline_ctrl_([1-4])", "RNA"),
        (r"from_udg_([1-4])", "DNA"),
        (r"(?:rna|rt)_reaction_(?:block)?_?([1-4])", "RNA"),
    ]
    for pattern, material in patterns:
        match = re.search(pattern, text)
        if match:
            return int(match.group(1)), material
    match = re.search(r"(?:ctrl|switch|oil)_([1-4])(?:_|$)", text)
    if match:
        return int(match.group(1)), None
    return None, None


def block_status_table(lineage: pd.DataFrame, material: str) -> pd.DataFrame:
    eligible = lineage[
        (~lineage["is_control"])
        & lineage["material_type"].eq(material)
        & lineage["path_status"].isin(["failed", "survivor"])
        & lineage["workflow_block"].notna()
    ].copy()
    if eligible.empty:
        return pd.DataFrame()
    summary = (
        eligible.groupby("workflow_block", as_index=False)
        .agg(
            failed_paths=("path_status", lambda x: int((x == "failed").sum())),
            surviving_paths=("path_status", lambda x: int((x == "survivor").sum())),
            planned_orders=("planned_order", lambda x: ";".join(map(str, sorted(x.astype(int))))),
        )
    )
    summary["path_status"] = np.select(
        [
            summary["failed_paths"].gt(0) & summary["surviving_paths"].eq(0),
            summary["surviving_paths"].gt(0) & summary["failed_paths"].eq(0),
        ],
        ["failed", "survivor"],
        default="mixed",
    )
    return summary


def reaction_location_map(
    scores: pd.DataFrame,
    block_status: pd.DataFrame,
    material: str,
) -> dict[str, tuple[str, int]]:
    if block_status.empty:
        return {}
    valid_blocks = {
        int(row.workflow_block): str(row.path_status)
        for row in block_status.itertuples(index=False)
        if row.path_status in {"failed", "survivor"}
    }
    votes: dict[str, list[int]] = {}
    for row in scores.itertuples(index=False):
        location = str(row.location).lower()
        if not location.startswith("pcr_"):
            continue
        block, hinted_material = infer_block_hint(row.process_step)
        if block not in valid_blocks:
            continue
        if hinted_material is not None and hinted_material != material:
            continue
        votes.setdefault(location, []).append(int(block))
    result: dict[str, tuple[str, int]] = {}
    for location, blocks in votes.items():
        counts = pd.Series(blocks).value_counts()
        block = int(counts.index[0])
        if len(counts) == 1 or int(counts.iloc[0]) > int(counts.iloc[1]):
            result[location] = (valid_blocks[block], block)
    return result


def add_adjacent_transfer_phase(
    assigned: dict[int, dict[str, Any]],
    scores: pd.DataFrame,
) -> dict[int, dict[str, Any]]:
    indexed = scores.set_index("operation_index", drop=False)
    for operation_index in list(assigned):
        if operation_index not in indexed.index:
            continue
        row = indexed.loc[operation_index]
        if isinstance(row, pd.DataFrame) or row["operation"] not in {"aspirate", "dispense"}:
            continue
        wanted = "aspirate" if row["operation"] == "dispense" else "dispense"
        direction = -1 if wanted == "aspirate" else 1
        candidates = scores[
            scores["operation"].eq(wanted)
            & scores["pipette"].eq(row["pipette"])
            & scores["programmed_volume_ul"].eq(row["programmed_volume_ul"])
            & scores["liquid_class_index"].eq(row["liquid_class_index"])
            & ((scores["operation_index"] - operation_index) * direction > 0)
            & ((scores["operation_index"] - operation_index).abs() <= 2)
        ]
        if len(candidates) != 1:
            continue
        # Workflow logs frequently use different names for the aspiration and
        # dispense halves of one physical transfer.  Uniqueness within two
        # adjacent operations plus identical pipette/volume/liquid class is
        # therefore the pairing criterion; record that the names differed.
        paired = int(candidates.iloc[0]["operation_index"])
        proposed = dict(assigned[operation_index])
        proposed["mapping_scope"] = (
            "paired_same_transfer"
            if str(candidates.iloc[0]["process_step"]) == str(row["process_step"])
            else "paired_adjacent_transfer_phases"
        )
        if paired not in assigned:
            assigned[paired] = proposed
    return assigned


def map_operations_to_paths(
    scores: pd.DataFrame,
    lineage: pd.DataFrame,
    material: str,
    config: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from analyze_additional_dropout_steps import family_name

    scores = eligible_waveforms(scores).sort_values("operation_index").copy()
    scores["location"] = scores["location"].fillna("").astype(str).str.lower()
    blocks = block_status_table(lineage, material)
    block_lookup = (
        {
            int(row.workflow_block): str(row.path_status)
            for row in blocks.itertuples(index=False)
            if row.path_status in {"failed", "survivor"}
        }
        if not blocks.empty
        else {}
    )
    reaction_lookup = reaction_location_map(scores, blocks, material)
    direct: dict[str, dict[str, Any]] = {}
    eligible = lineage[
        (~lineage["is_control"])
        & lineage["material_type"].eq(material)
        & lineage["path_status"].isin(["failed", "survivor"])
    ]
    for row in eligible.itertuples(index=False):
        if str(row.barcode_plate_well) not in {"", "<NA>", "nan"}:
            direct[f"barcode_{str(row.barcode_plate_well).lower()}"] = {
                "path_status": row.path_status,
                "planned_order": int(row.planned_order),
                "workflow_block": row.workflow_block,
                "mapping_scope": "direct_barcode_well",
            }

    # Start with exact barcode-well assignments, then propagate backward to the
    # paired reaction-well aspiration.  Those later adapter transfers provide
    # a privacy-safe physical lineage from each non-control barcode well to its
    # reaction well and prevent inline-control wells from entering the sample
    # comparison merely because they share a workflow block.
    assigned: dict[int, dict[str, Any]] = {}
    for row in scores.itertuples(index=False):
        index = int(row.operation_index)
        location = str(row.location).lower()
        if location in direct:
            assigned[index] = dict(direct[location])
    assigned = add_adjacent_transfer_phase(assigned, scores)
    exact_reaction: dict[str, dict[str, Any]] = {}
    indexed = scores.set_index("operation_index", drop=False)
    for index, metadata in assigned.items():
        if index not in indexed.index:
            continue
        row = indexed.loc[index]
        if isinstance(row, pd.DataFrame):
            continue
        location = str(row["location"]).lower()
        if location.startswith("pcr_"):
            exact = dict(metadata)
            exact["mapping_scope"] = "reaction_well_lineage_via_barcode_transfer"
            exact_reaction[location] = exact

    for row in scores.itertuples(index=False):
        index = int(row.operation_index)
        if index in assigned:
            continue
        location = str(row.location).lower()
        if location in exact_reaction:
            assigned[index] = dict(exact_reaction[location])
            continue
        # Block-based reaction mapping is a fallback for workflows where the
        # direct adapter lineage is absent.  It is not mixed with exact
        # reaction-well lineage because that would reintroduce control wells.
        if not exact_reaction and location in reaction_lookup:
            status, block = reaction_lookup[location]
            assigned[index] = {
                "path_status": status,
                "planned_order": pd.NA,
                "workflow_block": block,
                "mapping_scope": "reaction_well_block",
            }
            continue
        block, hinted_material = infer_block_hint(row.process_step)
        if (
            not exact_reaction
            and
            block in block_lookup
            and (hinted_material is None or hinted_material == material)
        ):
            assigned[index] = {
                "path_status": block_lookup[int(block)],
                "planned_order": pd.NA,
                "workflow_block": block,
                "mapping_scope": "workflow_block_step",
            }
    assigned = add_adjacent_transfer_phase(assigned, scores)
    indexed = scores.set_index("operation_index", drop=False)
    rows: list[dict[str, Any]] = []
    for index, metadata in assigned.items():
        if index not in indexed.index:
            continue
        row = indexed.loc[index]
        if isinstance(row, pd.DataFrame):
            continue
        record = row.to_dict()
        record.update(metadata)
        record["material_type"] = material
        rows.append(record)
    if not rows:
        return pd.DataFrame(), blocks

    mapped = pd.DataFrame(rows).sort_values("operation_index")
    scores_with_family = scores[["operation_index", "process_step"]].copy()
    scores_with_family["context_family"] = scores_with_family["process_step"].map(family_name)
    context_lookup = scores_with_family.set_index("operation_index")["context_family"]
    mapped["family"] = mapped["process_step"].map(family_name)
    mixing_context = {
        "UDG transfer to DNA reaction well": "Post-UDG reaction-well mixing",
        "DNA target-amplification mastermix transfer": "Post-DNA-AT reaction-well mixing",
        "RNA target-amplification mastermix transfer": "Post-RNA-AT reaction-well mixing",
        "Partial-digestion reagent transfer": "Partial-digestion reaction-well mixing",
        "Ligation-mastermix addition": "Post-ligation-mastermix reaction-well mixing",
    }
    for index, row in mapped[mapped["family"].eq("Reaction-well mixing")].iterrows():
        operation_index = int(row["operation_index"])
        previous = [
            context_lookup.get(candidate)
            for candidate in range(operation_index - 1, max(operation_index - 5, -1), -1)
            if candidate in context_lookup.index
            and context_lookup.get(candidate) != "Reaction-well mixing"
        ]
        if previous and previous[0] in mixing_context:
            mapped.loc[index, "family"] = mixing_context[previous[0]]
    mapped["absolute_log_amplitude_ratio"] = np.abs(
        np.log(pd.to_numeric(mapped["amplitude_ratio_to_reference"], errors="coerce").clip(lower=1e-9))
    )
    keys = [
        "material_type",
        "family",
        "operation",
        "pipette",
        "programmed_volume_ul",
        "liquid_class_index",
    ]
    if "internal_context_fingerprint" in mapped:
        keys.append("internal_context_fingerprint")
    batch = pd.Series(index=mapped.index, dtype="Int64")
    for _, group in mapped.groupby(keys, dropna=False, sort=False):
        ordered = group.sort_values("operation_index")
        values = (
            ordered["operation_index"]
            .diff()
            .fillna(0)
            .gt(int(config["operation_batch_gap_indices"]))
            .cumsum()
            + 1
        )
        batch.loc[ordered.index] = values.astype(int).values
    mapped["batch"] = batch.astype(int)
    mapped["group_id"] = (
        mapped["material_type"].astype(str)
        + "|"
        + mapped["family"].astype(str)
        + "|"
        + mapped["operation"].astype(str)
        + "|"
        + mapped["pipette"].astype(str)
        + "|"
        + mapped["programmed_volume_ul"].astype(str)
        + "|LC"
        + mapped["liquid_class_index"].astype(str)
        + "|B"
        + mapped["batch"].astype(str)
    )
    if "internal_context_fingerprint" in mapped:
        mapped["group_id"] += "|C" + mapped["internal_context_fingerprint"].astype(str)
    return mapped, blocks


def auc_score(failed_values: np.ndarray, survivor_values: np.ndarray) -> float:
    comparisons = [
        1.0 if failed > survivor else 0.5 if failed == survivor else 0.0
        for failed in failed_values
        for survivor in survivor_values
    ]
    return float(np.mean(comparisons)) if comparisons else np.nan


def permutation_p(
    values: np.ndarray,
    failed: np.ndarray,
    seed: int = SEED,
) -> tuple[float, str]:
    values = np.asarray(values, dtype=float)
    failed = np.asarray(failed, dtype=bool)
    n_failed = int(failed.sum())
    observed = float(values[failed].mean() - values[~failed].mean())
    total = math.comb(len(values), n_failed)
    differences: list[float] = []
    if total <= 100_000:
        iterator = combinations(range(len(values)), n_failed)
        method = "exact"
    else:
        rng = np.random.default_rng(seed)
        iterator = (
            tuple(rng.choice(len(values), n_failed, replace=False))
            for _ in range(20_000)
        )
        method = "monte_carlo_20000"
    for chosen in iterator:
        mask = np.zeros(len(values), dtype=bool)
        mask[list(chosen)] = True
        differences.append(float(values[mask].mean() - values[~mask].mean()))
    array = np.asarray(differences)
    return float(np.mean(np.abs(array) >= abs(observed) - 1e-12)), method


def bh_adjust(values: pd.Series) -> pd.Series:
    output = pd.Series(np.nan, index=values.index, dtype=float)
    valid = values.dropna().sort_values()
    if valid.empty:
        return output
    n = len(valid)
    adjusted = valid.to_numpy(float) * n / np.arange(1, n + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    output.loc[valid.index] = np.minimum(adjusted, 1.0)
    return output


def group_short_label(row: pd.Series | dict[str, Any]) -> str:
    family = str(row["family"]).replace("Other: ", "")
    replacements = {
        "DNA target-amplification mastermix transfer": "DNA AT mastermix",
        "RNA target-amplification mastermix transfer": "RNA AT mastermix",
        "Adapter-ligation barcode-well recovery aspiration": "Barcode recovery",
        "Adapter-ligation return dispense to reaction well": "Return to reaction well",
        "Adapter-ligation reaction-well aspiration": "Reaction-well to barcode",
        "Adapter-ligation barcode-well dispense": "Barcode-well delivery",
        "AMPure cleanup transfer out of reaction well": "AMPure transfer",
        "Ligation-mastermix addition": "Ligation mastermix",
        "Reaction-well mixing": "Reaction-well mix",
    }
    family = replacements.get(family, family)
    operation = str(row["operation"])[:3]
    return f"{family} · {operation} · {float(row['programmed_volume_ul']):g} µL"


def summarize_step_evidence(
    mapped: pd.DataFrame,
    material: str,
    config: dict[str, Any],
) -> pd.DataFrame:
    mapped = eligible_waveforms(mapped)
    if mapped.empty:
        return pd.DataFrame()
    metrics = INTERNAL_METRICS
    records: list[dict[str, Any]] = []
    for group_id, group in mapped.groupby("group_id", sort=False):
        operations = group.drop_duplicates("operation_id").copy()
        # Repeated aspiration/dispense attempts on one barcode are not new
        # independent paths. Use one median raw waveform per mapped path.
        group = collapse_paths(operations)
        failed_mask = group["path_status"].eq("failed").to_numpy()
        n_failed = int(failed_mask.sum())
        n_survivor = int((~failed_mask).sum())
        base = group.iloc[0]
        failed_times = pd.to_datetime(
            group.loc[failed_mask, "event_time"], errors="coerce", utc=True
        )
        survivor_times = pd.to_datetime(
            group.loc[~failed_mask, "event_time"], errors="coerce", utc=True
        )
        time_gap = np.nan
        if failed_times.notna().any() and survivor_times.notna().any():
            time_gap = abs((failed_times.median() - survivor_times.median()).total_seconds()) / 60
        record: dict[str, Any] = {
            "material_type": material,
            "group_id": group_id,
            "family": base["family"],
            "operation": base["operation"],
            "pipette": base["pipette"],
            "programmed_volume_ul": float(base["programmed_volume_ul"]),
            "liquid_class_index": base["liquid_class_index"],
            "first_operation_index": int(operations["operation_index"].min()),
            "last_operation_index": int(operations["operation_index"].max()),
            "first_event_time": group["event_time"].min(),
            "last_event_time": group["event_time"].max(),
            "n_failed": n_failed,
            "n_survivor": n_survivor,
            "minimum_reference_runs": int(group["reference_physical_runs"].min()),
            "mapping_scopes": ";".join(sorted(group["mapping_scope"].astype(str).unique())),
            "failed_survivor_time_gap_minutes": float(time_gap) if np.isfinite(time_gap) else np.nan,
            "comparison_basis": "within_run_loo_survivor_template",
            "historical_reference_required": False,
            "historical_confirmation_status": "available_all_paths" if operations["reference_physical_runs"].ge(config["minimum_reference_physical_runs"]).all()
                else "partial_historical_coverage" if operations["reference_physical_runs"].ge(config["minimum_reference_physical_runs"]).any()
                else "insufficient_historical_references",
            "workflow_stage": base.get("workflow_stage", "unresolved"),
            "process_step": base.get("process_step", "unresolved"),
        }
        replication_ok = n_failed >= int(config["minimum_failed_paths"]) and n_survivor >= int(config["minimum_surviving_paths"])
        context_ok = bool(group["internal_context_verified"].all()) if "internal_context_verified" in group else False
        raw_ok = "observed_profile" in group and all(len(parse_profile(value)) == 32 and np.isfinite(parse_profile(value)).all() for value in group["observed_profile"])
        eligible = replication_ok and context_ok and raw_ok
        record["eligible_internal_comparison"] = eligible
        if eligible:
            matrix = np.vstack(group["observed_profile"].map(parse_profile))
            values, composite, auc = deviation_scores(matrix, failed_mask)
            group[metrics] = values
            group["composite_deviation"] = composite
            # Export one fitted score per independent path, even when retries
            # created multiple ledger rows. Historical scores remain separate.
            path_ids = independent_path_ids(operations)
            for metric in metrics:
                lookup = dict(zip(group["independent_path"], group[metric]))
                mapped.loc[operations.index, metric] = path_ids.map(lookup)
        else:
            group[metrics] = np.nan
        directions = 0
        for metric in metrics:
            failed_median = (
                float(group.loc[failed_mask, metric].median()) if n_failed else np.nan
            )
            survivor_median = (
                float(group.loc[~failed_mask, metric].median()) if n_survivor else np.nan
            )
            record[f"failed_median_{metric}"] = failed_median
            record[f"survivor_median_{metric}"] = survivor_median
            directions += int(
                np.isfinite(failed_median)
                and np.isfinite(survivor_median)
                and failed_median > survivor_median
            )
        record["metrics_more_deviant_in_failed"] = directions
        if not eligible:
            record.update(
                {
                    "failed_path_deviation_auc": np.nan,
                    "permutation_p": np.nan,
                    "permutation_method": "not_run",
                    "median_composite_difference": np.nan,
                    "failed_above_survivor_median_fraction": np.nan,
                    "screen_label": "insufficient_replication" if not replication_ok else "physical_configuration_unverified" if not context_ok else "raw_waveform_unavailable",
                    "permutations_evaluated": 0,
                }
            )
            records.append(record)
            continue
        failed_values = group.loc[failed_mask, "composite_deviation"].to_numpy(float)
        survivor_values = group.loc[~failed_mask, "composite_deviation"].to_numpy(float)
        p_value, p_method, permutations = permutation_test(matrix, failed_mask, seed=SEED,
                                                         monte_carlo_count=config["internal_permutation_count"])
        record["permutation_statistic"] = "raw_waveform_energy_distance"
        record["within_run_energy_distance"] = energy_distance(waveform_distances(matrix), failed_mask)
        temporal_confounded = (
            np.isfinite(time_gap)
            and time_gap > float(config["maximum_failed_survivor_time_gap_minutes"])
        )
        if temporal_confounded:
            label = "time_or_block_confounded"
        elif (
            auc >= float(config["positive_auc"])
            and p_value <= float(config["maximum_permutation_p"])
            and directions >= 2
        ):
            label = "screen_positive"
        elif auc >= float(config["borderline_auc"]) and directions >= 2:
            label = "borderline"
        elif auc <= 0.25:
            label = "opposite_direction"
        else:
            label = "not_selective"
        record.update(
            {
                "failed_path_deviation_auc": auc,
                "permutation_p": p_value,
                "permutation_method": p_method,
                "permutations_evaluated": permutations,
                "median_composite_difference": float(
                    np.median(failed_values) - np.median(survivor_values)
                ),
                "failed_above_survivor_median_fraction": float(
                    np.mean(failed_values > np.median(survivor_values))
                ),
                "screen_label": label,
            }
        )
        records.append(record)
    summary = pd.DataFrame(records).sort_values("first_operation_index").reset_index(drop=True)
    eligible = summary["eligible_internal_comparison"].astype(bool)
    summary.loc[eligible, "bh_fdr_q"] = bh_adjust(
        summary.loc[eligible, "permutation_p"]
    )
    summary["evidence_role"] = summary["screen_label"]
    positive = summary[
        summary["screen_label"].eq("screen_positive")
    ].sort_values("first_operation_index")
    if not positive.empty:
        first_index = positive.index[0]
        summary.loc[first_index, "evidence_role"] = "initial_candidate"
        first = summary.loc[first_index]
        for index, row in positive.iloc[1:].iterrows():
            overlaps = int(row["first_operation_index"]) <= (
                int(first["last_operation_index"])
                + int(config["same_transaction_gap_indices"])
            )
            same_family = row["family"] == first["family"]
            summary.loc[index, "evidence_role"] = (
                "same_transaction_confirmation"
                if overlaps or same_family
                else "downstream_support"
            )
    summary["step_label"] = summary.apply(group_short_label, axis=1)
    summary["statistical_interpretation"] = np.select(
        [
            summary["bh_fdr_q"].le(0.05),
            summary["bh_fdr_q"].le(0.10),
            summary["screen_label"].eq("screen_positive"),
        ],
        ["fdr_supported", "promising_after_fdr", "exploratory_not_fdr_supported"],
        default="not_supported",
    )
    # Kept for older JSON consumers; this is the within-run BH result, not an
    # assertion that external references are available or confirm causation.
    summary["reference_interpretation"] = summary["statistical_interpretation"]
    return summary


def choose_focus_material(
    lineage: pd.DataFrame,
    evidence_by_material: dict[str, pd.DataFrame],
) -> str | None:
    candidates: list[tuple[int, int, str]] = []
    for material in ["DNA", "RNA"]:
        group = lineage[
            (~lineage["is_control"]) & lineage["material_type"].eq(material)
        ]
        failed = int(group["path_status"].eq("failed").sum())
        evidence = evidence_by_material.get(material, pd.DataFrame())
        has_initial = int(
            not evidence.empty and evidence["evidence_role"].eq("initial_candidate").any()
        )
        if failed:
            candidates.append((has_initial, failed, material))
    return max(candidates)[2] if candidates else None


def style_axis(ax: plt.Axes) -> None:
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color=PALETTE["grid"], lw=0.55, alpha=0.72)
    ax.tick_params(length=2.5, width=0.6)


def plot_barcode_outcomes(ax: plt.Axes, lineage: pd.DataFrame) -> None:
    rows = lineage[~lineage["is_control"]].sort_values("planned_order").copy()
    if rows.empty:
        ax.text(0.5, 0.5, "No evaluable sample barcodes", ha="center", va="center")
        ax.axis("off")
        return
    heights = rows["read_count"].fillna(0).clip(lower=0.5)
    colors = rows["material_type"].map({"DNA": PALETTE["blue"], "RNA": PALETTE["rna"]}).fillna(PALETTE["gray"])
    affected = rows["path_status"].eq("failed")
    edges = np.where(rows["apparent_dropout"], PALETTE["coral"], np.where(affected, PALETTE["orange"], PALETTE["ink"]))
    widths = np.where(affected, 2.2, 0.5)
    ax.bar(rows["planned_order"], heights, color=colors, edgecolor=edges, linewidth=widths)
    for row in rows.itertuples(index=False):
        if row.path_status == "failed":
            ax.text(
                row.planned_order,
                max(float(row.read_count), 0.5) * 1.55,
                f"{row.material_type}{int(row.planned_order)}\n{int(row.read_count):,}",
                ha="center",
                va="bottom",
                fontsize=5.5,
                color=PALETTE["coral"],
                fontweight="bold",
            )
    ax.set_yscale("log")
    ax.set_ylim(0.35, max(float(heights.max()) * 12, 1_000))
    ax.set_xticks(rows["planned_order"])
    ax.set_xticklabels(rows["planned_order"].astype(int), fontsize=5.4)
    ax.set_xlabel("Planned barcode order")
    ax.set_ylabel("Final assigned reads (log scale)")
    ax.set_title("Barcode outcome audit", loc="left", fontweight="bold", color=PALETTE["ink"])
    style_axis(ax)
    ax.legend(
        handles=[
            Line2D([0], [0], color=PALETTE["blue"], lw=6, label="DNA"),
            Line2D([0], [0], color=PALETTE["rna"], lw=6, label="RNA"),
            Line2D([0], [0], color=PALETTE["coral"], lw=2, label="dropout outline"),
            Line2D([0], [0], color=PALETTE["orange"], lw=2, label="imbalance outline"),
        ],
        frameon=False,
        fontsize=5.8,
        ncol=2,
        loc="upper right",
    )


def plot_process_logic(
    ax: plt.Axes,
    lineage: pd.DataFrame,
    focus_material: str | None,
    evidence: pd.DataFrame,
    mapped: pd.DataFrame,
) -> None:
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    focus = (
        lineage[
            (~lineage["is_control"]) & lineage["material_type"].eq(focus_material)
        ]
        if focus_material
        else pd.DataFrame()
    )
    failed = int(focus["path_status"].eq("failed").sum()) if not focus.empty else 0
    survivors = int((focus["outcome_class"] == "surviving").sum()) if not focus.empty else 0
    eligible = int(evidence["eligible_internal_comparison"].sum()) if not evidence.empty else 0
    initial = evidence[evidence["evidence_role"].eq("initial_candidate")] if not evidence.empty else pd.DataFrame()
    support = (
        int(evidence["evidence_role"].isin(["same_transaction_confirmation", "downstream_support"]).sum())
        if not evidence.empty
        else 0
    )
    initial_text = group_short_label(initial.iloc[0]) if not initial.empty else "No qualified initial step"
    q_text = (
        f"q={initial.iloc[0]['bh_fdr_q']:.3f}"
        if not initial.empty and pd.notna(initial.iloc[0]["bh_fdr_q"])
        else "q=NA"
    )
    boxes = [
        ("1  Outcome audit", f"{focus_material or 'No material'}: {failed} failed / {survivors} surviving", PALETTE["pale_coral"] if failed else PALETTE["pale_teal"]),
        ("2  Lineage mapping", f"{len(mapped):,} barcode/block-mapped QPM operations", PALETTE["pale_teal"]),
        ("3  Within-run comparison", f"{eligible} eligible groups; leave-one-path-out survivors", PALETTE["pale_gold"]),
        ("4  Earliest divergence", initial_text, PALETTE["pale_coral"] if not initial.empty else "#F1F1ED"),
        ("5  Statistical check", f"Permutation refits templates; {q_text}; history optional", PALETTE["pale_gold"]),
        ("6  Guarded conclusion", f"{support} later support group(s); association, not cause", PALETTE["pale_teal"]),
    ]
    draw_logic_boxes(ax, boxes)


def draw_logic_boxes(ax: plt.Axes, boxes: list[tuple[str, str, str]]) -> None:
    """Use one layout for barcode-selective and reference-only decision panels."""
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    positions = [(0.02, 0.58), (0.35, 0.58), (0.68, 0.58), (0.02, 0.12), (0.35, 0.12), (0.68, 0.12)]
    width, height = 0.29, 0.27
    for (title, detail, color), (x, y) in zip(boxes, positions):
        patch = FancyBboxPatch(
            (x, y), width, height,
            boxstyle="round,pad=0.018,rounding_size=0.02",
            ec=PALETTE["grid"], fc=color, lw=0.8,
        )
        ax.add_patch(patch)
        ax.text(x + 0.02, y + height - 0.055, title, fontsize=6.5, fontweight="bold", color=PALETTE["ink"], va="top")
        ax.text(
            x + 0.02,
            y + height - 0.12,
            textwrap.fill(detail, width=31),
            fontsize=5.15,
            color=PALETTE["ink"],
            va="top",
            linespacing=1.18,
        )
    for start, end in [
        ((0.31, 0.715), (0.35, 0.715)),
        ((0.64, 0.715), (0.68, 0.715)),
        ((0.825, 0.58), (0.165, 0.39)),
        ((0.31, 0.255), (0.35, 0.255)),
        ((0.64, 0.255), (0.68, 0.255)),
    ]:
        ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=8, lw=0.8, color=PALETTE["gray"]))
    ax.set_title("How the conclusion was reached", loc="left", fontweight="bold", color=PALETTE["ink"])


def plot_shared_process_logic(
    ax: plt.Axes,
    evidence: pd.DataFrame,
    trigger: dict | None,
) -> None:
    trigger = trigger or {}
    labels = {
        "below_chip_lane_total_read_criterion": "Below chip/lane total-read criterion",
        "low_peer_relative_performance": "Low peer-relative performance",
        "barcode_dropout": "Barcode dropout",
        "barcode_imbalance": "Barcode imbalance",
    }
    reason = "; ".join(labels.get(item, item) for item in trigger.get("reasons", [])) or "No configured trigger"
    positive = evidence[evidence["evidence_role"].ne("not_reference_positive")] if not evidence.empty else pd.DataFrame()
    first = positive.iloc[0] if not positive.empty else None
    earliest = (
        f"Op {int(first['operation_index'])} · {first['operation']} {first['programmed_volume_ul']:g} µL"
        if first is not None else "No qualifying reference deviation"
    )
    time_policy = first.get("reference_time_policy", "policy recorded") if first is not None else "policy recorded"
    boxes = [
        ("1  Outcome audit", reason, PALETTE["pale_coral"]),
        ("2  Physical references", f"{time_policy}; same instrument; target/siblings excluded", PALETTE["pale_teal"]),
        ("3  Like-for-like scan", f"{len(evidence):,} covered operations; others unresolved", PALETTE["pale_gold"]),
        ("4  Earliest deviation", earliest, PALETTE["pale_coral"] if first is not None else "#F1F1ED"),
        ("5  Later anomalies", f"{max(0, len(positive) - 1)} reference deviations; not barcode-selective", PALETTE["pale_gold"]),
        ("6  Guarded conclusion", "Reference anomaly; not delivery error or proven cause", PALETTE["pale_teal"]),
    ]
    draw_logic_boxes(ax, boxes)


def plot_auc_scan(ax: plt.Axes, evidence: pd.DataFrame, config: dict[str, Any]) -> None:
    if evidence.empty or "eligible_internal_comparison" not in evidence.columns:
        ax.text(
            0.5,
            0.5,
            "No mapped/replicated affected-path contrast\nSee reference-only scan and coverage warnings",
            ha="center",
            va="center",
            color=PALETTE["ink"],
        )
        ax.axis("off")
        return
    eligible = evidence[evidence["eligible_internal_comparison"].astype(bool)].copy()
    if eligible.empty:
        ax.text(0.5, 0.5, "No operation had enough failed and surviving paths", ha="center", va="center")
        ax.axis("off")
        return
    positive = eligible[eligible["evidence_role"].isin(["initial_candidate", "same_transaction_confirmation", "downstream_support"])]
    context = eligible.drop(positive.index).sort_values("failed_path_deviation_auc", ascending=False)
    limit = int(config["maximum_auc_rows_in_figure"])
    # Keep the earliest candidate visible even if many later steps qualify.
    selected = pd.concat([positive.head(limit), context.head(max(0, limit - len(positive)))])
    selected = selected.drop_duplicates().sort_values("first_operation_index")
    y = np.arange(len(selected))
    color_map = {
        "initial_candidate": PALETTE["coral"],
        "same_transaction_confirmation": PALETTE["orange"],
        "downstream_support": PALETTE["gold"],
        "borderline": "#C4A24F",
        "not_selective": PALETTE["gray"],
        "opposite_direction": "#7C8AA0",
        "time_or_block_confounded": "#B8B1A4",
    }
    colors = selected["evidence_role"].map(color_map).fillna(PALETTE["gray"])
    ax.scatter(selected["failed_path_deviation_auc"], y, c=colors, s=35, edgecolor="white", lw=0.5, zorder=3)
    for yi, (_, row) in zip(y, selected.iterrows()):
        ax.plot([0.5, row["failed_path_deviation_auc"]], [yi, yi], color=PALETTE["grid"], lw=0.8, zorder=1)
    ax.axvline(0.5, color=PALETTE["ink"], ls="--", lw=0.8)
    ax.axvline(float(config["positive_auc"]), color=PALETTE["gold"], ls=":", lw=0.8)
    ax.set_xlim(0.0, 1.03)
    ax.set_yticks(y)
    labels = []
    for _, row in selected.iterrows():
        family = str(row["family"]).replace("reaction-well mixing", "mixing")
        family = family.replace("Post-ligation-mastermix", "Post-ligation")
        phase = "asp" if row["operation"] == "aspirate" else "dsp"
        labels.append(textwrap.fill(family, width=34) +
                      f"\n{phase} {row['programmed_volume_ul']:g} µL · op {int(row['first_operation_index'])}")
    ax.set_yticklabels(labels, fontsize=4.9)
    ax.invert_yaxis()
    ax.set_xlabel("Within-run failed-path deviation AUC")
    ax.set_title("Chronological within-run QPM comparison", loc="left", fontweight="bold", color=PALETTE["ink"])
    style_axis(ax)


def plot_group_waveforms(
    ax: plt.Axes,
    mapped: pd.DataFrame,
    row: pd.Series | None,
    title_prefix: str,
) -> None:
    if row is None:
        ax.text(0.5, 0.5, "No qualifying waveform", ha="center", va="center")
        ax.axis("off")
        return
    operations = mapped[mapped["group_id"].eq(row["group_id"])].drop_duplicates("operation_id")
    group = collapse_paths(operations)
    curves: dict[str, list[np.ndarray]] = {"failed": [], "survivor": []}
    for operation in group.itertuples(index=False):
        observed = parse_profile(operation.observed_profile)
        if len(observed) == 0:
            continue
        status = str(operation.path_status)
        curves[status].append(observed)
        color = PALETTE["coral"] if status == "failed" else PALETTE["teal"]
        ax.plot(np.linspace(0, 100, len(observed)), observed, color=color, alpha=0.35, lw=0.9)
    for status, values in curves.items():
        if not values:
            continue
        median = np.nanmedian(np.vstack(values), axis=0)
        color = PALETTE["coral"] if status == "failed" else PALETTE["teal"]
        ax.plot(np.linspace(0, 100, len(median)), median, color=color, lw=2.1)
    ax.axhline(0, color=PALETTE["ink"], lw=0.8, ls="--")
    ax.set_xlim(0, 100)
    ax.set_xlabel("Normalized operation progress (%)")
    ax.set_ylabel("Baseline-centered QPM\n(raw sensor counts)")
    heading = textwrap.fill(f"{title_prefix}: {row['step_label']}", width=68) + f"\nWorkflow: {str(row.get('workflow_stage', 'unresolved')).replace('_', ' ')} · ops {int(row['first_operation_index'])}–{int(row['last_operation_index'])}"
    ax.set_title(heading, loc="left", fontweight="bold", color=PALETTE["ink"], fontsize=6.6)
    q_text = "NA" if pd.isna(row["bh_fdr_q"]) else f"{row['bh_fdr_q']:.3f}"
    ax.text(
        0.02, 0.03,
        f"AUC {row['failed_path_deviation_auc']:.2f} · p {row['permutation_p']:.3f} · BH q {q_text}\n"
        f"independent affected/surviving n={int(row['n_failed'])}/{int(row['n_survivor'])}\n"
        f"History: {str(row.get('historical_confirmation_status', 'optional')).replace('_', ' ')}; not required\n"
        + volume_annotation(operations[operations["path_status"].eq("failed")]),
        transform=ax.transAxes, fontsize=5.2, va="bottom", color=PALETTE["ink"],
        bbox={"boxstyle": "round,pad=0.22", "fc": "white", "ec": PALETTE["grid"], "alpha": 0.92},
    )
    style_axis(ax)


def plot_shared_reference_scan(ax: plt.Axes, evidence: pd.DataFrame, config: dict) -> None:
    if evidence.empty:
        ax.text(.5, .5, "No adequately matched QPM references\nUncovered steps are unresolved, not normal", ha="center", va="center")
        ax.axis("off")
        return
    ax.scatter(evidence["operation_index"], evidence["qpm_anomaly_percentile"], s=9,
               c=np.where(evidence["evidence_role"].eq("not_reference_positive"), PALETTE["gray"], PALETTE["coral"]), alpha=.75)
    ax.axhline(config["shared_reference_minimum_percentile"], color=PALETTE["gold"], ls=":")
    ax.set(xlabel="Workflow operation index", ylabel="Historical shape-deviation percentile", ylim=(0, 1.07))
    ax.set_title("Shared-path historical-reference scan", loc="left", fontweight="bold", color=PALETTE["ink"])
    style_axis(ax)


def shared_waveform_heading(operation: pd.Series, title: str) -> str:
    """Display the recorded workflow context, not just the operation index."""
    raw_stage = str(operation.get("workflow_stage", "unknown"))
    raw_step = str(operation.get("process_step", "unknown"))
    stage = {
        "templating_started": "Templating",
        "sequencing": "Sequencing",
        "libprep_started": "Library preparation",
    }.get(raw_stage, raw_stage.replace("_", " ").capitalize())
    volume_step = re.fullmatch(r"(transferring|removing)_(\d+(?:\.\d+)?)", raw_step)
    step = (f"{volume_step.group(1).capitalize()} {volume_step.group(2)} µL"
            if volume_step else raw_step.replace("_", " ").capitalize())
    workflow = textwrap.fill(f"Workflow: {stage} · {step}", width=58)
    details = (f"{operation['operation']} {operation['programmed_volume_ul']:g} µL · "
               f"LC{operation['liquid_class_index']:g} · {operation['location']}")
    return f"{workflow}\n{title} · op {int(operation['operation_index'])}\n{details}"


def plot_shared_waveform(ax: plt.Axes, scores: pd.DataFrame, row: pd.Series | None, title: str) -> None:
    if row is None:
        ax.text(.5, .5, "No qualifying reference-only step", ha="center", va="center")
        ax.axis("off")
        return
    selected = scores[scores["operation_id"].eq(row["operation_id"])]
    operation = selected.iloc[0]
    observed = parse_profile(reference_curve(operation))
    x = np.linspace(0, 100, len(observed))
    ax.fill_between(x, parse_profile(operation["reference_q05_profile"]), parse_profile(operation["reference_q95_profile"]), color=PALETTE["gold"], alpha=.3, label="reference 5th–95th%")
    ax.plot(x, parse_profile(operation["reference_median_profile"]), color=PALETTE["ink"], ls="--", lw=1.2, label="reference median")
    ax.plot(x, observed, color=PALETTE["coral"], lw=1.8, label="target operation")
    ax.set_title(shared_waveform_heading(operation, title), loc="left", fontweight="bold", color=PALETTE["ink"], fontsize=7.0)
    shape_only = reference_unit(operation) == "dimensionless_shape"
    ax.set(xlabel="Normalized operation progress (%)", ylabel=("Normalized QPM shape (dimensionless)" if shape_only else "Baseline-centered QPM (raw sensor counts)"), xlim=(0, 100))
    ax.text(.02, .03, f"shape {operation['qpm_shape_score']:.2f}; outside {operation['outside_90pct_envelope_fraction']:.0%}; refs n={int(operation['reference_physical_runs'])}\n"
            + ((f"Cross-instrument shape only · {int(operation['reference_instruments'])} instruments; amplitude unassessed\nSeparate raw-waveform " + volume_annotation(selected)) if shape_only else volume_annotation(selected)), transform=ax.transAxes, va="bottom", fontsize=5.2,
            bbox={"fc": "white", "ec": PALETTE["grid"], "alpha": .92, "boxstyle": "round,pad=.22"})
    ax.legend(fontsize=5, loc="best", frameon=False)
    style_axis(ax)


def select_shared_display(evidence: pd.DataFrame) -> list[pd.Series]:
    """Earliest covered anomaly plus four later anomalies, never an earlier phase.

    Distinct steps are preferred before repeats. Later reference anomalies are
    troubleshooting context, not proven support or a demonstrated failure chain.
    """
    evidence = eligible_waveforms(evidence)
    if evidence.empty:
        return []
    positive = evidence[evidence["evidence_role"].ne("not_reference_positive")].sort_values("operation_index")
    if positive.empty:
        return []
    first = positive.iloc[0]
    return [first] + later_evidence(first, positive, "operation_index", "operation_id", "process_step")


def make_barcode_reference_figure(output_dir: Path, observation_id: str, material: str,
                                 mapped: pd.DataFrame, evidence: pd.DataFrame, config: dict) -> tuple[Path, Path]:
    """Show coverage and reference-only anomalies on the same affected path."""
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7, "pdf.fonttype": 42, "ps.fonttype": 42})
    fig, axes = plt.subplots(2, 3, figsize=(16.5, 10), facecolor=PALETTE["paper"])
    axes = axes.ravel()
    fig.subplots_adjust(left=.07, right=.985, top=.81, bottom=.16, wspace=.30, hspace=.65)
    scored = evidence[evidence["fallback_status"].eq("reference_scored")]
    unresolved = evidence[evidence["fallback_status"].eq("unresolved")]
    ax = axes[0]
    if not scored.empty:
        for scope, marker in [("same_instrument", "o"), ("cross_instrument_shape", "D")]:
            entries = scored[scored.reference_scope.eq(scope)]
            ax.scatter(entries["operation_index"], entries["qpm_anomaly_percentile"], s=21, marker=marker,
                       c=np.where(entries["reference_positive"], PALETTE["coral"], PALETTE["teal"]), alpha=.85)
    if not unresolved.empty:
        ax.scatter(unresolved["operation_index"], np.full(len(unresolved), -.12), marker="x", s=20, color=PALETTE["gray"])
    ax.axhline(config["shared_reference_minimum_percentile"], color=PALETTE["gold"], ls=":", lw=1)
    ax.set(xlabel="Workflow operation index", ylabel="Historical shape-deviation percentile", ylim=(-.2, 1.07))
    ax.set_yticks([-.12, 0, .5, 1], ["unresolved", "0", "0.5", "1.0"])
    same_n = int(scored.reference_scope.eq("same_instrument").sum())
    cross_n = int(scored.reference_scope.eq("cross_instrument_shape").sum())
    ax.set_title(f"Affected-path reference coverage\n{len(scored)}/{len(evidence)} qualified · same {same_n}; cross-shape {cross_n}", loc="left", color=PALETTE["ink"], fontsize=8, fontweight="bold")
    ax.legend(handles=[Line2D([0], [0], marker="o", ls="", color=PALETTE["coral"], label="reference anomaly"),
                       Line2D([0], [0], marker="o", ls="", color=PALETTE["teal"], label="covered; below screen threshold"),
                       Line2D([0], [0], marker="x", ls="", color=PALETTE["gray"], label="unresolved, not normal"),
                       Line2D([0], [0], marker="D", ls="", color=PALETTE["ink"], label="diamond: cross-instrument shape")],
              fontsize=5.8, frameon=False, loc="lower right")
    style_axis(ax)
    chosen = select_path_reference_display(evidence)
    for position, axis in enumerate(axes[1:]):
        row = chosen[position] if position < len(chosen) else None
        title = f"Evidence {position + 1}/5 · " + ("Earliest covered path anomaly" if position == 0 else "Later anomaly on the same path")
        if row is None:
            message = "No qualifying historical path anomaly" if position == 0 else "No additional qualified anomaly on this path"
            axis.text(.5, .5, title + "\n" + message + "\nCoverage gaps do not establish normality", ha="center", va="center", color=PALETTE["ink"], fontsize=8)
            axis.axis("off")
            continue
        plot_shared_waveform(axis, mapped, row, f"{title} · barcode {int(row['planned_order'])}")
        context = ("Surviving-path comparison is time-confounded" if row["survivor_context_time_confounded"] else
                   "No qualified historical context for surviving paths" if not row["surviving_paths_reference_scored"] else
                   f"Surviving paths also reference-positive: {int(row['surviving_paths_reference_positive'])}/{int(row['surviving_paths_reference_scored'])}")
        scope_label = "Cross-instrument normalized shape" if reference_unit(row) == "dimensionless_shape" else "Same-instrument raw-count reference"
        axis.set_title(shared_waveform_heading(mapped[mapped["operation_id"].eq(row["operation_id"])].iloc[0],
                                               f"{title} · barcode {int(row['planned_order'])}") + f"\n{context}",
                       loc="left", color=PALETTE["ink"], fontsize=6.3, fontweight="bold")
        axis.set_title(axis.get_title(loc="left") + f"\n{scope_label}", loc="left", fontsize=6.3, fontweight="bold", color=PALETTE["ink"])
        controls = mapped[mapped["group_id"].eq(row["group_id"]) & mapped["path_status"].eq("survivor")].drop_duplicates("operation_id")
        if not controls.empty:
            controls = collapse_paths(controls)
            for index, curve in enumerate(controls["observed_profile"]):
                values = parse_profile(curve)
                if len(values) == 32:
                    if reference_unit(row) == "dimensionless_shape":
                        try:
                            values = normalize_shape(values)
                        except ValueError:
                            continue
                    axis.plot(np.linspace(0, 100, 32), values, color=PALETTE["teal"], lw=.85, alpha=.45,
                              label="matched surviving path (internal context)" if index == 0 else None)
            axis.legend(fontsize=5, frameon=False, loc="best")
    for label, axis in zip("ABCDEF", axes):
        axis.text(-.1, 1.15, label, transform=axis.transAxes, fontsize=10, fontweight="bold", color=PALETTE["ink"])
    fig.suptitle("Barcode-path historical-reference fallback", y=.975, fontsize=16, fontweight="bold", color=PALETTE["ink"])
    fig.text(.5, .925, f"{observation_id} · {material} · triggered by insufficient within-run replication", ha="center", fontsize=8, color=PALETTE["ink"])
    fig.text(.5, .07, "Reference-only exploratory evidence: no group AUC/p-value or measured delivery error. Later anomalies are not proven propagation.\n"
             "Same-instrument raw history first; cross-instrument fallback is normalized shape only, not amplitude calibration. Gray crosses remain unresolved.",
             ha="center", fontsize=7, color=PALETTE["ink"])
    stem = f"qpm_barcode_reference_{material.lower()}"
    png, pdf = output_dir / f"{stem}.png", output_dir / f"{stem}.pdf"
    fig.savefig(png, dpi=300, facecolor=PALETTE["paper"])
    fig.savefig(pdf, facecolor=PALETTE["paper"])
    plt.close(fig)
    return png, pdf


def make_figure(
    output_dir: Path,
    observation_id: str,
    lineage: pd.DataFrame,
    focus_material: str | None,
    mapped: pd.DataFrame,
    evidence: pd.DataFrame,
    config: dict[str, Any],
    shared_scores: pd.DataFrame | None = None,
    shared_evidence: pd.DataFrame | None = None,
    trigger: dict | None = None,
    shared_mode: bool = False,
) -> tuple[Path, Path]:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 6.2,
            "axes.labelsize": 5.8,
            "axes.titlesize": 7.5,
            "xtick.labelsize": 5.2,
            "ytick.labelsize": 5.2,
            "axes.linewidth": 0.65,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig = plt.figure(figsize=(16.5, 13.8), facecolor=PALETTE["paper"])
    grid = fig.add_gridspec(
        3, 3, left=0.075, right=0.985, bottom=0.14, top=0.87,
        wspace=0.34, hspace=0.55, width_ratios=[1.05, 1.12, 1.0],
    )
    axes = [fig.add_subplot(grid[row, col]) for row in range(3) for col in range(3)]
    axes[-1].set_axis_off()
    plot_barcode_outcomes(axes[0], lineage)
    plot_process_logic(axes[1], lineage, focus_material, evidence, mapped)
    plot_auc_scan(axes[2], evidence, config)
    initial_rows = (
        evidence[evidence["evidence_role"].eq("initial_candidate")]
        if not evidence.empty and "evidence_role" in evidence.columns
        else pd.DataFrame()
    )
    initial = initial_rows.iloc[0] if not initial_rows.empty else None
    support_rows = (
        evidence[
            evidence["evidence_role"].isin(
                ["same_transaction_confirmation", "downstream_support"]
            )
        ].sort_values("first_operation_index")
        if not evidence.empty and "evidence_role" in evidence.columns
        else pd.DataFrame()
    )
    def support_stage(family: object) -> str:
        text = str(family).lower()
        if "adapter-ligation" in text or "ligation-mastermix" in text:
            return "adapter_ligation"
        if "ampure" in text:
            return "ampure"
        if "target-amplification" in text or "dna-at" in text or "rna-at" in text:
            return "target_amplification"
        if "udg" in text:
            return "udg"
        return re.sub(r"[^a-z]+", "_", text).strip("_")

    support: list[pd.Series] = []
    same_transaction = (
        support_rows[
            support_rows["evidence_role"].eq("same_transaction_confirmation")
        ]
        if not support_rows.empty
        else pd.DataFrame()
    )
    downstream = (
        support_rows[support_rows["evidence_role"].eq("downstream_support")]
        if not support_rows.empty
        else pd.DataFrame()
    )
    if not same_transaction.empty:
        support.append(same_transaction.iloc[0])
    used_stages = {support_stage(row["family"]) for row in support}
    for _, row in downstream.iterrows():
        stage = support_stage(row["family"])
        if stage in used_stages:
            continue
        support.append(row)
        used_stages.add(stage)
        if len(support) >= EVIDENCE_WAVEFORM_SLOTS - 1:
            break
    if len(support) < EVIDENCE_WAVEFORM_SLOTS - 1:
        selected_ids = {str(row["group_id"]) for row in support}
        for _, row in support_rows.iterrows():
            if str(row["group_id"]) in selected_ids:
                continue
            support.append(row)
            selected_ids.add(str(row["group_id"]))
            if len(support) >= EVIDENCE_WAVEFORM_SLOTS - 1:
                break
    # Display support chronologically and only after the qualifying initial.
    support = sorted([row for row in support if initial is not None and
                      row["first_operation_index"] > initial["first_operation_index"]],
                     key=lambda row: row["first_operation_index"])
    chosen_internal = ([initial] + support[:EVIDENCE_WAVEFORM_SLOTS - 1]) if initial is not None else []
    for position, ax in enumerate(axes[3:8]):
        row = chosen_internal[position] if position < len(chosen_internal) else None
        title = f"Evidence {position + 1}/5 · " + ("Earliest divergence" if position == 0 else "Later support")
        plot_group_waveforms(ax, mapped, row, title)
    if shared_mode:
        shared_scores = shared_scores if shared_scores is not None else pd.DataFrame()
        shared_evidence = shared_evidence if shared_evidence is not None else pd.DataFrame()
        for ax in axes[1:8]:
            ax.clear()
        plot_shared_process_logic(axes[1], shared_evidence, trigger)
        plot_shared_reference_scan(axes[2], shared_evidence, config)
        chosen = select_shared_display(shared_evidence)
        for index, ax in enumerate(axes[3:8]):
            row = chosen[index] if len(chosen) > index else None
            title = f"Evidence {index + 1}/5 · " + ("Earliest reference deviation" if index == 0 else
                     "Later anomaly · relationship unproven")
            plot_shared_waveform(ax, shared_scores, row, title)
    for label, ax in zip("ABCDEFGH", axes[:8]):
        if ax.axison or label == "B":
            ax.text(-0.10, 1.10, label, transform=ax.transAxes, fontsize=8.5, fontweight="bold", va="top", color=PALETTE["ink"], clip_on=False)
    fig.suptitle(
        "QPM shared-path reference diagnostic" if shared_mode else "QPM dropout / imbalance diagnostic",
        y=0.98, fontsize=15, fontweight="bold", color=PALETTE["ink"],
    )
    fig.text(
        0.5, 0.94,
        f"{observation_id} · " + ((f"physical-operation {shared_evidence.iloc[0]['reference_time_policy']} references · same instrument · exploratory" if not shared_evidence.empty else "physical-operation references · coverage unresolved") if shared_mode else f"focus: {focus_material or 'none'} · within-run affected versus surviving paths · history optional"),
        ha="center", fontsize=7.5, color=PALETTE["ink"],
    )
    fig.legend(
        handles=[
            Line2D([0], [0], color=PALETTE["coral"], lw=2, label="affected-path median"),
            Line2D([0], [0], color=PALETTE["teal"], lw=2, label="surviving-path median"),
            Line2D([0], [0], color=PALETTE["ink"], lw=0.8, ls="--", label="baseline-centered zero"),
            Line2D([0], [0], marker="o", color="none", markerfacecolor=PALETTE["coral"], label="initial candidate"),
            Line2D([0], [0], marker="o", color="none", markerfacecolor=PALETTE["gold"], label="later support"),
            Line2D([0], [0], marker="o", color="none", markerfacecolor=PALETTE["gray"], label="not selective"),
        ],
        loc="lower center", bbox_to_anchor=(0.5, 0.075), ncol=6,
        frameon=False, fontsize=6.0,
    )
    if shared_mode:
        for legend in list(fig.legends):
            legend.remove()
    fig.text(
        0.5, 0.025,
        "QPM values are raw sensor counts. Earliest = earliest qualifying covered "
        + ("reference deviation" if shared_mode else "affected-path divergence")
        + "; not a proven cause. Delivered volume is NOT measured; any validated ML output recognizes nominal command signatures only.",
        ha="center", fontsize=6.2, color=PALETTE["ink"],
        bbox={"boxstyle": "round,pad=0.38", "fc": PALETTE["pale_teal"], "ec": PALETTE["teal"], "lw": 0.7},
    )
    stem = "qpm_shared_path_diagnostic" if shared_mode else "qpm_dropout_diagnostic"
    png = output_dir / f"{stem}.png"
    pdf = output_dir / f"{stem}.pdf"
    fig.savefig(png, dpi=300, facecolor=PALETTE["paper"])
    fig.savefig(pdf, dpi=300, facecolor=PALETTE["paper"])
    plt.close(fig)
    return png, pdf


def conclusion_payload(
    observation_id: str,
    lineage: pd.DataFrame,
    evidence_by_material: dict[str, pd.DataFrame],
) -> dict[str, Any]:
    materials: dict[str, Any] = {}
    for material in ["DNA", "RNA"]:
        calls = lineage[
            (~lineage["is_control"]) & lineage["material_type"].eq(material)
        ]
        if calls.empty:
            continue
        evidence = evidence_by_material.get(material, pd.DataFrame())
        initial_rows = (
            evidence[evidence["evidence_role"].eq("initial_candidate")]
            if not evidence.empty
            else pd.DataFrame()
        )
        support_rows = (
            evidence[
                evidence["evidence_role"].isin(
                    ["same_transaction_confirmation", "downstream_support"]
                )
            ]
            if not evidence.empty
            else pd.DataFrame()
        )
        initial = initial_rows.iloc[0].to_dict() if not initial_rows.empty else None
        materials[material] = {
            "planned_noncontrol_barcodes": int(len(calls)),
            "dropout_barcodes": int(calls["apparent_dropout"].sum()),
            "imbalanced_barcodes": int(calls["outcome_class"].isin(["partial_imbalance", "overrepresented"]).sum()),
            "surviving_barcodes": int(calls["outcome_class"].eq("surviving").sum()),
            "initial_candidate": (
                {
                    "step": group_short_label(initial),
                    "operation_index": int(initial["first_operation_index"]),
                    "failed_path_deviation_auc": float(initial["failed_path_deviation_auc"]),
                    "permutation_p": float(initial["permutation_p"]),
                    "bh_fdr_q": (
                        None if pd.isna(initial["bh_fdr_q"]) else float(initial["bh_fdr_q"])
                    ),
                    "reference_interpretation": initial["reference_interpretation"],
                    "comparison_basis": initial["comparison_basis"],
                    "historical_reference_required": False,
                    "historical_confirmation_status": initial["historical_confirmation_status"],
                    "permutation_method": initial["permutation_method"],
                    "permutation_statistic": initial["permutation_statistic"],
                    "within_run_energy_distance": float(initial["within_run_energy_distance"]),
                    "statistical_interpretation": initial["statistical_interpretation"],
                }
                if initial is not None
                else None
            ),
            "later_support_steps": [
                {
                    "step": row.step_label,
                    "role": row.evidence_role,
                    "operation_index": int(row.first_operation_index),
                    "failed_path_deviation_auc": float(row.failed_path_deviation_auc),
                    "bh_fdr_q": None if pd.isna(row.bh_fdr_q) else float(row.bh_fdr_q),
                }
                for row in support_rows.itertuples(index=False)
            ],
            "interpretation": (
                "dropout/imbalance present; initial QPM divergence localized"
                if initial is not None
                else "dropout/imbalance present but no sufficiently replicated selective QPM step was localized"
                if calls["path_status"].eq("failed").any()
                else "no material-specific sample dropout or imbalance"
            ),
        }
    return {
        "plugin_version": VERSION,
        "observation_id": observation_id,
        "generated_utc": utc_now(),
        "materials": materials,
        "causal_guardrail": (
            "QPM evidence is diagnostic and hypothesis-generating. It does not prove "
            "delivered volume, barcode-dropout causality, or a setting change."
        ),
    }


def dataframe_for_html(frame: pd.DataFrame, columns: list[str], max_rows: int = 30) -> str:
    if frame.empty:
        return "<p class='muted'>No rows available.</p>"
    selected = frame[[column for column in columns if column in frame.columns]].head(max_rows).copy()
    for column in selected.select_dtypes(include=[np.number]).columns:
        selected[column] = selected[column].map(
            lambda value: "" if pd.isna(value) else f"{value:.4g}"
        )
    return selected.to_html(index=False, border=0, classes="data-table", escape=True)


def build_diagnostic_workflow(
    lineage: pd.DataFrame, trigger: dict[str, Any], csa_diagnostics: dict[str, Any],
) -> dict[str, Any]:
    """Route existing outcome calls without turning associations into causes.

    QPM is the only explanation source for a barcode-selective issue. ML
    metrics concern run-wide total reads and never fill a missing QPM cause.
    Missing/partial barcode coverage remains explicit, even if reads are low.
    """
    controls = lineage.get("is_control", pd.Series(pd.NA, index=lineage.index))
    samples = lineage.loc[~controls.eq(True).fillna(False)]
    classes = samples.get("outcome_class", pd.Series("unresolved", index=samples.index))
    known = classes.isin(["surviving", "dropout", "partial_imbalance", "overrepresented"])
    known &= controls.reindex(samples.index).eq(False).fillna(False)
    evaluable = int(known.sum())
    unresolved = int(len(samples) - evaluable)
    coverage = "complete" if len(samples) and not unresolved else "partial" if evaluable else "unresolved"
    material_counts = samples.loc[known].get("material_type", pd.Series(dtype=str)).value_counts()
    sparse_material = any(int(count) < 2 for count in material_counts.values)
    default_barcode_status = "not_detected_in_evaluable_barcodes" if coverage == "complete" else "unresolved_or_partial_barcode_coverage"
    dropout_status = "detected" if trigger.get("has_dropout") else default_barcode_status
    imbalance_status = ("detected" if trigger.get("has_imbalance") else
                        "unresolved_insufficient_material_replication" if sparse_material else default_barcode_status)
    low = bool(trigger.get("below_chip_lane_read_criterion") or trigger.get("low_outcomes"))
    criterion = trigger.get("chip_lane_read_criterion", {})
    absolute_status = criterion.get("total_read_criterion_status", "unresolved")
    low_status = "detected" if low else "not_triggered_by_available_checks" if absolute_status == "passed" else "unresolved_absolute_read_criterion"
    barcode_common = dict(explanation_sources=["qpm"], ml_metrics_allowed_as_barcode_reason=False,
        same_run_display_minimum_affected_paths=1, same_run_display_minimum_surviving_paths=1,
        formal_statistical_minimum_not_relaxed=True,
        evidence_scope="barcode_path_qpm_only", causal_status="candidate_explanations_not_proven_causes")
    top5 = csa_diagnostics.get("top5_ml_metrics", [])
    return dict(
        version="csa-diagnostic-workflow-1.0.0",
        barcode_coverage=dict(status=coverage, recorded_noncontrol_or_unknown_rows=len(samples),
            evaluable_noncontrol_barcodes=evaluable, unresolved_rows=unresolved,
            scope="Recorded DNA/RNA barcodes only; controls excluded; absent/unknown data are not a pass"),
        barcode_dropout=dict(status=dropout_status, detected=bool(trigger.get("has_dropout")), **barcode_common),
        barcode_imbalance=dict(status=imbalance_status, detected=bool(trigger.get("has_imbalance")), **barcode_common),
        low_performance=dict(status=low_status, triggered=low,
            triggers=(["below_chip_lane_total_read_criterion"] if trigger.get("below_chip_lane_read_criterion") else []) + list(trigger.get("low_outcomes", [])),
            explanation_sources=["qpm", "total_read_ml_metrics"], report_parts=[1, 2] if low else [],
            ml_status=csa_diagnostics.get("status", "unresolved"), top5_feature_count=len(top5),
            top5_ml_policy=csa_diagnostics.get("top5_ml_policy", {}),
            root_cause_assessment_status=csa_diagnostics.get("root_cause_assessment", {}).get("status", "unresolved"),
            root_cause_hypothesis_count=len(csa_diagnostics.get("root_cause_assessment", {}).get("hypotheses", [])),
            ml_evidence_scope="Global total-read model importance plus separately qualified case measurements; not a read-length/accuracy explanation or a barcode-specific cause",
            causal_status="candidate_explanations_not_proven_causes"),
        report_parts=[dict(part=1, id="qpm-investigation", required=True, title="QPM investigation"),
                      dict(part=2, id="csa-low-performance-diagnostics", required=low, title="Total-read ML metrics and CSA evidence")],
        no_ml_substitution_for_missing_barcode_qpm=True,
        missing_evidence_does_not_establish_normality=True,
        settings_modified=False,
    )


def diagnostic_workflow_html(workflow: dict[str, Any]) -> str:
    """Explicit detection and explanation scope before either report part."""
    esc = lambda value: html.escape(str(value), quote=True)
    rows = []
    for key, label, source in [
        ("barcode_dropout", "Sample dropout", "QPM only — mapped affected/surviving barcode paths"),
        ("barcode_imbalance", "Barcode imbalance", "QPM only — mapped affected/surviving barcode paths"),
        ("low_performance", "Low performance", "Part 1: QPM; Part 2: direction-checked low-read hypotheses, top-five ML table and supported CSA diagnostics"),
    ]:
        finding = workflow.get(key, {})
        if key == "low_performance" and not finding.get("triggered"):
            source = "Not triggered — no total-read ML explanation section; QPM audit retained"
        rows.append(f"<tr><td>{label}</td><td>{esc(finding.get('status', 'unresolved').replace('_', ' '))}</td><td>{source}</td></tr>")
    nav = '<a href="#qpm-investigation">Part 1 — QPM investigation</a>'
    if workflow.get("low_performance", {}).get("triggered"):
        nav += ' · <a href="#csa-low-performance-diagnostics">Part 2 — Total-read ML metrics</a>'
    return f'''<section id="diagnostic-routing"><h2>What was detected and how it is investigated</h2>
<table class="data-table"><thead><tr><th>Finding</th><th>Detection status</th><th>Permitted explanation source</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<p>Barcode evidence coverage: <strong>{esc(workflow.get('barcode_coverage', {}).get('status', 'unresolved'))}</strong>. DNA/RNA are evaluated separately and controls excluded. Missing barcode outcomes do not mean no dropout.</p>
<p class="guard">For dropout or imbalance, potential reasons come from QPM evidence only. A low-read run receives two separate investigation parts. Total-read ML rankings never substitute for missing barcode-path QPM evidence. No qualifying evidence means the reason remains unresolved; no root cause or lost-read amount is manufactured.</p>
<p class="files">{nav} · <a href="diagnostic_workflow.json">Decision and evidence-routing audit</a></p></section>'''


def make_html_report(
    output_dir: Path,
    observation_id: str,
    lineage: pd.DataFrame,
    focus_material: str | None,
    evidence: pd.DataFrame,
    conclusions: dict[str, Any],
    warnings: list[str],
    figure_path: Path,
    outcome_summary: pd.DataFrame,
    outcome_context: pd.DataFrame,
    shared_evidence: pd.DataFrame,
    volume_proxies: pd.DataFrame,
    shared_figure: Path | None,
    barcode_reference_evidence: pd.DataFrame | None = None,
    barcode_reference_summary: pd.DataFrame | None = None,
    barcode_reference_figures: dict[str, Path] | None = None,
) -> Path:
    encoded = base64.b64encode(figure_path.read_bytes()).decode("ascii")
    workflow = conclusions.get("diagnostic_workflow") or build_diagnostic_workflow(
        lineage, conclusions["qpm_trigger"], conclusions.get("csa_low_performance_diagnostics", {}))
    low_performance = workflow["low_performance"]["triggered"]
    csa_report_part = (csa_low_performance_html(conclusions.get("csa_low_performance_diagnostics", {}))
                       if low_performance else "")
    material_summary = conclusions["materials"].get(focus_material or "", {})
    initial = material_summary.get("initial_candidate")
    if initial:
        headline = f"Earliest localized {html.escape(focus_material or '')} divergence: {html.escape(initial['step'])}"
        detail = (
            f"AUC {initial['failed_path_deviation_auc']:.2f}; permutation p "
            f"{initial['permutation_p']:.3f}; BH q "
            f"{initial['bh_fdr_q']:.3f}" if initial["bh_fdr_q"] is not None else
            f"AUC {initial['failed_path_deviation_auc']:.2f}; permutation p {initial['permutation_p']:.3f}; BH q unavailable"
        )
        detail += "; exploratory localization, not a demonstrated cause or delivered-volume measurement."
    else:
        shared_initial = conclusions["shared_path_reference"].get("earliest_reference_deviation")
        if not conclusions["qpm_trigger"]["run_qpm"]:
            headline = "No barcode/outcome trigger; all three QPM comparisons are audited below"
            detail = "No affected-versus-surviving contrast can be inferred without affected paths. Historical scans remain separate exploratory evidence; missing outcome peers do not establish normal performance."
        elif conclusions["report_branch"] == "barcode_path_reference_fallback":
            fallback = material_summary.get("reference_fallback", {})
            path_anomalies = fallback.get("earliest_path_anomalies", [])
            first = min(path_anomalies, key=lambda row: row["operation_index"]) if path_anomalies else None
            headline = (f"{html.escape(focus_material or '')} barcode {int(first['planned_order'])}: earliest covered historical QPM anomaly at op {int(first['operation_index'])}"
                        if first else "Insufficient within-run replication: barcode-path historical-reference fallback")
            detail = (f"{fallback.get('reference_scored_operations', 0)} affected-path operations have qualified references; "
                      f"{fallback.get('unresolved_operations', 0)} remain unresolved. Reference anomalies are not replicated barcode-group evidence or proven dropout causes.")
        elif conclusions["report_branch"] == "within_run_barcode_comparison":
            headline = "Barcode dropout/imbalance detected; no qualifying within-run divergence localized"
            detail = "Historical-reference shortage does not gate the internal comparison. Check matched-path replication, configuration, timing, and lineage coverage; later reference-only anomalies are separate evidence."
        else:
            headline = (f"Earliest reference-only deviation: operation {int(shared_initial['operation_index'])}"
                        if shared_initial else "No qualifying QPM divergence was localized")
            detail = "Reference-only deviations are common-mode hypotheses, not barcode-selective evidence or proven causes."
    shared_image = ("<p>The shared-path figure is shown in the integrated view above.</p>" if shared_figure == figure_path
                    else f'<img src="data:image/png;base64,{base64.b64encode(shared_figure.read_bytes()).decode("ascii")}" alt="Shared-path reference QPM scan">'
                    if shared_figure is not None else "<p>Shared-path reference scan was not indicated or had no adequate reference coverage.</p>")
    trigger_text = html.escape(", ".join(conclusions["qpm_trigger"]["reasons"]) or "none")
    warning_html = "".join(f"<li>{html.escape(item)}</li>" for item in warnings) or "<li>None</li>"
    fallback_evidence = barcode_reference_evidence if barcode_reference_evidence is not None else pd.DataFrame()
    fallback_summary = barcode_reference_summary if barcode_reference_summary is not None else pd.DataFrame()
    fallback_images = "".join(
        f'<h3>{html.escape(material)} affected-path reference fallback</h3><img src="data:image/png;base64,{base64.b64encode(path.read_bytes()).decode("ascii")}" alt="{html.escape(material)} barcode-path reference fallback">'
        for material, path in (barcode_reference_figures or {}).items()
        if path != figure_path
    )
    parallel_baselines = baseline_html_section(output_dir, conclusions["baseline_comparison"])
    nominal_model_text = (
        "A hash-pinned, command-corrected model registry is active. Only validated single-operation nominal-volume signatures may be recognized; unsupported contexts and target physical runs present in model training abstain."
        if conclusions.get("volume_proxy", {}).get("registry_sha256") else
        "No validated in-scope nominal-volume prediction was activated for these candidate operations. Legacy inherited-liquid-class classifiers are not restored for command-corrected operations.")
    volume_display = volume_proxies.copy()
    if not volume_display.empty:
        volume_display["estimate_available"] = volume_display.waveform_equivalent_volume_ul.notna()
        order = [c for c in ["estimate_available", "volume_proxy_nominated_evidence", "operation_index"] if c in volume_display]
        volume_display = volume_display.sort_values(order, ascending=[c == "operation_index" for c in order])
        volume_counts = volume_proxies.volume_proxy_status.value_counts().rename_axis("status").reset_index(name="operations")
    else:
        volume_counts = pd.DataFrame(columns=["status", "operations"])
    criterion = conclusions["qpm_trigger"].get("chip_lane_read_criterion", {})
    criterion_table = dataframe_for_html(pd.DataFrame([criterion]), [
        "chip_type", "evaluated_lane_count", "total_reads_value", "total_reads_threshold",
        "total_read_criterion_status", "low_performance_trigger", "qualification_status", "reference_eligible", "qualification_reasons"], 1)
    criterion_html = f'''<section id="read-criterion"><h2>Chip/lane read criterion and reference qualification</h2>
<p>The user-specified minimum is <strong>12.5 million reads per analyzed GX5 lane, 25 million per GX7 or GX8 lane, and 50 million per GX9 lane</strong> (one to four analyzed lanes). GX7 and GX8 share read criteria: 25, 50, 75 and 100 million reads for one, two, three and four analyzed lanes. Equality passes; below the minimum triggers low-performance investigation even when no historical outcome peers exist. Unknown chip, analyzed-lane scope or read count is unresolved, never a pass. Equal cutoffs do not merge chip identities for outcome-peer or chip-contact waveform matching.</p>
{criterion_table}
<p>Both historical waveform populations now require a passing read criterion and no detected noncontrol DNA/RNA barcode dropout or imbalance. Known failing or unresolved sibling scopes cannot provide a healthy-reference vote. Matching geometry, liquid class, volume, pipette and command settings remains required after this outcome gate. Outcome-qualified is a screening definition, not proof that a run or every operation was fault-free.</p>
<p>Read thresholds use the lanes represented by the CSA's analyzed outcome, not the instrument's active-lane count when other lanes are absent. Missing lane totals are not invented; overlapping exports are never summed. See the audit for scope provenance and exclusion reasons.</p>
<p class="files"><a href="historical_reference_qualification.csv">Every run's read and barcode eligibility</a><a href="reference_qualification_manifest.json">Qualification policy and input provenance</a></p></section>'''
    quality = conclusions.get("trace_quality", {})
    quality_html = ""
    if quality:
        excluded = pd.read_csv(output_dir / "qpm_excluded_traces.csv")
        quality_html = f'''<section id="trace-quality"><h2>Er72 trace-quality gate — before scoring and evidence selection</h2>
<p class="guard">Er72 traces are excluded from target waveform scores, affected/surviving templates, same-instrument references, cross-instrument references, and earliest/later evidence plots. An Er72 on any retry excludes the entire recorded operation, even if a later retry succeeds. Unknown trace status is unresolved, not normal. Raw archives and barcode outcome calls are unchanged.</p>
<p>Target: {quality['target_eligible_waveforms']} eligible waveforms; {quality['target_er72_excluded_waveforms']} Er72-associated waveforms excluded; {quality['target_other_unresolved_waveforms']} other unverified waveforms excluded. Bank-wide: {quality['bank_excluded_waveforms']} waveform exclusions before physical matching (not the size of any individual reference cohort).</p>
{dataframe_for_html(excluded, ['operation_index','workflow_stage','process_step','operation','pipette','programmed_volume_ul','loc','qpm_trace_quality_status','qpm_er72_command_ids','qpm_exclusion_reason'], 50)}
<p class="files"><a href="qpm_excluded_traces.csv">All excluded target traces</a><a href="qpm_reference_excluded_traces.csv">Excluded bank traces</a><a href="qpm_trace_quality_manifest.json">Error-association policy and archive audit</a></p></section>'''
    report = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CSA diagnostic investigation — {html.escape(observation_id)}</title>
<style>
:root{{--ink:#264653;--teal:#2A9D8F;--gold:#E9C46A;--orange:#F4A261;--coral:#E76F51;--paper:#FCFCF8;--grid:#D9DED9}}
body{{font-family:Arial,sans-serif;background:var(--paper);color:var(--ink);margin:0;line-height:1.45}}
main{{max-width:1320px;margin:0 auto;padding:28px}}
h1,h2{{color:var(--ink)}} h1{{margin-bottom:4px}} h2{{margin-top:34px;border-bottom:1px solid var(--grid);padding-bottom:6px}}
.subtitle,.muted{{color:#65716D}} .hero{{background:#E8F3EF;border-left:6px solid var(--teal);padding:18px 22px;border-radius:8px}}
.guard{{background:#FBF2D8;border:1px solid var(--gold);padding:12px 16px;border-radius:8px}}
img{{width:100%;height:auto;border:1px solid var(--grid);background:white}}
.data-table{{border-collapse:collapse;width:100%;font-size:12px;display:block;overflow-x:auto}}
.data-table th,.data-table td{{border-bottom:1px solid var(--grid);padding:7px 9px;text-align:left;white-space:nowrap}}
.data-table th{{background:#E8F3EF;position:sticky;top:0}}
.files a{{color:#1A6F65;margin-right:18px}} code{{background:#F1F1ED;padding:2px 4px}}
.same-run-curve{{background:white;border:1px solid var(--grid);border-radius:5px;padding:12px;margin:12px 0}}
.same-run-curve summary{{cursor:pointer;font-weight:bold}} .same-run-curve svg{{max-width:100%;height:auto}}
#run-information{{background:white;border:1px solid var(--grid);border-top:4px solid var(--teal);border-radius:8px;padding:14px 20px;margin:18px 0}}
#run-information h2{{margin-top:0;border:0}}
.run-info-grid{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px 24px;margin:14px 0}}
.run-info-grid div{{min-width:0}} .run-info-grid dt{{font-size:12px;color:#65716D;text-transform:uppercase;letter-spacing:.04em}}
.run-info-grid dd{{margin:4px 0 0;font-weight:600;overflow-wrap:anywhere}}
.run-info-grid div:nth-child(n+5){{grid-column:span 2}} .run-detail{{overflow-wrap:anywhere}}
@media(max-width:760px){{.run-info-grid{{grid-template-columns:repeat(2,minmax(0,1fr))}} main{{padding:16px}}}}
@media(max-width:420px){{.run-info-grid{{grid-template-columns:minmax(0,1fr)}} .run-info-grid div:nth-child(n+5){{grid-column:span 1}}}}
</style></head><body><main>
<h1>CSA performance and QPM dropout/imbalance diagnostic</h1>
<p class="subtitle"><code>{html.escape(observation_id)}</code> · focus material: {html.escape(focus_material or "none")}</p>
{run_metadata_html(conclusions.get('run_metadata', {}))}
<p>QPM trigger: {trigger_text}. Low-performance checks: absolute chip/lane read minimum, plus matched-peer {html.escape(conclusions['qpm_trigger']['performance_boundary'])} where available. Missing references do not mean normal performance.</p>
{diagnostic_workflow_html(workflow)}
{criterion_html}
<section id="qpm-investigation" data-report-part="1"><h2>Part 1 — QPM investigation</h2>
<p>Barcode dropout/imbalance is investigated using QPM evidence only. When low performance is also detected, this part separately reviews run-wide QPM anomalies; Part 2 reviews ML-ranked total-read metrics. Shared-path anomalies are not automatically barcode-selective evidence.</p>
<p class="files"><a href="#same-run-affected-survivor-curves">Every physically comparable same-run affected/surviving curve — including fewer than three affected barcodes</a></p>
<section class="hero"><h2 style="margin-top:0;border:0">{headline}</h2><p>{html.escape(detail)}</p></section>
<p class="guard">{html.escape(conclusions["causal_guardrail"])}</p>
{parallel_baselines}
{quality_html}
{same_run_curves_html(conclusions.get('same_run_curve_display', {}))}
<h2>Integrated diagnostic view</h2>
<img src="data:image/png;base64,{encoded}" alt="Barcode dropout and QPM diagnostic multipanel figure">
<h2>Outcome benchmark against matched prior physical runs</h2>
<p>References must pass the chip/lane read and barcode-balance gate, then match chip type, assay/panel identity, workflow, flow settings, run mode, software, sequencing kit, and DNA/RNA barcode counts. Each physical run contributes one aggregate value. The target and its sibling lanes are excluded. The 5th–95th percentile range describes the empirical peer distribution. Sparse cohorts and cross-instrument pooling are explicitly labeled. Unrecorded loading concentration and input quality remain unverified.</p>
{dataframe_for_html(outcome_summary, ["outcome","target_value","reference_median","reference_q05","reference_q95","target_pct_of_reference_median","reference_physical_runs","reference_instruments","match_level","status","percentile_precision"], 10)}
<h2>Outcome matching metadata</h2>
{dataframe_for_html(outcome_context, ["field","target_value","status"], 40)}
<h2>Barcode outcome calls</h2>
{dataframe_for_html(lineage, ["material_type","planned_order","read_count","relative_to_material_median","outcome_class","workflow_block","barcode_plate_well"], 50)}
<h2>Chronological QPM evidence</h2>
<p>Primary barcode-path analysis uses raw baseline-centered waveforms from this run, not historical residuals. Each mapped barcode/location contributes one median waveform. Actual liquid-class configuration, container/deck geometry, command modes, volume, pipette and operation must match. Each queried path is excluded from its surviving-path template. AUC describes survivor-template deviation separation. Significance is tested separately by raw-waveform energy distance using label-invariant scaling and path-level label permutations; templates and scores are also rebuilt for every assignment. BH correction covers eligible step tests. Surviving paths are an internal comparator, not certified healthy. At least three independent paths per class are required. Historical confirmation is optional and cannot suppress an otherwise eligible within-run test. AUC is not held-out run prediction accuracy or causal proof.</p>
{dataframe_for_html(evidence, ["evidence_role","step_label","first_operation_index","n_failed","n_survivor","failed_path_deviation_auc","within_run_energy_distance","permutation_p","permutation_statistic","permutation_method","bh_fdr_q","statistical_interpretation","historical_confirmation_status","minimum_reference_runs","mapping_scopes","failed_survivor_time_gap_minutes"], 50)}
<h2>Barcode-path reference fallback for insufficient replication</h2>
<p>Each insufficient-replication group with an affected path first tries same-instrument historical waveforms. If fewer than eight compatible independent runs are available, it checks <strong>other instruments</strong>, using at least eight physical runs across at least two reference instruments. Full liquid-class/container/deck definitions, command modes, phase, volume, pipette and source units must still match; chip-contact geometry also requires chip type. Only the instrument identity is relaxed. Cross-instrument curves are baseline-centered and divided by their own peak-to-peak amplitude: their <strong>dimensionless shape</strong> can be screened, but absolute pressure amplitude, over/under-delivery and delivered volume cannot be inferred. Normalization is not sensor calibration. The original raw waveforms and replicated within-run findings are unchanged.</p>
<p>Reference routing is independent of another material's finding. No group AUC, permutation p-value or BH q is manufactured. Earliest and later anomalies are recorded per mapped barcode; generic shared-operation anomalies are not substituted. Surviving-path reference context uses the same comparison scale; raw and normalized screens are not equated. Repeated attempts do not increase independent n. Missing definitions or lineage, sparse history and flat cross-instrument traces remain unresolved. Reference percentiles are exploratory, not validated false-positive probabilities; an uncovered earlier step can still contain the actual problem.</p>
{dataframe_for_html(fallback_summary, ["material_type","planned_order","fallback_operations","reference_scored_operations","same_instrument_scored_operations","cross_instrument_shape_scored_operations","unresolved_operations","reference_anomaly_operations","earliest_reference_operation_index","earliest_reference_step","status"], 50)}
{fallback_images}
{dataframe_for_html(fallback_evidence, ["material_type","planned_order","operation_index","step_label","operation","n_failed","n_survivor","fallback_status","reference_scope","reference_profile_unit","exclusion_reasons","same_instrument_available_runs","cross_instrument_available_runs","reference_physical_runs","reference_instruments","qpm_anomaly_percentile","outside_90pct_envelope_fraction","survivor_context","evidence_role"], 100)}
<h2>Shared-path historical-reference evidence</h2>
<p>Waveform references share the chip/lane read and barcode-balance qualification gate, but do not inherit the outcome peers' assay/panel restrictions. Actual GA/GD commands identify the liquid class, container and deck geometry; full configuration definitions and operation-mode settings are fingerprint-matched along with aspiration/dispense, volume, instrument, pipette, and sensor unit. Exact step/location references are preferred; compatible cross-step fallback is labeled. Chip-contact operations additionally match chip type. Raw counts are never pooled across instruments. Waveform time policy: <strong>{html.escape(conclusions.get('waveform_reference', {}).get('policy', {}).get('time_policy', 'unresolved'))}</strong>; retrospective references may include later runs and are not prospective validation. Each physical run has one vote; the target and sibling lanes are excluded. Missing definitions or insufficient references mean unresolved, not normal. Earliest means earliest qualifying covered operation, not earliest physical failure. Display retains earliest and up to four later qualifying anomalies, favoring distinct steps and showing them chronologically. Later abnormalities have an unproven relationship to the first.</p>
{shared_image}
{dataframe_for_html(shared_evidence, ["evidence_role","operation_index","workflow_stage","process_step","location","operation","programmed_volume_ul","liquid_class_index","qpm_shape_score","qpm_anomaly_percentile","outside_90pct_envelope_fraction","reference_physical_runs","matched_reference_level"], 50)}
<h2>ML nominal-volume signature — not delivered-volume measurement</h2>
<p><strong>{html.escape(nominal_model_text)}</strong></p>
<p>The expanded study uses authoritative commanded liquid classes and individual waveforms, with Er72 exclusions, physical-run grouping, nested model selection, held-out instruments and chronological testing. Registered models are fitted retrospectively: a target must be absent from their training physical runs, and exact validated liquid-class, volume-level, geometry, command-setting, pipette and sensor-unit support is required. A nominal-signature estimate or ΔµL expresses waveform resemblance to commanded training volumes, <strong>not the actual volume transferred, an over/under-aspiration or dispense amount, or a demonstrated failure cause</strong>. Cross-instrument sensors are not calibrated transfer meters. Missing validation or incompatible settings abstain; no extrapolation is licensed. Independent measured-volume calibration is required before any delivery-error claim. Detailed model comparisons and uncertainty are in the separately validated study.</p>
<p>Every quality-cleared target QPM operation is attempted, not only the displayed anomalies. Available estimates appear first below. Validation MAE is a task-level average error on unseen instruments, not an individual confidence interval. A signature difference smaller than that error scale is not strong quantitative evidence. All operations and abstention reasons are retained in <a href="qpm_volume_proxies.csv">the full volume-signature CSV</a>.</p>
{dataframe_for_html(volume_counts, ["status","operations"], 30)}
{dataframe_for_html(volume_display, ["operation_index","operation","pipette","liquid_class_index","programmed_volume_ul","volume_proxy_model","waveform_equivalent_volume_ul","equivalent_volume_delta_ul","equivalent_volume_delta_pct","volume_proxy_validation_mae_ul","volume_proxy_within_10pct_agreement","volume_proxy_error_scale_relation","volume_proxy_status"], 60)}
</section>
{csa_report_part}
<h2>How the conclusion is generated</h2>
<ol>
<li>Audit planned DNA and RNA barcodes separately and exclude controls.</li>
<li>Map each barcode to its physical workflow block, reaction well, and barcode well.</li>
<li>Compare failed and surviving paths at physically matched within-run operations; do not require historical references.</li>
<li>Use leave-one-path-out surviving templates, recompute them under every label permutation, and report BH-adjusted uncertainty. Historical templates are optional, separately labeled context.</li>
<li>If a group lacks sufficient affected/surviving replication, use physically matched historical references on each affected barcode's mapped path. Record the earliest covered reference anomaly and later same-path anomalies separately; retain every exclusion reason.</li>
<li>Scan operations chronologically and nominate the earliest selective divergence.</li>
<li>Label later selective operations as same-transaction confirmation or downstream support.</li>
<li>Show negative, opposite-direction, underpowered, and confounded comparisons in the evidence table.</li>
<li>Always show physically comparable same-run affected/surviving curves when at least one independent path of each class exists. Individual curves and medians are descriptive when formal replication is insufficient; no extra AUC, p-value, BH q-value, or earliest-failure claim is created.</li>
<li>Independently detect low performance from the configured chip/lane criterion or available matched-peer outcome checks. For a triggered run, show both QPM and the top five individual total-read ML features.</li>
<li>Keep global ML importance separate from case-specific reference deviations. Context, ambiguous count proxies, leakage-excluded features and unavailable measurements do not become failure causes. These metrics never explain a barcode dropout in place of QPM.</li>
</ol>
<h2>Warnings</h2><ul>{warning_html}</ul>
<h2>Files</h2><p class="files">
<a href="barcode_dropout_calls.csv">Barcode calls</a>
<a href="barcode_lineage.csv">Lineage</a>
<a href="qpm_step_evidence.csv">Step evidence</a>
<a href="qpm_barcode_reference_evidence.csv">Under-replicated barcode-path references</a>
<a href="qpm_barcode_reference_summary.csv">Barcode reference coverage summary</a>
<a href="initial_failure_candidates.json">Conclusion JSON</a>
<a href="qpm_dropout_diagnostic.pdf">Vector figure</a>
<a href="outcome_reference_summary.csv">Outcome references</a>
<a href="outcome_peer_audit.csv">Peer matching audit</a>
<a href="qpm_shared_path_evidence.csv">Shared-path evidence</a>
<a href="qpm_waveform_reference_coverage.csv">Waveform coverage and corrected labels</a>
<a href="qpm_waveform_reference_members.csv">Waveform reference membership</a>
<a href="qpm_waveform_reference_manifest.json">Waveform reference policy and provenance</a>
<a href="qpm_volume_proxies.csv">Volume proxy audit</a>
<a href="diagnostic_workflow.json">Detection and explanation routing</a>
</p>
</main></body></html>"""
    path = output_dir / "qpm_dropout_report.html"
    path.write_text(report, encoding="utf-8")
    return path


def underpowered_reference_operation_ids(
    mapped: pd.DataFrame, evidence: pd.DataFrame, minimum_runs: int,
) -> set[str]:
    """No mapped lineage is an unresolved case, not a historical candidate."""
    if mapped.empty or evidence.empty:
        return set()
    underpowered = set(evidence.loc[evidence["screen_label"].eq("insufficient_replication"), "group_id"])
    entries = mapped[mapped["group_id"].isin(underpowered)]
    lacking_same = entries["reference_physical_runs"].fillna(0).lt(minimum_runs)
    return set(entries.loc[lacking_same, "operation_id"])


def write_trace_quality_audit(output_dir: Path, observation_id: str, profiles) -> dict:
    fields = ["observation_id", "physical_run_id", "instrument_id", "archive_id", "chip_lane",
              "operation_id", "operation_index", "operation", "pipette", "programmed_volume_ul",
              "event_time", "workflow_stage", "process_step", "loc", "source_file", *QUALITY_FIELDS]
    cache = profiles[1] if profiles is not None else {}
    excluded = pd.DataFrame(cache.get("trace_quality_exclusions", []), columns=fields)
    target = excluded[excluded.observation_id.eq(observation_id)]
    bank = excluded[~excluded.observation_id.eq(observation_id)]
    target.to_csv(output_dir / "qpm_excluded_traces.csv", index=False)
    bank.to_csv(output_dir / "qpm_reference_excluded_traces.csv", index=False)
    er72 = target.qpm_has_er72.fillna(False).astype(bool)
    accepted = profiles[0] if profiles is not None else pd.DataFrame(columns=["observation_id"])
    audit = dict(version=TRACE_QUALITY_VERSION, excluded_from_all_scoring_and_evidence=True,
                 status="checked" if cache.get("trace_quality") else "unresolved_no_trace_audit",
                 target_eligible_waveforms=int(accepted.observation_id.eq(observation_id).sum()),
                 target_er72_excluded_waveforms=int(er72.sum()), target_other_unresolved_waveforms=int((~er72).sum()),
                 bank_excluded_waveforms=len(bank),
                 successful_retry_does_not_clear_exclusion=True,
                 trace_status_cache=cache.get("trace_quality", {}))
    (output_dir / "qpm_trace_quality_manifest.json").write_text(json.dumps(json_ready(audit), indent=2))
    return audit


def run_plugin(
    project: Path,
    observation_id: str,
    output_dir: Path,
    config: dict[str, Any],
    *,
    preloaded_profiles: tuple[pd.DataFrame, dict] | None = None,
) -> dict[str, Any]:
    from qpm_reference_bank import resolve_reference_bank, reference_bank_info
    project = resolve_reference_bank(project)
    bank_info = reference_bank_info(project)
    start = time.time()
    output_dir.mkdir(parents=True, exist_ok=True)
    warnings: list[str] = []
    if bank_info.get("bank_id"):
        warnings.append(f"Reference bank {bank_info['bank_id']}: {bank_info['physical_runs']} physical runs, "
                        f"{bank_info['observations']} observations, {bank_info['instruments']} instruments. "
                        "Same-run, same-instrument, and other-instrument evidence remain separate; historical bands are not certified healthy.")
    lineage, lineage_warnings, archive_path, manifest = build_barcode_lineage(
        project, observation_id, config
    )
    warnings.extend(lineage_warnings)
    run_metadata = build_run_metadata(project, observation_id)
    warnings.extend(run_metadata["warnings"])
    (output_dir / "run_metadata.json").write_text(
        json.dumps(run_metadata, indent=2, allow_nan=False), encoding="utf-8")
    qualification, qualification_metadata = load_reference_qualification(project)
    target_qualification = qualification.loc[qualification.observation_id.eq(observation_id)]
    if len(target_qualification) != 1:
        raise ValueError("Target read criterion must resolve to one observation")
    criterion = json_ready(target_qualification.iloc[0].to_dict())
    qualification.to_csv(output_dir / "historical_reference_qualification.csv", index=False)
    (output_dir / "reference_qualification_manifest.json").write_text(
        json.dumps(json_ready(qualification_metadata), indent=2, allow_nan=False))
    outcome_result = build_outcome_benchmark(
        project, observation_id, config.get("outcome_reference_policy_overrides")
    )
    write_benchmark(output_dir, outcome_result)
    outcome_summary, peer_audit, outcome_context, outcome_metadata = outcome_result
    warnings.extend(outcome_metadata["warnings"])
    trigger = diagnostic_trigger(lineage, outcome_summary, config, criterion)
    # This diagnostic layer must not depend on usable QPM or barcode waveforms.
    # Its model-level priorities are not per-case causes or a tuning ranking.
    try:
        csa_diagnostics = build_low_performance_diagnostics(
            project, observation_id, archive_path, output_dir, trigger, config)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        diagnostic_warning = f"CSA low-performance diagnostics unresolved ({type(exc).__name__}): {exc}"
        csa_diagnostics = {
            "version": CSA_DIAGNOSTIC_VERSION,
            "status": "unresolved", "observation_id": observation_id,
            "triggered": bool(trigger.get("below_chip_lane_read_criterion") or trigger.get("low_outcomes")),
            "summary": "CSA evidence could not be evaluated; missing evidence is not normal performance.",
            "warnings": [diagnostic_warning], "metrics": [], "component_priority": [],
            "plugin_inventory": [], "native_images": [], "outputs": {},
            "models_retrained": False, "instrument_settings_changed": False,
        }
        manifest_path = output_dir / "csa_low_performance_manifest.json"
        csa_diagnostics["manifest_path"] = str(manifest_path)
        manifest_path.write_text(json.dumps(json_ready(csa_diagnostics), indent=2, allow_nan=False))
    warnings.extend(f"CSA diagnostics: {item}" for item in csa_diagnostics.get("warnings", []))
    has_affected_barcodes = trigger["has_dropout"] or trigger["has_imbalance"]
    waveform_scores = pd.DataFrame()
    waveform_coverage = pd.DataFrame(columns=["operation_id", "reference_status", "reason"])
    waveform_members = pd.DataFrame(columns=["target_operation_id", "reference_physical_run_id"])
    waveform_metadata = {"status": "not_indicated", "warnings": []}
    profiles = None
    # The three-comparator audit always runs; outcome triggers still govern
    # the legacy diagnostic route, not whether historical evidence is visible.
    try:
        profiles = preloaded_profiles if preloaded_profiles is not None else load_profiles(project)
        waveform_scores, waveform_coverage, waveform_members, waveform_metadata = scan_references(project, observation_id, config, profiles)
        warnings.extend(waveform_metadata["warnings"])
    except (ValueError, FileNotFoundError, KeyError) as exc:
        warnings.append(str(exc))
        waveform_metadata = {"status": "unresolved", "warnings": [str(exc)]}
    same_scores, same_coverage, same_members = waveform_scores.copy(), waveform_coverage.copy(), waveform_members.copy()
    trace_quality = write_trace_quality_audit(output_dir, observation_id, profiles)
    warnings.append(f"Er72 gate: {trace_quality['target_er72_excluded_waveforms']} target waveforms excluded before scoring/templates/evidence; "
                    f"{trace_quality['target_other_unresolved_waveforms']} other target waveforms have unresolved status. "
                    "A successful retry does not reinstate an Er72-associated operation. Bank exclusions are audited separately.")
    same_metadata = dict(waveform_metadata)
    target_profiles = profiles[0][profiles[0].observation_id.eq(observation_id)].copy() if profiles is not None else pd.DataFrame()
    scores = internal_operation_frame(profiles[0], observation_id, waveform_scores, waveform_coverage) if has_affected_barcodes and profiles is not None else pd.DataFrame()
    score_source = "raw_within_run_profiles_with_optional_historical_annotations" if not scores.empty else "no_raw_barcode_selective_profiles"
    if not trigger["run_qpm"]:
        warnings.append("No configured low-performance, dropout, or imbalance trigger. The independent historical-baseline audit still runs; no affected-path contrast is manufactured.")
    evidence_by_material: dict[str, pd.DataFrame] = {}
    mapped_by_material: dict[str, pd.DataFrame] = {}
    barcode_reference_by_material: dict[str, pd.DataFrame] = {}
    barcode_reference_summaries: list[pd.DataFrame] = []
    block_tables: list[pd.DataFrame] = []
    for material in ["DNA", "RNA"]:
        calls = lineage[
            (~lineage["is_control"]) & lineage["material_type"].eq(material)
        ]
        if calls.empty or not calls["path_status"].eq("failed").any() or scores.empty:
            continue
        mapped, blocks = map_operations_to_paths(scores, lineage, material, config)
        evidence = summarize_step_evidence(mapped, material, config)
        mapped_by_material[material] = mapped
        evidence_by_material[material] = evidence
        if not blocks.empty:
            blocks = blocks.copy()
            blocks["material_type"] = material
            block_tables.append(blocks)
        if evidence.empty:
            warnings.append(f"{material}: no QPM operations could be mapped to both path classes")
        elif not evidence["evidence_role"].eq("initial_candidate").any():
            warnings.append(
                f"{material}: dropout/imbalance present but no sufficiently replicated selective QPM group qualified"
            )
    # Evaluate other-instrument history even when same history exists or
    # internal tests are replicated; never overwrite those separate results.
    full_cross_scores = pd.DataFrame(columns=["operation_id"] + REFERENCE_FIELDS)
    full_cross_coverage = pd.DataFrame(columns=COVERAGE_FIELDS)
    full_cross_members = pd.DataFrame()
    full_cross_metadata = {"enabled": True, "scope": "all_target_operations_independent", "warnings": []}
    if profiles is not None and not target_profiles.empty:
        try:
            full_cross_scores, full_cross_coverage, full_cross_members, full_cross_metadata = scan_cross_instrument_fallback(
                project, observation_id, set(target_profiles.operation_id), config, profiles, same_coverage, independent=True)
            warnings.extend(full_cross_metadata["warnings"])
        except (ValueError, FileNotFoundError, KeyError) as exc:
            full_cross_metadata.update(status="unresolved", error=str(exc), warnings=[str(exc)])
            warnings.append(f"Independent cross-instrument reference scan unresolved: {exc}")
    # Keep the existing same-first underpowered-path fallback annotations as
    # a subset of the parallel scan for backward-compatible primary decisions.
    candidate_ids: set[str] = set()
    for material, mapped in mapped_by_material.items():
        evidence = evidence_by_material[material]
        candidate_ids.update(underpowered_reference_operation_ids(
            mapped, evidence, config["minimum_reference_physical_runs"]))
    cross_metadata = {"enabled": False, "requested_operations": 0, "scored_operations": 0, "warnings": [],
                      "scope": "insufficient_replication_groups_only"}
    if candidate_ids and profiles is not None:
        cross_scores = full_cross_scores[full_cross_scores.operation_id.isin(candidate_ids)].copy()
        cross_coverage = full_cross_coverage[full_cross_coverage.operation_id.isin(candidate_ids)].copy()
        cross_members = (full_cross_members[full_cross_members.target_operation_id.isin(candidate_ids)].copy()
                         if not full_cross_members.empty else full_cross_members.copy())
        cross_metadata = {**full_cross_metadata, "scope": "insufficient_replication_groups_only",
                          "requested_operations": len(candidate_ids), "scored_operations": len(cross_scores),
                          "attempted_operations": int(cross_coverage.cross_instrument_attempted.sum()) if not cross_coverage.empty else 0,
                          "warnings": [f"Under-replicated path fallback: {len(cross_scores)}/{len(candidate_ids)} requested operations received other-instrument shape references; the independent full scan is reported separately."]}
        waveform_coverage = overlay_by_operation(waveform_coverage, cross_coverage, COVERAGE_FIELDS[1:])
        if not cross_members.empty:
            waveform_members = pd.concat([waveform_members, cross_members], ignore_index=True)
        mapped_coverage = cross_coverage.rename(columns={"reference_status": "historical_reference_status",
                                                        "reason": "historical_reference_exclusion_reason"})
        coverage_columns = [field for field in mapped_coverage if field != "operation_id"]
        for material, mapped in mapped_by_material.items():
            mapped = overlay_by_operation(mapped, cross_scores, REFERENCE_FIELDS)
            mapped_by_material[material] = overlay_by_operation(mapped, mapped_coverage, coverage_columns)
        warnings.extend(cross_metadata["warnings"])
    waveform_metadata["cross_instrument_fallback"] = cross_metadata
    waveform_metadata["same_instrument_scored_operations"] = waveform_metadata.get("scored_operations", 0)
    waveform_metadata["total_scored_operations_including_path_fallback"] = int(waveform_coverage.get("reference_status", pd.Series(dtype=str)).eq("scored").sum())
    write_reference_audit(output_dir, waveform_coverage, waveform_members, waveform_metadata)
    for material, mapped in mapped_by_material.items():
        fallback_evidence, fallback_summary = build_barcode_reference_fallback(mapped, evidence_by_material[material], config)
        barcode_reference_by_material[material] = fallback_evidence
        barcode_reference_summaries.append(fallback_summary)
        if not fallback_evidence.empty:
            qualified = int(fallback_evidence["fallback_status"].eq("reference_scored").sum())
            warnings.append(f"{material}: insufficient-replication groups routed to affected-barcode historical references; "
                            f"{qualified}/{len(fallback_evidence)} affected operations have qualified history. "
                            "This is path-level exploratory evidence, not replicated group significance or a causal claim.")

    barcode_reference_evidence = (pd.concat(barcode_reference_by_material.values(), ignore_index=True)
                                  if barcode_reference_by_material else pd.DataFrame(columns=BARCODE_REFERENCE_COLUMNS))
    barcode_reference_summary = (pd.concat(barcode_reference_summaries, ignore_index=True)
                                 if barcode_reference_summaries else pd.DataFrame(columns=BARCODE_REFERENCE_SUMMARY_COLUMNS))

    has_selective_initial = any(not evidence.empty and evidence["evidence_role"].eq("initial_candidate").any()
                                for evidence in evidence_by_material.values())
    shared_scores = pd.DataFrame(columns=["observation_id", "operation_id", "operation_index", "operation",
                                         "programmed_volume_ul", "liquid_class_index", "reference_physical_runs"])
    shared_evidence = shared_reference_scan(pd.DataFrame(), config)
    if trigger["run_qpm"] and (trigger["low_outcomes"] or trigger.get("below_chip_lane_read_criterion") or not has_selective_initial):
        shared_scores = waveform_scores.copy()
        shared_evidence = shared_reference_scan(shared_scores, config)
        if shared_scores.empty and not len(shared_scores.columns):
            shared_scores = pd.DataFrame(columns=["observation_id", "operation_id", "operation_index", "operation",
                                                 "programmed_volume_ul", "liquid_class_index", "reference_physical_runs"])
    if has_affected_barcodes and not has_selective_initial:
        warnings.append("Barcode-path QPM comparison is independent of historical-reference coverage. No qualifying internal step was found; check replication, physical configuration, timing and lineage. This does not establish normality or exclude an unobserved cause.")
    if has_affected_barcodes:
        warnings.append("Primary within-run comparison uses leave-one-path-out surviving templates and template-refitting label permutations. Surviving outcomes do not certify healthy fluidics; associations remain exploratory and non-causal.")
    # Nomination is a display label, not an inference gate. Evaluate every
    # quality-cleared target operation from its RAW profile, including the
    # independent other-instrument scan (whose plotted shape is normalized).
    selected_operation_ids = set()
    for material, evidence in evidence_by_material.items():
        if not evidence.empty:
            ids = set(evidence.loc[evidence["evidence_role"].isin(["initial_candidate", "same_transaction_confirmation", "downstream_support"]), "group_id"])
            mapped = mapped_by_material[material]
            selected_operation_ids.update(mapped.loc[mapped["group_id"].isin(ids), "operation_id"])
    if not barcode_reference_evidence.empty:
        selected_operation_ids.update(barcode_reference_evidence.loc[barcode_reference_evidence["reference_positive"], "operation_id"])
    if not shared_evidence.empty:
        selected_operation_ids.update(shared_evidence.loc[shared_evidence["evidence_role"].ne("not_reference_positive"), "operation_id"])
    for historical in [same_scores, full_cross_scores]:
        if not historical.empty:
            positive = (historical.qpm_anomaly_percentile.ge(config["shared_reference_minimum_percentile"])
                        & historical.outside_90pct_envelope_fraction.ge(config["shared_reference_minimum_outside_fraction"]))
            selected_operation_ids.update(historical.loc[positive, "operation_id"])
    candidate_operations = eligible_waveforms(target_profiles).copy()
    if not candidate_operations.empty:
        if set(PROFILE_COLUMNS).issubset(candidate_operations):
            candidate_operations["observed_profile"] = [json.dumps(row.tolist()) for row in candidate_operations[PROFILE_COLUMNS].to_numpy(float)]
        elif "observed_profile" not in candidate_operations:
            # Missing raw samples must not be replaced by a normalized
            # historical-comparison curve; volume recognition will abstain.
            candidate_operations["observed_profile"] = None
        candidate_operations["volume_proxy_nominated_evidence"] = candidate_operations.operation_id.isin(selected_operation_ids)
    volume_proxies, volume_metadata = add_volume_proxies(project, candidate_operations, observation_id, config)
    if not volume_proxies.empty:
        proxy_columns = [column for column in volume_proxies if column.startswith(("volume_proxy_", "waveform_equivalent_", "equivalent_volume_", "aggregate_validation_", "delivered_volume_"))]
        annotations = volume_proxies[["operation_id"] + proxy_columns]
        for material in mapped_by_material:
            if not mapped_by_material[material].empty:
                mapped_by_material[material] = mapped_by_material[material].merge(annotations, on="operation_id", how="left", validate="many_to_one")
        if not shared_scores.empty:
            shared_scores = shared_scores.merge(annotations, on="operation_id", how="left", validate="many_to_one")
        if not same_scores.empty:
            same_scores = same_scores.merge(annotations, on="operation_id", how="left", validate="many_to_one")
        if not full_cross_scores.empty:
            full_cross_scores = full_cross_scores.merge(annotations, on="operation_id", how="left", validate="many_to_one")
    warnings.append(volume_metadata["warning"])
    focus_material = choose_focus_material(lineage, evidence_by_material)
    focus_evidence = evidence_by_material.get(focus_material or "", pd.DataFrame())
    focus_mapped = mapped_by_material.get(focus_material or "", pd.DataFrame())
    all_evidence = (
        pd.concat(evidence_by_material.values(), ignore_index=True)
        if evidence_by_material
        else pd.DataFrame(columns=["material_type", "group_id", "family", "operation", "pipette", "programmed_volume_ul",
                                  "liquid_class_index", "first_operation_index", "last_operation_index", "n_failed", "n_survivor",
                                  "failed_path_deviation_auc", "permutation_p", "bh_fdr_q", "evidence_role", "step_label"])
    )
    if all_evidence.empty and not len(all_evidence.columns):
        all_evidence = pd.DataFrame(columns=["material_type", "group_id", "first_operation_index", "evidence_role", "step_label"])
    all_mapped = (
        pd.concat(mapped_by_material.values(), ignore_index=True)
        if mapped_by_material
        else pd.DataFrame()
    )
    baseline_comparison = write_comparison(
        output_dir, lineage, evidence_by_material, mapped_by_material, target_profiles,
        same_scores, same_coverage, same_members, same_metadata,
        full_cross_scores, full_cross_coverage, full_cross_members, full_cross_metadata, config, PALETTE)
    conclusions = conclusion_payload(observation_id, lineage, evidence_by_material)
    conclusions["run_metadata"] = run_metadata
    conclusions["csa_low_performance_diagnostics"] = csa_diagnostics
    conclusions["trace_quality"] = trace_quality
    conclusions["baseline_comparison"] = baseline_comparison
    for material, details in conclusions["materials"].items():
        details["reference_fallback"] = fallback_payload(barcode_reference_evidence, barcode_reference_summary, material)
        if details["initial_candidate"] is None and details["reference_fallback"]["requested"]:
            details["interpretation"] = ("insufficient replicated group evidence; historical barcode-path anomalies are exploratory and non-causal"
                                         if details["reference_fallback"]["reference_anomaly_operations"] else
                                         "insufficient replicated group evidence; historical barcode-path fallback found no qualifying covered anomaly; uncovered steps remain unresolved")
    conclusions["outcome_reference"] = {
        "metadata": outcome_metadata,
        "summary": outcome_summary.to_dict(orient="records"),
    }
    shared_positive = shared_evidence[shared_evidence["evidence_role"].ne("not_reference_positive")] if not shared_evidence.empty else pd.DataFrame()
    conclusions["qpm_trigger"] = trigger
    conclusions["report_branch"] = report_route(has_affected_barcodes, has_selective_initial,
                                               not barcode_reference_evidence.empty, trigger["run_qpm"])
    conclusions["barcode_reference_fallback"] = {
        "version": BARCODE_REFERENCE_VERSION, "trigger": "insufficient_replication_per_group",
        "requested": not barcode_reference_evidence.empty,
        "affected_operations": len(barcode_reference_evidence),
        "reference_scored_operations": int(barcode_reference_evidence["fallback_status"].eq("reference_scored").sum()),
        "minimum_reference_physical_runs": config["minimum_reference_physical_runs"],
        "thresholds": {"shape_percentile": config["shared_reference_minimum_percentile"],
                       "outside_empirical_band_fraction": config["shared_reference_minimum_outside_fraction"]},
        "routing_independent_of_other_material_findings": True,
        "reference_matching_policy_unchanged": False,
        "full_physical_matching_unchanged": True,
        "reference_hierarchy": ["replicated_within_run", "same_instrument_history", "cross_instrument_normalized_shape", "unresolved"],
        "cross_instrument_shape_only": True,
        "cross_instrument_fallback": cross_metadata,
        "evidence_basis": "historical_reference_fallback_not_replicated_group_evidence",
    }
    conclusions["internal_comparison"] = {"version": "qpm-within-run-comparison-1.0.0", "historical_reference_required": False,
                                          "score_basis": "leave_one_independent_path_out_surviving_template",
                                          "permutation_policy": "refit_templates_and_scores_for_every_label_assignment",
                                          "significance_statistic": "raw_waveform_energy_distance_label_invariant_scaling",
                                          "multiplicity_policy": "BH_across_eligible_step_tests_within_material",
                                          "minimum_failed_paths": config["minimum_failed_paths"], "minimum_surviving_paths": config["minimum_surviving_paths"]}
    conclusions["waveform_reference"] = waveform_metadata
    conclusions["shared_path_reference"] = {
        "operations_scored": len(shared_scores),
        "earliest_reference_deviation": shared_positive.iloc[0].to_dict() if not shared_positive.empty else None,
        "later_reference_anomalies": shared_positive.iloc[1:].to_dict("records"),
        "displayed_operation_indices": [int(row["operation_index"]) for row in select_shared_display(shared_evidence)],
        "display_policy": "five_slots; earliest_positive_then_distinct_later_steps_then_repeats; chronological; not_causal_ranking",
        "interpretation": "exploratory_reference_only_not_barcode_selective_not_causal",
    }
    conclusions["volume_proxy"] = volume_metadata
    conclusions["diagnostic_workflow"] = build_diagnostic_workflow(lineage, trigger, csa_diagnostics)
    shared_evidence.to_csv(output_dir / "qpm_shared_path_evidence.csv", index=False)
    barcode_reference_evidence.to_csv(output_dir / "qpm_barcode_reference_evidence.csv", index=False)
    barcode_reference_summary.to_csv(output_dir / "qpm_barcode_reference_summary.csv", index=False)
    shared_scores.drop(columns=["observed_profile", "reference_median_profile", "reference_q05_profile", "reference_q95_profile"], errors="ignore").to_csv(output_dir / "qpm_shared_path_operation_ledger.csv", index=False)
    compact_proxies = volume_proxies.drop(columns=["observed_profile", "reference_median_profile", "reference_q05_profile", "reference_q95_profile"], errors="ignore")
    compact_proxies.to_csv(output_dir / "qpm_volume_proxies.csv", index=False)
    (output_dir / "qpm_volume_proxy_manifest.json").write_text(json.dumps(json_ready(volume_metadata), indent=2), encoding="utf-8")

    lineage.to_csv(output_dir / "barcode_dropout_calls.csv", index=False)
    lineage.to_csv(output_dir / "barcode_lineage.csv", index=False)
    all_evidence.to_csv(output_dir / "qpm_step_evidence.csv", index=False)
    if not all_mapped.empty:
        all_mapped.to_parquet(output_dir / "qpm_operation_ledger.parquet", index=False)
        compact = all_mapped.drop(
            columns=[
                "observed_profile",
                "reference_observed_profile",
                "reference_median_profile",
                "reference_q05_profile",
                "reference_q95_profile",
            ],
            errors="ignore",
        )
        compact.to_csv(output_dir / "qpm_operation_ledger.csv", index=False)
    else:
        empty_ledger = pd.DataFrame(
            {
                "observation_id": pd.Series(dtype="string"),
                "material_type": pd.Series(dtype="string"),
                "operation_id": pd.Series(dtype="string"),
                "operation_index": pd.Series(dtype="Int64"),
                "path_status": pd.Series(dtype="string"),
                "mapping_scope": pd.Series(dtype="string"),
            }
        )
        empty_ledger.to_csv(output_dir / "qpm_operation_ledger.csv", index=False)
        empty_ledger.to_parquet(output_dir / "qpm_operation_ledger.parquet", index=False)
    if block_tables:
        pd.concat(block_tables, ignore_index=True).to_csv(
            output_dir / "workflow_block_evidence.csv", index=False
        )
    else:
        pd.DataFrame(
            columns=[
                "workflow_block",
                "failed_paths",
                "surviving_paths",
                "planned_orders",
                "path_status",
                "material_type",
            ]
        ).to_csv(output_dir / "workflow_block_evidence.csv", index=False)
    try:
        same_run_display = build_same_run_curves(output_dir, all_evidence, all_mapped, PALETTE)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        warnings.append(f"Same-run descriptive curve display unresolved ({type(exc).__name__}); formal statistics and historical comparisons remain separate.")
        same_run_display = dict(version=SAME_RUN_CURVES_VERSION, status="unresolved_display_error",
            curve_groups=0, outputs={}, statistics_not_relaxed=True,
            error_type=type(exc).__name__, manifest_path=str(output_dir / "qpm_same_run_curve_manifest.json"))
        (output_dir / "qpm_same_run_curve_manifest.json").write_text(json.dumps(same_run_display, indent=2), encoding="utf-8")
    conclusions["same_run_curve_display"] = same_run_display
    conclusions["diagnostic_workflow"]["same_run_curve_display"] = {
        "status": same_run_display["status"], "curve_groups": same_run_display.get("curve_groups", 0),
        "minimum_affected_paths_for_display": 1, "minimum_surviving_paths_for_display": 1,
        "formal_statistical_minimum_unchanged": True, "all_materials_retained_separately": True,
    }
    (output_dir / "diagnostic_workflow.json").write_text(
        json.dumps(json_ready(conclusions["diagnostic_workflow"]), indent=2, allow_nan=False), encoding="utf-8")
    (output_dir / "initial_failure_candidates.json").write_text(
        json.dumps(json_ready(conclusions), indent=2), encoding="utf-8"
    )
    png, pdf = make_figure(
        output_dir,
        observation_id,
        lineage,
        focus_material,
        focus_mapped,
        focus_evidence,
        config,
    )
    shared_png = None
    shared_pdf = None
    if trigger["run_qpm"] and (trigger["low_outcomes"] or trigger.get("below_chip_lane_read_criterion") or not has_selective_initial):
        shared_png, shared_pdf = make_figure(output_dir, observation_id, lineage, None, pd.DataFrame(), pd.DataFrame(), config,
                                            shared_scores, shared_evidence, trigger, shared_mode=True)
    barcode_reference_figures: dict[str, Path] = {}
    barcode_reference_pdfs: dict[str, Path] = {}
    for material, fallback_evidence in barcode_reference_by_material.items():
        if not fallback_evidence.empty:
            fallback_png, fallback_pdf = make_barcode_reference_figure(output_dir, observation_id, material,
                                                                      mapped_by_material[material], fallback_evidence, config)
            barcode_reference_figures[material] = fallback_png
            barcode_reference_pdfs[material] = fallback_pdf
    primary_figure = (barcode_reference_figures.get(focus_material, png)
                      if conclusions["report_branch"] == "barcode_path_reference_fallback" else
                      shared_png if shared_png is not None and not has_affected_barcodes else png)
    report = make_html_report(
        output_dir,
        observation_id,
        lineage,
        focus_material,
        focus_evidence,
        conclusions,
        warnings,
        primary_figure,
        outcome_summary,
        outcome_context,
        shared_evidence,
        compact_proxies,
        shared_png,
        barcode_reference_evidence,
        barcode_reference_summary,
        barcode_reference_figures,
    )
    run_log = {
        "plugin_version": VERSION,
        "run_metadata": run_metadata,
        "evidence_waveform_slots_per_comparison": EVIDENCE_WAVEFORM_SLOTS,
        "observation_id": observation_id,
        "generated_utc": utc_now(),
        "project": str(project),
        "reference_bank": bank_info,
        "reference_qualification": qualification_metadata,
        "archive_path": str(archive_path),
        "archive_id": manifest.get("archive_id"),
        "archive_sha256": manifest.get("sha256") or sha256_file(archive_path),
        "reference_score_source": score_source,
        "profile_input": {"source": "preloaded_batch_view" if preloaded_profiles is not None else "project_tables",
                          "candidate_prefilter": profiles[1].get("batch_candidate_prefilter") if profiles is not None else None},
        "outcome_reference": outcome_metadata,
        "csa_low_performance_diagnostics": csa_diagnostics,
        "diagnostic_workflow": conclusions["diagnostic_workflow"],
        "same_run_curve_display": same_run_display,
        "waveform_reference": waveform_metadata,
        "qpm_trigger": trigger,
        "report_branch": conclusions["report_branch"],
        "internal_comparison": conclusions["internal_comparison"],
        "baseline_comparison": baseline_comparison,
        "trace_quality": trace_quality,
        "barcode_reference_fallback": conclusions["barcode_reference_fallback"],
        "shared_reference_operations_scored": len(shared_scores),
        "volume_proxy": volume_metadata,
        "code_sha256": {name: sha256_file(Path(__file__).resolve().parent / name) for name in ["train_multimodal_csa.py", "qpm_same_run_curves.py"] +
                        ["qpm_dropout_plugin.py", "csa_low_performance_diagnostics.py", "csa_root_cause_hypotheses.py", "qpm_diagnostic_extensions.py", "outcome_reference.py", "qpm_waveform_reference.py", "qpm_internal_comparison.py", "qpm_barcode_reference.py", "qpm_cross_instrument_reference.py", "qpm_baseline_comparison.py", "qpm_trace_quality.py", "qpm_reference_bank.py", "qpm_reference_qualification.py", "qpm_nominal_volume_inference.py", "qpm_all_volume_inference.py", "qpm_run_metadata.py"]},
        "random_seed": SEED,
        "config": config,
        "focus_material": focus_material,
        "barcode_rows": int(len(lineage)),
        "qpm_operations_scored": int(len(scores)),
        "qpm_raw_operations_loaded": int(len(scores)),
        "qpm_internal_path_operations_scored": int(all_mapped["within_run_shape_deviation"].notna().sum())
            if "within_run_shape_deviation" in all_mapped else 0,
        "qpm_operations_path_mapped": int(len(all_mapped)),
        "qpm_step_groups": int(len(all_evidence)),
        "warnings": warnings,
        "runtime_seconds": round(time.time() - start, 3),
        "outputs": {
            "report": str(report),
            "csa_low_performance_manifest": csa_diagnostics.get("manifest_path"),
            "diagnostic_workflow": str(output_dir / "diagnostic_workflow.json"),
            "same_run_curve_manifest": same_run_display.get("manifest_path"),
            "same_run_curves": same_run_display.get("outputs", {}).get("report"),
            "run_metadata": str(output_dir / "run_metadata.json"),
            "baseline_comparison_summary": str(output_dir / "qpm_baseline_comparison_summary.csv"),
            "baseline_comparison_figure": baseline_comparison["figure_png"],
            "baseline_comparison_pdf": baseline_comparison["figure_pdf"],
            "baseline_comparison_svg": baseline_comparison.get("figure_svg"),
            "figure_png": str(png),
            "figure_pdf": str(pdf),
            "shared_figure_png": str(shared_png) if shared_png else None,
            "shared_figure_pdf": str(shared_pdf) if shared_pdf else None,
            "primary_figure_png": str(primary_figure),
            "barcode_reference_figures": {key: str(value) for key, value in barcode_reference_figures.items()},
            "barcode_reference_pdfs": {key: str(value) for key, value in barcode_reference_pdfs.items()},
        },
    }
    (output_dir / "plugin_run_log.json").write_text(
        json.dumps(json_ready(run_log), indent=2), encoding="utf-8"
    )
    return run_log


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Diagnose barcode-associated QPM waveform divergence for one CSA observation."
    )
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parent)
    selectors = parser.add_mutually_exclusive_group(required=True)
    selectors.add_argument("--observation-id")
    selectors.add_argument("--archive-id")
    selectors.add_argument("--run-name")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--config", type=Path)
    return parser.parse_args()


def main() -> None:
    from qpm_reference_bank import resolve_reference_bank
    args = parse_args()
    project = resolve_reference_bank(args.project)
    config = load_config(args.config)
    observation_id = resolve_observation(
        project, args.observation_id, args.archive_id, args.run_name
    )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir
        else project / "qpm_dropout_plugin_outputs" / observation_id
    )
    log = run_plugin(project, observation_id, output_dir, config)
    print(json.dumps(json_ready({"plugin_version": log["plugin_version"], "observation_id": observation_id,
                               "report": log["outputs"]["report"], "qpm_operations_scored": log["qpm_operations_scored"],
                               "shared_reference_operations_scored": log["shared_reference_operations_scored"],
                               "runtime_seconds": log["runtime_seconds"], "warnings": log["warnings"]}), indent=2))


if __name__ == "__main__":
    main()
