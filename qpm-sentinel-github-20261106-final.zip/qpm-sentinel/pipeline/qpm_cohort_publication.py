"""Read-only cohort label reconciliation from the plugin's saved evidence.

This adapter does not score a waveform or select new evidence. It recognizes
the explicit evidence_role emitted by shared_reference_scan and keeps the two
historical comparators separate when describing an already-flagged anomaly.
"""
from __future__ import annotations

import math
import pandas as pd


def finite(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def reconcile_historical_label(row: dict, shared: pd.DataFrame, displayed: pd.DataFrame) -> dict:
    result = dict(row)
    if result.get("diagnostic_status") not in {"no_qualifying_qpm_divergence", "insufficient_comparable_qpm_evidence", "historical_reference_only_anomaly"}:
        return result
    candidates = []
    labels = {"same_instrument": "Same-instrument raw waveform", "cross_instrument": "Other-instrument normalized shape"}
    for baseline, label in labels.items():
        count = finite(result.get(f"{baseline}_positive_operations"))
        operation = finite(result.get(f"{baseline}_earliest_operation_index"))
        if count is None or count <= 0 or operation is None:
            continue
        selected = displayed.loc[displayed.baseline_id.eq(baseline) & displayed.available.eq(True)
                                 & pd.to_numeric(displayed.operation_index, errors="coerce").eq(operation)]
        step = str(selected.iloc[0]["step"]) if len(selected) else "Step label unavailable; inspect individual report"
        candidates.append(dict(operation_index=int(operation), step=step, comparator=label))
    # Shared evidence uses role strings, not a `reference_positive` column.
    # This fallback retains compatibility with reports lacking the independent
    # comparator summary, without converting negative or borderline rows.
    if not candidates and "evidence_role" in shared:
        selected = shared.loc[shared.evidence_role.isin(["earliest_reference_deviation", "later_reference_anomaly"])]
        if len(selected):
            first = selected.sort_values("operation_index").iloc[0]
            candidates.append(dict(operation_index=int(first.operation_index),
                                   step=" / ".join(str(first.get(k, "")) for k in ["workflow_stage", "process_step", "operation"]),
                                   comparator="Shared-path historical reference"))
    if candidates:
        first = min(candidates, key=lambda candidate:candidate["operation_index"])
        result.update(diagnostic_status="historical_reference_only_anomaly",
                      earliest_operation_index=first["operation_index"], earliest_step=f"{first['comparator']}: {first['step']}",
                      evidence_basis=f"{first['comparator']}; shared-operation anomaly, not barcode-selective or a proven cause")
        if not result.get("flagged", True):
            result["evidence_basis"] = "Unflagged sibling scope (context only). " + result["evidence_basis"]
    return result
