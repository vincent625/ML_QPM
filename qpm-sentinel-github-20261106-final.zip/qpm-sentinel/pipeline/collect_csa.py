#!/usr/bin/env python3
"""Read-only discovery and collision-safe collection of Genexus CSA archives."""

from __future__ import annotations

import argparse
import csv
import hashlib
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Iterable


# No instrument or jump host is embedded in the distribution.
TARGETS: tuple[str, ...] = ()
SSH_JUMP_HOST: str | None = None
SSH_CONTROL_DIRECTORY: str | None = None
NORMAL_ROOT = "/data/IR/data/analysis_output/GNX_Org"
FALLBACK_ROOT = "/data/IR/data/analysis_output"
CANDIDATE_SUFFIXES = (".txz", ".tar.xz", ".zip", ".tgz", ".tar.gz")
SSH_OPTIONS = (
    "-o", "BatchMode=yes",
    "-o", "StrictHostKeyChecking=yes",
    "-o", "ConnectTimeout=8",
    "-o", "ConnectionAttempts=1",
    "-o", "ServerAliveInterval=5",
    "-o", "ServerAliveCountMax=1",
)
INVENTORY_FIELDS = (
    "archive_id", "hostname", "ssh_user", "ssh_target", "connection_status",
    "search_root", "remote_path", "run_name", "physical_experiment_name",
    "chip_lane", "plugin_version", "filename", "size_bytes",
    "remote_mtime_epoch", "remote_mtime_utc", "match_reason",
)
MANIFEST_FIELDS = (
    "archive_id", "hostname", "remote_path", "local_path", "size_bytes",
    "local_size_bytes", "remote_mtime_utc", "sha256", "container_format",
    "validation_result", "state", "transfer_action", "error",
)


@dataclass(frozen=True)
class Discovery:
    archive_id: str
    hostname: str
    ssh_user: str
    ssh_target: str
    connection_status: str
    search_root: str
    remote_path: str
    run_name: str
    physical_experiment_name: str
    chip_lane: str
    plugin_version: str
    filename: str
    size_bytes: int
    remote_mtime_epoch: float
    remote_mtime_utc: str
    match_reason: str


def run_command(args: list[str], timeout: int | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        stdin=subprocess.DEVNULL, timeout=timeout, check=False,
    )


def connection_options(target: str) -> list[str]:
    options = list(SSH_OPTIONS)
    if SSH_CONTROL_DIRECTORY:
        options.extend(["-o", "ControlMaster=auto", "-o", "ControlPersist=60",
                        "-o", f"ControlPath={SSH_CONTROL_DIRECTORY}/%C"])
    if SSH_JUMP_HOST:
        options.extend(["-J", SSH_JUMP_HOST])
    return options


def ssh(target: str, remote_command: str, timeout: int = 120) -> subprocess.CompletedProcess[str]:
    return run_command(["ssh", *connection_options(target), target, remote_command], timeout=timeout)


def stable_archive_id(hostname: str, remote_path: str) -> str:
    return hashlib.sha256(f"{hostname}\0{remote_path}".encode()).hexdigest()[:20]


def iso_utc(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat().replace("+00:00", "Z")


def parse_path(target: str, root: str, path: str, size: int, mtime: float) -> Discovery | None:
    user, hostname = target.split("@", 1)
    path_lower = path.lower()
    basename = PurePosixPath(path).name
    basename_lower = basename.lower()
    is_named_csa = basename_lower.endswith(".csa.txz")
    in_plugin = "/plugins/customersupportarchive_" in path_lower
    valid_extension = basename_lower.endswith(CANDIDATE_SUFFIXES)
    if not (is_named_csa or (in_plugin and valid_extension)):
        return None

    reason_bits: list[str] = []
    if is_named_csa:
        reason_bits.append("case_insensitive_*.CSA.txz")
    if in_plugin and valid_extension:
        reason_bits.append("CustomerSupportArchive_plugin_candidate_extension")

    parts = list(PurePosixPath(path).parts)
    try:
        gnx_index = parts.index("GNX_Org")
        rel_parts = parts[gnx_index + 1:]
    except ValueError:
        analysis_parts = list(PurePosixPath(FALLBACK_ROOT).parts)
        rel_parts = parts[len(analysis_parts):] if parts[:len(analysis_parts)] == analysis_parts else parts[1:]
    run_name = rel_parts[0] if rel_parts else ""
    physical_name = rel_parts[1] if len(rel_parts) > 1 else run_name
    lane = next((p for p in rel_parts if re.fullmatch(r"ChipLane\d+", p, re.I)), "")
    plugin = next((p.split("_", 1)[1] for p in rel_parts if p.lower().startswith("customersupportarchive_")), "")
    return Discovery(
        archive_id=stable_archive_id(hostname, path),
        hostname=hostname,
        ssh_user=user,
        ssh_target=target,
        connection_status="reachable",
        search_root=root,
        remote_path=path,
        run_name=run_name,
        physical_experiment_name=physical_name,
        chip_lane=lane,
        plugin_version=plugin,
        filename=basename,
        size_bytes=size,
        remote_mtime_epoch=mtime,
        remote_mtime_utc=iso_utc(mtime),
        match_reason=";".join(reason_bits),
    )


def discover_target(target: str) -> tuple[str, str, list[Discovery], str]:
    probe = ssh(
        target,
        f"if test -d {NORMAL_ROOT}; then printf normal; "
        f"elif test -d {FALLBACK_ROOT}; then printf fallback; else printf absent; fi",
        timeout=20,
    )
    if probe.returncode != 0:
        error = probe.stderr.strip().replace("\n", " ")
        return target, "unreachable", [], error or f"ssh exit {probe.returncode}"
    mode = probe.stdout.strip()
    if mode == "absent":
        return target, "root_absent", [], "approved search roots absent"
    root = NORMAL_ROOT if mode == "normal" else FALLBACK_ROOT
    # Enumerate only candidate archive extensions within the approved root. Local
    # filtering then enforces CSA filename/plugin-directory criteria.
    find_command = (
        "LC_ALL=C find " + root + " -type f \\( "
        "-iname '*.txz' -o -iname '*.tar.xz' -o -iname '*.zip' -o "
        "-iname '*.tgz' -o -iname '*.tar.gz' \\) "
        "-printf '%s\\t%T@\\t%p\\n'"
    )
    result = ssh(target, find_command, timeout=1800)
    rows: list[Discovery] = []
    malformed = 0
    for line in result.stdout.splitlines():
        try:
            size_s, mtime_s, path = line.split("\t", 2)
            item = parse_path(target, root, path, int(size_s), float(mtime_s))
            if item is not None:
                rows.append(item)
        except (ValueError, IndexError):
            malformed += 1
    rows.sort(key=lambda x: x.remote_path)
    notes: list[str] = []
    if malformed:
        notes.append(f"{malformed} malformed find rows ignored")
    if result.returncode != 0:
        error = result.stderr.strip().replace("\n", " ")
        notes.append(error or f"find exit {result.returncode}")
        status = "reachable_with_search_warnings" if rows else "search_failed"
    else:
        status = "reachable"
    return target, status, rows, "; ".join(notes)


def atomic_write_csv(path: Path, fieldnames: Iterable[str], rows: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        os.replace(temp_name, path)
    except BaseException:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def relative_destination(item: Discovery, project: Path) -> Path:
    path = PurePosixPath(item.remote_path)
    parts = list(path.parts)
    try:
        idx = parts.index("GNX_Org")
        rel = Path(*parts[idx + 1:])
    except ValueError:
        analysis = list(PurePosixPath(FALLBACK_ROOT).parts)
        rel_parts = parts[len(analysis):] if parts[:len(analysis)] == analysis else parts[1:]
        rel = Path(*rel_parts)
    return project / "archives" / item.hostname / rel


def collision_safe_destination(item: Discovery, project: Path) -> tuple[Path, str]:
    preferred = relative_destination(item, project)
    if not preferred.exists() or preferred.stat().st_size == item.size_bytes:
        return preferred, "preferred_path"
    stamp = datetime.fromtimestamp(item.remote_mtime_epoch, timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    suffix = f".remote_{stamp}_{item.size_bytes}B"
    candidate = preferred.with_name(preferred.name + suffix)
    serial = 1
    while candidate.exists() and candidate.stat().st_size != item.size_bytes:
        candidate = preferred.with_name(preferred.name + suffix + f".{serial}")
        serial += 1
    return candidate, "size_collision_preserved"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_archive(path: Path) -> tuple[str, str, str]:
    with path.open("rb") as handle:
        signature = handle.read(8)
    if signature.startswith(b"PK\x03\x04") or signature.startswith(b"PK\x05\x06") or signature.startswith(b"PK\x07\x08"):
        fmt = "zip"
        test = run_command(["unzip", "-tqq", str(path)], timeout=1800)
        return fmt, "valid" if test.returncode == 0 else "invalid", test.stderr.strip()[-1000:]
    if signature.startswith(b"\xfd7zXZ\x00"):
        xz_test = run_command(["xz", "-t", str(path)], timeout=1800)
        if xz_test.returncode != 0:
            return "tar_xz", "invalid", xz_test.stderr.strip()[-1000:]
        tar_test = run_command(["tar", "-tJf", str(path)], timeout=1800)
        return "tar_xz", "valid" if tar_test.returncode == 0 else "invalid", tar_test.stderr.strip()[-1000:]
    if signature.startswith(b"\x1f\x8b"):
        test = run_command(["tar", "-tzf", str(path)], timeout=1800)
        return "tar_gzip", "valid" if test.returncode == 0 else "invalid", test.stderr.strip()[-1000:]
    return "unrecognized", "unrecognized", "content signature is not ZIP, XZ, or gzip"


def transfer_one(item: Discovery, project: Path) -> dict[str, str | int]:
    destination, collision_action = collision_safe_destination(item, project)
    destination.parent.mkdir(parents=True, exist_ok=True)
    existing_same_size = destination.exists() and destination.stat().st_size == item.size_bytes
    action = "already_present" if existing_same_size else collision_action
    error = ""
    if not existing_same_size:
        partial = destination.with_name(destination.name + ".partial")
        rsync = run_command([
            "rsync", "--partial", "--append-verify", "--protect-args",
            "-e", shlex.join(["ssh", *connection_options(item.ssh_target)]),
            f"{item.ssh_target}:{item.remote_path}", str(partial),
        ], timeout=24 * 3600)
        if rsync.returncode != 0:
            return {
                "archive_id": item.archive_id, "hostname": item.hostname,
                "remote_path": item.remote_path, "local_path": str(destination),
                "size_bytes": item.size_bytes,
                "local_size_bytes": partial.stat().st_size if partial.exists() else 0,
                "remote_mtime_utc": item.remote_mtime_utc, "sha256": "",
                "container_format": "", "validation_result": "not_tested",
                "state": "failed", "transfer_action": "rsync_failed",
                "error": (rsync.stderr or rsync.stdout).strip()[-2000:],
            }
        if not partial.exists() or partial.stat().st_size != item.size_bytes:
            actual = partial.stat().st_size if partial.exists() else 0
            return {
                "archive_id": item.archive_id, "hostname": item.hostname,
                "remote_path": item.remote_path, "local_path": str(destination),
                "size_bytes": item.size_bytes, "local_size_bytes": actual,
                "remote_mtime_utc": item.remote_mtime_utc, "sha256": "",
                "container_format": "", "validation_result": "not_tested",
                "state": "failed", "transfer_action": "size_mismatch",
                "error": f"expected {item.size_bytes} bytes, received {actual}",
            }
        os.replace(partial, destination)
        action = "transferred" if collision_action == "preferred_path" else collision_action

    try:
        fmt, validation, validation_error = validate_archive(destination)
        digest = sha256_file(destination)
    except Exception as exc:  # preserve the archive and report the validation failure
        return {
            "archive_id": item.archive_id, "hostname": item.hostname,
            "remote_path": item.remote_path, "local_path": str(destination),
            "size_bytes": item.size_bytes,
            "local_size_bytes": destination.stat().st_size if destination.exists() else 0,
            "remote_mtime_utc": item.remote_mtime_utc, "sha256": "",
            "container_format": "", "validation_result": "error", "state": "failed",
            "transfer_action": action, "error": repr(exc),
        }
    if validation == "unrecognized":
        state = "unrecognized_format"
    elif validation != "valid":
        state = "failed"
    else:
        state = "already_present" if existing_same_size else "transferred"
    error = validation_error
    return {
        "archive_id": item.archive_id, "hostname": item.hostname,
        "remote_path": item.remote_path, "local_path": str(destination),
        "size_bytes": item.size_bytes, "local_size_bytes": destination.stat().st_size,
        "remote_mtime_utc": item.remote_mtime_utc, "sha256": digest,
        "container_format": fmt, "validation_result": validation, "state": state,
        "transfer_action": action, "error": error,
    }


def write_summary(
    project: Path,
    host_status: dict[str, tuple[str, str]],
    discoveries: list[Discovery],
    manifest: list[dict],
    free_bytes: int,
    disk_ok: bool,
) -> None:
    manifest_by_id = {row["archive_id"]: row for row in manifest}
    lines = [
        "# Genexus CSA collection summary", "",
        f"Generated: {datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')}", "",
        f"Discovered archives: **{len(discoveries)}**", "",
        f"Discovered bytes: **{sum(x.size_bytes for x in discoveries):,}**", "",
        f"Local free bytes at preflight: **{free_bytes:,}**", "",
        f"Disk-space check (free >= 110% of discovered bytes): **{'PASS' if disk_ok else 'FAIL'}**", "",
        "| Instrument | Connection/search status | Archives | Bytes | Transferred | Already present | Valid | Failed | Unrecognized | Note |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for target in TARGETS:
        hostname = target.split("@", 1)[1]
        status, note = host_status.get(target, ("not_attempted", ""))
        items = [x for x in discoveries if x.hostname == hostname]
        rows = [manifest_by_id[x.archive_id] for x in items if x.archive_id in manifest_by_id]
        count = lambda key, value: sum(1 for row in rows if row.get(key) == value)
        safe_note = note.replace("|", "\\|")
        lines.append(
            f"| {hostname} | {status} | {len(items)} | {sum(x.size_bytes for x in items):,} | "
            f"{count('state', 'transferred')} | {count('state', 'already_present')} | "
            f"{count('validation_result', 'valid')} | {count('state', 'failed')} | "
            f"{count('state', 'unrecognized_format')} | {safe_note} |"
        )
    terminal = {"transferred", "already_present", "failed", "unrecognized_format"}
    documented = sum(1 for x in discoveries if manifest_by_id.get(x.archive_id, {}).get("state") in terminal)
    lines.extend([
        "", f"Documented terminal states: **{documented}/{len(discoveries)}**.", "",
        "Remote operations were limited to SSH probes and `find`/metadata reads beneath the approved run roots. No remote file was modified.", "",
    ])
    (project / "collection_summary.md").write_text("\n".join(lines), encoding="utf-8")


def load_discoveries(path: Path) -> list[Discovery]:
    rows = read_csv(path)
    result = []
    for row in rows:
        result.append(Discovery(**{
            **row,
            "size_bytes": int(row["size_bytes"]),
            "remote_mtime_epoch": float(row["remote_mtime_epoch"]),
        }))
    return result


def main() -> int:
    global TARGETS, SSH_JUMP_HOST, SSH_CONTROL_DIRECTORY
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, default=Path("genexus_csa_project"))
    parser.add_argument("--mode", choices=("inventory", "transfer", "all"), default="all")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(
        "--targets", nargs="+", required=True,
        help="Explicit user@host targets authorized by your organization; no default network targets.",
    )
    parser.add_argument("--jump-host",
                        help="Optional explicit user@host ProxyJump route for the supplied targets.")
    parser.add_argument("--connection-reuse", action="store_true",
                        help="Reuse SSH connections using a private temporary control-socket directory.")
    args = parser.parse_args()
    for target in [*args.targets, *([args.jump_host] if args.jump_host else [])]:
        if not re.fullmatch(r'[A-Za-z0-9_.-]+@[A-Za-z0-9_.-]+', target):
            parser.error('Targets must be explicit user@host SSH names without shell metacharacters')
    TARGETS = tuple(args.targets)
    SSH_JUMP_HOST = args.jump_host
    control_directory = tempfile.TemporaryDirectory(prefix="csa_ssh_mux_") if args.connection_reuse else None
    SSH_CONTROL_DIRECTORY = control_directory.name if control_directory else None
    project = args.project.resolve()
    project.mkdir(parents=True, exist_ok=True)
    inventory_path = project / "csa_inventory.csv"
    manifest_path = project / "csa_transfer_manifest.csv"
    prior_status_rows = read_csv(project / "host_status.csv")
    host_status: dict[str, tuple[str, str]] = {
        row["ssh_target"]: (row["status"], row["note"]) for row in prior_status_rows
    }

    if args.mode in {"inventory", "all"}:
        selected_targets = tuple(args.targets) if args.targets else TARGETS
        previous_discoveries = load_discoveries(inventory_path) if inventory_path.exists() else []
        selected_hosts = {target.split("@", 1)[1] for target in selected_targets}
        discoveries = [x for x in previous_discoveries if x.hostname not in selected_hosts]
        with ThreadPoolExecutor(max_workers=min(len(selected_targets), max(1, args.workers))) as pool:
            futures = {pool.submit(discover_target, target): target for target in selected_targets}
            for future in as_completed(futures):
                try:
                    target, status, rows, note = future.result()
                except (subprocess.TimeoutExpired, OSError) as exc:
                    target = futures[future]
                    status, rows, note = "unreachable", [], type(exc).__name__
                # A failed probe must not discard previously inventoried files.
                if status in {"unreachable", "search_failed"}:
                    rows = [x for x in previous_discoveries if x.hostname == target.split("@", 1)[1]]
                host_status[target] = (status, note)
                discoveries.extend(rows)
                print(f"{target}: {status}; {len(rows)} CSA candidates", flush=True)
        discoveries.sort(key=lambda x: (x.hostname, x.remote_path))
        atomic_write_csv(inventory_path, INVENTORY_FIELDS, (asdict(x) for x in discoveries))
        status_rows = [
            {"ssh_target": target, "status": host_status.get(target, ("not_attempted", ""))[0],
             "note": host_status.get(target, ("", ""))[1]}
            for target in TARGETS
        ]
        atomic_write_csv(project / "host_status.csv", ("ssh_target", "status", "note"), status_rows)
    else:
        discoveries = load_discoveries(inventory_path)
        status_rows = read_csv(project / "host_status.csv")
        host_status = {row["ssh_target"]: (row["status"], row["note"]) for row in status_rows}

    total_bytes = sum(x.size_bytes for x in discoveries)
    free_bytes = shutil.disk_usage(project).free
    disk_ok = free_bytes >= int(total_bytes * 1.10)
    previous_manifest = {row["archive_id"]: row for row in read_csv(manifest_path)}

    if args.mode == "inventory":
        write_summary(project, host_status, discoveries, list(previous_manifest.values()), free_bytes, disk_ok)
        print(f"TOTAL\t{len(discoveries)} archives\t{total_bytes} bytes\tfree={free_bytes}\tdisk_ok={disk_ok}")
        return 0 if disk_ok else 2
    if not disk_ok:
        rows = []
        for item in discoveries:
            rows.append({
                "archive_id": item.archive_id, "hostname": item.hostname,
                "remote_path": item.remote_path, "local_path": "",
                "size_bytes": item.size_bytes, "local_size_bytes": 0,
                "remote_mtime_utc": item.remote_mtime_utc, "sha256": "",
                "container_format": "", "validation_result": "not_tested",
                "state": "failed", "transfer_action": "blocked_by_disk_preflight",
                "error": "free space is less than 110% of total discovered bytes",
            })
        atomic_write_csv(manifest_path, MANIFEST_FIELDS, rows)
        write_summary(project, host_status, discoveries, rows, free_bytes, disk_ok)
        return 2

    manifest_by_id = dict(previous_manifest)
    selected_hosts = {target.split("@", 1)[1] for target in args.targets} if args.targets else None
    transfer_discoveries = [item for item in discoveries
                            if selected_hosts is None or item.hostname in selected_hosts]
    pending = [
        item for item in transfer_discoveries
        if manifest_by_id.get(item.archive_id, {}).get("state") not in {"transferred", "already_present"}
    ]
    # Revalidate previously successful files on every invocation as requested.
    pending.extend(
        item for item in transfer_discoveries
        if manifest_by_id.get(item.archive_id, {}).get("state") in {"transferred", "already_present"}
    )
    # Round-robin hosts so one large inventory does not delay all other hosts.
    host_queues: dict[str, list[Discovery]] = {}
    for item in pending:
        host_queues.setdefault(item.hostname, []).append(item)
    pending = [queue[index] for index in range(max((len(q) for q in host_queues.values()), default=0))
               for queue in host_queues.values() if index < len(queue)]
    completed = 0
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        futures = {pool.submit(transfer_one, item, project): item for item in pending}
        for future in as_completed(futures):
            item = futures[future]
            try:
                row = future.result()
            except Exception as exc:
                row = {
                    "archive_id": item.archive_id, "hostname": item.hostname,
                    "remote_path": item.remote_path, "local_path": "",
                    "size_bytes": item.size_bytes, "local_size_bytes": 0,
                    "remote_mtime_utc": item.remote_mtime_utc, "sha256": "",
                    "container_format": "", "validation_result": "error",
                    "state": "failed", "transfer_action": "exception", "error": repr(exc),
                }
            manifest_by_id[item.archive_id] = row
            completed += 1
            ordered = [manifest_by_id[x.archive_id] for x in discoveries if x.archive_id in manifest_by_id]
            atomic_write_csv(manifest_path, MANIFEST_FIELDS, ordered)
            print(f"[{completed}/{len(pending)}] {item.hostname} {item.filename}: {row['state']}", flush=True)

    manifest = [manifest_by_id[x.archive_id] for x in discoveries if x.archive_id in manifest_by_id]
    atomic_write_csv(manifest_path, MANIFEST_FIELDS, manifest)
    write_summary(project, host_status, discoveries, manifest, free_bytes, disk_ok)
    terminal = {"transferred", "already_present", "failed", "unrecognized_format"}
    return 0 if len(manifest) == len(discoveries) and all(r["state"] in terminal for r in manifest) else 3


if __name__ == "__main__":
    sys.exit(main())
