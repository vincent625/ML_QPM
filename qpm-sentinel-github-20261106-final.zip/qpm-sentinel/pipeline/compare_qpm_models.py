#!/usr/bin/env python3
"""Compare guarded small-data classifiers for matched QPM waveforms."""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Callable

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import sklearn
from matplotlib.gridspec import GridSpec
from sklearn.decomposition import PCA
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    recall_score,
)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC

from analyze_qpm_volume_diagnostics import (
    LIQUID_CLASS_NAME,
    RANDOM_SEED,
    VOLUMES,
    baseline_correct,
    load_cohort,
)


PROJECT = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT / "qpm_model_comparison"
OUTPUT_DIR.mkdir(exist_ok=True)

MODEL_ORDER = [
    "Majority baseline",
    "Robust template",
    "Logistic regression",
    "Linear SVM",
    "PCA + logistic",
    "Extra Trees",
    "DTW 5-NN",
]
MODEL_COLORS = {
    "Majority baseline": "#9AA0A6",
    "Robust template": "#606C38",
    "Logistic regression": "#2A9D8F",
    "Linear SVM": "#277DA1",
    "PCA + logistic": "#577590",
    "Extra Trees": "#E76F51",
    "DTW 5-NN": "#6D597A",
}


def estimator_factory(model_name: str):
    if model_name == "Logistic regression":
        return make_pipeline(
            StandardScaler(),
            LogisticRegression(
                C=0.2,
                max_iter=3000,
                class_weight="balanced",
                random_state=RANDOM_SEED,
            ),
        )
    if model_name == "Linear SVM":
        return make_pipeline(
            StandardScaler(),
            LinearSVC(
                C=0.1,
                class_weight="balanced",
                dual="auto",
                max_iter=10000,
                random_state=RANDOM_SEED,
            ),
        )
    if model_name == "PCA + logistic":
        return make_pipeline(
            StandardScaler(),
            PCA(n_components=0.95, svd_solver="full"),
            LogisticRegression(
                C=0.2,
                max_iter=3000,
                class_weight="balanced",
                random_state=RANDOM_SEED,
            ),
        )
    if model_name == "Extra Trees":
        return ExtraTreesClassifier(
            n_estimators=400,
            max_depth=8,
            min_samples_leaf=5,
            max_features="sqrt",
            class_weight="balanced",
            random_state=RANDOM_SEED,
            n_jobs=-1,
        )
    raise KeyError(model_name)


def majority_prediction(y_train: np.ndarray, n_test: int) -> np.ndarray:
    values, counts = np.unique(y_train, return_counts=True)
    return np.full(n_test, values[np.argmax(counts)], dtype=int)


def robust_template_prediction(
    x_train: np.ndarray, y_train: np.ndarray, x_test: np.ndarray
) -> np.ndarray:
    distances = []
    for volume in VOLUMES:
        members = x_train[y_train == volume]
        median = np.median(members, axis=0)
        mad = 1.4826 * np.median(np.abs(members - median), axis=0)
        scale = np.maximum(mad, 5.0)
        distances.append(
            np.sqrt(np.mean(((x_test - median) / scale) ** 2, axis=1))
        )
    return np.asarray(VOLUMES, dtype=int)[np.argmin(np.column_stack(distances), axis=1)]


def constrained_dtw_distance_matrix(
    x: np.ndarray, radius: int = 3
) -> np.ndarray:
    """Pairwise equal-length DTW using a narrow Sakoe-Chiba band."""
    n_rows, n_points = x.shape
    matrix = np.empty((n_rows, n_rows), dtype=np.float32)
    for query_index in range(n_rows):
        query = x[query_index]
        previous = np.full((n_rows, n_points + 1), np.inf, dtype=float)
        previous[:, 0] = 0.0
        for i in range(1, n_points + 1):
            current = np.full((n_rows, n_points + 1), np.inf, dtype=float)
            low = max(1, i - radius)
            high = min(n_points, i + radius)
            for j in range(low, high + 1):
                cost = (x[:, j - 1] - query[i - 1]) ** 2
                current[:, j] = cost + np.minimum(
                    np.minimum(previous[:, j], current[:, j - 1]),
                    previous[:, j - 1],
                )
            previous = current
        matrix[query_index] = np.sqrt(previous[:, n_points] / n_points)
    matrix = (matrix + matrix.T) / 2.0
    np.fill_diagonal(matrix, 0.0)
    return matrix


def dtw_knn_prediction(
    distance_matrix: np.ndarray,
    train: np.ndarray,
    test: np.ndarray,
    y_train: np.ndarray,
    neighbors: int = 5,
) -> np.ndarray:
    predictions = []
    for test_index in test:
        distances = distance_matrix[test_index, train]
        k = min(neighbors, len(train))
        nearest = np.argpartition(distances, k - 1)[:k]
        neighbor_labels = y_train[nearest]
        weights = 1.0 / np.maximum(distances[nearest], 1e-6)
        votes = {
            volume: float(weights[neighbor_labels == volume].sum())
            for volume in VOLUMES
        }
        predictions.append(max(VOLUMES, key=lambda volume: (votes[volume], -volume)))
    return np.asarray(predictions, dtype=int)


def score_predictions(
    y_true: np.ndarray, y_pred: np.ndarray
) -> dict[str, float]:
    recalls = recall_score(
        y_true, y_pred, labels=VOLUMES, average=None, zero_division=0
    )
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "minimum_volume_recall": float(np.min(recalls)),
        "maximum_volume_recall": float(np.max(recalls)),
    }


def fit_predict(
    model_name: str,
    x: np.ndarray,
    y: np.ndarray,
    train: np.ndarray,
    test: np.ndarray,
    distance_matrix: np.ndarray,
) -> np.ndarray:
    if model_name == "Majority baseline":
        return majority_prediction(y[train], len(test))
    if model_name == "Robust template":
        return robust_template_prediction(x[train], y[train], x[test])
    if model_name == "DTW 5-NN":
        return dtw_knn_prediction(distance_matrix, train, test, y[train])
    estimator = estimator_factory(model_name)
    estimator.fit(x[train], y[train])
    return estimator.predict(x[test]).astype(int)


def evaluate_scheme(
    scheme: str,
    splits: list[tuple[str, np.ndarray, np.ndarray]],
    x: np.ndarray,
    y: np.ndarray,
    distance_matrix: np.ndarray,
) -> tuple[dict[str, np.ndarray], list[dict[str, object]], dict[str, float]]:
    predictions = {
        model_name: np.full(len(y), -1, dtype=int) for model_name in MODEL_ORDER
    }
    fold_rows: list[dict[str, object]] = []
    runtimes = {model_name: 0.0 for model_name in MODEL_ORDER}
    for fold_name, train, test in splits:
        for model_name in MODEL_ORDER:
            started = time.perf_counter()
            fold_prediction = fit_predict(
                model_name, x, y, train, test, distance_matrix
            )
            runtimes[model_name] += time.perf_counter() - started
            predictions[model_name][test] = fold_prediction
            fold_rows.append(
                {
                    "validation_scheme": scheme,
                    "fold": fold_name,
                    "model": model_name,
                    "test_n": int(len(test)),
                    **score_predictions(y[test], fold_prediction),
                }
            )
    for model_name, prediction in predictions.items():
        if np.any(prediction < 0):
            raise RuntimeError(f"Missing {scheme} predictions for {model_name}")
    return predictions, fold_rows, runtimes


def summarize_performance(
    predictions: dict[str, dict[str, np.ndarray]],
    y: np.ndarray,
    runtimes: dict[str, dict[str, float]],
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for scheme, model_predictions in predictions.items():
        for model_name in MODEL_ORDER:
            pred = model_predictions[model_name]
            recalls = recall_score(
                y, pred, labels=VOLUMES, average=None, zero_division=0
            )
            row: dict[str, object] = {
                "validation_scheme": scheme,
                "model": model_name,
                "n_waveforms": int(len(y)),
                **score_predictions(y, pred),
                "fit_predict_seconds": float(runtimes[scheme][model_name]),
            }
            for volume, recall in zip(VOLUMES, recalls):
                row[f"recall_{volume}ul"] = float(recall)
            rows.append(row)
    return pd.DataFrame(rows)


def confusion_long(
    predictions: dict[str, dict[str, np.ndarray]], y: np.ndarray
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for scheme, model_predictions in predictions.items():
        for model_name, pred in model_predictions.items():
            counts = confusion_matrix(y, pred, labels=VOLUMES)
            fractions = confusion_matrix(y, pred, labels=VOLUMES, normalize="true")
            for i, actual in enumerate(VOLUMES):
                for j, predicted in enumerate(VOLUMES):
                    rows.append(
                        {
                            "validation_scheme": scheme,
                            "model": model_name,
                            "actual_volume_ul": actual,
                            "predicted_volume_ul": predicted,
                            "count": int(counts[i, j]),
                            "row_fraction": float(fractions[i, j]),
                        }
                    )
    return pd.DataFrame(rows)


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        0.01,
        0.99,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=10,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.82, "pad": 1.2},
        zorder=20,
    )


def make_figure(
    performance: pd.DataFrame,
    fold_performance: pd.DataFrame,
    per_instrument: pd.DataFrame,
    confusion: pd.DataFrame,
) -> str:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 7,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig = plt.figure(figsize=(183 / 25.4, 170 / 25.4), constrained_layout=True)
    gs = GridSpec(2, 2, figure=fig, height_ratios=[1.0, 1.12])
    axes = [fig.add_subplot(gs[row, col]) for row in range(2) for col in range(2)]
    x_position = np.arange(len(MODEL_ORDER))

    ax = axes[0]
    grouped = performance.set_index(["validation_scheme", "model"]).loc["grouped"]
    values = grouped.loc[MODEL_ORDER, "balanced_accuracy"].to_numpy()
    bars = ax.bar(
        x_position,
        values,
        color=[MODEL_COLORS[name] for name in MODEL_ORDER],
        width=0.72,
        zorder=2,
    )
    group_folds = fold_performance[
        fold_performance["validation_scheme"].eq("grouped")
    ]
    rng = np.random.default_rng(RANDOM_SEED)
    for index, model_name in enumerate(MODEL_ORDER):
        fold_values = group_folds.loc[
            group_folds["model"].eq(model_name), "balanced_accuracy"
        ].to_numpy()
        ax.scatter(
            index + rng.normal(0, 0.035, len(fold_values)),
            fold_values,
            s=12,
            color="white",
            edgecolor="#24352A",
            linewidth=0.4,
            zorder=3,
        )
    for bar, value in zip(bars, values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.018,
            f"{value * 100:.1f}%",
            ha="center",
            va="bottom",
            fontsize=6.5,
            fontweight="bold",
        )
    ax.set_xticks(x_position, MODEL_ORDER, rotation=34, ha="right")
    ax.set_ylim(0, 1.04)
    ax.set_ylabel("Balanced accuracy")
    ax.set_title("Held-out physical-run performance", fontweight="bold")
    ax.grid(axis="y", color="#D8E2DC", linewidth=0.55, alpha=0.7, zorder=0)
    ax.spines[["top", "right"]].set_visible(False)
    add_panel_label(ax, "a")

    ax = axes[1]
    loio = performance.set_index(["validation_scheme", "model"]).loc[
        "leave_one_instrument_out"
    ]
    values = loio.loc[MODEL_ORDER, "balanced_accuracy"].to_numpy()
    bars = ax.bar(
        x_position,
        values,
        color=[MODEL_COLORS[name] for name in MODEL_ORDER],
        width=0.72,
        alpha=0.88,
        zorder=2,
    )
    for index, model_name in enumerate(MODEL_ORDER):
        instrument_values = per_instrument.loc[
            per_instrument["model"].eq(model_name), "balanced_accuracy"
        ].to_numpy()
        ax.scatter(
            np.full(len(instrument_values), index),
            instrument_values,
            s=15,
            color="white",
            edgecolor="#24352A",
            linewidth=0.5,
            zorder=3,
        )
    for bar, value in zip(bars, values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.018,
            f"{value * 100:.1f}%",
            ha="center",
            va="bottom",
            fontsize=6.5,
            fontweight="bold",
        )
    ax.set_xticks(x_position, MODEL_ORDER, rotation=34, ha="right")
    ax.set_ylim(0, 1.04)
    ax.set_ylabel("Balanced accuracy")
    ax.set_title("Unseen-instrument transport", fontweight="bold")
    ax.grid(axis="y", color="#D8E2DC", linewidth=0.55, alpha=0.7, zorder=0)
    ax.spines[["top", "right"]].set_visible(False)
    add_panel_label(ax, "b")

    ax = axes[2]
    recall_matrix = grouped.loc[MODEL_ORDER, [f"recall_{v}ul" for v in VOLUMES]].to_numpy()
    image = ax.imshow(recall_matrix, vmin=0, vmax=1, cmap="YlGnBu", aspect="auto")
    for row in range(recall_matrix.shape[0]):
        for col in range(recall_matrix.shape[1]):
            value = recall_matrix[row, col]
            ax.text(
                col,
                row,
                f"{value * 100:.0f}",
                ha="center",
                va="center",
                fontsize=6.5,
                color="white" if value > 0.55 else "#24352A",
                fontweight="bold" if value > 0.8 else "normal",
            )
    ax.set_xticks(range(len(VOLUMES)), [f"{v} µL" for v in VOLUMES])
    ax.set_yticks(range(len(MODEL_ORDER)), MODEL_ORDER)
    ax.set_xlabel("Actual programmed volume")
    ax.set_title("Held-out recall by volume (%)", fontweight="bold")
    fig.colorbar(image, ax=ax, shrink=0.72, label="Recall")
    add_panel_label(ax, "c")

    candidates = loio.drop(index="Majority baseline")
    best_model = str(candidates["balanced_accuracy"].idxmax())
    ax = axes[3]
    selected = confusion[
        confusion["validation_scheme"].eq("leave_one_instrument_out")
        & confusion["model"].eq(best_model)
    ]
    matrix = selected.pivot(
        index="actual_volume_ul", columns="predicted_volume_ul", values="row_fraction"
    ).reindex(index=VOLUMES, columns=VOLUMES).to_numpy()
    image = ax.imshow(matrix, vmin=0, vmax=1, cmap="YlGnBu", aspect="auto")
    for row in range(matrix.shape[0]):
        for col in range(matrix.shape[1]):
            value = matrix[row, col]
            ax.text(
                col,
                row,
                f"{value * 100:.0f}%",
                ha="center",
                va="center",
                fontsize=7,
                color="white" if value > 0.55 else "#24352A",
                fontweight="bold" if row == col else "normal",
            )
    ax.set_xticks(range(len(VOLUMES)), VOLUMES)
    ax.set_yticks(range(len(VOLUMES)), VOLUMES)
    ax.set_xlabel("Predicted volume (µL)")
    ax.set_ylabel("Actual volume (µL)")
    ax.set_title(
        f"Best unseen-instrument model: {best_model}\n"
        f"balanced accuracy {loio.loc[best_model, 'balanced_accuracy'] * 100:.1f}%",
        fontweight="bold",
    )
    fig.colorbar(image, ax=ax, shrink=0.72, label="Row fraction")
    add_panel_label(ax, "d")

    fig.suptitle(
        "Comparison of QPM waveform classifiers",
        fontsize=12,
        fontweight="bold",
    )
    fig.text(
        0.5,
        -0.012,
        f"{LIQUID_CLASS_NAME}; 1,030 matched PIP2 aspiration waveforms. "
        "All model settings were fixed before evaluation; no target-guided tuning was performed.",
        ha="center",
        fontsize=6.5,
        color="#4F5D4F",
    )
    fig.savefig(
        OUTPUT_DIR / "qpm_model_comparison.png",
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    return best_model


def main() -> None:
    started = time.perf_counter()
    frame = load_cohort()
    x = baseline_correct(frame)
    y = frame["programmed_volume_ul"].to_numpy(dtype=int)
    groups = frame["physical_run_id"].to_numpy()
    instruments = frame["instrument_id"].to_numpy()

    dtw_started = time.perf_counter()
    dtw_distances = constrained_dtw_distance_matrix(x, radius=3)
    dtw_seconds = time.perf_counter() - dtw_started

    splitter = StratifiedGroupKFold(
        n_splits=5, shuffle=True, random_state=RANDOM_SEED
    )
    grouped_splits = [
        (f"group_fold_{index}", train, test)
        for index, (train, test) in enumerate(splitter.split(x, y, groups), start=1)
    ]
    loio_splits = []
    for instrument in sorted(np.unique(instruments)):
        test = np.flatnonzero(instruments == instrument)
        train = np.flatnonzero(instruments != instrument)
        loio_splits.append((str(instrument), train, test))

    predictions: dict[str, dict[str, np.ndarray]] = {}
    fold_rows: list[dict[str, object]] = []
    runtimes: dict[str, dict[str, float]] = {}
    for scheme, splits in (
        ("grouped", grouped_splits),
        ("leave_one_instrument_out", loio_splits),
    ):
        scheme_predictions, scheme_rows, scheme_runtimes = evaluate_scheme(
            scheme, splits, x, y, dtw_distances
        )
        predictions[scheme] = scheme_predictions
        fold_rows.extend(scheme_rows)
        runtimes[scheme] = scheme_runtimes

    performance = summarize_performance(predictions, y, runtimes)
    fold_performance = pd.DataFrame(fold_rows)
    confusion = confusion_long(predictions, y)

    per_instrument = fold_performance[
        fold_performance["validation_scheme"].eq("leave_one_instrument_out")
    ].copy()
    per_instrument = per_instrument.rename(columns={"fold": "heldout_instrument"})

    prediction_table = frame[
        [
            "observation_id",
            "physical_run_id",
            "instrument_id",
            "chip_lane",
            "run_start_time",
            "operation_id",
            "programmed_volume_ul",
        ]
    ].copy()
    for scheme, model_predictions in predictions.items():
        for model_name, values in model_predictions.items():
            slug = (
                model_name.lower()
                .replace(" ", "_")
                .replace("+", "plus")
                .replace("-", "_")
            )
            prediction_table[f"{scheme}.{slug}.predicted_volume_ul"] = values

    performance.to_csv(OUTPUT_DIR / "qpm_model_performance.csv", index=False)
    fold_performance.to_csv(
        OUTPUT_DIR / "qpm_model_fold_performance.csv", index=False
    )
    per_instrument.to_csv(
        OUTPUT_DIR / "qpm_model_per_instrument.csv", index=False
    )
    confusion.to_csv(OUTPUT_DIR / "qpm_model_confusion.csv", index=False)
    prediction_table.to_csv(
        OUTPUT_DIR / "qpm_model_predictions.csv", index=False
    )

    best_model = make_figure(
        performance, fold_performance, per_instrument, confusion
    )

    code_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    run_log = {
        "analysis": "QPM matched-volume model comparison",
        "code_sha256": code_hash,
        "random_seed": RANDOM_SEED,
        "n_waveforms": int(len(frame)),
        "n_observations": int(frame["observation_id"].nunique()),
        "n_physical_runs": int(frame["physical_run_id"].nunique()),
        "n_instruments": int(frame["instrument_id"].nunique()),
        "volumes_ul": VOLUMES,
        "models": {
            "Majority baseline": "training-fold most frequent class",
            "Robust template": "per-volume median and pointwise MAD distance, fold-local",
            "Logistic regression": "StandardScaler + LogisticRegression(C=0.2, balanced)",
            "Linear SVM": "StandardScaler + LinearSVC(C=0.1, balanced)",
            "PCA + logistic": "StandardScaler + PCA(95% variance) + LogisticRegression(C=0.2, balanced)",
            "Extra Trees": "400 trees, depth<=8, min leaf 5, sqrt features, balanced",
            "DTW 5-NN": "5-neighbor distance vote, Sakoe-Chiba radius 3",
        },
        "validation": {
            "grouped": "5-fold StratifiedGroupKFold by physical_run_id",
            "leave_one_instrument_out": "four held-out-instrument folds",
            "target_guided_tuning": False,
        },
        "dtw_distance_precompute_seconds": dtw_seconds,
        "execution_seconds": time.perf_counter() - started,
        "best_leave_one_instrument_out_model": best_model,
        "software_versions": {
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
            "matplotlib": matplotlib.__version__,
        },
    }
    (OUTPUT_DIR / "qpm_model_comparison_run_log.json").write_text(
        json.dumps(run_log, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
