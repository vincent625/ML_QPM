#!/usr/bin/env python3
"""Outcome models on an immutable expanded CSA bank; never changes instruments.

The complete good+bad cohort is used. Outcome-qualified QPM reference selection
is deliberately unrelated to this predictive experiment. Raw identities and
debug logs are never persisted by this extractor. Programmed QPM operations,
not independently measured delivered volumes, supply liquid-transfer context.
"""
from __future__ import annotations

import argparse
import configparser
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import hashlib
import html
import io
import inspect
import json
import math
import multiprocessing
from pathlib import Path
import re
import shutil
import sys
import time
import warnings

import joblib
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import sklearn
from scipy import stats
from scipy.fft import dct
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import ElasticNet
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

import analyze_csa as core
import train_multimodal_csa as multi
from build_expanded_reference_bank import members, json_safe, write_json, sha256
from forecast_next_run_csa import FORBIDDEN, SAFE_CATEGORICAL
from qpm_trace_quality import eligible_waveforms

VERSION = "expanded-csa-outcome-training-2.1.0-feature-audit"
POLICY_VERSION = "expanded-diagnostic-leakage-policy-2.0.0-reviewed-families"
SEED = 20261027
TARGETS = ["total_reads", "mean_read_length_bp", "raw_read_accuracy_pct"]
META = ["observation_id", "physical_run_id", "instrument_id", "archive_id", "chip_lane", "run_start_time", *TARGETS]
# Full outcome documents and final QC reports cannot become predictors, even
# when a product-specific field name evades an outcome regex.
FINAL_REPORT = re.compile(r"basecaller|ionstats|(?:^|/)info\.csv$|quality.?report|final.?qc|run.?qc|barcod|coverage|variant|histogram|read.?length|read.?accuracy", re.I)
EXTRA_FORBIDDEN = re.compile(r"(?:^|[._/])(?:id|pk|uuid|guid|timestamp|filename|filepath|path|hostname|serial)(?:$|[._/])|(?:^|[._])(?:full|q\d+|aq\d+|nomatch)[._](?:mean|num|length|bases)|quality[_ .-]?(?:score|hist)|barcode|sample|outcome|pass.?fail|success.?label", re.I)
MAX_MEMBER = 24 * 2**20
_WORKER_DATASETS = {}
REVIEWED_PLUGIN_FAMILIES = frozenset({"rawtrace", "flowrate", "autocal", "chip_diagnostics", "nucstep_rendered", "bubbleplots"})
CONTAMINATED_PLUGIN_FAMILIES = frozenset({"true_loading", "edge_effects", "lane_diagnostics", "reseq_diagnostics"})
NESTED_TARGET_ALIAS = re.compile(r"hist(?:ogram)?|filtpass|pass[_ .-]?filter|filter(?:ed|ing)[_ .-]?(?:read|bead)|bcmatch[_ .-]?length|(?:^|[_ .-])(?:q20|aq\d+|qv\d+)(?:$|[_ .-])", re.I)
DATE_IN_NAME = re.compile(r"(?:19|20)\d{2}[_-](?:0[1-9]|1[0-2])[_-](?:0[1-9]|[12]\d|3[01])")
UNSAFE_METADATA = re.compile(r"^csa\.report_summary(?:\.|$)|(?:^|\.)startplugin(?:[._]|$)|plugin_user_input|^csa\.ion_params_00\.(?:experiment_analysis_settings_experiment|exp_json_plan|exp_json_rep_result|exp_json_ftp_status|exp_json_chef_progress|exp_json_log_currentstate)(?:\.|$)", re.I)


def say(message):
    print(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), message, flush=True)


def exclusion_reason(name):
    """Fail closed on mixed outcome-map families, not just their filenames."""
    if name.startswith("plugin."):
        family=name.split(".")[1]
        if family in CONTAMINATED_PLUGIN_FAMILIES:
            return "whole_plugin_family_contains_direct_outcome_maps_including_aggregated_images"
        if family not in REVIEWED_PLUGIN_FAMILIES:
            return "plugin_provenance_unverified_not_asserted_proven_leakage"
    if UNSAFE_METADATA.search(name):
        return "final_summary_foreign_identifier_clinical_input_or_status_metadata"
    if DATE_IN_NAME.search(name):
        return "literal_date_or_timestamp_in_descriptor_name"
    if NESTED_TARGET_ALIAS.search(name):
        return "nested_target_alias_or_unverified_histogram_conservative_quarantine"
    if FORBIDDEN.search(name) or EXTRA_FORBIDDEN.search(name) or multi.TARGET_LEAKAGE_RE.search(name) or multi.OUTCOME_PROXY_RE.search(name):
        return "sensitive_identifier_or_outcome_proxy"
    return None


def forbidden(name):
    return exclusion_reason(name) is not None


def component(name):
    return multi.component_for_feature(name) if not name.startswith("context.") else "context"


def direct_target_copies(matrix):
    """Leakage audit, not association-based feature selection.

    Only virtually exact numeric identities/affine copies are quarantined.
    Ordinary predictive correlations are left entirely to fold-local learning.
    """
    rows=[]
    targets={target:pd.to_numeric(matrix[target],errors="coerce").to_numpy(dtype=float) for target in TARGETS}
    supports=matrix.notna().sum()
    for feature in matrix:
        if feature in META or supports[feature]<30 or not pd.api.types.is_numeric_dtype(matrix[feature]):
            continue
        x=pd.to_numeric(matrix[feature],errors="coerce").to_numpy(dtype=float)
        for target in TARGETS:
            y=targets[target]
            valid=np.isfinite(x)&np.isfinite(y)
            if valid.sum()<30 or len(np.unique(x[valid]))<10 or len(np.unique(y[valid]))<10:
                continue
            xv,yv=x[valid],y[valid]
            xc=xv-xv.mean();yc=yv-yv.mean()
            denom=xc@xc
            if denom<=0:
                continue
            slope=(xc@yc)/denom; intercept=yv.mean()-slope*xv.mean()
            residual=np.max(np.abs(yv-(slope*xv+intercept)))
            scale=max(1.,float(np.ptp(yv)))
            if residual/scale<1e-8:
                rows.append(dict(feature_name=feature,outcome=target,support=int(valid.sum()),slope=float(slope),intercept=float(intercept),reason="deterministic_outcome_copy_or_affine_transform"))
    return pd.DataFrame(rows,columns=["feature_name","outcome","support","slope","intercept","reason"])


def extract_one(record, cache_root):
    cache = Path(cache_root) / (str(record["archive_sha256"])[:24] + ".joblib")
    key = VERSION + "|" + POLICY_VERSION + "|" + str(record["archive_sha256"])
    if cache.exists():
        try:
            value = joblib.load(cache)
            if value.get("key") == key and value["result"].get("members", 0) > 0:
                return value["result"]
        except (EOFError, OSError, ValueError):
            pass  # Concurrent atomic writer or interrupted previous attempt.
    values, dictionary, excluded, spatial, plugin_values = {}, {}, {}, [], {}
    from collections import defaultdict
    plugin_values = defaultdict(list)
    inventory, ignored = {}, []
    warning_rows = []
    seen_members = 0

    def store(name, value, source, field, tier="C"):
        if forbidden(name) or core.SENSITIVE_RE.search(field) or core.IDENTIFIER_RE.search(field):
            excluded[name] = "sensitive_identifier_or_outcome_proxy"
            return
        numeric = core.parse_number(value)
        if numeric is not None:
            values.setdefault(name, []).append(float(numeric))
            dictionary[name] = dict(feature_name=name, component=component(name), source_file=source,
                                    source_field=field, tier=tier, data_type="numeric")
        elif value is not None and SAFE_CATEGORICAL.search(field):
            text = str(value).strip()
            if len(text) <= 160 and not re.search(r"[/\\]|@|(?:\d{1,3}\.){3}\d{1,3}", text):
                values.setdefault(name, []).append(text)
                dictionary[name] = dict(feature_name=name, component=component(name), source_file=source,
                                        source_field=field, tier=tier, data_type="categorical")

    try:
        fmt = {"tar_xz":"xz_tar", "tar_gz":"gzip_tar"}.get(record["container_format"], record["container_format"])
        for name, size, handle in members(record["local_path"], fmt):
            seen_members += 1
            lower, base = name.lower(), Path(name).name.lower()
            if size > MAX_MEMBER or lower == "csa/debug" or FINAL_REPORT.search(lower):
                continue
            spatial_match = multi.SPATIAL_RE.match(name)
            structured = core.is_interesting_member(name) and (base.endswith((".json", ".ini")))
            plugin = not lower.startswith("csa/") and Path(lower).suffix in (multi.IMAGE_EXTENSIONS | multi.STRUCTURED_EXTENSIONS | multi.TEXT_EXTENSIONS)
            if not (spatial_match or structured or plugin or base in {"vacuum_log.csv", "libprep_log.csv"}):
                continue
            data = handle.read(MAX_MEMBER + 1)
            if len(data) > MAX_MEMBER:
                warning_rows.append("member_size_limit")
                continue
            if spatial_match:
                spatial.extend(multi.parse_spatial_bytes(data, spatial_match, {}, name))
            elif base == "vacuum_log.csv":
                for row in core.parse_vacuum_log(data, name, record):
                    store("vacuum." + row["feature_name"], row["value"], name, row["source_field"], row["feature_tier"])
            elif base == "libprep_log.csv":
                for key_name, number in multi.libprep_features(data).items():
                    store(key_name, number, name, key_name)
            elif structured and base.endswith(".json"):
                try:
                    obj = json.loads(data.decode("utf-8-sig", "replace"))
                    for field, value in core.flatten_json(obj):
                        tier, _, _ = core.classify_feature(name, field, value)
                        feature = "csa." + core.normalize_name(Path(name).stem) + "." + core.normalize_name(field)
                        if tier == "D":
                            excluded[feature] = "feature_policy_tier_D"
                            continue
                        store(feature, value, name, field, tier)
                except Exception as exc:
                    warning_rows.append("json:" + type(exc).__name__)
            elif structured and base.endswith(".ini") and core.should_parse_ini(name):
                text = data.decode("utf-8-sig", "replace")
                parser = configparser.ConfigParser(interpolation=None, strict=False)
                try:
                    parser.read_string(text)
                    pairs = [(section + "." + key, value) for section in parser.sections() for key, value in parser.items(section)]
                except configparser.MissingSectionHeaderError:
                    pairs = [(line.split("=", 1)[0].strip(), line.split("=", 1)[1].strip()) for line in text.splitlines() if "=" in line and not line.lstrip().startswith(("#", ";", "import "))]
                except Exception as exc:
                    warning_rows.append("ini:" + type(exc).__name__)
                    pairs = []
                for field, value in pairs:
                    tier, _, _ = core.classify_feature(name, field, value)
                    if tier != "D":
                        store("csa." + core.normalize_name(Path(name).stem) + "." + core.normalize_name(field), value, name, field, tier)
            if plugin:
                multi.plugin_member_features(name, data, size, plugin_values, inventory, ignored, [])
    except Exception as exc:
        warning_rows.append("archive:" + type(exc).__name__)
    for name, value in {**multi.spatial_run_features(spatial), **multi.aggregate_plugin_values(plugin_values)}.items():
        # File sizes and HTML lengths can proxy reads or the target report;
        # report only independent physical/image/structured diagnostics.
        if any(x in name for x in (".inventory.", ".text.", ".parse.")):
            excluded[name] = "export_packaging_not_physical_measurement"
            continue
        store(name, value, name.split(".")[0], name)
    output = {}
    for name, items in values.items():
        if dictionary[name]["data_type"] == "numeric":
            output[name] = float(np.median(items))
        else:
            distinct = set(items)
            output[name] = items[0] if len(distinct) == 1 else None
    result = dict(archive_id=record["archive_id"], features=output, dictionary=list(dictionary.values()),
                  exclusions=[dict(feature_name=k, reason=v) for k, v in excluded.items()],
                  warnings=warning_rows, members=seen_members, spatial_rows=len(spatial), plugin_inventory=list(inventory.values()))
    partial=cache.with_name(cache.name+f".{time.time_ns()}.partial")
    joblib.dump(dict(key=key, result=result), partial, compress=3)
    partial.replace(cache)
    return result


def qpm_features(bank, out):
    path = out / "qpm_run_descriptors.parquet"
    manifest_path=out/"qpm_run_descriptors.manifest.json"
    signature=dict(algorithm="qpm32-er72-step-and-commandLC-summary-v2-numpy-trapezoid",bank=str(bank.resolve()),
                   waves_sha256=sha256(bank/"qpm_operation_waveforms.parquet"),
                   trace_quality_sha256=sha256(bank/"qpm_trace_quality.parquet"),
                   command_context_sha256=sha256(bank/"qpm_physical_operation_context.parquet"),
                   trace_quality_code_sha256=sha256(Path(__file__).parent/"qpm_trace_quality.py"),
                   vector_features_source=hashlib.sha256(inspect.getsource(multi.vector_features).encode()).hexdigest())
    if path.exists() and manifest_path.exists():
        manifest=json.loads(manifest_path.read_text())
        if manifest.get("input_signature")==signature and manifest.get("output_sha256")==sha256(path):
            return pd.read_parquet(path)
    say("Summarizing audited Er72-cleared QPM profiles by run, operation, verified liquid class, and workflow step")
    wave = pd.read_parquet(bank / "qpm_operation_waveforms.parquet")
    quality = pd.read_parquet(bank / "qpm_trace_quality.parquet")
    wave = wave.merge(quality, on=["archive_id", "operation_index", "pipette"], how="left", validate="one_to_one")
    wave = eligible_waveforms(wave)
    wave = wave[wave.qpm_available.fillna(False) & wave.qpm_profile.map(lambda v: len(v) == 32)].copy()
    context=pd.read_parquet(bank/"qpm_physical_operation_context.parquet",columns=["archive_id","operation_index","pipette","command_operation","command_volume_ul","command_context_status","liquid_class_fingerprint"])
    wave=wave.merge(context,on=["archive_id","operation_index","pipette"],how="left",validate="one_to_one")
    verified=wave.command_context_status.eq("command_verified") & wave.operation.eq(wave.command_operation) & np.isclose(wave.programmed_volume_ul,wave.command_volume_ul,equal_nan=False)
    wave.loc[~verified,"liquid_class_fingerprint"]=None
    frames = []
    for observation_id, frame in wave.groupby("observation_id", sort=False):
        profiles = np.vstack(frame.qpm_profile)
        finite = np.isfinite(profiles).all(axis=1)
        frame = frame.loc[finite].reset_index(drop=True)
        profiles = profiles[finite]
        if not len(profiles):
            continue
        profiles = profiles - np.median(profiles[:, :3], axis=1, keepdims=True)
        for name, array in {"wave_mean":profiles.mean(axis=1), "wave_std":profiles.std(axis=1),
                            "wave_min":profiles.min(axis=1), "wave_max":profiles.max(axis=1),
                            "wave_amplitude":np.ptp(profiles,axis=1), "wave_end":profiles[:,-1],
                            "wave_area_signed":np.trapezoid(profiles,axis=1),
                            "wave_area_absolute":np.trapezoid(abs(profiles),axis=1),
                            "wave_difference_noise":np.diff(profiles,axis=1).std(axis=1)}.items():
            frame[name] = array
        coeff = dct(profiles, norm="ortho", axis=1)
        for i in range(8):
            frame[f"wave_dct_{i}"] = coeff[:,i]
        features = {}
        metric_cols = [c for c in frame if c.startswith("wave_")]
        for keys, group in frame.groupby(["operation", "pipette"], sort=False):
            tag = "qpm." + ".".join(multi.normalize_name(x) for x in keys)
            array=group[metric_cols].to_numpy(dtype=float)
            summaries={"count":np.full(len(metric_cols),len(group)),"mean":array.mean(axis=0),"std":array.std(axis=0),
                       "min":array.min(axis=0),"max":array.max(axis=0),"median":np.median(array,axis=0),
                       "q10":np.quantile(array,.1,axis=0),"q90":np.quantile(array,.9,axis=0)}
            for suffix,numbers in summaries.items():
                for metric,number in zip(metric_cols,numbers):
                    features[tag+"."+metric+"."+suffix]=float(number)
        detail_metrics=["wave_mean","wave_std","wave_min","wave_max","wave_amplitude","wave_area_absolute","wave_difference_noise"]
        grouped=frame.groupby(["workflow_stage","process_step","operation","pipette"],sort=False,dropna=False)[detail_metrics].agg(["median","max"])
        for keys,numbers in zip(grouped.index,grouped.to_numpy()):
            tag="qpm.step."+".".join(multi.normalize_name(x,48) for x in keys)
            for (metric,suffix),number in zip(grouped.columns,numbers):
                features[tag+"."+metric+"."+suffix]=float(number)
        grouped=frame.dropna(subset=["liquid_class_fingerprint"]).groupby(["liquid_class_fingerprint","operation","pipette"],sort=False)[detail_metrics].agg(["median","max"])
        for keys,numbers in zip(grouped.index,grouped.to_numpy()):
            tag="qpm.liquidclass.lc_"+str(keys[0])[:12]+"."+".".join(multi.normalize_name(x) for x in keys[1:])
            for (metric,suffix),number in zip(grouped.columns,numbers):
                features[tag+"."+metric+"."+suffix]=float(number)
        frames.append(dict(observation_id=observation_id, **features))
        if len(frames)%250==0:
            say(f"QPM descriptor summaries {len(frames)} observations")
    result = pd.DataFrame(frames)
    result.to_parquet(path, index=False)
    write_json(manifest_path,dict(input_signature=signature,output_sha256=sha256(path),rows=len(result),columns=len(result.columns)))
    write_json(out/"qpm_feature_provenance.json", dict(source_bank=str(bank), operations_after_quality_gate=len(wave),
               all_Er72_excluded=True, profile_points=32, unit="baseline_centered_raw_sensor_counts", liquid_class="actual-command verified full-definition fingerprint, not inherited numeric LC label", caveat="32-point summaries, not full-rate raw traces; no cross-unit conversion; raw sensor amplitude is not calibrated across instruments"))
    return result


def extract(bank, out, workers, limit=0):
    out.mkdir(parents=True, exist_ok=True)
    cache = out / ".feature_cache"
    cache.mkdir(exist_ok=True)
    metadata = pd.read_parquet(bank / "csa_ml_dataset.parquet")
    manifests = pd.read_csv(bank / "csa_transfer_manifest.csv").drop_duplicates("archive_id")
    records = metadata.merge(manifests[["archive_id","local_path","container_format","sha256"]], on="archive_id",validate="one_to_one")
    if limit:
        records = records.head(limit)
    results = []
    started = time.monotonic()
    say(f"Extracting {len(records)} independent primary run/lane archives; {workers} bounded workers")
    with ProcessPoolExecutor(max_workers=workers, mp_context=multiprocessing.get_context("spawn")) as pool:
        futures = [pool.submit(extract_one, record, cache) for record in records.to_dict("records")]
        for future in as_completed(futures):
            results.append(future.result())
            if len(results) % 25 == 0 or len(results) == len(records):
                say(f"CSA feature extraction {len(results)}/{len(records)}, {time.monotonic()-started:.0f}s elapsed")
    features = pd.DataFrame([dict(archive_id=result["archive_id"], **result["features"]) for result in results])
    say(f"Consolidating structured descriptors {features.shape}")
    matrix = records[META].merge(features,on="archive_id",validate="one_to_one")
    # A zero raw read length with no reads is an undefined statistic, not a
    # real zero-bp read. Keep zero read-count failures in the reads task.
    invalid_rows=[]
    for target in TARGETS:
        value=pd.to_numeric(matrix[target],errors="coerce")
        invalid=value.notna() & (~np.isfinite(value) | (value<0))
        if target=="mean_read_length_bp":
            invalid |= value.eq(0)
        if target=="raw_read_accuracy_pct":
            invalid |= value.gt(100)
        for i in matrix.index[invalid]:
            invalid_rows.append(dict(observation_id=matrix.at[i,"observation_id"],outcome=target,raw_value=matrix.at[i,target],reason="undefined_zero_length_or_invalid_outcome_range"))
        matrix.loc[invalid,target]=np.nan
    pd.DataFrame(invalid_rows,columns=["observation_id","outcome","raw_value","reason"]).to_csv(out/"invalid_outcome_audit.csv",index=False)
    qpm_out=out/"qpm_v2"
    qpm_out.mkdir(exist_ok=True)
    qpm = qpm_features(bank,qpm_out)
    say(f"Merging audited QPM descriptors {qpm.shape}")
    matrix = matrix.merge(qpm,on="observation_id",how="left",validate="one_to_one")
    dictionary = pd.DataFrame([r for result in results for r in result["dictionary"]]).drop_duplicates("feature_name")
    existing = set(dictionary.feature_name)
    extra = [dict(feature_name=c,component=component(c),source_file="CSA/debug",source_field=c,tier="C",data_type="numeric") for c in qpm if c not in existing and c!="observation_id"]
    dictionary = pd.concat([dictionary,pd.DataFrame(extra)],ignore_index=True)
    # Instrument identity is an adjustment/context covariate, never a setting.
    matrix["context.instrument"] = matrix.instrument_id.astype(str)
    matrix["context.lane_scope"] = records.analysis_lane_scope.to_numpy()
    from qpm_reference_qualification import lane_tokens
    matrix["context.analyzed_lane_count"] = matrix.chip_lane.map(lambda v: float(len(lane_tokens(v))) if lane_tokens(v) else np.nan)
    context_sources={"chip_type":"ion_params_00.chip_info_chip_type","assay_type":"global.analysis_application_type",
                     "panel_technology":"global.analysis_panel_technology","workflow":"planned_run.object_script_name",
                     "run_mode":"planned_run.object_run_type","template_size":"planned_run.object_templating_size",
                     "flow_count":"ion_params_00.flows","flow_order":"ion_params_00.flow_order",
                     "instrument_software":"ion_params_00.exp_json_log_genexus_release_version",
                     "analysis_software":"global.ir_version_number","sequencing_kit":"ion_params_00.exp_json_sequencekitname"}
    for label,source in context_sources.items():
        if source not in records:
            continue
        name="context."+label
        matrix[name]=records[source].to_numpy()
        if label in {"template_size","flow_count"}:
            matrix[name]=pd.to_numeric(matrix[name],errors="coerce")
        dictionary.loc[len(dictionary)] = dict(feature_name=name,component="context",source_file="verified_compact_metadata",source_field=source,tier="B",data_type="numeric" if label in {"template_size","flow_count"} else "categorical")
    for c in ("context.instrument", "context.lane_scope"):
        dictionary.loc[len(dictionary)] = dict(feature_name=c,component="context",source_file="observation_metadata",source_field=c,tier="B",data_type="categorical")
    dictionary.loc[len(dictionary)] = dict(feature_name="context.analyzed_lane_count",component="context",source_file="observation_metadata",source_field="chip_lane",tier="B",data_type="numeric")
    # Apply the same leakage/privacy rule to derived workflow labels too,
    # not only to values arriving through the structured-member extractor.
    blocked=[c for c in matrix if c not in META and forbidden(c)]
    matrix=matrix.drop(columns=blocked)
    dictionary=dictionary[~dictionary.feature_name.isin(blocked)].copy()
    pd.DataFrame([dict(feature_name=c,reason="derived_descriptor_sensitive_identifier_or_outcome_proxy") for c in blocked],columns=["feature_name","reason"]).to_csv(out/"derived_feature_policy_exclusions.csv",index=False)
    say(f"Auditing deterministic leakage copies across {len(matrix.columns)-len(META)} descriptors")
    copies=direct_target_copies(matrix)
    copies.to_csv(out/"deterministic_outcome_copy_audit.csv",index=False)
    if len(copies):
        matrix=matrix.drop(columns=copies.feature_name.unique())
        dictionary=dictionary[~dictionary.feature_name.isin(copies.feature_name)].copy()
    # Cached descriptors never invent a pressure unit. Retrospective field
    # audits can recover explicit unit labels but cannot recover absent units.
    # Keep raw QPM sensor counts under their explicit sensor-count identity;
    # omit other unresolved pressure magnitudes from the cross-instrument ML.
    unit_rows=[]
    for _,row in dictionary.iterrows():
        feature=str(row.feature_name);field=str(row.source_field)
        pressure=bool(re.search(r"pressure|vacuum",feature,re.I)) and not feature.startswith("qpm.")
        explicit=re.search(r"(?:^|[_ .-])(psi|kpa|mpa|mbar|bar|pa|mmhg|counts?)(?:$|[_ .-])",field,re.I)
        is_magnitude=pressure and not bool(re.search(r"duration|time|duty|oscillation|retry|count|ramp",feature,re.I))
        excluded=is_magnitude and explicit is None
        unit_rows.append(dict(feature_name=feature,source_field=field,source_file=row.source_file,
                              unit=explicit.group(1).lower() if explicit else ("baseline_centered_raw_sensor_counts_or_derived_shape" if feature.startswith("qpm.") else "not_verified_source_native"),
                              modeling_excluded=excluded,reason="pressure_magnitude_unit_unresolved_no_conversion_or_pooling" if excluded else "no_unverified_unit_conversion"))
    unit_audit=pd.DataFrame(unit_rows)
    unit_audit.to_csv(out/"feature_unit_audit.csv",index=False)
    omit=unit_audit.loc[unit_audit.modeling_excluded,"feature_name"]
    matrix=matrix.drop(columns=omit,errors="ignore")
    dictionary=dictionary[~dictionary.feature_name.isin(omit)].copy()
    # Historical software serializes a few logical settings as both numeric
    # flags and text (e.g. 0 versus "false"). Preserve them categorically;
    # never let a storage engine guess a numeric unit/type from mixed values.
    type_rows=[]
    for name in matrix.select_dtypes(exclude=[np.number]).columns:
        if name in META:
            continue
        kinds=sorted({type(v).__name__ for v in matrix[name].dropna()})
        matrix[name]=matrix[name].map(lambda v: None if pd.isna(v) else str(v))
        dictionary.loc[dictionary.feature_name.eq(name),"data_type"]="categorical"
        if len(kinds)>1:
            type_rows.append(dict(feature_name=name,source_types=";".join(kinds),treatment="categorical_preserve_raw_representation_no_numeric_assumption"))
    pd.DataFrame(type_rows,columns=["feature_name","source_types","treatment"]).to_csv(out/"mixed_type_audit.csv",index=False)
    dictionary.to_csv(out/"feature_dictionary.csv",index=False)
    pd.DataFrame([dict(archive_id=result["archive_id"],**r) for result in results for r in result["exclusions"]]).to_csv(out/"leakage_exclusions.csv",index=False)
    pd.DataFrame([dict(archive_id=result["archive_id"],members=result["members"],spatial_rows=result["spatial_rows"],features=len(result["features"]),warnings=";".join(result["warnings"])) for result in results]).to_csv(out/"archive_parse_audit.csv",index=False)
    source_cols = [c for c in records if c in META or "__source_" in c or "__discrepancy" in c]
    records[source_cols].to_csv(out/"outcome_source_provenance.csv",index=False)
    say(f"Writing validated modeling matrix {matrix.shape}")
    matrix.to_parquet(out/"training_dataset.parquet",index=False)
    coverage = dictionary.copy()
    coverage["nonmissing_observations"] = coverage.feature_name.map(matrix.notna().sum())
    coverage["unique_values"] = coverage.feature_name.map(matrix.nunique(dropna=True))
    coverage["missing_fraction"] = 1-coverage.nonmissing_observations/len(matrix)
    coverage["availability_time"] = coverage.tier.map({"A":"pre_run_setting","B":"context","C":"during_or_post_run_diagnostic"})
    coverage["unit"] = coverage.feature_name.map(lambda x: "baseline_centered_raw_sensor_counts_or_derived_shape" if x.startswith("qpm.") else "source_native_no_unverified_conversion")
    coverage.to_csv(out/"feature_coverage.csv",index=False)
    write_json(out/"extraction_log.json",dict(version=VERSION,feature_policy=POLICY_VERSION,bank=str(bank),
               archive_hashes=dict(zip(records.archive_id,records.archive_sha256)), observations=len(matrix),
               physical_runs=matrix.physical_run_id.nunique(),instruments=matrix.instrument_id.nunique(),
               features=len(matrix.columns)-len(META),outcomes={y:int(matrix[y].notna().sum()) for y in TARGETS},
               execution_seconds=time.monotonic()-started,source_code_sha256=sha256(Path(__file__)),
               cache_compatibility="Initial feature-cache executions were version/policy/archive-SHA pinned but not executable-source stamped. Nonsemantic mid-extraction edits repaired legacy container aliases and made writes atomic; extraction feature definitions and privacy filters did not change. QPM aggregation has a separate content/parser manifest; model caches include complete data/code/fold signatures.",
               limitations=["post-run diagnostic prediction, not causal or pre-run prognosis", "no outcome-qualified training filter", "large members >24MiB skipped before materialization; only total member count retained", "nested compressed members not recursively parsed", "histograms/final QC and identifiers excluded wholesale", "unresolved non-QPM pressure magnitudes excluded; no unit conversion invented", "raw QPM counts uncalibrated between instruments", "commanded-volume labels are not actual delivery measurements"]))
    say(f"Extraction complete: {len(matrix)} observations; {len(matrix.columns)-len(META)} candidate features")
    return matrix,dictionary


def prepare_strict(source, out):
    """Quarantine the audited prepared matrix without rereading raw archives.

    Feature availability and outcomes are unchanged. No target association is
    consulted: exclusions are exclusively source/provenance/privacy rules.
    The rejected first pass remains in place for audit, with an explicit
    withdrawal landing page instead of its misleading predictive report.
    """
    source=source.resolve();out=out.resolve();out.mkdir(parents=True,exist_ok=True)
    if source==out:
        raise ValueError("Strict snapshot must not overwrite its prepared source")
    if (out/"training_dataset.parquet").exists():
        raise FileExistsError("Strict dataset already exists; use train to resume its immutable snapshot")
    source_matrix=source/"training_dataset.parquet"
    source_sha=sha256(source_matrix)
    names=pq.read_schema(source_matrix).names
    rows=[dict(feature_name=c,reason=exclusion_reason(c)) for c in names if c not in META and forbidden(c)]
    blocked={r["feature_name"] for r in rows}
    keep=[c for c in names if c not in blocked]
    say(f"Strict provenance quarantine: removing {len(blocked):,}; retaining {len(keep)-len(META):,} descriptors")
    matrix=pd.read_parquet(source_matrix,columns=keep,use_threads=False)
    if any(forbidden(c) for c in matrix if c not in META):
        raise AssertionError("Strict source filtering failed")
    matrix.to_parquet(out/"training_dataset.parquet",index=False)
    for filename in ("feature_dictionary.csv","feature_coverage.csv"):
        value=pd.read_csv(source/filename)
        value=value[value.feature_name.isin(keep)].copy()
        value.to_csv(out/filename,index=False)
    for filename in ("archive_parse_audit.csv","outcome_source_provenance.csv","feature_unit_audit.csv",
                     "mixed_type_audit.csv","invalid_outcome_audit.csv","derived_feature_policy_exclusions.csv",
                     "deterministic_outcome_copy_audit.csv","leakage_exclusions.csv"):
        shutil.copy2(source/filename,out/filename)
    pd.DataFrame(rows,columns=["feature_name","reason"]).to_csv(out/"strict_leakage_quarantine.csv",index=False)
    original=json.loads((source/"extraction_log.json").read_text())
    original.update(version=VERSION,feature_policy=POLICY_VERSION,source_code_sha256=sha256(Path(__file__)),
                    features=len(keep)-len(META),prepared_source=str(source),prepared_source_dataset_sha256=source_sha,
                    strict_quarantined_features=len(blocked),strict_review="Independent source-family and nested-field audit; no outcome-dependent exclusion thresholds",
                    reviewed_plugin_families=sorted(REVIEWED_PLUGIN_FAMILIES),
                    limitations=original["limitations"]+["Initial model experiment withdrawn after nested outcome maps escaped filename guards; all contaminated aggregated families excluded in this strict snapshot", "Unreviewed plugin families excluded as provenance_unverified, not asserted leakage", "Calibration histograms also conservatively excluded; bounded eligible descriptors, not every CSA value"])
    write_json(out/"extraction_log.json",original)
    review=dict(status="strict_policy_frozen",feature_policy=POLICY_VERSION,code_sha256=sha256(Path(__file__)),
                prepared_source_dataset_sha256=source_sha,dataset_sha256=sha256(out/"training_dataset.parquet"),
                quarantined_features=len(blocked),reviewed_plugin_families=sorted(REVIEWED_PLUGIN_FAMILIES),
                contaminated_plugin_families=sorted(CONTAMINATED_PLUGIN_FAMILIES),prior_results="withdrawn_not_validated")
    write_json(out/"strict_policy_review.json",review)
    audit=source/"rejected_audit";audit.mkdir(exist_ok=True)
    for filename in ("expanded_csa_outcome_report.html","model_training_log.json"):
        destination=audit/filename
        if (source/filename).exists() and not destination.exists():
            shutil.copy2(source/filename,destination)
    oldlog=json.loads((audit/"model_training_log.json").read_text())
    oldlog.update(status="rejected_leakage_audit",invalidation_reason="Nested target histograms and pass-filter outcome maps contaminated the initial descriptor matrix",superseded_by=str(out),prior_results_valid=False)
    write_json(source/"model_training_log.json",oldlog)
    write_json(source/"leakage_review_status.json",dict(status="rejected",prior_results_valid=False,superseded_by=str(out),reason=oldlog["invalidation_reason"]))
    (source/"expanded_csa_outcome_report.html").write_text("<!doctype html><meta charset='utf-8'><title>Withdrawn CSA model experiment</title><style>body{font:20px system-ui;max-width:1000px;margin:60px;color:#253237}h1{color:#9c4221}</style><h1>Withdrawn: initial outcome-model results are invalid</h1><p>A source-level leakage audit found nested target-encoding histograms and pass-filter outcome maps, including aggregated rendered images. The initial predictive gains and rankings must not be interpreted or cited.</p><p>The original report is retained only in rejected_audit for traceability. A new conservative, independently reviewed descriptor policy quarantines these entire plugin families and all unreviewed families.</p><p><a href='../"+html.escape(out.name)+"/expanded_csa_outcome_report.html'>Strict replacement study</a> (available only after its fresh validation completes).</p>")
    say("Strict immutable dataset prepared; initial model results explicitly withdrawn")


def prepare_retrain(source,out):
    """Reuse a validated strict matrix unchanged; reference eligibility is separate."""
    source=source.resolve();out=out.resolve();out.mkdir(parents=True,exist_ok=True)
    seal=json.loads((source/"validation.json").read_text())
    if not seal["passed"] or seal["artifact_sha256"]["training_dataset.parquet"]!=sha256(source/"training_dataset.parquet"):
        raise ValueError("Prepared source lacks a valid immutable dataset seal")
    if (out/"training_dataset.parquet").exists():
        raise FileExistsError("Use train to resume an existing prepared retraining snapshot")
    files=["training_dataset.parquet","feature_dictionary.csv","feature_coverage.csv","archive_parse_audit.csv",
           "outcome_source_provenance.csv","feature_unit_audit.csv","mixed_type_audit.csv","invalid_outcome_audit.csv",
           "derived_feature_policy_exclusions.csv","deterministic_outcome_copy_audit.csv","leakage_exclusions.csv","strict_leakage_quarantine.csv"]
    for filename in files:
        shutil.copy2(source/filename,out/filename)
    log=json.loads((source/"extraction_log.json").read_text())
    log.update(version=VERSION,source_code_sha256=sha256(Path(__file__)),prepared_source=str(source),
               prepared_source_dataset_sha256=seal["artifact_sha256"]["training_dataset.parquet"],
               reference_qualification_policy=dict(GX5_minimum_reads_per_lane=12500000,GX7_minimum_reads_per_lane=25000000,GX8_minimum_reads_per_lane=25000000,GX9_minimum_reads_per_lane=50000000,training_cohort_filtered=False),
               comparison_note="GX8=GX7 is a healthy-reference/low-performance-trigger policy only. The complete good+bad modeling cohort, predictors, seed, nested folds, estimators and grids remain unchanged; only fresh fitting and feature-level explanation are added.")
    write_json(out/"extraction_log.json",log)
    review=json.loads((source/"strict_policy_review.json").read_text())
    review.update(code_sha256=sha256(Path(__file__)),dataset_sha256=sha256(out/"training_dataset.parquet"),
                  prepared_source=str(source),prepared_source_validation_sha256=sha256(source/"validation.json"),
                  retraining_version=VERSION,reference_policy_independent_of_training_filter=True)
    write_json(out/"strict_policy_review.json",review)
    say("Copied sealed strict matrix unchanged; reference qualification does not filter training")


def transformed_feature_audit(fitted,x,observed,prediction,target,scheme,fold,model,repeats=5):
    """Held-out raw-feature permutation with exact fold-fitted transforms.

    One raw feature jointly permutes all its selected numeric/dummy columns
    and imputation indicators. Fixed imputation/scaling commute with row
    permutation, so no test-dependent preprocessing or feature choice occurs.
    """
    reg=fitted.regressor_;selector=reg.named_steps["select"]
    sources=list(dict.fromkeys(c for _,c,_ in selector.selected_specs_))
    reduced=x[sources]
    z=reg[:-1].transform(reduced)
    estimator=reg.named_steps["model"]
    def inverse(p):
        return fitted.transformer_.inverse_transform(np.asarray(p).reshape(-1,1)).ravel()
    if not np.allclose(inverse(estimator.predict(z)),prediction):
        raise AssertionError("Feature-audit transformed prediction differs from original")
    cols={source:[i for i,(_,c,_) in enumerate(selector.selected_specs_) if c==source] for source in sources}
    imputer=reg.named_steps["impute"]
    for j,original in enumerate(imputer.indicator_.features_):
        source=selector.selected_specs_[original][1]
        cols[source].append(len(selector.selected_specs_)+j)
    original_error=np.abs(np.asarray(observed)-prediction)
    original_mae=float(original_error.mean())
    rng=np.random.default_rng(SEED)
    rows=[];coefficients=[]
    for source in sources:
        indices=cols[source];deltas=[]
        for _ in range(repeats):
            order=rng.permutation(len(z))
            if model=="elastic_net":
                change=(z[order][:,indices]-z[:,indices])@estimator.coef_[indices]
                p=prediction+change*float(fitted.transformer_.scale_[0])
            else:
                shuffled=z.copy();shuffled[:,indices]=z[order][:,indices]
                p=inverse(estimator.predict(shuffled))
            deltas.append(float(np.mean(np.abs(np.asarray(observed)-p)))-original_mae)
        rows.append(dict(outcome=target,validation_scheme=scheme,fold=fold,model=model,feature_name=source,
                         heldout_mae_increase=float(np.mean(deltas)),permutation_repeat_std=float(np.std(deltas)),
                         permutation_repeats=repeats,test_n=len(x),selected=True))
        if model=="elastic_net":
            for i in indices:
                indicator=i>=len(selector.selected_specs_)
                kind=selector.selected_specs_[i][0] if not indicator else "missing_indicator"
                transformed=selector.selected_names_[i] if not indicator else "missing_indicator_for."+source
                coefficients.append(dict(outcome=target,validation_scheme=scheme,fold=fold,model=model,
                                         feature_name=source,transformed_feature=transformed,transformation=kind,
                                         standardized_coefficient=float(estimator.coef_[i]),
                                         coefficient_outcome_units_per_training_x_sd=float(estimator.coef_[i]*fitted.transformer_.scale_[0])))
    return rows,coefficients


class FoldSelector(BaseEstimator, TransformerMixin):
    """Training-fold support, categories, duplicate removal and target selection."""
    def __init__(self,k=192):
        self.k=k

    def _numeric(self, X, fit=False):
        if fit:
            self.columns_=list(X.columns)
            self.numeric_columns_=list(X.select_dtypes(include=[np.number]).columns)
            numeric_set=set(self.numeric_columns_)
            self.categories_={}
            for c in self.columns_:
                if c not in numeric_set:
                    vals=X[c].dropna().astype(str).value_counts()
                    limit=100 if c.startswith("context.") else 12
                    self.categories_[c]=sorted(vals[vals>=3].index[:limit])
        arrays=[X[self.numeric_columns_].to_numpy(dtype=np.float32)]
        names=list(self.numeric_columns_)
        self.category_specs_=[]
        for c,levels in self.categories_.items():
            raw=X[c].astype(str)
            for level in levels:
                arrays.append(raw.eq(level).to_numpy(dtype=np.float32)[:,None])
                names.append(c+".level_"+hashlib.sha256(level.encode()).hexdigest()[:10])
                self.category_specs_.append((c,level))
        return np.concatenate(arrays,axis=1), names

    def fit(self,X,y):
        array,names=self._numeric(X,True)
        valid=np.isfinite(array)
        support=valid.sum(axis=0)
        context=np.asarray([name.startswith("context.") for name in names])
        candidate=np.flatnonzero((support>=max(8,int(.1*len(X)))) | (context & (support>=3)))
        array=array[:,candidate]
        valid=valid[:,candidate]
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            medians=np.nanmedian(np.where(valid,array,np.nan),axis=0)
        array=np.where(valid,array,medians)
        array=np.nan_to_num(array,nan=0,posinf=0,neginf=0)
        var=array.var(axis=0,dtype=np.float64)
        supported_columns=candidate
        candidate=np.flatnonzero(var>1e-12)
        # Hashing exact training columns prevents duplicated fields getting
        # several slots; no held-out rows influence this decision.
        seen=set(); unique=[]
        for i in candidate:
            digest=hashlib.sha256(array[:,i].tobytes()).digest()
            if digest not in seen:
                seen.add(digest); unique.append(i)
        candidate=np.asarray(unique,dtype=int)
        if not len(candidate):
            raise ValueError("No nonconstant supported predictors in training fold")
        sub=array[:,candidate].astype(np.float64)
        center=np.asarray(y,dtype=np.float64)-np.mean(y)
        sub-=sub.mean(axis=0)
        score=np.abs(sub.T@center)/(np.sqrt((sub*sub).sum(axis=0))*np.sqrt((center*center).sum())+1e-12)
        self.indices_=supported_columns[candidate[np.argsort(score,kind="stable")[-min(self.k,len(candidate)):]]]
        self.selected_names_=[names[i] for i in self.indices_]
        self.selected_specs_=[("numeric",self.numeric_columns_[i],None) if i<len(self.numeric_columns_) else ("categorical",*self.category_specs_[i-len(self.numeric_columns_)]) for i in self.indices_]
        return self

    def transform(self,X):
        a=np.empty((len(X),len(self.selected_specs_)),dtype=np.float32)
        numeric=[(i,c) for i,(kind,c,_) in enumerate(self.selected_specs_) if kind=="numeric"]
        if numeric:
            a[:,[i for i,_ in numeric]]=X[[c for _,c in numeric]].to_numpy(dtype=np.float32)
        for i,(kind,c,level) in enumerate(self.selected_specs_):
            if kind=="categorical":
                a[:,i]=X[c].astype(str).eq(level).to_numpy(dtype=np.float32)
        return np.where(np.isfinite(a),a,np.nan)


def pipeline(model):
    if model=="elastic_net":
        estimator=ElasticNet(max_iter=5000,tol=.001,random_state=SEED)
        grid={"regressor__model__alpha":[.03,.3],"regressor__model__l1_ratio":[.5]}
    else:
        estimator=ExtraTreesRegressor(n_estimators=160,max_depth=6,min_samples_leaf=8,max_features="sqrt",n_jobs=1,random_state=SEED)
        grid={"regressor__model__max_depth":[4,8]}
    pipe=Pipeline([("select",FoldSelector()),("impute",SimpleImputer(strategy="median",add_indicator=True)),("scale",StandardScaler()),("model",estimator)])
    return TransformedTargetRegressor(regressor=pipe,transformer=StandardScaler()),grid


def splits(frame):
    groups=frame.physical_run_id.to_numpy()
    rows=[]
    for i,(tr,te) in enumerate(GroupKFold(5).split(frame,groups=groups)):
        rows.append(("grouped",f"group_{i+1}",tr,te))
    for instrument in sorted(frame.instrument_id.unique()):
        te=np.flatnonzero(frame.instrument_id.eq(instrument)); tr=np.flatnonzero(frame.instrument_id.ne(instrument))
        if len(te)>=2 and len(np.unique(groups[tr]))>=20:
            rows.append(("leave_one_instrument_out",str(instrument),tr,te))
    dates=pd.to_datetime(frame.run_start_time,utc=True,errors="coerce")
    gd=pd.DataFrame(dict(g=groups,t=dates)).groupby("g").t.min().dropna().sort_values()
    if len(gd)>=25:
        cutoff=gd.iloc[-math.ceil(.2*len(gd))]
        train_groups=set(gd.index[gd<cutoff]); test_groups=set(gd.index[gd>=cutoff])
        tr=np.flatnonzero(np.isin(groups,list(train_groups)));te=np.flatnonzero(np.isin(groups,list(test_groups)))
        if len(tr)>=20 and len(te)>=2:
            rows.append(("chronological","newest_20pct",tr,te))
    for scheme,fold,tr,te in rows:
        assert not set(groups[tr])&set(groups[te])
        if scheme=="chronological":
            assert dates.iloc[tr].max()<dates.iloc[te].min()
    return rows


def metrics(obs,pred):
    return dict(mae=float(mean_absolute_error(obs,pred)),rmse=float(np.sqrt(mean_squared_error(obs,pred))),r2=float(r2_score(obs,pred)) if len(obs)>1 else None,
                spearman=float(stats.spearmanr(obs,pred).statistic) if len(obs)>2 and len(np.unique(pred))>1 else None)


def worker_dataset(path,expected_sha):
    """One immutable, hash-verified raw matrix per bounded worker process."""
    path=Path(path).resolve()
    key=(str(path),expected_sha)
    stat=path.stat();signature=(stat.st_size,stat.st_mtime_ns)
    if key in _WORKER_DATASETS:
        frame,original=_WORKER_DATASETS[key]
        if signature!=original:
            raise ValueError("Pinned modeling dataset changed during fitting")
        return frame
    if sha256(path)!=expected_sha:
        raise ValueError("Model dataset content hash mismatch")
    frame=pd.read_parquet(path,use_threads=False)
    _WORKER_DATASETS.clear()
    _WORKER_DATASETS[key]=(frame,signature)
    return frame


def fit_task(dataset_path, out, target, scheme, fold, tr, te, model, features, input_signature):
    cache_payload=dict(target=target,scheme=scheme,fold=fold,model=model,version=VERSION,
                       input_signature=input_signature,train_indices=tr.tolist(),test_indices=te.tolist())
    cache=Path(out)/".model_cache"/(hashlib.sha256(json.dumps(cache_payload,sort_keys=True).encode()).hexdigest()[:24]+".joblib")
    if cache.exists():
        return joblib.load(cache)
    source=worker_dataset(dataset_path,input_signature["dataset_sha256"])
    frame=source[list(dict.fromkeys(META+features))]
    frame=frame[pd.to_numeric(frame[target],errors="coerce").notna()].reset_index(drop=True)
    x=frame[features];y=frame[target].astype(float)
    base_model=model.removeprefix("context_only_")
    pipe,grid=pipeline(base_model)
    inner=GroupKFold(min(2,frame.iloc[tr].physical_run_id.nunique()))
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        search=GridSearchCV(pipe,grid,cv=inner,scoring="neg_mean_absolute_error",n_jobs=1,error_score="raise")
        search.fit(x.iloc[tr],y.iloc[tr],groups=frame.iloc[tr].physical_run_id)
        prediction=search.predict(x.iloc[te])
    baseline=np.repeat(y.iloc[tr].median(),len(te))
    q1,q3=y.iloc[tr].quantile([.25,.75]); iqr=q3-q1
    rows=[]
    for index,p,b in zip(te,prediction,baseline):
        rows.append(dict(outcome=target,validation_scheme=scheme,fold=fold,model=model,
                         observation_id=frame.loc[index,"observation_id"],physical_run_id=frame.loc[index,"physical_run_id"],
                         instrument_id=frame.loc[index,"instrument_id"],observed=y.iloc[index],predicted=p,baseline_predicted=b,
                         outcome_outlier_3iqr=bool(y.iloc[index]<q1-3*iqr or y.iloc[index]>q3+3*iqr)))
    importance=[];feature_importance=[];coefficients=[]
    if scheme in {"grouped","chronological"} and not model.startswith("context_only_"):
        selected=search.best_estimator_.regressor_.named_steps["select"].selected_names_
        selector=search.best_estimator_.regressor_.named_steps["select"]
        source_columns=list(dict.fromkeys(c for _,c,_ in selector.selected_specs_))
        reduced=x.iloc[te][source_columns].copy()
        if not np.allclose(search.predict(reduced),prediction,equal_nan=True):
            raise AssertionError("Selected-source prediction optimization changed model output")
        components=sorted(set(component(c.split(".level_")[0]) for c in selected))
        original=float(mean_absolute_error(y.iloc[te],prediction))
        rng=np.random.default_rng(SEED)
        # Joint held-out permutation preserves each component's internal
        # correlations. Importance is interpreted only after generalization.
        for comp in components:
            cols=[c for c in source_columns if component(c)==comp]
            deltas=[]
            for repeat in range(3):
                shuffled=reduced.copy()
                order=rng.permutation(len(shuffled))
                shuffled[cols]=shuffled[cols].iloc[order].to_numpy()
                deltas.append(float(mean_absolute_error(y.iloc[te],search.predict(shuffled)))-original)
            importance.append(dict(outcome=target,validation_scheme=scheme,fold=fold,model=model,component=comp,heldout_mae_increase=float(np.mean(deltas)),repeat_std=float(np.std(deltas)),test_n=len(te)))
        feature_importance,coefficients=transformed_feature_audit(search.best_estimator_,reduced,y.iloc[te].to_numpy(),prediction,target,scheme,fold,model)
    result=dict(predictions=rows,importance=importance,feature_importance=feature_importance,coefficients=coefficients,settings=dict(outcome=target,scheme=scheme,fold=fold,model=model,best_params=search.best_params_,inner_mae=-float(search.best_score_),selected=search.best_estimator_.regressor_.named_steps["select"].selected_names_),warnings=sorted(set(type(w.message).__name__ for w in caught)))
    joblib.dump(result,cache,compress=3)
    return result


def train(out,workers):
    start=time.monotonic(); frame=pd.read_parquet(out/"training_dataset.parquet")
    features=[c for c in frame if c not in META]
    (out/".model_cache").mkdir(exist_ok=True)
    input_signature=dict(dataset_sha256=sha256(out/"training_dataset.parquet"),
                         feature_columns_sha256=hashlib.sha256(json.dumps(features).encode()).hexdigest(),
                         code_sha256=sha256(Path(__file__)),policy=POLICY_VERSION,seed=SEED,
                         groups_sha256=hashlib.sha256(frame[["observation_id","physical_run_id","instrument_id","run_start_time"]].to_json(orient="split").encode()).hexdigest(),
                         model_definitions=hashlib.sha256((inspect.getsource(FoldSelector)+inspect.getsource(pipeline)+inspect.getsource(splits)+inspect.getsource(fit_task)).encode()).hexdigest())
    tasks=[]; skipped=[]
    for target in TARGETS:
        valid=frame[frame[target].notna()].reset_index(drop=True)
        if len(valid)<30 or valid.physical_run_id.nunique()<20:
            skipped.append(dict(outcome=target,usable_n=len(valid),reason="insufficient_independent_labels"));continue
        for scheme,fold,tr,te in splits(valid):
            for model in ("elastic_net","extra_trees","context_only_elastic_net","context_only_extra_trees"):
                use_features=[f for f in features if f.startswith("context.")] if model.startswith("context_only_") else features
                tasks.append((str(out/"training_dataset.parquet"),str(out),target,scheme,fold,tr,te,model,use_features,input_signature))
    results=[]
    say(f"Running {len(tasks)} nested outer model evaluations on complete good+bad cohort")
    with ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context("spawn")) as pool:
        futures=[pool.submit(fit_task,*t) for t in tasks]
        for future in as_completed(futures):
            results.append(future.result())
            if len(results)%5==0 or len(results)==len(tasks):
                say(f"Nested model evaluations {len(results)}/{len(tasks)}, {time.monotonic()-start:.0f}s elapsed")
    predictions=pd.DataFrame([r for result in results for r in result["predictions"]])
    if predictions.empty:
        write_json(out/"model_training_log.json",dict(status="no_trainable_outcomes",skipped=skipped));return
    baseline=predictions.drop_duplicates(["outcome","validation_scheme","fold","observation_id"]).copy()
    baseline["model"]="median_baseline";baseline["predicted"]=baseline.baseline_predicted
    predictions=pd.concat([predictions,baseline],ignore_index=True)
    predictions.to_csv(out/"heldout_predictions.csv",index=False)
    performance=[]
    per_instrument=[]
    for keys,g in predictions.groupby(["outcome","validation_scheme","model"]):
        vals=metrics(g.observed,g.predicted);bm=metrics(g.observed,g.baseline_predicted)
        errors=pd.DataFrame(dict(g=g.physical_run_id.to_numpy(), e=np.abs(g.observed-g.predicted),b=np.abs(g.observed-g.baseline_predicted),n=1.)).groupby("g").sum()
        rng=np.random.default_rng(SEED)
        draws=rng.integers(len(errors),size=(500,len(errors)))
        ns=errors.n.to_numpy()[draws].sum(axis=1)
        ea=errors.e.to_numpy()[draws].sum(axis=1)/ns
        ba=errors.b.to_numpy()[draws].sum(axis=1)/ns
        improvement=100*(ba-ea)/ba
        performance.append(dict(zip(["outcome","validation_scheme","model"],keys),n_observations=len(g),n_physical_runs=g.physical_run_id.nunique(),instruments=g.instrument_id.nunique(),baseline_mae=bm["mae"],mae_improvement_pct=100*(bm["mae"]-vals["mae"])/bm["mae"],mae_ci_low=float(np.quantile(ea,.025)),mae_ci_high=float(np.quantile(ea,.975)),improvement_ci_low_pct=float(np.quantile(improvement,.025)),improvement_ci_high_pct=float(np.quantile(improvement,.975)),**vals))
        for instrument,sub in g.groupby("instrument_id"):
            per_instrument.append(dict(zip(["outcome","validation_scheme","model"],keys),instrument_id=instrument,n=len(sub),**metrics(sub.observed,sub.predicted)))
    performance=pd.DataFrame(performance)
    for idx,row in performance.iterrows():
        if row["model"] in {"elastic_net","extra_trees"}:
            control=performance[(performance.outcome==row.outcome)&(performance.validation_scheme==row.validation_scheme)&performance.model.eq("context_only_"+row.model)]
            if len(control)==1:
                value=float(control.iloc[0].mae)
                performance.loc[idx,"context_only_mae"]=value
                performance.loc[idx,"mae_improvement_over_context_pct"]=100*(value-row.mae)/value
                full=predictions[(predictions.outcome==row.outcome)&predictions.validation_scheme.eq(row.validation_scheme)&predictions.model.eq(row.model)]
                ctl=predictions[(predictions.outcome==row.outcome)&predictions.validation_scheme.eq(row.validation_scheme)&predictions.model.eq("context_only_"+row.model)]
                paired=full.merge(ctl[["fold","observation_id","predicted"]].rename(columns={"predicted":"context_predicted"}),on=["fold","observation_id"],validate="one_to_one")
                errors=pd.DataFrame(dict(g=paired.physical_run_id.to_numpy(),e=np.abs(paired.observed-paired.predicted),c=np.abs(paired.observed-paired.context_predicted),n=1.)).groupby("g").sum()
                rng=np.random.default_rng(SEED);draws=rng.integers(len(errors),size=(500,len(errors)))
                e=errors.e.to_numpy()[draws].sum(axis=1)/errors.n.to_numpy()[draws].sum(axis=1)
                c=errors.c.to_numpy()[draws].sum(axis=1)/errors.n.to_numpy()[draws].sum(axis=1)
                delta=100*(c-e)/c
                performance.loc[idx,"context_improvement_ci_low_pct"]=float(np.quantile(delta,.025))
                performance.loc[idx,"context_improvement_ci_high_pct"]=float(np.quantile(delta,.975))
    performance.to_csv(out/"model_performance.csv",index=False)
    pd.DataFrame(per_instrument).to_csv(out/"per_instrument_performance.csv",index=False)
    folds=[];sensitivity=[]
    for keys,g in predictions.groupby(["outcome","validation_scheme","fold","model"]):
        folds.append(dict(zip(["outcome","validation_scheme","fold","model"],keys),n=len(g),**metrics(g.observed,g.predicted)))
    pd.DataFrame(folds).to_csv(out/"fold_performance.csv",index=False)
    for keys,g in predictions.groupby(["outcome","validation_scheme","model"]):
        subset=g[~g.outcome_outlier_3iqr]
        if len(subset)>1:
            sensitivity.append(dict(zip(["outcome","validation_scheme","model"],keys),removed_3iqr=len(g)-len(subset),remaining=len(subset),**metrics(subset.observed,subset.predicted)))
    pd.DataFrame(sensitivity).to_csv(out/"outlier_sensitivity.csv",index=False)
    importance=pd.DataFrame([r for result in results for r in result["importance"]])
    if len(importance):
        for (target,model),idx in importance.groupby(["outcome","model"]).groups.items():
            validation=performance[(performance.outcome==target)&performance.model.eq(model)]
            baseline_support=bool(len(validation)==3 and validation.improvement_ci_low_pct.gt(0).all())
            context_support=bool("context_improvement_ci_low_pct" in validation and validation.context_improvement_ci_low_pct.gt(0).all())
            importance.loc[idx,"support_status"]="diagnostic_association_supported_across_validations" if baseline_support and context_support else "exploratory_only_model_not_consistently_above_baseline_and_context"
    importance.to_csv(out/"component_importance_folds.csv",index=False)
    if len(importance):
        importance.groupby(["outcome","validation_scheme","model","component"]).agg(heldout_mae_increase=("heldout_mae_increase","mean"),fold_std=("heldout_mae_increase","std"),positive_folds=("heldout_mae_increase",lambda s:int((s>0).sum())),folds=("fold","nunique"),support_status=("support_status","first")).reset_index().to_csv(out/"component_importance.csv",index=False)
    summarize_feature_audit(out,results,performance)
    write_json(out/"model_settings.json",[r["settings"] for r in results])
    write_json(out/"model_training_log.json",dict(status="validation_complete_final_refit_running",version=VERSION,seed=SEED,feature_policy=POLICY_VERSION,execution_seconds=time.monotonic()-start,skipped=skipped,model_tasks=len(tasks),
               code_sha256=sha256(Path(__file__)),dataset_sha256=sha256(out/"training_dataset.parquet"),input_signature=input_signature,validation="nested2-fold grouped selection, 5 outer physical-run folds, leave-one-instrument-out, strict chronological newest20%",warnings=[r["warnings"] for r in results if r["warnings"]]))
    render(out,frame,performance,skipped)
    # Refit after validation for reproducible offline inference, with a model
    # card preventing these post-run models being mistaken for prognosis.
    import train_expanded_csa_outcomes as stable_module
    cards=[]
    for target in TARGETS:
        valid=frame[frame[target].notna()].reset_index(drop=True)
        if len(valid)<30 or valid.physical_run_id.nunique()<20:
            continue
        for model in ("elastic_net","extra_trees"):
            pipe,grid=stable_module.pipeline(model)
            search=GridSearchCV(pipe,grid,cv=GroupKFold(3),scoring="neg_mean_absolute_error",n_jobs=1,error_score="raise")
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                search.fit(valid[features],valid[target],groups=valid.physical_run_id)
            joblib.dump(dict(model=search.best_estimator_,feature_columns=features,target=target,policy=POLICY_VERSION,training_version=VERSION,nominal_use="post-run diagnostic outcome reconstruction; not a future-run forecast"),out/f"{target}_{model}_final.joblib",compress=3)
            scores=performance[(performance.outcome==target)&performance.model.eq(model)]
            cards.append(dict(target=target,model=model,parameters=search.best_params_,validation_all_schemes_improve=bool(scores.mae_improvement_pct.gt(0).all()),future_forecasting_validated=False,causal_tuning_validated=False,labels=len(valid),physical_runs=valid.physical_run_id.nunique()))
    write_json(out/"model_cards.json",cards)
    log=json.loads((out/"model_training_log.json").read_text())
    log.update(status="complete",execution_seconds=time.monotonic()-start,packages=dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__,sklearn=sklearn.__version__),
               code_hashes={p:sha256(Path(__file__).parent/p) for p in ["train_expanded_csa_outcomes.py","analyze_csa.py","train_multimodal_csa.py","forecast_next_run_csa.py","qpm_trace_quality.py","build_expanded_reference_bank.py"]})
    write_json(out/"model_training_log.json",log)
    say("Expanded outcome training complete")


def summarize_feature_audit(out,results,performance):
    raw=pd.DataFrame([r for result in results for r in result.get("feature_importance",[])])
    coefficients=pd.DataFrame([r for result in results for r in result.get("coefficients",[])])
    coefficients.to_csv(out/"elastic_net_feature_coefficients.csv",index=False)
    dictionary=pd.read_csv(out/"feature_dictionary.csv").set_index("feature_name")
    units=pd.read_csv(out/"feature_coverage.csv").set_index("feature_name").unit
    all_rows=[];summaries=[]
    for (target,scheme,model),group in raw.groupby(["outcome","validation_scheme","model"]):
        folds=sorted(group.fold.unique());names=sorted(raw.loc[raw.outcome.eq(target)&raw.model.eq(model),"feature_name"].unique())
        indexed=group.set_index(["feature_name","fold"])
        control=performance[performance.outcome.eq(target)&performance.model.eq(model)]
        model_supported=bool(len(control)==3 and control.improvement_ci_low_pct.gt(0).all() and control.context_improvement_ci_low_pct.gt(0).all())
        for feature in names:
            rows=[]
            for fold in folds:
                if (feature,fold) in indexed.index:
                    row=indexed.loc[(feature,fold)].to_dict();row.update(feature_name=feature,fold=fold)
                else:
                    row=dict(feature_name=feature,fold=fold,heldout_mae_increase=0.,permutation_repeat_std=0.,permutation_repeats=5,selected=False,test_n=int(group[group.fold.eq(fold)].test_n.iloc[0]))
                row.update(outcome=target,validation_scheme=scheme,model=model);rows.append(row)
            all_rows.extend(rows)
            values=np.asarray([r["heldout_mae_increase"] for r in rows]);selected=sum(bool(r["selected"]) for r in rows)
            rng=np.random.default_rng(SEED)
            if len(values)>=2:
                boot=values[rng.integers(len(values),size=(2000,len(values)))].mean(axis=1)
                low,high=np.quantile(boot,[.025,.975]);uncertainty="outer_fold_bootstrap_exploratory_not_physical_run_ci"
            else:
                low=high=np.nan;uncertainty="one_chronological_holdout_no_between_fold_ci"
            c=coefficients[coefficients.outcome.eq(target)&coefficients.validation_scheme.eq(scheme)&coefficients.model.eq(model)&coefficients.feature_name.eq(feature)&coefficients.transformation.eq("numeric")] if len(coefficients) else pd.DataFrame()
            signs=c.standardized_coefficient.to_numpy() if len(c) else np.asarray([])
            pos=int((signs>0).sum());neg=int((signs<0).sum())
            direction="positive_conditional_association" if pos>neg else "negative_conditional_association" if neg>pos else "not_resolved_or_categorical"
            metadata=dictionary.loc[feature].to_dict() if feature in dictionary.index else {}
            positive=int((values>0).sum())
            supported=model_supported and scheme=="grouped" and selected>=4 and positive>=4 and low>0
            summaries.append(dict(outcome=target,validation_scheme=scheme,model=model,feature_name=feature,**metadata,
                unit=units.get(feature,"source_native_not_verified"),heldout_mae_increase=float(values.mean()),
                importance_ci_low=float(low),importance_ci_high=float(high),uncertainty_method=uncertainty,
                outer_folds=len(folds),selection_count=selected,selection_frequency=selected/len(folds),positive_folds=positive,
                median_standardized_coefficient=float(np.median(signs)) if len(signs) else np.nan,
                coefficient_positive_folds=pos,coefficient_negative_folds=neg,direction=direction,
                support_status="supported_diagnostic_association_not_causal" if supported else "exploratory_not_stable_across_all_validations",
                caveat="Unselected folds are zero; correlated features split or mask importance; coefficients are conditional associations, not intervention effects"))
    pd.DataFrame(all_rows).to_csv(out/"feature_importance_folds.csv",index=False)
    summary=pd.DataFrame(summaries).sort_values(["outcome","validation_scheme","model","heldout_mae_increase"],ascending=[True,True,True,False])
    summary.to_csv(out/"feature_rankings.csv",index=False)


def render(out,frame,performance,skipped):
    parts=["<!doctype html><meta charset='utf-8'><title>Expanded CSA outcome models</title><style>body{font:16px system-ui;margin:40px;max-width:1400px;color:#253237;background:#f4f1de}table{border-collapse:collapse;background:white;font-size:14px}td,th{padding:8px;border-bottom:1px solid #ddd}h1,h2{color:#31572c}.note{background:#fff6df;padding:18px}</style><h1>Expanded CSA: leakage-reviewed outcome prediction</h1>",f"<p>{len(frame):,} run/lane observations · {frame.physical_run_id.nunique():,} physical runs · {frame.instrument_id.nunique()} instruments · {len(frame.columns)-len(META):,} candidate descriptors.</p>","<p class='note'>Post-run diagnostic models, not future-run prognosis or causal explanations. Both good and bad runs are retained. All imputation, category creation, duplicate removal, feature selection, scaling, and hyperparameter selection happen inside training folds. Sibling lanes and reanalyses are kept together. Raw read length is never replaced by AQ20 length. Model performance is reported separately for unseen runs, instruments, and future dates.</p>","<h2>Outcome availability</h2>",pd.DataFrame([dict(outcome=y,available=int(frame[y].notna().sum()),missing=int(frame[y].isna().sum())) for y in TARGETS]).to_html(index=False),"<h2>Held-out performance</h2>",performance.to_html(index=False,float_format=lambda x:f"{x:,.3f}"),"<p>MAE and RMSE are in reads, base pairs, or percentage points for their corresponding outcomes. Positive MAE improvement is better than the training-fold median.</p>"]
    parts.insert(2,"<p class='note'>Strict replacement experiment: initial outcome-model results were withdrawn after nested target-encoding histograms and pass-filter maps were discovered. This study excludes the entire TrueLoading, EdgeEffects, LaneDiagnostics and ReseqDiagnostics families including aggregated images, all other unreviewed plugin families, nested histogram aliases, final summaries, clinical input, identifiers, dates and status metadata. Only independently reviewed raw physical-diagnostic families remain. No earlier metric or ranking is reused. <a href='strict_leakage_quarantine.csv'>Full quarantine audit</a>.</p>")
    if skipped:
        parts += ["<h2>Unavailable outcomes</h2>",pd.DataFrame(skipped).to_html(index=False)]
    ranking=pd.read_csv(out/"feature_rankings.csv")
    parts += ["<h2>Specific held-out features</h2><p>The GX8=GX7 read criterion updates reference eligibility and low-performance triggering only. This fresh retraining deliberately preserves the same complete good+bad cohort and strict feature matrix. Feature importance uses five held-out shuffles after training-fold selection in all five grouped folds and the chronological holdout. A feature not selected in a fold contributes zero. Direction is an Elastic Net standardized conditional coefficient, not an expected effect from changing a setting. Correlated features can mask or divide importance; fold-bootstrap intervals are exploratory, not causal or physical-run confidence intervals. Read-length rankings remain exploratory if chronological incremental value is uncertain.</p>"]
    for target in TARGETS[:2]:
        view=ranking[ranking.outcome.eq(target)&ranking.validation_scheme.eq("grouped")&ranking.model.eq("elastic_net")].head(12)
        fields=["feature_name","tier","heldout_mae_increase","importance_ci_low","importance_ci_high","selection_count","outer_folds","positive_folds","direction","support_status","source_file","source_field","unit"]
        parts += ["<h3>"+html.escape(target)+"</h3>",view[fields].to_html(index=False,float_format=lambda x:f"{x:,.4g}")]
    parts += ["<p><a href='feature_rankings.csv'>All feature rankings</a> · <a href='feature_importance_folds.csv'>Fold-level feature audit including unselected zeros</a> · <a href='elastic_net_feature_coefficients.csv'>Signed standardized coefficients</a></p>"]
    importance=pd.read_csv(out/"component_importance.csv") if (out/"component_importance.csv").exists() else pd.DataFrame()
    supported=importance[importance.support_status.eq("diagnostic_association_supported_across_validations") & importance.validation_scheme.eq("grouped") & importance.heldout_mae_increase.gt(0) & importance.positive_folds.ge(4)] if len(importance) else pd.DataFrame()
    parts += ["<h2>Main contributing components</h2>"]
    if len(supported):
        parts += [supported.sort_values(["outcome","heldout_mae_increase"],ascending=[True,False]).groupby(["outcome","model"]).head(5).to_html(index=False),"<p>Components must have positive held-out permutation contribution in at least4/5groupedfolds; the underlying model must beat bothmedian andcontext controls in allthreevalidation schemes withpositivebootstraplowerbounds. Correlated components can share or mask one another's importance. This is not causal evidence.</p>"]
    else:
        parts += ["<p>No component ranking cleared the pre-specified full-model generalization and incremental-value gates. Exploratory held-out permutations remain downloadable for audit, not tuning recommendations.</p>"]
    parts += ["<h2>Held-out summary</h2><img src='expanded_csa_prediction_summary.png' style='width:100%'>", "<h2>Interpretation</h2><p>Feature importance is association among contemporaneous process diagnostics. It cannot establish an instrument setting to change. Independent delivered-volume measurements are not present in this outcome experiment. Missing outcome labels or incompatible physical contexts remain unresolved, never normal. Total-read models predict the documented analysis scope (one or multiple lanes), with lane count included as context; counts from overlapping analyses are never added together. Confidence intervals resample independent physical runs. Aggregate scores are observation-weighted; per-instrument and fold metrics are also provided.</p>","<p><a href='model_performance.csv'>Metrics</a> · <a href='heldout_predictions.csv'>All held-out predictions</a> · <a href='component_importance.csv'>Held-out component permutation</a> · <a href='feature_coverage.csv'>Feature coverage</a> · <a href='leakage_exclusions.csv'>Leakage exclusions</a> · <a href='outcome_source_provenance.csv'>Outcome provenance</a> · <a href='model_training_log.json'>Reproducibility log</a></p>"]
    (out/"expanded_csa_outcome_report.html").write_text("\n".join(parts))
    plot_summary(out,frame,performance)


def plot_summary(out,frame,performance):
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt
    matplotlib.rcParams.update({"pdf.fonttype":42,"ps.fonttype":42,"font.size":11,"axes.spines.top":False,"axes.spines.right":False})
    fig,axes=plt.subplots(1,3,figsize=(17,5.8),layout="constrained")
    names={"grouped":"Unseen physical runs","leave_one_instrument_out":"Unseen instruments","chronological":"Newest runs"}
    colors={"elastic_net":"#457b9d","extra_trees":"#4f772d"}
    for ax,target,title in zip(axes[:2],TARGETS[:2],["Total reads","Mean raw read length"]):
        for j,model in enumerate(colors):
            sub=performance[(performance.outcome==target)&performance.model.eq(model)].set_index("validation_scheme")
            for i,scheme in enumerate(names):
                if scheme not in sub.index:
                    continue
                row=sub.loc[scheme]; y=i+(j-.5)*.26
                ax.errorbar(row.mae_improvement_over_context_pct,y,xerr=[[max(0,row.mae_improvement_over_context_pct-row.context_improvement_ci_low_pct)],[max(0,row.context_improvement_ci_high_pct-row.mae_improvement_over_context_pct)]],fmt="o",color=colors[model],capsize=3,label=model.replace("_"," ").title() if i==0 else None)
        ax.axvline(0,color="#bc6c25",ls="--")
        ax.set_yticks(list(range(3)),list(names.values()));ax.invert_yaxis()
        ax.set(title=title,xlabel="Full CSA MAE improvement vs context-only (%)")
        ax.grid(axis="x",alpha=.2);ax.legend(frameon=False,loc="lower right")
    axes[2].axis("off")
    axes[2].text(0,1,"Expanded-bank outcome study",fontsize=17,weight="bold",color="#31572c",va="top")
    axes[2].text(0,.86,f"{len(frame):,} run/lane observations\n{frame.physical_run_id.nunique():,} independent physical runs\n{frame.instrument_id.nunique()} instruments\n\nAccuracy labels: {frame.raw_read_accuracy_pct.notna().sum()}\nNo credible accuracy model\n\nControls: chip + lane + protocol/context\n95% intervals: physical-run bootstrap\nAll feature learning inside folds\nGood + bad runs retained\n\nPost-run diagnostic prediction\nNot future-run forecasting\nNot causal tuning evidence",va="top",linespacing=1.5)
    fig.suptitle("Do richer CSA diagnostics add beyond chip, lane, and protocol context?",fontsize=19,weight="bold",color="#253237")
    fig.savefig(out/"expanded_csa_prediction_summary.png",dpi=180)
    fig.savefig(out/"expanded_csa_prediction_summary.pdf")
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--bank",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--workers",type=int,default=8)
    parser.add_argument("--model-workers",type=int,default=4)
    parser.add_argument("--limit",type=int,default=0)
    parser.add_argument("--stage",choices=["extract","train","all","strict-refit","retrain-prepared"],default="all")
    parser.add_argument("--prepared-source",type=Path)
    args=parser.parse_args()
    if args.stage=="retrain-prepared":
        if args.prepared_source is None:
            parser.error("retrain-prepared requires --prepared-source")
        prepare_retrain(args.prepared_source,args.output)
    if args.stage=="strict-refit":
        if args.prepared_source is None:
            parser.error("strict-refit requires --prepared-source")
        prepare_strict(args.prepared_source,args.output)
    if args.stage in {"extract","all"}:
        extract(args.bank.resolve(),args.output.resolve(),args.workers,args.limit)
    if args.stage in {"train","all","strict-refit","retrain-prepared"}:
        train(args.output.resolve(),args.model_workers)


if __name__=="__main__":
    main()
