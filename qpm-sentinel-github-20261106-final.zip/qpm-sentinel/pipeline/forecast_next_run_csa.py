#!/usr/bin/env python3
"""Offline, as-of-time CSA forecasting. Never changes instruments or the reference bank.

The prediction unit is a future physical run (all retained lanes kept together).
Only CSA exports whose remote mtime precedes that run are allowed as predictors.
This is an availability proxy, not a verified instrument completion timestamp.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import sklearn
from scipy import stats
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss,
                             log_loss, roc_auc_score, precision_score, recall_score)
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from outcome_reference import load_policy, load_outcome_table, benchmark_table

VERSION = "csa-next-observed-run-forecast-1.0.0"
SEED = 20261021
TARGETS = ["low_total_reads", "short_mean_read_length"]
FAMILIES = ["history_only", "history_configuration_context", "history_fluidics",
            "history_spatial_plugins", "history_all_csa"]
PARAMS = [("logistic", 8, .05), ("logistic", 20, .5),
          ("extra_trees", 8, 3), ("extra_trees", 20, 5)]
FORBIDDEN = re.compile(
    r"password|passwd|secret|token|credential|api.?key|patient|operator|username|"
    r"email|hostname|ip_address|mac_address|serial|barcode_sequence|sample_name|"
    r"sample_id|sample_external|remote_path|(?:^|[._])(?:path|filename|filepath|"
    r"directory|timestamp|guid|uuid|hash|run_id|analysis_id|experiment_id)(?:$|[._])|"
    r"(?:_dir|_file|_date|_time)$|(?:^|[._])(?:start_time|end_time|time_stamp)|"
    r"(?:^|[._])network(?:$|[._])|run_date_ordinal|wafer_id|package_test_id|"
    r"(?:^|[._])(?:pk|uuid|guid)(?:$|[._])|(?:analysis|result|experiment)_pk|"
    r"exp_json_(?:id|pk)$|plugin\.bubbleplots\.structured\.|plugin\.serverdata\.", re.I)
SAFE_CATEGORICAL = re.compile(
    r"chip_type|chiptype|application_type|panel_technology|script_name|run_type|"
    r"workflow.*version|release_version|version_number|sequencekitname|flow_order|"
    r"liquid.*class|container.*geometry|tube_model|resequenc|templating_size|"
    r"(?:^|[._])(?:enabled|enable|mode|chemistry|temperature|speed|volume|cycles)(?:$|[._])", re.I)


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for b in iter(lambda: fh.read(2**20), b""):
            h.update(b)
    return h.hexdigest()


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, default=str, allow_nan=False), encoding="utf-8")


def say(msg):
    print(datetime.now(timezone.utc).isoformat(timespec="seconds"), msg, flush=True)


def nullable_any(values):
    a = pd.to_numeric(values, errors="coerce")
    if a.eq(1).any():
        return 1.
    return 0. if a.notna().all() and len(a) else np.nan


def prepare(project, out):
    start = time.monotonic()
    bank = json.loads((project / "reference_bank_refresh.json").read_text())
    multimodal_dir = project / "refreshes" / bank["bank_id"] / "project"
    core_path = project / "csa_ml_dataset.parquet"
    multi_path = multimodal_dir / "multimodal_training_dataset.parquet"
    dictionary_path = multimodal_dir / "multimodal_feature_dictionary.csv"
    paths = [core_path, multi_path, dictionary_path, project / "feature_policy.csv",
             project / "csa_inventory.csv", project / "csa_transfer_manifest.csv",
             project / "qpm_failure_examples/dna_rna_balance_by_run.csv",
             project / "outcome_reference_policy.json", Path(__file__),
             project / "outcome_reference.py"]
    say("Auditing primary run/lane observations, archive availability, and strict-past peer labels")
    core = pd.read_parquet(core_path)
    inv = pd.read_csv(project / "csa_inventory.csv")
    meta_cols = ["observation_id", "physical_run_id", "instrument_id", "chip_lane",
                 "run_start_time", "archive_id", "total_reads", "mean_read_length_bp",
                 "raw_read_accuracy_pct"]
    lanes = core[meta_cols].merge(inv[["archive_id", "hostname", "remote_mtime_utc"]],
                                  on="archive_id", validate="one_to_one")
    lanes["start"] = pd.to_datetime(lanes.run_start_time, utc=True)
    lanes["available"] = pd.to_datetime(lanes.remote_mtime_utc, utc=True)
    assert not lanes.observation_id.duplicated().any()
    assert lanes.groupby("physical_run_id").instrument_id.nunique().max() == 1
    # Future-looking or negative-time exports are not silently repaired.
    assert lanes.available.notna().all() and lanes.start.notna().all()
    if (lanes.available < lanes.start).any():
        raise ValueError("An archive mtime predates its run: manual timestamp audit required")
    policy = load_policy(project)
    t = load_outcome_table(project, policy).merge(
        lanes[["observation_id", "available", "start"]], on="observation_id", validate="one_to_one")
    peer_rows, peer_members = [], []
    for _, row in t.iterrows():
        # The target is included only for its outcome/metadata, never as a peer.
        past = t[t.available.lt(row.start) | t.observation_id.eq(row.observation_id)].copy()
        summary, audit, _, _ = benchmark_table(past, row.observation_id, policy)
        for _, s in summary.iterrows():
            peer_rows.append({"observation_id": row.observation_id,
                              "physical_run_id": row.physical_run_id,
                              **s.to_dict(), "label": float(s.target_value < s.reference_q05)
                              if s.status == "available" else np.nan})
        for _, a in audit.iterrows():
            chosen = [y for y in ["total_reads", "mean_read_length_bp"] if a.get(f"selected_for_{y}", False)]
            if chosen:
                peer_members.append({"target_observation_id": row.observation_id,
                                     "target_start": row.start,
                                     "peer_observation_id": a.observation_id,
                                     "peer_physical_run_id": a.physical_run_id,
                                     "peer_available": t.set_index("observation_id").at[a.observation_id, "available"],
                                     "outcomes": ";".join(chosen)})
    peers = pd.DataFrame(peer_rows)
    peers.to_csv(out / "outcome_label_audit.csv", index=False)
    pd.DataFrame(peer_members).to_csv(out / "outcome_peer_members.csv", index=False)
    for target, outcome in zip(TARGETS, ["total_reads", "mean_read_length_bp"]):
        lanes[target] = lanes.observation_id.map(peers[peers.outcome.eq(outcome)].set_index("observation_id").label)
    balance = pd.read_csv(project / "qpm_failure_examples/dna_rna_balance_by_run.csv").set_index("observation_id")
    for material in ["dna", "rna"]:
        counts = lanes.observation_id.map(balance[f"{material}_apparent_dropout_count"])
        n = lanes.observation_id.map(balance[f"{material}_n_planned_noncontrol_barcodes"])
        # No material and missing barcode tables must not become negative examples.
        lanes[f"{material}_dropout"] = (counts > 0).astype(float).where(n.gt(0))
    has_balance = lanes.observation_id.isin(balance.index)
    lanes["any_dropout"] = lanes[["dna_dropout", "rna_dropout"]].max(axis=1).where(has_balance)
    physical = lanes.groupby("physical_run_id", sort=False).agg(
        instrument_id=("instrument_id", "first"), hostname=("hostname", "first"),
        start=("start", "min"), available=("available", "max"),
        retained_lanes=("chip_lane", "size"),
        total_reads=("total_reads", "median"), mean_read_length_bp=("mean_read_length_bp", "median"),
        low_total_reads=("low_total_reads", nullable_any),
        short_mean_read_length=("short_mean_read_length", nullable_any),
        dna_dropout=("dna_dropout", nullable_any), rna_dropout=("rna_dropout", nullable_any),
        any_dropout=("any_dropout", nullable_any),
        source_archive_ids=("archive_id", lambda s: ";".join(s)),
        observation_ids=("observation_id", lambda s: ";".join(s)),
    ).reset_index().sort_values(["instrument_id", "start"]).reset_index(drop=True)
    physical.to_csv(out / "physical_run_timeline.csv", index=False)
    lanes.to_csv(out / "lane_label_audit.csv", index=False)
    idx = physical.set_index("physical_run_id")
    pair_rows = []
    history_cols = ["total_reads", "mean_read_length_bp", *TARGETS, "dna_dropout", "rna_dropout", "any_dropout"]
    history_features = []
    for instrument, group in physical.groupby("instrument_id"):
        for _, target in group.iterrows():
            earlier = group[group.start.lt(target.start)]
            available = earlier[earlier.available.lt(target.start)].sort_values("start")
            r = target.to_dict()
            r["immediate_previous_id"] = earlier.iloc[-1].physical_run_id if len(earlier) else None
            r["prior_observed_runs"] = len(earlier)
            r["available_prior_runs"] = len(available)
            if not len(available):
                r.update(pair_status="no_earlier_csa_available", source_physical_run_id=None)
                pair_rows.append(r)
                continue
            source = available.iloc[-1]
            r.update(source_physical_run_id=source.physical_run_id, source_start=source.start,
                     source_available=source.available, source_archive_ids=source.source_archive_ids,
                     gap_days=(target.start-source.start).total_seconds()/86400,
                     availability_margin_hours=(target.start-source.available).total_seconds()/3600,
                     source_is_immediate_previous=source.physical_run_id == r["immediate_previous_id"],
                     pair_status="eligible" if (target.start-source.start).total_seconds()/86400 <= 14 else "gap_over_14_days")
            f = {"physical_run_id": target.physical_run_id,
                 "history.gap_days": r["gap_days"],
                 "history.archive_age_hours": r["availability_margin_hours"]}
            for col in history_cols:
                last3 = pd.to_numeric(available.tail(3)[col], errors="coerce")
                f[f"history.last.{col}"] = source[col]
                f[f"history.mean3.{col}"] = last3.mean()
                f[f"history.count3.{col}"] = last3.notna().sum()
                f[f"history.delta.{col}"] = source[col]-available.iloc[-2][col] if len(available)>1 else np.nan
            history_features.append(f)
            pair_rows.append(r)
    pairs = pd.DataFrame(pair_rows).sort_values("start").reset_index(drop=True)
    pairs.to_csv(out / "forecast_cohort.csv", index=False)
    hist = pd.DataFrame(history_features).set_index("physical_run_id")
    pairs = pairs[pairs.pair_status.eq("eligible")].reset_index(drop=True)
    assert pairs.source_physical_run_id.ne(pairs.physical_run_id).all()
    assert pd.to_datetime(pairs.source_available, utc=True).lt(pairs.start).all()
    say(f"Forecast pairs within 14 days: {len(pairs)} / {len(physical)} physical runs")

    feature_policy = pd.read_csv(project / "feature_policy.csv", low_memory=False)
    multi_dict = pd.read_csv(dictionary_path)
    multi_schema = pq.read_schema(multi_path)
    multi_ids = pd.read_parquet(multi_path, columns=["observation_id", "archive_id"])
    assert set(multi_ids.observation_id) == set(core.observation_id)
    assert multi_ids.set_index("observation_id").archive_id.sort_index().equals(core.set_index("observation_id").archive_id.sort_index())
    inventory, nums, cats = [], [], []
    for _, row in feature_policy.iterrows():
        name = row.feature_name
        reason = ""
        categorical = row.data_type != "numeric"
        if name not in core:
            reason = "not_in_current_core_table"
        elif row.actionability_tier == "D":
            reason = "Tier_D_forbidden_even_when_lagged_except_canonical_history_outcomes"
        elif FORBIDDEN.search(name):
            reason = "identifier_sensitive_path_or_absolute_time"
        elif categorical and not SAFE_CATEGORICAL.search(name):
            reason = "categorical_not_on_predeclared_safe_configuration_context_allowlist"
        selected = not reason
        if selected:
            (cats if categorical else nums).append(name)
        inventory.append({"feature_name": "core."+name, "component": "core_configuration_context" if row.actionability_tier in {"A", "B"} else "core_diagnostics",
                          "tier": row.actionability_tier, "data_type": row.data_type,
                          "source": str(row.source_file), "eligible_before_fold_filter": selected,
                          "exclusion_reason": reason})
    multi_names = []
    for _, row in multi_dict.iterrows():
        name = row.feature_name
        reason = ("core_duplicate_or_globally_encoded_categorical" if name.startswith("csa.")
                  else "identifier_sensitive_path_or_absolute_time" if FORBIDDEN.search(name)
                  else "Tier_D_forbidden" if row.tier == "D" else "")
        selected = not reason
        if selected:
            multi_names.append(name)
        inventory.append({"feature_name": "multi."+name, "component": row.component,
                          "tier": row.tier, "data_type": "numeric", "source": row.source,
                          "eligible_before_fold_filter": selected, "exclusion_reason": reason})
    say(f"Preparing lagged candidate features: core {len(nums)} numeric + {len(cats)} safe categorical; multimodal {len(multi_names)}")
    physical_numeric = core[nums].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    physical_numeric.index = core.physical_run_id
    physical_numeric = physical_numeric.groupby(level=0).median().astype(np.float32)
    physical_numeric.columns = "core."+physical_numeric.columns
    multi = pd.read_parquet(multi_path, columns=["observation_id", *multi_names]).set_index("observation_id")
    multi = multi.loc[core.observation_id, multi_names]
    multi.index = core.physical_run_id
    multi = multi.replace([np.inf, -np.inf], np.nan).groupby(level=0).median().astype(np.float32)
    multi.columns = "multi."+multi.columns
    numeric_source = pd.concat([physical_numeric, multi], axis=1)
    numeric = numeric_source.loc[pairs.source_physical_run_id].reset_index(drop=True)
    numeric = pd.concat([hist.loc[pairs.physical_run_id].reset_index(drop=True).astype(np.float32), numeric], axis=1)
    # Never stringify arbitrary sample/operator/path values into the model.
    cat_source = core[["physical_run_id", *cats]].copy()
    def same_value(s):
        v = s.dropna().astype(str).unique()
        return v[0] if len(v) == 1 else "__missing_or_mixed_lanes__"
    cat_source = cat_source.groupby("physical_run_id")[cats].agg(same_value)
    categorical = cat_source.loc[pairs.source_physical_run_id].reset_index(drop=True).fillna("__missing__").astype(str)
    categorical.columns = "core."+categorical.columns
    unsafe_value = re.compile(r"[/\\]|@|(?:\d{1,3}\.){3}\d{1,3}|Auto_R_|gnxs-", re.I)
    for c in categorical:
        categorical[c] = categorical[c].mask(categorical[c].str.contains(unsafe_value), "__redacted_identifier_or_path__")
    for c in hist.columns:
        inventory.append({"feature_name": c, "component": "outcome_history", "tier": "lagged_outcome_history",
                          "data_type": "numeric", "source": "earlier available canonical outcomes/strict-past labels",
                          "eligible_before_fold_filter": True, "exclusion_reason": ""})
    fi = pd.DataFrame(inventory)
    fi.to_csv(out / "forecast_feature_policy.csv", index=False)
    feature_meta = fi[fi.eligible_before_fold_filter].copy()
    feature_meta["lagged_missing_fraction"] = feature_meta.feature_name.map(pd.concat([numeric.isna().mean(), categorical.eq("__missing__").mean()]))
    feature_meta.to_csv(out / "candidate_feature_inventory.csv", index=False)
    numeric.to_parquet(out / "lagged_numeric_features.parquet", index=False)
    categorical.to_parquet(out / "lagged_categorical_features.parquet", index=False)
    pairs.to_csv(out / "model_cohort.csv", index=False)
    label_counts = []
    for name in [*TARGETS, "dna_dropout", "rna_dropout", "any_dropout"]:
        for population, frame in [("all_physical_runs", physical), ("forecast_pairs_14d", pairs)]:
            label_counts.append({"target": name, "population": population,
                                 "n": len(frame), "known": int(frame[name].notna().sum()),
                                 "events": int(frame[name].eq(1).sum()), "unknown": int(frame[name].isna().sum())})
    pd.DataFrame(label_counts).to_csv(out / "label_counts.csv", index=False)
    manifest = pd.read_csv(project / "csa_transfer_manifest.csv")
    manifest[manifest.archive_id.isin(lanes.archive_id)][["archive_id", "sha256", "state"]].to_csv(out / "input_archive_hashes.csv", index=False)
    metadata = {"version": VERSION, "seed": SEED, "bank_id": bank["bank_id"],
                "physical_runs": len(physical), "run_lane_observations": len(core), "instruments": int(physical.instrument_id.nunique()),
                "forecast_pairs": len(pairs), "candidate_numeric_features": len(numeric.columns), "candidate_safe_categorical_features": len(categorical.columns),
                "labels": label_counts, "outcome_reference_policy": policy,
                "input_sha256": {str(path): sha256(path) for path in paths},
                "warnings": [
                    "Remote archive mtime is a conservative export-availability proxy; actual CSA-ready timestamps, clock offsets, and run completion times are unverified.",
                    "Only final retained exports are used; an earlier export might have been available but is not reconstructed.",
                    "Next observed CSA-covered run need not be the immediately next real instrument run; missing intervening runs and selective archive collection can bias results.",
                    "Low performance means below a strict-past, exact-recorded-protocol empirical peer 5th percentile, not an approved QC failure or certified healthy reference.",
                    "No current target-run CSA measurements are predictors. Target protocol metadata are used only to define labels, never as forecast features.",
                    "Physical-run outcomes are any-lane events, with negative labels requiring all retained lanes to have known labels; continuous history is median across retained lanes.",
                    "Raw read accuracy is unavailable in this bank and cannot be evaluated.",
                    "Only previously extracted numeric/verified-safe categorical descriptors are tested, not every byte or unparsed log string in each CSA.",
                    "The inherited multimodal table had target-independent global sparse/constant column screening. Current fold-local preprocessing cannot recover descriptors omitted by that earlier extractor; core numeric A/B/C fields are loaded without that eligibility screen.",
                    "Four apparent-dropout physical runs in the whole bank are insufficient for credible prospective classifier validation; absent material or missing barcode tables is not a negative.",
                ], "prepare_seconds": round(time.monotonic()-start, 2)}
    write_json(out / "preparation_log.json", metadata)
    say("Preparation complete")


class FoldFeatures:
    """Every learned transform is fit only on the current inner/outer training set."""
    def __init__(self, k):
        self.k = k

    def fit(self, x, cat, y):
        self.numeric_names = np.asarray(x.columns)
        a = x.to_numpy(dtype=np.float64, copy=True)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            valid = (np.isfinite(a).mean(axis=0) >= .5) & (np.nanstd(a, axis=0) > 1e-12)
        self.keep = np.flatnonzero(valid)
        a = a[:, self.keep]
        self.median = np.nanmedian(a, axis=0)
        missing = np.isnan(a)
        a = np.where(missing, self.median, a)
        # Exclude near constants and exact duplicates using training values only.
        usable, seen = [], set()
        for j in range(a.shape[1]):
            _, counts = np.unique(a[:, j], return_counts=True)
            if counts.max()/len(a) > .98:
                continue
            digest = hashlib.blake2b(a[:, j].tobytes()+missing[:, j].tobytes(), digest_size=16).digest()
            if digest not in seen:
                usable.append(j)
                seen.add(digest)
        self.subkeep = np.asarray(usable, dtype=int)
        a = a[:, self.subkeep]
        missing = missing[:, self.subkeep]
        self.missing_cols = np.flatnonzero(missing.any(axis=0) & ~missing.all(axis=0))
        self.lower = np.quantile(a, .01, axis=0)
        self.upper = np.quantile(a, .99, axis=0)
        a = np.clip(a, self.lower, self.upper)
        names = list(self.numeric_names[self.keep][self.subkeep])
        names += [names[j]+".__missing" for j in self.missing_cols]
        a = np.column_stack([a, missing[:, self.missing_cols]])
        self.cat_cols = [c for c in cat if 2 <= cat[c].nunique() <= min(30, len(cat)//3)]
        self.encoder = None
        if self.cat_cols:
            self.encoder = OneHotEncoder(handle_unknown="ignore", min_frequency=3, max_categories=15, sparse_output=False)
            encoded = self.encoder.fit_transform(cat[self.cat_cols])
            names.extend(self.encoder.get_feature_names_out(self.cat_cols))
            a = np.column_stack([a, encoded])
        self.names_before_select = np.asarray(names)
        self.scaler = StandardScaler().fit(a)
        a = self.scaler.transform(a)
        self.filtered_count = a.shape[1]
        # The univariate screen is a predictive preprocessing step, not a p-value claim.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            score, _ = __import__("sklearn.feature_selection", fromlist=["f_classif"]).f_classif(a, y)
        score = np.nan_to_num(score, nan=-np.inf, posinf=1e30, neginf=-np.inf)
        self.selected = np.argsort(score, kind="stable")[-min(self.k, len(score)):]
        self.names = self.names_before_select[self.selected]
        self.fit_n = len(y)
        return self

    def transform(self, x, cat):
        a = x.to_numpy(dtype=np.float64)[:, self.keep]
        missing = np.isnan(a)
        a = np.where(missing, self.median, a)[:, self.subkeep]
        a = np.clip(a, self.lower, self.upper)
        a = np.column_stack([a, missing[:, self.subkeep][:, self.missing_cols]])
        if self.encoder is not None:
            a = np.column_stack([a, self.encoder.transform(cat[self.cat_cols])])
        return self.scaler.transform(a)[:, self.selected]


def make_model(param):
    model, k, strength = param
    if model == "logistic":
        return LogisticRegression(C=strength, solver="lbfgs", max_iter=1500, random_state=SEED)
    return ExtraTreesClassifier(n_estimators=160, max_depth=int(strength), min_samples_leaf=8,
                                max_features=.7, random_state=SEED, n_jobs=4)


def metric(y, p):
    p = np.clip(p, 1e-6, 1-1e-6)
    both = len(np.unique(y)) > 1
    return {"n": len(y), "events": int(np.sum(y)), "prevalence": float(np.mean(y)),
            "average_precision": float(average_precision_score(y, p)) if both else np.nan,
            "roc_auc": float(roc_auc_score(y, p)) if both else np.nan,
            "brier": float(brier_score_loss(y, p)), "log_loss": float(log_loss(y, p, labels=[0, 1])),
            "precision_at_0_20": float(precision_score(y, p >= .2, zero_division=0)),
            "recall_at_0_20": float(recall_score(y, p >= .2, zero_division=0)),
            "alert_rate_at_0_20": float(np.mean(p >= .2))}


def splits(frame):
    # Cutoffs are unsupervised calendar quantiles of this cohort; final 20% is held out.
    dates = frame.start.sort_values().reset_index(drop=True)
    boundaries = [dates.iloc[int(len(dates)*q)] for q in [.4, .55, .7, .8]]
    result = []
    for j, lo in enumerate(boundaries):
        hi = boundaries[j+1] if j+1 < len(boundaries) else pd.Timestamp.max.tz_localize("UTC")
        train = frame.index[frame.start.lt(lo) & frame.available.lt(lo)].to_numpy()
        test = frame.index[frame.start.ge(lo) & frame.start.lt(hi)].to_numpy()
        result.append(("final_chronological_holdout" if j == 3 else "rolling_origin", f"time_{j+1}", train, test, lo))
    cutoff = boundaries[-1]
    for inst in sorted(frame.instrument_id.unique()):
        train = frame.index[frame.start.lt(cutoff) & frame.available.lt(cutoff) & frame.instrument_id.ne(inst)].to_numpy()
        test = frame.index[frame.start.ge(cutoff) & frame.instrument_id.eq(inst)].to_numpy()
        result.append(("unseen_instrument_and_future", inst, train, test, cutoff))
    return result


def inner_splits(frame, indices):
    a = frame.loc[indices].sort_values("start")
    result = []
    for left, right in [(.5, .75), (.75, 1.)]:
        lo = a.start.iloc[int(len(a)*left)]
        hi = a.start.iloc[int(len(a)*right)] if right < 1 else pd.Timestamp.max.tz_localize("UTC")
        tr = a.index[a.start.lt(lo) & a.available.lt(lo)].to_numpy()
        va = a.index[a.start.ge(lo) & a.start.lt(hi)].to_numpy()
        if len(tr) >= 25 and len(va) >= 8:
            result.append((tr, va))
    return result


def run_models(project, out):
    say("Starting nested, availability-purged, chronological validation")
    begun = time.monotonic()
    frame = pd.read_csv(out / "model_cohort.csv")
    for c in ["start", "available", "source_available"]:
        frame[c] = pd.to_datetime(frame[c], utc=True)
    x = pd.read_parquet(out / "lagged_numeric_features.parquet")
    cat = pd.read_parquet(out / "lagged_categorical_features.parquet")
    # Reapply the semantic policy at model entry as a defense against inherited
    # policy mistakes (e.g. run-date ordinals labeled Tier B by an older parser).
    forbidden = [c for c in [*x.columns, *cat.columns] if FORBIDDEN.search(c)]
    pd.DataFrame({"feature_name": forbidden,
                  "reason": ["secondary_identifier_absolute_date_or_path_key_review"]*len(forbidden)}).to_csv(out / "additional_identifier_exclusions.csv", index=False)
    x = x.drop(columns=[c for c in forbidden if c in x])
    cat = cat.drop(columns=[c for c in forbidden if c in cat])
    info = pd.read_csv(out / "candidate_feature_inventory.csv").set_index("feature_name")
    components = info.component.to_dict()
    h = [c for c in x if c.startswith("history.")]
    config = [c for c in x if components.get(c) == "core_configuration_context"]
    fluidics = [c for c in x if components.get(c) in {"qpm_debug", "vacuum_steps", "libprep_telemetry"} or
                c.startswith("core.") and re.search(r"pressure|vacuum|pipett|libprep|liquid|templating", c, re.I)]
    spatial = [c for c in x if components.get(c, "").startswith("plugin:") or components.get(c) == "nucstep_spatial"]
    columns = dict(zip(FAMILIES, [h, list(dict.fromkeys(h+config)), list(dict.fromkeys(h+fluidics)),
                                  list(dict.fromkeys(h+spatial)), list(x.columns)]))
    cat_columns = {family: list(cat.columns) if family in {"history_configuration_context", "history_all_csa"} else [] for family in FAMILIES}
    performance, predictions, tuning, selections, skipped, fold_audit = [], [], [], [], [], []
    model_dir = out / "models"
    model_dir.mkdir(exist_ok=True)
    for target in [*TARGETS, "dna_dropout", "rna_dropout", "any_dropout"]:
        known = frame[target].notna()
        n_event = int(frame.loc[known, target].sum())
        if target not in TARGETS or n_event < 10:
            skipped.append({"target": target, "reason": "fewer_than_10_events_in_forecast_cohort_no_credible_classifier_test",
                            "known": int(known.sum()), "events": n_event})
            say(f"Not fitting {target}: {n_event} events / {int(known.sum())} known labels")
            continue
        y = frame[target].fillna(0).to_numpy(dtype=int)
        for scheme, fold, tr_all, te_all, cutoff in splits(frame):
            train = tr_all[known.iloc[tr_all].to_numpy()]
            test = te_all[known.iloc[te_all].to_numpy()]
            if len(train) < 40 or np.sum(y[train]) < 5 or len(test) < 3:
                skipped.append({"target": target, "scheme": scheme, "fold": fold,
                                "reason": "insufficient_training_events_or_test_labels", "train_n": len(train),
                                "train_events": int(np.sum(y[train])), "test_n": len(test)})
                continue
            assert frame.loc[train, "available"].lt(cutoff).all()
            assert not set(frame.loc[train, "physical_run_id"]) & set(frame.loc[test, "physical_run_id"])
            say(f"{target} / {scheme} {fold}: train={len(train)} ({sum(y[train])} events), test={len(test)} ({sum(y[test])} events)")
            fold_audit.append({"target": target, "scheme": scheme, "fold": fold, "cutoff": cutoff,
                               "train_n": len(train), "train_events": int(sum(y[train])), "test_n": len(test),
                               "test_events": int(sum(y[test])), "train_max_label_available": frame.loc[train, "available"].max(),
                               "training_physical_runs": ";".join(frame.loc[train, "physical_run_id"]),
                               "test_physical_runs": ";".join(frame.loc[test, "physical_run_id"]),
                               "purged_unavailable_training_rows": int(sum(frame.loc[tr_all, "available"].ge(cutoff)))})
            # Basic references fit only from the earlier training window.
            prior = (sum(y[train])+1)/(len(train)+2)
            by_inst = frame.loc[train].assign(label=y[train]).groupby("instrument_id").label.agg(["sum", "count"])
            inst_prior = frame.loc[test, "instrument_id"].map((by_inst["sum"]+5*prior)/(by_inst["count"]+5)).fillna(prior).to_numpy()
            last_label = x.loc[test, f"history.last.{target}"].fillna(prior).to_numpy()
            # Shrink persistence to avoid unjustified 0/1 probabilities.
            persistence = .5*last_label + .5*prior
            fold_predictions = {"historical_prevalence": np.full(len(test), prior), "instrument_prevalence": inst_prior,
                                "previous_run_status": persistence}
            candidates, history_candidates = [], []
            for family in FAMILIES:
                xx, cc = x[columns[family]], cat[cat_columns[family]]
                inner = inner_splits(frame.loc[known], train)
                scores = [[] for _ in PARAMS]
                for itrain, ival in inner:
                    if np.sum(y[itrain]) < 3 or len(np.unique(y[itrain])) < 2:
                        continue
                    for k in [8, 20]:
                        pre = FoldFeatures(k).fit(xx.loc[itrain], cc.loc[itrain], y[itrain])
                        aa, bb = pre.transform(xx.loc[itrain], cc.loc[itrain]), pre.transform(xx.loc[ival], cc.loc[ival])
                        for pi, param in enumerate(PARAMS):
                            if param[1] != k:
                                continue
                            model = make_model(param).fit(aa, y[itrain])
                            pp = model.predict_proba(bb)[:, 1]
                            scores[pi].append((len(ival), brier_score_loss(y[ival], pp)))
                averages = [sum(n*v for n, v in s)/sum(n for n, _ in s) if s else np.inf for s in scores]
                for pi, param in enumerate(PARAMS):
                    tuning.append({"target": target, "scheme": scheme, "fold": fold, "family": family,
                                   "model": param[0], "k": param[1], "strength_or_depth": param[2],
                                   "inner_validation_folds": len(scores[pi]), "inner_brier": averages[pi] if np.isfinite(averages[pi]) else np.nan})
                for model_name in ["logistic", "extra_trees"]:
                    options = [i for i, p in enumerate(PARAMS) if p[0] == model_name]
                    best = min(options, key=lambda i: averages[i])
                    param = PARAMS[best]
                    pre = FoldFeatures(param[1]).fit(xx.loc[train], cc.loc[train], y[train])
                    model = make_model(param).fit(pre.transform(xx.loc[train], cc.loc[train]), y[train])
                    pp = model.predict_proba(pre.transform(xx.loc[test], cc.loc[test]))[:, 1]
                    name = f"{family}__{model_name}"
                    fold_predictions[name] = pp
                    (history_candidates if family == "history_only" else candidates).append((averages[best], name, pp))
                    for feature in pre.names:
                        selections.append({"target": target, "scheme": scheme, "fold": fold, "model": name,
                                           "feature": feature, "training_filtered_features": pre.filtered_count,
                                           "interpretation": "training_selected_not_validated_importance"})
                    if scheme == "final_chronological_holdout":
                        # These are offline research artifacts, not deployed plugin changes.
                        joblib.dump({"preprocessor": pre, "model": model, "numeric_columns": columns[family],
                                     "categorical_columns": cat_columns[family], "cutoff": str(cutoff),
                                     "version": VERSION}, model_dir / f"{target}__{name}.joblib")
            # Joint family/model selection occurs in the inner loop, never on this test block.
            chosen = min(candidates, key=lambda a: (a[0], a[1]))
            if np.isfinite(chosen[0]):
                fold_predictions["nested_selected"] = chosen[2]
                tuning.append({"target": target, "scheme": scheme, "fold": fold, "family": "nested_selected",
                               "model": chosen[1], "inner_brier": chosen[0]})
            history_chosen = min(history_candidates, key=lambda a: (a[0], a[1]))
            if np.isfinite(history_chosen[0]):
                fold_predictions["history_nested_selected"] = history_chosen[2]
                tuning.append({"target": target, "scheme": scheme, "fold": fold, "family": "history_nested_selected",
                               "model": history_chosen[1], "inner_brier": history_chosen[0]})
            for name, pp in fold_predictions.items():
                performance.append({"target": target, "scheme": scheme, "fold": fold, "model": name,
                                    "train_n": len(train), "train_events": int(sum(y[train])), **metric(y[test], pp)})
                for i, pred in zip(test, pp):
                    predictions.append({"target": target, "scheme": scheme, "fold": fold, "model": name,
                                        "physical_run_id": frame.at[i, "physical_run_id"],
                                        "instrument_id": frame.at[i, "instrument_id"], "hostname": frame.at[i, "hostname"],
                                        "start": frame.at[i, "start"], "observed": int(y[i]), "probability": float(pred),
                                        "source_physical_run_id": frame.at[i, "source_physical_run_id"]})
            # Checkpoint after every outer fold, so lengthy runs are recoverable/auditable.
            pd.DataFrame(performance).to_csv(out / "model_performance_folds.csv", index=False)
            pd.DataFrame(predictions).to_csv(out / "heldout_predictions.csv", index=False)
            pd.DataFrame(tuning).to_csv(out / "nested_model_selection.csv", index=False)
            pd.DataFrame(selections).to_csv(out / "fold_selected_features.csv", index=False)
            pd.DataFrame(fold_audit).to_csv(out / "validation_split_audit.csv", index=False)
    pd.DataFrame(skipped).to_csv(out / "skipped_tests.csv", index=False)
    log = json.loads((out / "preparation_log.json").read_text())
    log.update(executed_utc=datetime.now(timezone.utc).isoformat(), execution_seconds=round(time.monotonic()-begun, 2),
               candidate_numeric_features=len(x.columns), candidate_safe_categorical_features=len(cat.columns),
               secondary_identifier_exclusions=forbidden,
               code_sha256_at_model_execution=sha256(__file__), sklearn=sklearn.__version__, numpy=np.__version__,
               models={"candidate_grid": PARAMS, "families": FAMILIES, "selection_metric": "inner_availability_purged_Brier_score",
                       "minimum_training_events": 5, "minimum_cohort_events": 10, "classifier_threshold": .20,
                       "fold_numeric_missingness_max": .5, "fold_near_constant_dominance_max": .98,
                       "fold_winsorization": [.01, .99], "final_holdout": "latest_20_percent_of_pair_start_times",
                       "uncalibrated_probabilities": True, "oversampling": False,
                       "inner_splits": "expanding 50%-75% and 75%-100% of earlier training window",
                       "shared_source_runs": "a completed earlier run can legitimately supply more than one forecast; block uncertainty is used"})
    write_json(out / "analysis_run_log.json", log)
    say("Model fitting complete")


def summarize(out):
    p = pd.read_csv(out / "heldout_predictions.csv")
    summary = []
    for (target, scheme, model), group in p.groupby(["target", "scheme", "model"]):
        summary.append({"target": target, "scheme": scheme, "model": model,
                        "folds": group.fold.nunique(), **metric(group.observed, group.probability)})
    summary = pd.DataFrame(summary)
    summary.to_csv(out / "model_performance_summary.csv", index=False)
    instruments = []
    for (target, scheme, model, host), group in p.groupby(["target", "scheme", "model", "hostname"]):
        instruments.append({"target": target, "scheme": scheme, "model": model, "hostname": host,
                            **metric(group.observed, group.probability)})
    pd.DataFrame(instruments).to_csv(out / "per_instrument_performance.csv", index=False)
    rng = np.random.default_rng(SEED)
    comparisons = []
    for (target, scheme), group in p.groupby(["target", "scheme"]):
        wide = group.pivot(index="physical_run_id", columns="model", values="probability")
        meta = group.drop_duplicates("physical_run_id").set_index("physical_run_id").loc[wide.index]
        clusters = meta.instrument_id + "_" + pd.to_datetime(meta.start, utc=True).dt.strftime("%Y_%U")
        blocks = [np.flatnonzero(clusters.to_numpy() == c) for c in clusters.unique()]
        for baseline in ["historical_prevalence", "history_nested_selected", "history_only__logistic", "history_only__extra_trees"]:
            for model in ["nested_selected", "history_all_csa__logistic", "history_all_csa__extra_trees",
                          "history_fluidics__logistic", "history_spatial_plugins__logistic"]:
                if baseline not in wide or model not in wide:
                    continue
                valid = wide[[baseline, model]].notna().all(axis=1).to_numpy()
                yy = meta.observed.to_numpy()
                delta = (wide[baseline].to_numpy()-yy)**2-(wide[model].to_numpy()-yy)**2
                boots = []
                for _ in range(1500):
                    ii = np.concatenate([blocks[j] for j in rng.integers(0, len(blocks), len(blocks))])
                    ii = ii[valid[ii]]
                    if len(ii):
                        boots.append(float(delta[ii].mean()))
                comparisons.append({"target": target, "scheme": scheme, "baseline": baseline, "model": model,
                                    "n": int(valid.sum()), "brier_improvement": float(delta[valid].mean()),
                                    "ci_low": float(np.quantile(boots, .025)), "ci_high": float(np.quantile(boots, .975)),
                                    "uncertainty": "instrument_week_block_bootstrap_heldout_predictions_conditional_on_fitted_models"})
    comparisons = pd.DataFrame(comparisons)
    comparisons.to_csv(out / "incremental_prognostic_value.csv", index=False)
    return p, summary, comparisons


def report(out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    from sklearn.calibration import calibration_curve
    p, scores, comparisons = summarize(out)
    log = json.loads((out / "analysis_run_log.json").read_text())
    timeline = pd.read_csv(out / "physical_run_timeline.csv")
    cohort = pd.read_csv(out / "model_cohort.csv")
    counts = pd.read_csv(out / "label_counts.csv")
    palette = {"historical_prevalence": "#777777", "history_nested_selected": "#0072B2",
               "history_all_csa__logistic": "#009E73", "history_all_csa__extra_trees": "#D55E00", "nested_selected": "#CC79A7"}
    names = {"historical_prevalence": "Prior event rate", "history_nested_selected": "Outcome history only",
             "history_all_csa__logistic": "All CSA · logistic", "history_all_csa__extra_trees": "All CSA · trees", "nested_selected": "Nested-selected model"}
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False,
                         "axes.spines.right": False, "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none"})
    fig, axes = plt.subplots(2, 2, figsize=(15, 10), layout="constrained")
    fig.set_facecolor("#fafbf8")
    ax = axes[0, 0]
    for i, (host, g) in enumerate(timeline.groupby("hostname")):
        ax.scatter(pd.to_datetime(g.start), np.full(len(g), i), color="#a3b5ad", s=17, marker="o")
        bad = g[g.any_dropout.eq(1)]
        ax.scatter(pd.to_datetime(bad.start), np.full(len(bad), i), color="#D55E00", s=65, marker="X", zorder=3)
    ax.set_yticks(range(timeline.hostname.nunique()), [h.split(".")[0] for h in sorted(timeline.hostname.unique())])
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b"))
    ax.set_title(f"a  Six-instrument timeline · {log['physical_runs']} physical runs", loc="left", fontweight="bold")
    ax.set_xlabel("2026 · X = apparent barcode dropout (4 physical runs)")
    ax = axes[0, 1]
    display_models = list(palette)
    chronological = scores[scores.scheme.eq("final_chronological_holdout")]
    width = .14
    for j, model in enumerate(display_models):
        values = [chronological[(chronological.target.eq(t)) & chronological.model.eq(model)].brier for t in TARGETS]
        vals = [float(v.iloc[0]) if len(v) else np.nan for v in values]
        ax.bar(np.arange(2)+(j-2)*width, vals, width=width, color=palette[model], label=names[model])
    ax.set_xticks([0, 1], ["Future low reads", "Future short reads"])
    ax.set_ylabel("Brier error ↓ better")
    ax.set_title("b  Locked latest-20% holdout · no random split", loc="left", fontweight="bold")
    ax.legend(fontsize=8, frameon=False)
    ax = axes[1, 0]
    selected = p[p.scheme.eq("final_chronological_holdout") & p.model.eq("nested_selected")]
    for target, color, marker in zip(TARGETS, ["#0072B2", "#D55E00"], ["o", "s"]):
        g = selected[selected.target.eq(target)]
        if len(g):
            obs, pred = calibration_curve(g.observed, g.probability, n_bins=4, strategy="quantile")
            ax.plot(pred, obs, marker=marker, color=color, label=target.replace("_", " ")+f" (n={len(g)}, events={int(g.observed.sum())})")
    ax.plot([0, 1], [0, 1], "--", color="#777777", linewidth=1)
    ax.set(xlim=(0, 1), ylim=(0, 1), xlabel="Forecast probability", ylabel="Observed event fraction")
    ax.set_title("c  Calibration · sparse events limit precision", loc="left", fontweight="bold")
    ax.legend(fontsize=8, frameon=False)
    ax = axes[1, 1]
    comp = comparisons[comparisons.baseline.eq("history_nested_selected") & comparisons.model.eq("nested_selected")]
    rows = comp.sort_values(["target", "scheme"])
    labs = []
    for j, (_, row) in enumerate(rows.iterrows()):
        label = ("Reads" if row.target == "low_total_reads" else "Length")+" · "+{
            "rolling_origin": "rolling time", "final_chronological_holdout": "final holdout", "unseen_instrument_and_future": "new instrument + time"}[row.scheme]
        labs.append(label)
        ax.errorbar(row.brier_improvement, j, xerr=[[max(0, row.brier_improvement-row.ci_low)], [max(0, row.ci_high-row.brier_improvement)]],
                    fmt="o", color="#009E73", capsize=3)
    ax.axvline(0, color="#777777", linestyle="--")
    ax.set_yticks(range(len(labs)), labs, fontsize=8)
    ax.set_xlabel("Brier improvement vs nested outcome-history model → better")
    ax.set_title("d  Added value · 95% instrument-week block intervals", loc="left", fontweight="bold")
    fig.suptitle("Can a completed CSA forecast a later underperforming run?", fontsize=19, fontweight="bold", color="#254b46")
    fig.savefig(out / "next_run_forecast_summary.png", dpi=220)
    fig.savefig(out / "next_run_forecast_summary.pdf", metadata={"CreationDate": None})
    plt.close(fig)
    def table(df):
        return df.to_html(index=False, float_format=lambda x: f"{x:.4g}", border=0, escape=True)
    policy = pd.read_csv(out / "candidate_feature_inventory.csv")
    coverage = policy.groupby("component").agg(candidate_features=("feature_name", "size"), median_lagged_missing_fraction=("lagged_missing_fraction", "median")).reset_index()
    skips = pd.read_csv(out / "skipped_tests.csv")
    decision_rows = []
    for target in TARGETS:
        comps = comparisons[(comparisons.target.eq(target)) & comparisons.model.eq("nested_selected") & comparisons.baseline.eq("history_nested_selected")]
        robust = len(comps) == 3 and comps.ci_low.gt(0).all()
        decision_rows.append({"target": target, "status": "incremental_signal_warrants_prospective_validation" if robust else "no_consistent_validated_incremental_prognostic_value",
                              "reason": "Requires positive incremental Brier improvement and interval above zero in rolling, final temporal, and unseen-instrument temporal validation"})
    decision = pd.DataFrame(decision_rows)
    decision.to_csv(out / "forecast_conclusions.csv", index=False)
    text = f"""<!doctype html><html><head><meta charset='utf-8'><title>Previous-run CSA forecasting</title>
<style>body{{font:16px/1.5 system-ui;max-width:1450px;margin:36px auto;color:#243d3b;background:#fafbf8;padding:0 20px}}h1,h2{{color:#254b46}}table{{border-collapse:collapse;font-size:13px;margin:18px 0}}th,td{{padding:8px;border-bottom:1px solid #d2ddd4;text-align:left}}th{{background:#e5eee8}}img{{width:100%}}.note{{background:#f3e7cd;padding:18px;border-radius:8px}}a{{color:#0072B2}}</style></head><body>
<h1>Previous completed CSA → future run prognosis</h1><p>Offline research experiment · six-instrument bank {html.escape(log['bank_id'])} · seed {SEED}.</p>
<div class='note'><strong>Not a same-run diagnostic model.</strong> Every predictor comes from a different, earlier physical run on the same instrument, whose retained CSA exports existed before the target run started. No settings or plugin/reference-bank defaults were changed. Apparent dropout is too rare for reliable forecasting here. Low performance is peer-relative, not an approved instrument failure.</div>
<img src='next_run_forecast_summary.png' alt='Chronology, temporal holdout error, calibration and incremental-value intervals'>
<h2>Conclusions</h2>{table(decision)}
<h2>Cohort and event counts</h2><p>{log['run_lane_observations']} retained run/lane observations, {log['physical_runs']} physical runs, {log['forecast_pairs']} eligible forecast pairs (latest available earlier CSA, gap ≤14 days). All sibling lanes are aggregated into one independent physical-run target.</p>{table(counts)}
<h2>What was tested</h2><p>Historical prevalence; instrument prevalence; shrunken previous-run status; regularized logistic regression and constrained Extra Trees. Five feature sets: outcome history, history + configuration/context, history + QPM/vacuum/lib-prep, history + spatial/plugin diagnostics, and history + all eligible CSA descriptors. A nested-selected model chooses its family and hyperparameters using only earlier inner validation windows and Brier score.</p>
<p>{log['candidate_numeric_features']} numeric and {log['candidate_safe_categorical_features']} safe categorical candidates enter training-fold screens. These are candidates, not 60,000 independently established useful predictors. Each fold removes >50%-missing, constant/near-constant and duplicate numeric features; fits imputation, 1st–99th percentile clipping, missingness indicators, categorical encoding, scaling and top-8/top-20 predictive selection using training data only.</p>{table(coverage)}
<h2>Validation logic</h2><ol><li>Define each target against only earlier CSA-available, exact chip/assay/panel/workflow/software/kit/sample-count matched peers, minimum eight independent physical runs. Below peer 5th percentile = positive; insufficient peers = unknown.</li><li>Only earlier source CSAs available before the forecast target starts are used. Final retained exports are used conservatively; unavailable immediate previous exports are skipped in favor of an older available run.</li><li>Three expanding temporal test blocks followed by the locked latest-20% holdout. Training rows whose labels were not available at the block start are purged.</li><li>Unseen-instrument-and-future tests exclude the held-out instrument from all model training and evaluate its late-period runs. Its own completed earlier CSA remains a legitimate input at prediction time.</li><li>All feature and model selection is repeated inside two earlier expanding validation windows. Folds without enough inner training events use predeclared defaults, not test results.</li><li>Models are frozen within each outer block, while new previous-run inputs become available online. Bootstrap intervals resample instrument-week blocks of held-out predictions; they are conditional on fitted models and do not include all model-development uncertainty.</li></ol>
<h2>Held-out results</h2><p>Average precision is compared with event prevalence, not accuracy. Lower Brier/log loss is better. A 20% alert threshold is predeclared for descriptive precision/recall, not operationally approved. Probabilities have not been independently recalibrated; calibration is evaluated, not assumed. Pooled PR/ROC summaries combine disjoint test predictions and are not averages of fold AUCs; see fold CSV.</p>{table(scores)}
<h2>Does the broad CSA add value beyond outcome history?</h2><p>Positive Brier improvement is better. Intervals crossing zero do not establish improvement. Trying many feature families does not justify selecting a winner on these test results; the nested-selected procedure is the primary test.</p>{table(comparisons)}
<h2>Individual parameters and causality</h2><p>Training-selected feature names are recorded for audit, not presented as validated prognostic biomarkers. A predictive claim needs consistent improvement over history-only models, stable held-out contributions, and independent prospective validation. Any lagged diagnostic signal would be a monitoring hypothesis, not evidence to change a pre-run setting or that one operation caused a later failure.</p>
<h2>Unperformed or untestable tests</h2>{table(skips)}
<h2>Limitations</h2><ul>{''.join('<li>'+html.escape(w)+'</li>' for w in log['warnings'])}<li>Eight historical peers give an imprecise 5th percentile. Outcome/reference changes, maintenance, and assay transitions can confound a forecast.</li><li>This small retrospective sample is not a consecutive production cohort. Rare barcode events and missing labels limit statistical power; a negative result does not establish no possible prognostic information.</li><li>No actual delivered-volume ground truth is available. These forecasts do not quantify over/under-delivery.</li></ul>
<h2>Next controlled study</h2><p>Collect consecutive runs and immutable CSA-ready, completion and maintenance timestamps. Lock the source-availability policy and approved low-performance criteria before testing; retain missing/intervening runs in the audit. Continue shadow-mode forecasts against outcome-history baselines without changing instrument settings. Accumulate independent dropout events across instruments before assessing dropout recall or calibration. Only investigate specific parameter or feature-family alerts after reliable prospective added value is demonstrated.</p>
<h2>Artifacts</h2><p><a href='model_performance_summary.csv'>Performance</a> · <a href='heldout_predictions.csv'>Predictions</a> · <a href='forecast_cohort.csv'>All source/target pairs</a> · <a href='outcome_label_audit.csv'>Peer label audit</a> · <a href='candidate_feature_inventory.csv'>Feature inventory</a> · <a href='forecast_feature_policy.csv'>Exclusions</a> · <a href='validation_split_audit.csv'>Splits</a> · <a href='nested_model_selection.csv'>Nested selection</a> · <a href='analysis_run_log.json'>Run log/hashes</a></p></body></html>"""
    (out / "next_run_forecast_report.html").write_text(text, encoding="utf-8")
    say("Report and summary figure complete")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--stage", choices=["all", "prepare", "models", "report"], default="all")
    args = parser.parse_args()
    out = args.output_dir or args.project / "next_run_forecast_20261021"
    out.mkdir(parents=True, exist_ok=True)
    if args.stage in {"all", "prepare"}:
        if (out / "preparation_log.json").exists():
            raise FileExistsError("Preparation already exists; use a new output directory or --stage models/report")
        prepare(args.project, out)
    if args.stage in {"all", "models"}:
        run_models(args.project, out)
    if args.stage in {"all", "report"}:
        report(out)


if __name__ == "__main__":
    main()
