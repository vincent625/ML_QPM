"""Explicit, validated routing to a versioned local QPM reference bank."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

VERSION = "qpm-reference-bank-routing-1.0.0"
POINTER = "active_reference_bank.json"
MANIFEST = "reference_bank_manifest.json"


def file_sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(2**20), b""):
            h.update(block)
    return h.hexdigest()


def resolve_reference_bank(project):
    """No pointer means an explicit project/snapshot remains unchanged.

    An invalid pointer fails closed: never silently fall back to an older bank.
    Isolated manual-case projects have no pointer and never add other targets.
    """
    project = Path(project).resolve()
    pointer = project / POINTER
    if not pointer.exists():
        return project
    chosen = json.loads(pointer.read_text())
    bank = Path(chosen["bank_path"])
    if not bank.is_absolute() or not bank.is_dir():
        raise ValueError("Active QPM reference bank is missing or not an absolute local directory")
    manifest = bank / MANIFEST
    if not manifest.is_file() or file_sha256(manifest) != chosen.get("manifest_sha256"):
        raise ValueError("Active QPM reference-bank manifest does not match validated activation")
    info = json.loads(manifest.read_text())
    if info.get("validation_status") != "passed":
        raise ValueError("QPM reference bank has not passed validation")
    for filename, record in info.get("artifacts", {}).items():
        path = bank / filename
        if not path.is_file() or path.stat().st_size != record["size_bytes"]:
            raise ValueError(f"Validated QPM reference-bank artifact changed or missing: {filename}")
    return bank.resolve()


def reference_bank_info(project):
    path = Path(project) / MANIFEST
    if not path.is_file():
        origin = Path(project) / "reference_bank_origin.json"
        if origin.is_file():
            return {**json.loads(origin.read_text()), "status": "isolated_target_view", "project_path": str(project)}
        return {"status": "explicit_project_snapshot", "path": str(project)}
    info = json.loads(path.read_text())
    return {"status": info.get("validation_status"), "path": str(project),
            "bank_id": info.get("bank_id"), "manifest_sha256": file_sha256(path),
            "observations": info.get("observations"), "physical_runs": info.get("physical_runs"),
            "instruments": info.get("instruments"), "eligible_waveforms": info.get("eligible_waveforms")}
