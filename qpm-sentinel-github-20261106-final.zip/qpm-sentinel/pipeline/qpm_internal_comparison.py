"""Reference-independent, path-level within-run QPM comparisons.

Surviving barcode paths are an internal comparator, not certified healthy.
Each path is left out of its own survivor-template fit. Every label permutation
rebuilds all templates and descriptive scores. Significance uses raw-waveform
energy distance with label-invariant scaling, not permuted fitted AUC scores.
"""
from __future__ import annotations

import ast
from itertools import combinations
import json
import math

import numpy as np
import pandas as pd
from scipy.stats import rankdata

from qpm_waveform_reference import PROFILE_COLUMNS, digest
from qpm_trace_quality import eligible_waveforms

VERSION = "qpm-within-run-comparison-1.0.0"
METRICS = ["within_run_shape_deviation", "within_run_outside_survivor_band_fraction",
           "within_run_absolute_log_amplitude_ratio"]


def profile(value: object) -> np.ndarray:
    if isinstance(value, str):
        value = ast.literal_eval(value)
    return np.asarray(value, dtype=float)


def independent_path_ids(frame: pd.DataFrame) -> pd.Series:
    return pd.Series([f"barcode:{order}" if pd.notna(order) else f"location:{location}"
                      for order, location in zip(frame["planned_order"], frame["location"])], index=frame.index)


def collapse_paths(group: pd.DataFrame) -> pd.DataFrame:
    """One median raw waveform per barcode/location, never one vote per retry."""
    group = eligible_waveforms(group).drop_duplicates("operation_id").copy()
    if group.empty:
        return group
    group["independent_path"] = independent_path_ids(group)
    rows = []
    for _, entries in group.groupby("independent_path", sort=False):
        row = entries.iloc[0].to_dict()
        if entries["path_status"].nunique() != 1:
            raise ValueError("One mapped path has inconsistent outcome labels")
        if "observed_profile" in entries:
            try:
                curves = [profile(value) for value in entries["observed_profile"]]
                valid = all(curve.shape == (32,) and np.isfinite(curve).all() for curve in curves)
                row["observed_profile"] = np.median(np.vstack(curves), axis=0) if valid else np.array([])
            except (ValueError, TypeError, SyntaxError):
                row["observed_profile"] = np.array([])
        rows.append(row)
    return pd.DataFrame(rows)


def internal_operation_frame(qpm: pd.DataFrame, target_id: str,
                             historical_scores: pd.DataFrame, coverage: pd.DataFrame) -> pd.DataFrame:
    """Keep all raw target waves, irrespective of external-reference coverage."""
    qpm = eligible_waveforms(qpm)
    target = qpm[qpm["observation_id"].eq(target_id)].copy()
    if target.empty:
        return target
    raw = target[PROFILE_COLUMNS].to_numpy(float)
    target = target.drop(columns=PROFILE_COLUMNS + ["qpm_profile"], errors="ignore")
    target["observed_profile"] = [json.dumps(curve.tolist()) for curve in raw]
    extra = [column for column in historical_scores if column.startswith("reference_") or column in
             ["matched_reference_level", "qpm_shape_score", "qpm_anomaly_percentile",
              "outside_90pct_envelope_fraction", "amplitude_ratio_to_reference", "waveform_morphology"]]
    if not historical_scores.empty:
        target = target.merge(historical_scores[["operation_id"] + extra], on="operation_id", how="left", validate="one_to_one")
    for column in ["reference_physical_runs", "qpm_shape_score", "qpm_anomaly_percentile",
                   "outside_90pct_envelope_fraction", "amplitude_ratio_to_reference"]:
        if column not in target:
            target[column] = np.nan
    target["reference_physical_runs"] = target["reference_physical_runs"].fillna(0).astype(int)
    for column in ["reference_median_profile", "reference_q05_profile", "reference_q95_profile"]:
        if column not in target:
            target[column] = None
    if not coverage.empty:
        fields = [column for column in ["operation_id", "reference_status", "maximum_available_reference_runs", "reason"] if column in coverage]
        target = target.merge(coverage[fields].rename(columns={"reason": "historical_reference_exclusion_reason",
                                                            "reference_status": "historical_reference_status"}),
                              on="operation_id", how="left", validate="one_to_one")
    if "historical_reference_status" not in target:
        target["historical_reference_status"] = "unavailable"
    target["internal_context_verified"] = target["command_context_status"].eq("command_verified")
    physical = ["liquid_class_fingerprint", "container_geometry_fingerprint", "deck_geometry_fingerprint",
                "command_settings_fingerprint", "pressure_unit"]
    target["internal_context_fingerprint"] = target[physical].fillna("unresolved").apply(lambda row: digest(row.tolist())[:20], axis=1)
    target["comparison_basis"] = "within_run_loo_survivor_template"
    return target


def deviation_scores(matrix: np.ndarray, failed: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    """Fit survivor templates anew; omit the queried path when it is a survivor."""
    matrix = np.asarray(matrix, dtype=float)
    failed = np.asarray(failed, dtype=bool)
    if matrix.ndim != 2 or not np.isfinite(matrix).all() or (~failed).sum() < 3 or failed.sum() < 1:
        raise ValueError("Finite raw profiles and at least three independent surviving paths are required")
    metrics = np.zeros((len(matrix), 3))
    for index, observed in enumerate(matrix):
        included = ~failed.copy()
        included[index] = False
        anchor = matrix[included]
        median = np.median(anchor, axis=0)
        amplitude = float(np.median(np.ptp(anchor, axis=1)))
        scale = np.maximum(1.4826 * np.median(np.abs(anchor - median), axis=0), max(amplitude * .02, 1.0))
        q05, q95 = np.quantile(anchor, [.05, .95], axis=0)
        metrics[index, 0] = np.sqrt(np.mean(np.clip((observed - median) / scale, -10, 10) ** 2))
        metrics[index, 1] = np.mean((observed < q05) | (observed > q95))
        # One raw-count regularizer makes identical flat curves a neutral ratio.
        metrics[index, 2] = abs(np.log((np.ptp(observed) + 1.0) / (amplitude + 1.0)))
    composite = np.mean(rankdata(metrics, method="average", axis=0) / len(matrix), axis=1)
    differences = composite[failed, None] - composite[None, ~failed]
    auc = float(np.mean((differences > 0) + .5 * (differences == 0)))
    return metrics, composite, auc


def permutation_test(matrix: np.ndarray, failed: np.ndarray, seed: int = 1729,
                     monte_carlo_count: int = 2000) -> tuple[float, str, int]:
    """Raw-waveform energy-distance test; label-dependent scores are also refit.

    AUC is descriptive survivor-template separation, not the significance test:
    small survivor-template fits can produce high AUC even under mixed labels.
    Energy distance tests raw multivariate distribution separation using a
    label-invariant robust scale and valid path-level label permutations.
    """
    failed = np.asarray(failed, dtype=bool)
    if failed.ndim != 1 or len(failed) != len(matrix) or failed.sum() < 2 or (~failed).sum() < 3:
        raise ValueError("Energy-distance permutations require at least two affected and three surviving paths")
    if isinstance(monte_carlo_count, bool) or not isinstance(monte_carlo_count, int) or monte_carlo_count < 1:
        raise ValueError("monte_carlo_count must be a positive integer")
    deviation_scores(matrix, failed)
    distances = waveform_distances(matrix)
    observed = energy_distance(distances, failed)
    n_failed = int(failed.sum())
    total = math.comb(len(failed), n_failed)
    if total <= 5000:
        assignments = combinations(range(len(failed)), n_failed)
        method = "exact_raw_energy_recomputed_survivor_templates"
    else:
        rng = np.random.default_rng(seed)
        assignments = (rng.choice(len(failed), n_failed, replace=False) for _ in range(monte_carlo_count))
        method = f"monte_carlo_{monte_carlo_count}_raw_energy_recomputed_survivor_templates"
    extreme, evaluated = 0, 0
    for assignment in assignments:
        mask = np.zeros(len(failed), dtype=bool)
        mask[list(assignment)] = True
        deviation_scores(matrix, mask)
        statistic = energy_distance(distances, mask)
        extreme += int(statistic >= observed - 1e-12)
        evaluated += 1
    probability = extreme / evaluated if total <= 5000 else (extreme + 1) / (evaluated + 1)
    return float(probability), method, evaluated


def waveform_distances(matrix: np.ndarray) -> np.ndarray:
    """Label-independent pairwise shape/amplitude distance in matched raw units."""
    matrix = np.asarray(matrix, dtype=float)
    median = np.median(matrix, axis=0)
    scale = np.maximum(1.4826 * np.median(np.abs(matrix - median), axis=0),
                       max(float(np.median(np.ptp(matrix, axis=1))) * .02, 1.0))
    delta = (matrix[:, None, :] - matrix[None, :, :]) / scale
    return np.sqrt(np.mean(delta ** 2, axis=2))


def energy_distance(distances: np.ndarray, failed: np.ndarray) -> float:
    """Unbiased energy-distance statistic; diagonal self distances are omitted."""
    n_failed, n_surviving = int(failed.sum()), int((~failed).sum())
    cross = distances[np.ix_(failed, ~failed)].mean()
    within_failed = distances[np.ix_(failed, failed)].sum() / (n_failed * (n_failed - 1))
    within_surviving = distances[np.ix_(~failed, ~failed)].sum() / (n_surviving * (n_surviving - 1))
    return float(2 * cross - within_failed - within_surviving)
