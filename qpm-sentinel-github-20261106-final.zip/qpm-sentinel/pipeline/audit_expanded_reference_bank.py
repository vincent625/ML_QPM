#!/usr/bin/env python3
"""Validate and describe a versioned QPM bank before explicit activation."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import html
import json
from pathlib import Path
import unittest

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from build_expanded_reference_bank import write_json, sha256
from qpm_reference_bank import MANIFEST, POINTER, resolve_reference_bank
from qpm_waveform_reference import load_profiles, PHYSICAL_KEYS, PROFILE_COLUMNS
from qpm_trace_quality import er72_mask

VERSION = "expanded-csa-reference-audit-1.0.0"
REGRESSION_MODULES = ['test_csa_root_cause_hypotheses', 'test_csa_low_performance_diagnostics', 'test_csa_low_performance_batch', 'test_top5_csa_metrics', 'test_qpm_diagnostic_routing', 'test_qpm_er72', 'test_qpm_five_evidence', 'test_qpm_parallel_baselines', 'test_qpm_reference_qualification', 'test_qpm_run_metadata', 'test_qpm_same_run_curves', 'test_qpm_sparse_display', 'test_qpm_outcome_first_layout', 'test_qpm_all_volume_inference', 'test_qpm_nominal_plugin_integration', 'test_qpm_volume_expanded', 'test_all_qpm_volumes', 'test_expanded_csa_outcomes', 'test_expanded_reference_bank', 'test_flagged_qpm_batch', 'test_gx8_model_registration', 'test_qpm_cohort_publication', 'test_all_csa_run_screen', 'test_forecast_next_run_csa', 'test_forecast_10m_eight_runs', 'test_qpm_accuracy_by_volume']
CODE_FILES = ['analyze_additional_dropout_steps.py', 'analyze_csa.py', 'analyze_dna_rna_barcode_balance.py', 'analyze_qpm_volume_diagnostics.py', 'audit_expanded_reference_bank.py', 'build_expanded_reference_bank.py', 'build_qualified_reference_bank.py', 'collect_csa.py', 'compare_qpm_classes_operations.py', 'compare_qpm_models.py', 'csa_low_performance_diagnostics.py', 'csa_root_cause_hypotheses.py', 'find_qpm_failure_examples.py', 'forecast_10m_eight_runs.py', 'forecast_next_run_csa.py', 'outcome_reference.py', 'plot_dropout_workflow_curves.py', 'prepare_all_qpm_volumes.py', 'qpm_all_volume_inference.py', 'qpm_barcode_reference.py', 'qpm_baseline_comparison.py', 'qpm_cohort_publication.py', 'qpm_cross_instrument_reference.py', 'qpm_diagnostic_extensions.py', 'qpm_dropout_plugin.py', 'qpm_internal_comparison.py', 'qpm_nominal_volume_inference.py', 'qpm_reference_bank.py', 'qpm_reference_qualification.py', 'qpm_run_metadata.py', 'qpm_same_run_curves.py', 'qpm_trace_quality.py', 'qpm_waveform_reference.py', 'retrain_qpm_volume_models.py', 'run_flagged_qpm_batch.py', 'run_manual_csa_plugin.py', 'screen_all_csa_runs.py', 'stage_downloaded_csa.py', 'train_all_qpm_volumes.py', 'train_expanded_csa_outcomes.py', 'train_multimodal_csa.py', 'workflow_fingerprint_pilot.py', 'release_all_qpm_volume.py', 'audit_qpm_volume_scope.py', 'validate_all_qpm_volumes.py', 'report_all_qpm_volumes.py', 'plot_qpm_accuracy_by_volume.py', 'qpm_dropout_plugin_requirements.txt', 'QPM_ALL_OPERATIONS_VOLUME_README.md']


def regression_tests(bank):
    import sys
    test_root = Path(__file__).resolve().parent.parent / 'tests' / 'upstream'
    if str(test_root) not in sys.path:
        sys.path.insert(0, str(test_root))
    suite=unittest.defaultTestLoader.loadTestsFromNames(REGRESSION_MODULES)
    with (Path(bank)/"reference_bank_regression_tests.log").open("w") as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    record=dict(status="passed" if result.wasSuccessful() else "failed",tests_run=result.testsRun,
                failures=len(result.failures),errors=len(result.errors),
                code_sha256={name:sha256(Path(__file__).parent/name) for name in CODE_FILES})
    record["test_sha256"] = {name+".py": sha256(test_root/(name+".py")) for name in REGRESSION_MODULES}
    write_json(Path(bank)/"reference_bank_regression_tests.json",record)
    print(json.dumps({k:v for k,v in record.items() if k!="code_sha256"}),flush=True)
    if not result.wasSuccessful():
        raise ValueError("Reference-bank regression tests failed")


def catalog(frame, keys):
    return frame.groupby(keys, dropna=False, sort=False).agg(
        waveform_operations=("operation_id", "size"), physical_runs=("physical_run_id", "nunique"),
        observations=("observation_id", "nunique"), instruments=("instrument_id", "nunique")
    ).reset_index()


def audit(bank, legacy):
    bank, legacy = Path(bank).resolve(), Path(legacy).resolve()
    build = json.loads((bank/"reference_bank_build_log.json").read_text())
    core = pd.read_parquet(bank/"csa_ml_dataset.parquet")
    old = pd.read_parquet(legacy/"csa_ml_dataset.parquet", columns=["observation_id", "instrument_id"])
    regression=json.loads((bank/"reference_bank_regression_tests.json").read_text())
    dated=core.assign(acquisition_time=pd.to_datetime(core.run_start_time,utc=True,errors="coerce",format="mixed")).dropna(subset=["acquisition_time"])
    checks = {
        "source_files_all_copied": build["source_collection"]["successful"]+build["source_collection"].get("unrecognized",0) == build["source_collection"]["discovered"],
        "no_duplicate_observations": not core.observation_id.duplicated().any(),
        "no_duplicate_physical_run_lane": not core.duplicated(["physical_run_id", "chip_lane"]).any(),
        "all_legacy_observation_ids_retained": set(old.observation_id).issubset(set(core.observation_id)),
        "all_legacy_instruments_retained": set(old.instrument_id).issubset(set(core.instrument_id)),
        "all_primary_archive_hashes_available": core.archive_sha256.notna().all(),
        "distinct_instrument_per_physical_run": core.groupby("physical_run_id").instrument_id.nunique().le(1).all(),
        "no_renamed_acquisition_counted_as_independent_runs": dated.groupby(["instrument_id","acquisition_time"]).physical_run_id.nunique().le(1).all(),
        "regression_tests_passed": regression["status"]=="passed",
        "regression_matches_current_code": all(sha256(Path(__file__).parent/name)==value for name,value in regression["code_sha256"].items()),
        "regression_matches_current_tests": bool(regression.get("test_sha256")) and all(sha256(Path(__file__).resolve().parent.parent/"tests"/"upstream"/name)==value for name,value in regression["test_sha256"].items()),
    }
    print("Loading and auditing verified waveform reference candidates", flush=True)
    profiles, metadata = load_profiles(bank)
    checks.update(no_er72_in_eligible_profiles=not er72_mask(profiles).any(),
                  all_profile_status_verified=profiles.qpm_waveform_eligible.all(),
                  no_duplicate_operation_ids=not profiles.operation_id.duplicated().any(),
                  all_waveforms_in_primary_dataset=set(profiles.observation_id).issubset(set(core.observation_id)),
                  all_finite_profiles=np.isfinite(profiles[PROFILE_COLUMNS].to_numpy(float)).all(),
                  no_trace_quality_archive_failures=all(a["status"]=="parsed" for a in metadata["trace_quality"]["archives"]),
                  no_context_archive_failures=all(a["status"]=="parsed" for a in metadata["archives"]))
    coupler = profiles.container_model.fillna("").str.contains("chipCoupler", case=False) | profiles.location.str.contains("chip_coupler", case=False)
    profiles["chip_fluidic_context"]="not_chip_contact"
    profiles.loc[coupler,"chip_fluidic_context"]=profiles.loc[coupler,"chip_type"].fillna("missing_chip_context").astype(str)
    admissible = profiles[profiles.command_context_status.eq("command_verified") & profiles.chip_fluidic_context.ne("missing_chip_context")].copy()
    external = admissible[np.ptp(admissible[PROFILE_COLUMNS].to_numpy(float), axis=1)>1e-8].copy()
    print(f"Verified profiles: {len(profiles)}; physically matchable: {len(admissible)}", flush=True)
    same = catalog(admissible, PHYSICAL_KEYS)
    cross_keys = [k for k in PHYSICAL_KEYS if k != "instrument_id"]
    cross = catalog(external, cross_keys)
    same["leave_target_run_out_available_runs"] = same.physical_runs-1
    same["leave_target_run_out_minimum_met"] = same.leave_target_run_out_available_runs.ge(8)
    same.to_csv(bank/"qpm_same_instrument_reference_catalog.csv", index=False)
    cross.to_csv(bank/"qpm_cross_instrument_reference_catalog.csv", index=False)
    for name, frame, keys in [("same",admissible,PHYSICAL_KEYS),("cross",external,cross_keys)]:
        detailed=catalog(frame,keys+["workflow_stage","process_step","location"])
        detailed.to_parquet(bank/f"qpm_{name}_step_location_reference_catalog.parquet", index=False)
    # Other-instrument population sizes are explicit for each target instrument.
    local_cross = catalog(external, PHYSICAL_KEYS).rename(columns={"physical_runs":"same_instrument_shape_runs", "waveform_operations":"local_waveform_operations"})
    merged = local_cross.merge(cross[cross_keys+["physical_runs","instruments"]], on=cross_keys, how="left", suffixes=("_local",""), validate="many_to_one")
    merged["other_instrument_physical_runs"] = merged.physical_runs-merged.same_instrument_shape_runs
    merged["other_reference_instruments"] = merged.instruments-1
    merged["other_instrument_minimum_met"] = merged.other_instrument_physical_runs.ge(8)&merged.other_reference_instruments.ge(2)
    merged.to_parquet(bank/"qpm_cross_instrument_coverage_by_target_instrument.parquet",index=False)
    same_coverage = same.groupby("instrument_id").agg(physical_signatures=("physical_runs","size"),
                       qualified_same_signatures=("leave_target_run_out_minimum_met","sum"),
                       matchable_waveforms=("waveform_operations","sum"))
    same_coverage["same_instrument_covered_waveforms"] = same[same.leave_target_run_out_minimum_met].groupby("instrument_id").waveform_operations.sum()
    cross_coverage=merged[merged.other_instrument_minimum_met].groupby("instrument_id").local_waveform_operations.sum().rename("cross_instrument_covered_shape_waveforms")
    coverage=pd.read_csv(bank/"instrument_coverage.csv").merge(same_coverage.reset_index(),on="instrument_id",how="left")
    coverage=coverage.merge(cross_coverage.reset_index(),on="instrument_id",how="left")
    waveform_counts=profiles.groupby("instrument_id").size().rename("er72_cleared_waveforms")
    coverage=coverage.merge(waveform_counts.reset_index(),on="instrument_id",how="left")
    count_fields=["physical_signatures","qualified_same_signatures","matchable_waveforms","same_instrument_covered_waveforms", "cross_instrument_covered_shape_waveforms","er72_cleared_waveforms"]
    coverage[count_fields]=coverage[count_fields].fillna(0).astype(int)
    coverage.to_csv(bank/"instrument_reference_coverage.csv",index=False)
    excluded=pd.DataFrame(metadata.get("trace_quality_exclusions",[]))
    excluded.to_parquet(bank/"qpm_bank_excluded_traces.parquet",index=False)
    checks["catalog_does_not_count_operations_as_independent_runs"]=same.physical_runs.le(same.observations).all() and same.observations.le(same.waveform_operations).all()
    passed=all(bool(x) for x in checks.values())
    validation=dict(version=VERSION,status="passed" if passed else "failed",checks={k:bool(v) for k,v in checks.items()},
                    eligible_waveforms=len(profiles), physically_matchable_waveforms=len(admissible), cross_shape_waveforms=len(external),
                    excluded_waveforms=len(excluded), er72_excluded_waveforms=int(er72_mask(excluded).sum()) if len(excluded) else 0,
                    physical_signatures=len(same),cross_physical_signatures=len(cross),
                    waveform_reference_time_policy="retrospective",outcome_peer_time_policy="prior_only",
                    minimum_reference_physical_runs=8,minimum_cross_reference_instruments=2,
                    coverage_note="Coverage counts use allowed cross-step physical fallback and leave target physical run out. Step/location-specific catalog is retained separately. Prior-only coverage can be lower.")
    write_json(bank/"reference_bank_validation.json",validation)
    # Give every original downloaded file a terminal parse/dedup disposition.
    receipts=pd.read_csv(bank/"source_transfer_manifest.csv",dtype={"archive_id":str})
    audits=pd.read_csv(bank/"archive_parse_audit.csv",dtype={"archive_id":str})
    source_status=receipts.merge(audits[["archive_id","status","error_type"]],on="archive_id",how="left",validate="many_to_one")
    source_status["reference_disposition"]=source_status.status.fillna("byte_identical_legacy_archive_reused")
    source_status.loc[source_status.state.eq("unrecognized_format"),"reference_disposition"]="unrecognized_format_excluded"
    source_status.loc[source_status.state.eq("failed"),"reference_disposition"]="transfer_failed_excluded"
    primary_ids=set(core.archive_id)
    source_status.loc[source_status.status.eq("parsed")&~source_status.archive_id.isin(primary_ids),"reference_disposition"]="parsed_duplicate_export_not_primary"
    quarantined=pd.read_csv(bank/"quarantined_identity_archives.csv")
    source_status.loc[source_status.archive_id.isin(quarantined.archive_id),"reference_disposition"]="ambiguous_physical_identity_quarantined"
    source_status.to_csv(bank/"source_archive_status.csv",index=False)
    artifacts={}
    names=["csa_ml_dataset.parquet","csa_inventory.csv","csa_transfer_manifest.csv", "qpm_operation_waveforms.parquet",
           "qpm_physical_operation_context.parquet","qpm_physical_operation_context_manifest.json",
           "qpm_trace_quality.parquet","qpm_trace_quality_manifest.json","qpm_failure_examples/dna_rna_barcode_counts.csv",
           "qpm_failure_examples/dna_rna_balance_by_run.csv","outcome_reference_policy.json","qpm_waveform_reference_policy.json",
           "qpm_dropout_plugin_config.json","reference_bank_validation.json","instrument_reference_coverage.csv","reference_bank_regression_tests.json"]
    for name in names:
        path=bank/name
        artifacts[name]=dict(size_bytes=path.stat().st_size,sha256=sha256(path))
    manifest=dict(bank_id=bank.name,version=VERSION,created_utc=datetime.now(timezone.utc).isoformat(),validation_status=validation["status"],
                  observations=len(core),physical_runs=core.physical_run_id.nunique(),instruments=core.instrument_id.nunique(),
                  source_archives=build["source_collection"]["discovered"],eligible_waveforms=len(profiles),
                  er72_excluded_waveforms=validation["er72_excluded_waveforms"],artifacts=artifacts,
                  legacy_project=str(legacy),source_collection_read_only=True,no_settings_modified=True,no_model_retraining=True)
    write_json(bank/MANIFEST,manifest)
    cols=["hostname","observations","physical_runs","er72_cleared_waveforms","same_instrument_covered_waveforms","cross_instrument_covered_shape_waveforms"]
    report=f'''<!doctype html><html><head><meta charset="utf-8"><title>Expanded QPM reference bank</title><style>
body{{font:16px system-ui;color:#254653;background:#f7faf6;max-width:1300px;margin:32px auto;padding:20px}} h1,h2{{color:#245c53}}
table{{border-collapse:collapse;background:white;font-size:13px}}td,th{{padding:8px;border-bottom:1px solid #dce5db;text-align:right}}th:first-child,td:first-child{{text-align:left}}
.summary{{background:#e2eee4;padding:20px;border-radius:12px}} .note{{color:#715b37}}</style></head><body>
<h1>Expanded QPM instrument and cross-instrument reference bank</h1><p>{html.escape(bank.name)} · Validation: {validation['status']}</p>
<div class="summary">{manifest['source_archives']:,} source archives copied and verified · {manifest['observations']:,} independent run/lane observations · {manifest['physical_runs']:,} physical runs · {manifest['instruments']} instruments<br>
{len(profiles):,} Er72-cleared waveform candidates · {len(admissible):,} physically matchable · {validation['er72_excluded_waveforms']:,} Er72-associated waveforms excluded</div>
<h2>What the plugin now compares</h2><ol><li>Same run, affected versus surviving barcode paths; no historical reference required.</li>
<li>Same instrument and pipette: baseline-centered sensor counts, verified liquid class, volume, geometry and command settings.</li>
<li>Other instruments only: compatible physical settings, dimensionless curve shape; at least two reference instruments.</li></ol>
<p>Historical comparisons require at least eight independent physical runs. A physical run contributes one vote, regardless of sibling lanes, repeated operations or exports. Er72 operations and unresolved command associations never enter scoring or evidence.</p>
<h2>Coverage by instrument</h2>{coverage[cols].sort_values('hostname').to_html(index=False,border=0)}
<p class="note">{validation['coverage_note']} Counts are available reference coverage, not evidence of abnormal performance.</p>
<h2>Outcome peers remain separate</h2><p>Chip, assay/panel, workflow, flow settings, software and planned DNA/RNA sample counts remain exact-match criteria. Only earlier physical runs are eligible; combined-lane outcomes match only combined-lane outcomes. A larger bank does not prove these peers are healthy.</p>
<h2>Ingestion and limitations</h2><p>{build['parse_failures']} newly encountered archive parse failures are excluded and recorded in archive_parse_audit.csv. {build['ambiguous_identity_archives']} ambiguous raw-run identities are quarantined. More-complete exports can replace an older primary within this new snapshot; the original files, historical ML tables and reports are unchanged.</p>
<p>Waveform bands are empirical—not manufacturer acceptance limits, calibrated failure probabilities, delivered-volume measurements, or proven causes. No outcome/volume models were retrained and no instrument settings changed.</p>
<h2>Audit files</h2><p><a href="instrument_reference_coverage.csv">Instrument coverage</a> · <a href="reference_bank_validation.json">Validation checks</a> · <a href="source_archive_status.csv">All source archive dispositions</a> · <a href="reference_bank_build_log.json">Build provenance</a></p>
</body></html>'''
    (bank/"reference_bank_report.html").write_text(report)
    print(json.dumps(validation,indent=2),flush=True)
    if not passed:
        raise ValueError("Expanded bank validation failed; activation prohibited")


def activate(bank,project):
    bank,project=Path(bank).resolve(),Path(project).resolve()
    manifest=json.loads((bank/MANIFEST).read_text())
    if manifest["validation_status"]!="passed":
        raise ValueError("Cannot activate an unvalidated reference bank")
    for name,r in manifest["artifacts"].items():
        if sha256(bank/name)!=r["sha256"]:
            raise ValueError(f"Artifact hash mismatch: {name}")
    pointer=project/POINTER
    if pointer.exists():
        previous=project/(POINTER+".previous-"+datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"))
        previous.write_bytes(pointer.read_bytes())
    write_json(pointer,dict(version=VERSION,bank_path=str(bank),manifest_sha256=sha256(bank/MANIFEST),activated_utc=datetime.now(timezone.utc).isoformat()))
    if resolve_reference_bank(project)!=bank:
        raise ValueError("Activation resolution failed")
    print(json.dumps(dict(activated_reference_bank=str(bank),observations=manifest["observations"],physical_runs=manifest["physical_runs"],instruments=manifest["instruments"])),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--bank",type=Path,required=True)
    p.add_argument("--legacy",type=Path,default=Path(__file__).resolve().parent)
    p.add_argument("--activate",action="store_true")
    p.add_argument("--run-tests",action="store_true")
    args=p.parse_args()
    if args.run_tests:
        regression_tests(args.bank)
    elif args.activate:
        activate(args.bank,args.legacy)
    else:
        audit(args.bank,args.legacy)
