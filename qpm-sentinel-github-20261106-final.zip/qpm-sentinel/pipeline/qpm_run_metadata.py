"""Privacy-limited, source-traceable run labels for the QPM report.

These labels are presentation metadata only: they do not change outcome calls,
reference matching, waveform scores, or evidence selection.
"""
from __future__ import annotations

import html
from pathlib import Path
import re

import pandas as pd


VERSION = "qpm-run-metadata-1.0.0"
NOT_RECORDED = "Not recorded"


def clean_text(value) -> str:
    if value is None or pd.isna(value):
        return ""
    result = str(value).strip()
    return "" if result.lower() in {"nan", "none", "null", "nat", "n/a", "<na>"} else result


def unique_value(frame: pd.DataFrame, column: str) -> str:
    """Conflicting metadata must not be resolved by arbitrary row order."""
    if column not in frame:
        return ""
    values = {clean_text(value) for value in frame[column]} - {""}
    return next(iter(values)) if len(values) == 1 else ""


def build_run_metadata(project: Path, observation_id: str) -> dict:
    project = Path(project)
    core = pd.read_parquet(project / "csa_ml_dataset.parquet")
    target = core.loc[core.observation_id.eq(observation_id)]
    if len(target) != 1:
        raise ValueError("Run metadata requires exactly one retained observation")
    row = target.iloc[0]
    sources, warnings = {}, []

    def recorded(name, field):
        value = clean_text(row.get(field))
        if value:
            sources[name] = f"csa_ml_dataset.parquet:{field}"
        return value

    archive_id = clean_text(row.get("archive_id"))
    inventory = pd.DataFrame()
    if (project / "csa_inventory.csv").is_file():
        inventory = pd.read_csv(project / "csa_inventory.csv", dtype=str)
        inventory = (inventory.loc[inventory.archive_id.eq(archive_id)]
                     if archive_id and "archive_id" in inventory else pd.DataFrame())

    instrument = recorded("instrument", "hostname_for_report")
    if not instrument:
        instrument = unique_value(inventory, "hostname")
        if instrument:
            sources["instrument"] = "csa_inventory.csv:hostname (matched archive_id)"
    run_name = unique_value(inventory, "run_name")
    if run_name:
        sources["run_name"] = "csa_inventory.csv:run_name (matched archive_id)"
    for column in ["hostname", "run_name"]:
        if column in inventory and len({clean_text(v) for v in inventory[column]} - {""}) > 1:
            warnings.append(f"Conflicting inventory {column} values for the target archive; no arbitrary value selected.")

    start = recorded("run_start_time", "run_start_time")
    date = ""
    if start:
        try:
            date = pd.Timestamp(start).strftime("%Y-%m-%d")
            sources["run_date"] = sources["run_start_time"]
        except (ValueError, TypeError, OverflowError):
            warnings.append("Recorded run-start value is not a valid date; run date is unresolved.")

    packages, panels, panel_fields = [], [], []
    for field in ["global.analysis_regions_file", "global.analysis_fusions_file"]:
        value = clean_text(row.get(field)).replace("\\", "/")
        if not value:
            continue
        # Only package identity / basename is displayed, never a server path.
        parts = value.rstrip("/").split("/")
        if "AssayImport" in parts:
            index = parts.index("AssayImport") + 1
            if index < len(parts) - 1:
                packages.append(parts[index])
        if parts[-1]:
            panels.append(parts[-1])
            panel_fields.append(field)
    packages, panels = list(dict.fromkeys(packages)), list(dict.fromkeys(panels))
    label = " | ".join(packages or panels)
    basis = ("recorded AssayImport package" if packages else
             "recorded panel filename" if panels else "not recorded")
    if label:
        sources["assay_panel"] = "csa_ml_dataset.parquet:" + ", ".join(panel_fields)

    metadata = dict(
        schema_version=VERSION, observation_id=observation_id,
        physical_run_id=clean_text(row.get("physical_run_id")) or NOT_RECORDED,
        run_name=run_name or NOT_RECORDED, instrument=instrument or NOT_RECORDED,
        run_date=date or NOT_RECORDED, run_start_time=start or NOT_RECORDED,
        run_time_note="Recorded run-start value; instrument timezone has not been independently verified.",
        chip_type=recorded("chip_type", "ion_params_00.chip_info_chip_type") or NOT_RECORDED,
        chip_lane=recorded("chip_lane", "chip_lane") or NOT_RECORDED,
        analysis_lane_scope=recorded("analysis_lane_scope", "analysis_lane_scope") or NOT_RECORDED,
        assay_type=recorded("assay_type", "global.analysis_application_type") or NOT_RECORDED,
        assay_panel=label or NOT_RECORDED, assay_panel_basis=basis,
        panel_files=" | ".join(panels) or NOT_RECORDED,
        panel_technology=recorded("panel_technology", "global.analysis_panel_technology") or NOT_RECORDED,
        workflow=recorded("workflow", "planned_run.object_script_name") or NOT_RECORDED,
        sources=sources, warnings=warnings,
    )
    # Keep GX7 and GX8 identities distinct even though their read cutoffs match.
    chip = metadata["chip_type"]
    if re.fullmatch(r"gx[5789]", chip, re.IGNORECASE):
        metadata["chip_type"] = chip.upper()
    return metadata


def run_metadata_html(metadata: dict) -> str:
    def escape(field):
        return html.escape(clean_text(metadata.get(field)) or NOT_RECORDED)

    fields = [("Run date", "run_date"), ("Instrument", "instrument"),
              ("Chip type", "chip_type"), ("Analyzed lane(s)", "chip_lane"),
              ("Assay / application type", "assay_type"),
              ("Assay package / panel", "assay_panel")]
    cards = "".join(f'<div><dt>{html.escape(label)}</dt><dd data-run-field="{key}">{escape(key)}</dd></div>'
                    for label, key in fields)
    return f'''<section id="run-information" aria-labelledby="run-information-heading">
<h2 id="run-information-heading">Run information</h2>
<dl class="run-info-grid">{cards}</dl>
<p class="run-detail"><strong>Run name:</strong> <span data-run-field="run_name">{escape('run_name')}</span><br>
<strong>Recorded run start:</strong> <span data-run-field="run_start_time">{escape('run_start_time')}</span><br>
<strong>Workflow:</strong> <span data-run-field="workflow">{escape('workflow')}</span></p>
<p class="muted">Assay/panel label basis: {escape('assay_panel_basis')}. A workflow script is not treated as an assay name.
{escape('run_time_note')} Missing metadata is not inferred from filenames.</p>
<p class="files"><a href="run_metadata.json">Run metadata and field provenance</a></p>
</section>'''
