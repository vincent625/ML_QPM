"""Deterministic, offline low-read investigation hypotheses.

This adapter joins frozen *global* model reliance to already guarded, case-level
comparisons. It never fits a model, sums feature importance, attributes lost
reads, or converts an image descriptor into a physical fault measurement.
"""
from __future__ import annotations

from collections import Counter
import html
import math
from typing import Any


VERSION = "csa-low-read-hypotheses-1.0.0"
MINIMUM_RUNS = 8
RAWTRACE = {
    "plugin.rawtrace.image.pixel_median.std": "RawTrace image-median spread",
    "plugin.rawtrace.image.pixel_q90.std": "RawTrace image-q90 spread",
    "plugin.rawtrace.image.entropy.std": "RawTrace image-entropy spread",
}
PINNED = "plugin.chip_diagnostics.structured.results_offset_perc_pinned"
AMBIGUOUS = {
    "plugin.chip_diagnostics.structured.results_offset_pixel_in_range.mean": "Merged in-range pixel-count proxy",
    "plugin.chip_diagnostics.structured.results_edge_metrics_pixels_n.std": "Edge-region pixel-count spread",
}
FORBIDDEN = {"true_loading", "edge_effects", "lane_diagnostics", "reseq_diagnostics"}
POLICY = {
    "version": VERSION,
    "outcome": "total_reads",
    "ranking_scope": "fixed_top_ten_global_total_read_features",
    "model": "elastic_net",
    "validation_scheme": "grouped",
    "minimum_physical_runs_per_metric": MINIMUM_RUNS,
    "reference": "already_guarded_strictly_prior_protocol_matched_outcome_qualified_physical_runs",
    "range": "empirical_5th_to_95th_percentiles_not_a_confidence_interval_or_approved_acceptance_limit",
    "outside_rule": "strictly_below_q05_or_above_q95",
    "direction_rule": "all_selected_outer_folds_same_coefficient_sign_and_positive_heldout_permutation_in_all_folds",
    "direction_support": "outer_folds_at_least_3_all_folds_selected_positive_importance_and_exploratory_ci_low_above_zero",
    "rawtrace_dependency": "all_rawtrace_image_descriptors_are_one_source_family_not_independent_replication",
    "multiple_metric_rule": "one_or_more_concordant_metrics_can_support_one_family_no_importance_summing",
    "supplemental_chip_rule": "original_validated_offset_PercPinned_above_compatible_range_not_a_substitute_for_ranked_count_proxies",
    "missing_is_normal": False,
    "causal_interpretation": "candidate_explanations_not_proven_causes",
}
LIMITATIONS = [
    "These are post-run investigation hypotheses, not confirmed root causes, fault probabilities, or prospective predictions.",
    "Global held-out permutation importance prioritizes review; it is not this run's contribution, lost reads, or an intervention effect.",
    "Conditional coefficient agreement is a model-direction check, not a causal direction or a per-run prediction attribution.",
    "Empirical 5th–95th percentile outliers are descriptive; no multiple-testing-adjusted failure test or approved acceptance limit is implied.",
    "RawTrace descriptors summarize rendered images, not calibrated signal amplitude, SNR, loading, pressure, or delivered volume; rendering/content compatibility still needs review.",
    "Multiple RawTrace metrics share one source. Distinct plugin sources may also be dependent; their coexistence does not prove a common mechanism.",
    "Missing measurements, incompatible history, and withheld proxies are unresolved, not evidence of normal operation.",
    "No instrument setting is changed, no model is retrained, and no gain or loss in reads or transferred volume is estimated.",
]


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


def _count(value: Any) -> int | None:
    number = _number(value)
    return int(number) if number is not None and number >= 0 and number.is_integer() else None


def _rank(row: dict) -> int | None:
    return _count(row.get("global_rank", row.get("rank")))


def _ordered(rows: list[dict]) -> list[dict]:
    return sorted(rows, key=lambda row: (
        _rank(row) if _rank(row) is not None else math.inf,
        -(_number(row.get("heldout_mae_increase")) or 0),
        str(row.get("feature_name", row.get("feature", ""))),
    ))


def _trigger_reasons(trigger: dict) -> list[str]:
    reasons = []
    if trigger.get("below_chip_lane_read_criterion") is True:
        reasons.append("below_chip_lane_read_criterion")
    outcomes = trigger.get("low_outcomes", [])
    if isinstance(outcomes, str):
        outcomes = [outcomes]
    if isinstance(outcomes, (list, tuple, set)) and "total_reads" in outcomes:
        reasons.append("total_reads_below_matched_peer_threshold")
    return reasons


def _direction(row: dict) -> tuple[str, str]:
    """Require full saved-fold agreement; an average coefficient is not enough."""
    outer = _count(row.get("outer_folds"))
    selected = _count(row.get("selection_count"))
    positive = _count(row.get("positive_folds"))
    plus = _count(row.get("coefficient_positive_folds"))
    minus = _count(row.get("coefficient_negative_folds"))
    importance = _number(row.get("heldout_mae_increase"))
    low = _number(row.get("importance_ci_low"))
    high = _number(row.get("importance_ci_high"))
    stable = (outer is not None and outer >= 3 and selected == outer and positive == outer
              and importance is not None and importance > 0
              and low is not None and low > 0
              and high is not None and high >= low and low <= importance <= high)
    if not stable:
        return "unresolved_or_unstable", "Saved fold selection/permutation/direction support is incomplete or not stable in every outer fold."
    stated = row.get("direction", row.get("conditional_direction"))
    if plus == outer and minus == 0 and stated == "positive_conditional_association":
        return "stable_positive_conditional_association", "Higher values have a positive conditional association with reads in all saved outer folds."
    if minus == outer and plus == 0 and stated == "negative_conditional_association":
        return "stable_negative_conditional_association", "Higher values have a negative conditional association with reads in all saved outer folds."
    return "unresolved_or_unstable", "The saved coefficient signs or declared direction do not agree in every selected outer fold."


def _measurement(metric: dict | None) -> tuple[str, str, str]:
    if not metric:
        return "unresolved_measurement", "No validated current measurement adapter is available.", "unresolved"
    if metric.get("status") != "available":
        return "unresolved_measurement", "Measurement/reference unresolved: " + str(metric.get("status", "not recorded")) + ".", "unresolved"
    if metric.get("reference_mode") not in {"same_instrument_same_lane", "same_instrument_all_lanes", "other_instruments"}:
        return "unresolved_reference_mode", "No recognized guarded historical-reference mode is recorded.", "unresolved"
    runs = _count(metric.get("reference_physical_runs"))
    if runs is None or runs < MINIMUM_RUNS:
        return "unresolved_insufficient_history", "Fewer than eight compatible earlier physical-run measurements.", "unresolved"
    value, low, median, high = [_number(metric.get(key)) for key in ("target_value", "peer_q05", "peer_median", "peer_q95")]
    if None in (value, low, median, high) or not low <= median <= high:
        return "unresolved_invalid_measurement_or_range", "Current value or empirical reference range is nonfinite, missing, or misordered.", "unresolved"
    if value < low:
        return "outside_empirical_range", "Below the empirical 5th percentile.", "below_empirical_range"
    if value > high:
        return "outside_empirical_range", "Above the empirical 95th percentile.", "above_empirical_range"
    return "within_empirical_range", "Within the empirical 5th–95th percentile range; this does not establish health.", "within_empirical_range"


def _evidence_record(contributor: dict, metric: dict | None) -> dict:
    feature = str(contributor.get("feature_name", contributor.get("feature", "")))
    row = dict(feature_name=feature, global_rank=_rank(contributor),
        label=RAWTRACE.get(feature, AMBIGUOUS.get(feature, feature)),
        component=str(contributor.get("component", "unrecorded")), tier=str(contributor.get("tier", "unrecorded")),
        role="fixed_top_ten_contributor", source_family="unresolved",
        global_heldout_mae_increase=_number(contributor.get("heldout_mae_increase")),
        global_importance_ci_low=_number(contributor.get("importance_ci_low")),
        global_importance_ci_high=_number(contributor.get("importance_ci_high")),
        outer_folds=_count(contributor.get("outer_folds")), positive_folds=_count(contributor.get("positive_folds")),
        selection_count=_count(contributor.get("selection_count")),
        coefficient_positive_folds=_count(contributor.get("coefficient_positive_folds")),
        coefficient_negative_folds=_count(contributor.get("coefficient_negative_folds")),
        conditional_direction=contributor.get("direction", contributor.get("conditional_direction", "unrecorded")),
        direction_status="not_applicable", direction_evidence="Not a validated mechanism measurement.",
        assessment_status="withheld_no_validated_adapter", supports_hypothesis=False,
        reason="No validated case-metric interpretation is available for this ranked feature.",
        target_value=None, peer_q05=None, peer_median=None, peer_q95=None,
        reference_physical_runs=0, reference_mode="none", deviation="unresolved",
        source_file=contributor.get("source_file", contributor.get("ml_source_file", "unresolved")),
        source_field=contributor.get("source_field", contributor.get("ml_source_field", "unresolved")),
        unit=contributor.get("unit", "source units unresolved"),
        expected_read_gain=None, estimated_reads_lost=None)
    if metric:
        for key in ("label", "unit", "reference_mode", "source_file", "source_field"):
            if metric.get(key) is not None:
                row[key] = metric[key]
        for key in ("target_value", "peer_q05", "peer_median", "peer_q95"):
            row[key] = _number(metric.get(key))
        row["reference_physical_runs"] = _count(metric.get("reference_physical_runs")) or 0
    component = row["component"].removeprefix("plugin:")
    if row["tier"] == "D" or component in FORBIDDEN or any(feature.startswith("plugin." + family + ".") for family in FORBIDDEN):
        row.update(assessment_status="withheld_leakage_or_forbidden_family", reason="Excluded by the leakage/source policy; never a diagnostic cause.")
    elif feature in AMBIGUOUS:
        row.update(source_family="chip_diagnostics", assessment_status="withheld_ambiguous_count_proxy",
            reason="Merged pixel counts or region-count geometry are not validated health/loading measurements. No mechanism is inferred, even if a value is extreme.")
    elif feature.startswith(("context.", "csa.")) or row["tier"] == "B":
        row.update(source_family="metadata_context", assessment_status="withheld_context_or_configuration",
            reason="Adjustment context or unvalidated metadata/configuration proxy is not a low-read failure mechanism.")
    elif feature in RAWTRACE and row["tier"] == "C":
        row["source_family"] = "rawtrace"
        row["direction_status"], row["direction_evidence"] = _direction(contributor)
        status, reason, deviation = _measurement(metric)
        row.update(assessment_status=status, reason=reason, deviation=deviation)
        if status == "outside_empirical_range":
            if row["direction_status"] == "unresolved_or_unstable":
                row.update(assessment_status="anomaly_direction_unresolved",
                    reason="Rendered-image outlier, but the frozen model's adverse direction is unresolved or unstable; no low-read mechanism hypothesis is supported.")
            else:
                adverse = ((deviation == "above_empirical_range" and row["direction_status"] == "stable_negative_conditional_association")
                           or (deviation == "below_empirical_range" and row["direction_status"] == "stable_positive_conditional_association"))
                if adverse:
                    row.update(assessment_status="model_concordant_low_read_clue", supports_hypothesis=True,
                        reason="Outside the compatible empirical range in the frozen model's lower-read-associated direction. Rendered-image triage clue only, not direct physical signal or root-cause attribution.")
                else:
                    row.update(assessment_status="anomaly_direction_discordant",
                        reason="The outlier is opposite to the frozen model's lower-read-associated direction. Retain as counter-evidence; do not use it to explain the low reads.")
    return row


def _pinned_record(metric: dict) -> dict:
    row = dict(feature_name=PINNED, global_rank=None, label=metric.get("label", "Chip pinned pixels"),
        component="plugin:chip_diagnostics", tier="C", role="supplemental_not_top_ranked",
        source_family="chip_diagnostics", global_heldout_mae_increase=None,
        global_importance_ci_low=None, global_importance_ci_high=None,
        direction_status="higher_original_percentage_review_rule_not_model_attribution",
        direction_evidence="A high original pinned-pixel percentage is a supplemental review clue, not a replacement for the ambiguous ranked count proxies.",
        supports_hypothesis=False, expected_read_gain=None, estimated_reads_lost=None)
    for key in ("unit", "reference_mode", "source_file", "source_field"):
        row[key] = metric.get(key)
    for key in ("target_value", "peer_q05", "peer_median", "peer_q95"):
        row[key] = _number(metric.get(key))
    row["reference_physical_runs"] = _count(metric.get("reference_physical_runs")) or 0
    status, reason, deviation = _measurement(metric)
    row.update(assessment_status=status, reason=reason, deviation=deviation)
    if metric.get("unit") != "%" or metric.get("source_field") != "offset.PercPinned":
        row.update(assessment_status="withheld_unverified_original_percentage", reason="Only the validated original offset.PercPinned percentage is supported; no merged count or alias substitution.", deviation="unresolved")
    elif any(row[key] is not None and not 0 <= row[key] <= 100 for key in ("target_value", "peer_q05", "peer_median", "peer_q95")):
        row.update(assessment_status="unresolved_invalid_measurement_or_range", reason="A pinned-pixel percentage lies outside 0–100%.", deviation="unresolved")
    elif status == "outside_empirical_range" and deviation == "above_empirical_range":
        row.update(assessment_status="supplemental_high_pinned_pixel_clue", supports_hypothesis=True,
            reason="Validated original pinned-pixel percentage exceeds comparable earlier runs. Review offset calibration and pixel masks; this does not prove damaged wells or lost reads.")
    elif status == "outside_empirical_range":
        row.update(assessment_status="supplemental_anomaly_not_adverse", reason="A lower pinned percentage is not used as an adverse low-read explanation.")
    return row


def build_root_cause_assessment(metrics: list[dict], contributors: list[dict], trigger: dict, *, enabled: bool = True) -> dict:
    """Join allowlisted measured clues and frozen direction support, without fitting.

    ``metrics`` must come from the source-validated, prior-only peer adapter. The
    direction check is deliberately stricter than a nonzero global importance.
    Every contributor is retained in the audit, including abstentions.
    """
    reasons = _trigger_reasons(trigger)
    result = dict(version=VERSION, status="unresolved", triggered=bool(reasons), enabled=bool(enabled),
        trigger_reasons=reasons, outcome="total_reads", causal_status="candidate_explanations_not_proven_causes",
        mechanisms_confirmed=False, policy=dict(POLICY), contributor_assessments=[], supplemental_assessments=[],
        hypotheses=[], evidence_families=[], distinct_source_family_count=0,
        top_contributor_coverage={}, expected_read_gain=None, estimated_reads_lost=None,
        model_retrained=False, instrument_settings_changed=False, limitations=list(LIMITATIONS),
        summary="No supported adverse measured contributor currently explains this run's low reads; the mechanism remains unresolved.",
        decision_flow=[])
    if not enabled:
        result.update(status="disabled", summary="The low-read hypothesis adapter is disabled; the low-read mechanism remains unresolved.")
        return result
    if not reasons:
        result.update(status="not_triggered", summary="No total-read low-performance trigger. Read-length or accuracy flags alone do not trigger total-read root-cause hypotheses.")
        return result
    by_feature: dict[str, dict] = {}
    metric_counts = Counter(str(row.get("feature", row.get("feature_name", ""))) for row in metrics)
    for row in metrics:
        feature = str(row.get("feature", row.get("feature_name", "")))
        if metric_counts[feature] == 1:
            by_feature[feature] = row
    contributor_counts = Counter(str(row.get("feature_name", row.get("feature", ""))) for row in contributors)
    selected = _ordered(contributors)
    # The caller supplies the fixed global ten. Reject non-top-ten ranks rather
    # than silently extending the policy after seeing a target's abnormalities.
    for contributor in selected:
        feature = str(contributor.get("feature_name", contributor.get("feature", "")))
        record = _evidence_record(contributor, by_feature.get(feature))
        rank = _rank(contributor)
        if rank is None or not 1 <= rank <= 10:
            record.update(assessment_status="withheld_outside_fixed_top_ten", supports_hypothesis=False,
                reason="No valid fixed global rank from 1–10; no case-dependent ranking expansion.")
        if contributor_counts[feature] != 1 or metric_counts[feature] > 1:
            record.update(assessment_status="unresolved_duplicate_feature", supports_hypothesis=False,
                reason="Duplicate ranking or measured feature records; no arbitrary record selected.")
        result["contributor_assessments"].append(record)
    if PINNED in by_feature:
        result["supplemental_assessments"].append(_pinned_record(by_feature[PINNED]))
    concordant = [row for row in result["contributor_assessments"] if row["supports_hypothesis"] and row["source_family"] == "rawtrace"]
    chip = [row for row in result["supplemental_assessments"] if row["supports_hypothesis"]]
    raw_counter = [row["feature_name"] for row in result["contributor_assessments"] if row["source_family"] == "rawtrace" and row["assessment_status"] == "anomaly_direction_discordant"]
    if concordant:
        result["hypotheses"].append(dict(hypothesis_id="signal_trace_review",
            title="Trace-generation / signal-acquisition issue to investigate", source_family="rawtrace",
            support_status="single_source_descriptive_clue", evidence_role="model_concordant_fixed_top_ten_metrics",
            evidence=concordant, supporting_features=[row["feature_name"] for row in concordant],
            counter_evidence_features=raw_counter,
            strongest_global_rank=min(row["global_rank"] for row in concordant),
            interpretation="One or more compatible rendered-image outliers agree with the frozen model's lower-read-associated direction. The physical mechanism is unresolved.",
            next_checks=["First verify image layout, content, axis scaling and rendering compatibility with the selected peers.",
                "Inspect original inlet/middle/outlet key-background-subtracted and flow-residual plots and their axes; seek a repeatable native signal abnormality.",
                "Review signal acquisition, calibration, assay/sample input and contemporaneous QPM evidence with an instrument/assay expert; distinguish these possibilities before attributing a cause."],
            limitation="Rendered image-spread proxies do not measure physical signal amplitude, SNR, loading or transferred volume. Correlated RawTrace features count as one source, not replicated independent evidence.",
            expected_read_gain=None, estimated_reads_lost=None))
    if chip:
        result["hypotheses"].append(dict(hypothesis_id="offset_calibration_review",
            title="Offset calibration / pinned-pixel burden to investigate", source_family="chip_diagnostics",
            support_status="supplemental_descriptive_clue", evidence_role="supplemental_not_top_ranked",
            evidence=chip, supporting_features=[PINNED], counter_evidence_features=[], strongest_global_rank=None,
            interpretation="The validated original pinned-pixel percentage is high relative to comparable prior runs. This is supplementary chip-offset evidence, not a reinterpretation of ranked count proxies.",
            next_checks=["Verify the original chipDiagnostics/results.json offset.PercPinned and reconciled PixelCount denominator.",
                "Inspect pixel masks, offset calibration and usable-pixel spatial distribution; check maintenance/calibration records with an instrument expert.",
                "Compare native trace findings and QPM evidence before assigning a physical mechanism."],
            limitation="Does not establish chip damage, a loading defect, specific damaged wells or the number of reads lost. The high-percent review rule is not an ML local attribution.",
            expected_read_gain=None, estimated_reads_lost=None))
    result["evidence_families"] = [hypothesis["source_family"] for hypothesis in result["hypotheses"]]
    result["distinct_source_family_count"] = len(set(result["evidence_families"]))
    if result["distinct_source_family_count"] > 1:
        result.update(status="convergent_descriptive_clues", summary="RawTrace and chip-offset clues coexist across two source families. Review both; neither their independence nor a shared causal mechanism is established.")
    elif result["distinct_source_family_count"] == 1:
        result.update(status="single_source_descriptive_clue", summary="One source family provides a descriptive low-read investigation clue. Multiple metrics within that family are not independent confirmation; the cause remains unproven.")
    counts = Counter(row["assessment_status"] for row in result["contributor_assessments"])
    measured_statuses = {"within_empirical_range", "model_concordant_low_read_clue", "anomaly_direction_discordant", "anomaly_direction_unresolved"}
    result["top_contributor_coverage"] = dict(records=len(result["contributor_assessments"]),
        model_concordant_metrics=len(concordant), distinct_measured_source_families=len({row["source_family"] for row in result["contributor_assessments"] if row["source_family"] == "rawtrace" and row["assessment_status"] in measured_statuses}),
        status_counts=dict(sorted(counts.items())))
    result["decision_flow"] = [
        dict(step=1, title="Total-read trigger", result="; ".join(reasons)),
        dict(step=2, title="Fixed global top ten", result=f"{len(result['contributor_assessments'])} ranking records; no case-dependent ranking or importance sum"),
        dict(step=3, title="Source / measurement validation", result="Only guarded RawTrace adapters and original pinned percentages; context and ambiguous counts withheld"),
        dict(step=4, title="Compatible earlier peers", result="Each metric requires at least eight protocol-matched outcome-qualified physical runs; target and siblings excluded upstream"),
        dict(step=5, title="Empirical range", result="Strictly outside the exact 5th–95th percentile range; not a failure probability or significance test"),
        dict(step=6, title="Frozen model direction", result=f"{len(concordant)} top-ten metric(s) agree with a stable lower-read-associated direction; discordant/unstable metrics do not support a hypothesis"),
        dict(step=7, title="Group dependent metrics", result=f"{result['distinct_source_family_count']} distinct source family/families; no assumption of statistical independence"),
        dict(step=8, title="Review hypotheses", result=result["status"] + "; no confirmed cause or lost-read estimate"),
    ]
    return result


def _fmt(value: Any) -> str:
    number = _number(value)
    return "unresolved" if number is None else f"{number:.6g}"


def hypothesis_html(assessment: dict) -> str:
    """Safe, dependency-free report fragment; no model/API/network interaction."""
    esc = lambda value: html.escape(str(value), quote=True)
    page = "<div id='low-read-root-cause-hypotheses'><h3>Potential low-read explanations — evidence, not confirmed root causes</h3>"
    page += f"<p><strong>{esc(assessment.get('status', 'unresolved'))}</strong>: {esc(assessment.get('summary', 'Evidence not available; mechanism unresolved.'))}</p>"
    if not assessment.get("triggered") or assessment.get("status") == "disabled":
        return page + "</div>"
    page += "<p>One abnormal contributor can motivate an investigation. A candidate below requires a validated measured-peer comparison and, for ranked RawTrace features, agreement with the frozen model’s stable lower-read-associated direction. Global importance is not a local causal contribution.</p>"
    for candidate in assessment.get("hypotheses", []):
        page += f"<article class='guard'><h4>{esc(candidate.get('title'))}</h4><p>{esc(candidate.get('interpretation'))}</p>"
        page += f"<p><strong>Evidence role:</strong> {esc(candidate.get('evidence_role'))}; {esc(candidate.get('support_status'))}. <strong>Source family:</strong> {esc(candidate.get('source_family'))}.</p><ul>"
        for evidence in candidate.get("evidence", []):
            rank = evidence.get("global_rank")
            rank_text = "Supplemental, not a ranked substitute" if rank is None else f"Global rank {rank}"
            page += (f"<li><strong>{esc(evidence.get('label'))}</strong> ({esc(rank_text)}): target {esc(_fmt(evidence.get('target_value')))} {esc(evidence.get('unit'))}; "
                     f"peer median {esc(_fmt(evidence.get('peer_median')))}, 5th–95th {esc(_fmt(evidence.get('peer_q05')))}–{esc(_fmt(evidence.get('peer_q95')))}; "
                     f"n={esc(evidence.get('reference_physical_runs'))} physical runs, {esc(evidence.get('reference_mode'))}. {esc(evidence.get('reason'))}</li>")
        page += "</ul><p><strong>Verify next:</strong></p><ol>" + "".join(f"<li>{esc(check)}</li>" for check in candidate.get("next_checks", [])) + "</ol>"
        page += f"<p><em>{esc(candidate.get('limitation'))}</em></p></article>"
    if not assessment.get("hypotheses"):
        page += "<p><strong>No supported explanation from these contributors.</strong> Do not convert missing, normal-range, discordant or uninterpretable metrics into a root cause. Continue the separate QPM review and inspect sample/input, preparation, calibration and maintenance records.</p>"
    page += "<details open><summary>How the plugin reached this assessment</summary><ol>"
    for step in assessment.get("decision_flow", []):
        page += f"<li><strong>{esc(step.get('title'))}</strong>: {esc(step.get('result'))}</li>"
    page += "</ol></details><h4>Contributor-by-contributor case audit</h4><div style='overflow-x:auto'><table class='data-table'><thead><tr><th>Global rank / role</th><th>Metric / source</th><th>This run</th><th>Prior peer range / coverage</th><th>Model direction check</th><th>Case decision</th></tr></thead><tbody>"
    rows = [*assessment.get("contributor_assessments", []), *assessment.get("supplemental_assessments", [])]
    for row in rows:
        rank = row.get("global_rank")
        role = f"#{rank}" if rank is not None else row.get("role", "supplemental")
        page += (f"<tr><td>{esc(role)}</td><td style='max-width:270px;overflow-wrap:anywhere'><strong>{esc(row.get('label'))}</strong><br><code>{esc(row.get('feature_name'))}</code><br>{esc(row.get('source_file'))}: {esc(row.get('source_field'))}</td>"
                 f"<td>{esc(_fmt(row.get('target_value')))} {esc(row.get('unit'))}</td>"
                 f"<td>Median {esc(_fmt(row.get('peer_median')))}; 5th–95th {esc(_fmt(row.get('peer_q05')))}–{esc(_fmt(row.get('peer_q95')))}<br>n={esc(row.get('reference_physical_runs'))}; {esc(row.get('reference_mode'))}</td>"
                 f"<td>{esc(row.get('direction_status'))}<br>{esc(row.get('direction_evidence'))}</td>"
                 f"<td><strong>{esc(row.get('assessment_status'))}</strong><br>{esc(row.get('reason'))}</td></tr>")
    page += "</tbody></table></div><p><strong>Limits:</strong></p><ul>" + "".join(f"<li>{esc(limit)}</li>" for limit in assessment.get("limitations", LIMITATIONS)) + "</ul></div>"
    return page
