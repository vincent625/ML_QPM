#!/usr/bin/env python3
"""All-event QPM nominal-volume regression with run/instrument/time validation.

Every event in a trainable full-definition/pipette/operation/unit task is used.
Repeated events are retained but run/volume repetition is training-weighted.
This estimates programmed-volume signatures, never independently measured
delivery or a quantitative physical aspiration/dispense deficit.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import multiprocessing
from pathlib import Path
import time
import warnings

import joblib
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import scipy
from scipy.stats import spearmanr
import sklearn
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.linear_model import ElasticNet, Ridge
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler

from prepare_all_qpm_volumes import PROFILE_COLUMNS, CONTEXT_KEYS, SEED, write_json
from retrain_qpm_volume_models import sha256

VERSION = "all-operations-nominal-volume-1.0.0"
FORMAT_VERSION = "all-operations-nominal-v1"
MODELS = ["Ridge", "Elastic Net", "Extra Trees"]
BASELINES = ["Median baseline", "Context-only median"]
CONTEXT_CONTROL = ["container_geometry_fingerprint", "deck_geometry_fingerprint", "workflow_stage"]


def training_weights(frame):
    count = frame.groupby(["physical_run_id", "programmed_volume_ul"]).operation_id.transform("size").to_numpy(float)
    levels = frame.groupby("physical_run_id").programmed_volume_ul.transform("nunique").to_numpy(float)
    weights = 1 / (count * levels)
    return weights / weights.mean()


def evaluation_weights(frame):
    return 1 / frame.groupby("physical_run_id").operation_id.transform("size").to_numpy(float)


def weighted_median(values, weights):
    order = np.argsort(values, kind="stable")
    a = np.asarray(values)[order]
    w = np.asarray(weights)[order]
    return float(a[np.searchsorted(np.cumsum(w), w.sum() * .5, side="left")])


def fit_model(name, x, y, weight):
    y_mean = float(np.average(y, weights=weight))
    y_scale = max(float(np.sqrt(np.average((y-y_mean)**2, weights=weight))), 1e-8)
    target = (y-y_mean)/y_scale
    if name == "Extra Trees":
        scaler = None
        estimator = ExtraTreesRegressor(n_estimators=32, max_depth=8, min_samples_leaf=8,
            max_features=.7, n_jobs=1, random_state=SEED)
        estimator.fit(x, target, sample_weight=weight)
    else:
        scaler = StandardScaler().fit(x, sample_weight=weight)
        transformed = scaler.transform(x)
        estimator = Ridge(alpha=10.) if name == "Ridge" else ElasticNet(
            alpha=.03, l1_ratio=.5, max_iter=3000, tol=.001, random_state=SEED)
        estimator.fit(transformed, target, sample_weight=weight)
    return dict(model_name=name, scaler=scaler, estimator=estimator, y_mean=y_mean, y_scale=y_scale)


def predict_model(payload, x):
    if payload["scaler"] is not None:
        x = payload["scaler"].transform(x)
    return np.asarray(payload["estimator"].predict(x), dtype=float)*payload["y_scale"]+payload["y_mean"]


def context_baseline(train, test):
    weight = training_weights(train)
    global_value = weighted_median(train.programmed_volume_ul.to_numpy(float), weight)
    local = train[CONTEXT_CONTROL + ["programmed_volume_ul"]].copy()
    local["weight"] = weight
    mapping = {key: weighted_median(g.programmed_volume_ul.to_numpy(float), g.weight.to_numpy(float))
        for key, g in local.groupby(CONTEXT_CONTROL, sort=False, dropna=False)}
    prediction = np.asarray([mapping.get(tuple(row), global_value)
        for row in test[CONTEXT_CONTROL].itertuples(index=False, name=None)])
    return global_value, prediction


def group_splits(frame, folds=5):
    n = frame.physical_run_id.nunique()
    cv = GroupKFold(n_splits=min(folds, n), shuffle=True, random_state=SEED)
    return [(f"group_{i+1}", tr, te) for i, (tr, te) in enumerate(cv.split(
        np.zeros((len(frame), 1)), groups=frame.physical_run_id))]


def outer_splits(frame):
    result = [("grouped_run", label, tr, te) for label, tr, te in group_splits(frame)]
    instrument = frame.instrument_id.to_numpy()
    if frame.instrument_id.nunique() >= 2:
        for host in sorted(frame.instrument_id.unique()):
            tr, te = np.flatnonzero(instrument != host), np.flatnonzero(instrument == host)
            if frame.iloc[tr].physical_run_id.nunique() >= 8:
                result.append(("unseen_instrument", str(host), tr, te))
    times = frame.groupby("physical_run_id").run_start_time.min().dropna().sort_values(kind="stable")
    if len(times) >= 20:
        cutoff = times.iloc[max(0, int(len(times)*.8)-1)]
        older = set(times[times <= cutoff].index)
        newer = set(times[times > cutoff].index)
        if len(older) >= 12 and len(newer) >= 4:
            result.append(("chronological", "newest_20pct", np.flatnonzero(frame.physical_run_id.isin(older)), np.flatnonzero(frame.physical_run_id.isin(newer))))
    return result


def nearest_level(prediction, levels):
    levels = np.sort(np.unique(levels))
    right = np.searchsorted(levels, prediction).clip(0, len(levels)-1)
    left = (right-1).clip(0, len(levels)-1)
    return np.where(abs(prediction-levels[left]) <= abs(prediction-levels[right]), levels[left], levels[right])


def metrics(frame, prediction, assigned=None):
    truth = frame.programmed_volume_ul.to_numpy(float)
    prediction = np.asarray(prediction)
    weight = evaluation_weights(frame)
    error = abs(prediction-truth)
    avg = lambda value: float(np.average(value, weights=weight))
    center = avg(truth)
    denominator = np.sum(weight*(truth-center)**2)
    result = dict(mae_ul=avg(error), rmse_ul=float(np.sqrt(avg(error**2))),
        mape_pct=100*avg(error/truth), within_5pct=avg(error <= .05*truth), within_10pct=avg(error <= .1*truth),
        r2=1-float(np.sum(weight*(prediction-truth)**2)/denominator) if denominator > 0 else np.nan,
        spearman=float(spearmanr(truth, prediction).statistic) if np.unique(truth).size>1 and np.unique(prediction).size>1 else np.nan,
        test_waveforms=len(frame), test_physical_runs=frame.physical_run_id.nunique(), test_instruments=frame.instrument_id.nunique())
    if assigned is not None:
        correct = np.isclose(truth, assigned, atol=1e-6, rtol=0)
        result["nominal_level_accuracy"] = avg(correct)
        recalls = [float(np.average(correct[truth == level], weights=weight[truth == level])) for level in np.unique(truth)]
        result["nominal_level_balanced_accuracy"] = float(np.mean(recalls))
    return result


def choose_model(frame, x, y):
    trials = []
    for name in MODELS:
        scores = []
        for label, train, test in group_splits(frame, 2):
            fitted = fit_model(name, x[train], y[train], training_weights(frame.iloc[train]))
            score = metrics(frame.iloc[test], predict_model(fitted, x[test]))["mae_ul"]
            scores.append(score)
            trials.append(dict(model=name, inner_fold=label, mae_ul=score))
        trials.append(dict(model=name, inner_fold="mean", mae_ul=float(np.mean(scores))))
    means = [row for row in trials if row["inner_fold"] == "mean"]
    chosen = min(means, key=lambda row:(row["mae_ul"], MODELS.index(row["model"]))) ["model"]
    return chosen, trials


def uncertainty(frame, model_prediction, baseline_prediction, reps=250):
    data = pd.DataFrame(dict(group=frame.physical_run_id.to_numpy(),
        model_error=abs(model_prediction-frame.programmed_volume_ul.to_numpy()),
        baseline_error=abs(baseline_prediction-frame.programmed_volume_ul.to_numpy())))
    grouped = data.groupby("group")[["model_error", "baseline_error"]].mean().to_numpy()
    rng = np.random.default_rng(SEED)
    indices = rng.integers(0, len(grouped), size=(reps, len(grouped)))
    samples = grouped[indices].mean(axis=1)
    improvement = 100*(samples[:,1]-samples[:,0])/np.maximum(samples[:,1],1e-12)
    return dict(mae_ci_low=float(np.quantile(samples[:,0],.025)), mae_ci_high=float(np.quantile(samples[:,0],.975)),
        improvement_ci_low_pct=float(np.quantile(improvement,.025)), improvement_ci_high_pct=float(np.quantile(improvement,.975)),
        uncertainty_method="physical_run_bootstrap_fixed_heldout_predictions_no_refit")


def execute_task(study_path, task_id, code_hash):
    root = Path(study_path)
    output = root/"tasks"/task_id
    output.mkdir(parents=True, exist_ok=True)
    prep = json.loads((root/"preparation_audit.json").read_text())
    signature = dict(code_sha256=code_hash, dataset_sha256=prep["artifact_sha256"]["all_audited_operations.parquet"], task_id=task_id)
    complete = output/"task_complete.json"
    if complete.exists() and json.loads(complete.read_text()).get("input_signature") == signature:
        return json.loads(complete.read_text())
    frame = pq.read_table(root/"all_audited_operations.parquet", filters=[("task_id", "=", task_id)], use_threads=False).to_pandas()
    frame["run_start_time"] = pd.to_datetime(frame.run_start_time, utc=True)
    x = frame[PROFILE_COLUMNS].to_numpy(np.float32)
    y = frame.programmed_volume_ul.to_numpy(float)
    trials, folds, paths, caught_warnings = [], [], [], []
    began = time.monotonic()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        for scheme, fold, train, test in outer_splits(frame):
            train_frame, test_frame = frame.iloc[train], frame.iloc[test]
            if set(train_frame.physical_run_id) & set(test_frame.physical_run_id):
                raise AssertionError("Physical run crossed validation boundary")
            if scheme == "unseen_instrument" and set(train_frame.instrument_id) & set(test_frame.instrument_id):
                raise AssertionError("Instrument crossed held-out-instrument boundary")
            if scheme == "chronological":
                starts = frame.groupby("physical_run_id").run_start_time.min()
                if starts.loc[train_frame.physical_run_id.unique()].max() >= starts.loc[test_frame.physical_run_id.unique()].min():
                    raise AssertionError("Chronological acquisition groups are not ordered")
            fold_path = output/f"predictions_{scheme}_{fold}.parquet"
            fold_log = output/f"fold_{scheme}_{fold}.json"
            fold_signature = {**signature, "scheme":scheme, "fold":fold}
            if fold_path.exists() and fold_log.exists():
                previous = json.loads(fold_log.read_text())
                if previous.get("input_signature") == fold_signature and previous.get("predictions_sha256") == sha256(fold_path):
                    paths.append(fold_path)
                    folds.extend(previous["metrics"])
                    trials.extend(previous["selection"])
                    continue
            chosen, selection = choose_model(train_frame.reset_index(drop=True), x[train], y[train])
            selection = [dict(task_id=task_id, scheme=scheme, fold=fold, selected=(row["model"] == chosen), **row) for row in selection]
            trials.extend(selection)
            median, context_prediction = context_baseline(train_frame, test_frame)
            predictions = {"Median baseline":np.full(len(test),median), "Context-only median":context_prediction}
            for name in MODELS:
                fitted = fit_model(name, x[train], y[train], training_weights(train_frame))
                predictions[name] = predict_model(fitted, x[test])
            predictions["Nested-selected procedure"] = predictions[chosen]
            chunks, fold_metrics = [], []
            for name, prediction in predictions.items():
                assigned = nearest_level(prediction, y[train])
                result = dict(task_id=task_id, scheme=scheme, fold=fold, model=name,
                    selected_model=chosen if name == "Nested-selected procedure" else name,
                    train_waveforms=len(train), train_physical_runs=train_frame.physical_run_id.nunique(),
                    novel_nominal_level_test_waveforms=int((~test_frame.programmed_volume_ul.isin(np.unique(y[train]))).sum()),
                    **metrics(test_frame,prediction,assigned))
                folds.append(result); fold_metrics.append(result)
                part = test_frame[["task_id", "operation_id", "physical_run_id", "instrument_id", "programmed_volume_ul"]].copy()
                part["predicted_volume_ul"] = prediction
                part["nearest_training_level_ul"] = assigned
                part["scheme"], part["fold"], part["model"] = scheme, fold, name
                chunks.append(part)
            joined = pd.concat(chunks,ignore_index=True)
            joined.to_parquet(fold_path,index=False,compression="zstd")
            write_json(fold_log,dict(input_signature=fold_signature,predictions_sha256=sha256(fold_path),
                train_physical_runs=sorted(train_frame.physical_run_id.unique()),test_physical_runs=sorted(test_frame.physical_run_id.unique()),
                train_instruments=sorted(train_frame.instrument_id.unique()),test_instruments=sorted(test_frame.instrument_id.unique()),
                train_acquisition_max=str(train_frame.groupby("physical_run_id").run_start_time.min().max()),
                test_acquisition_min=str(test_frame.groupby("physical_run_id").run_start_time.min().min()),
                metrics=fold_metrics,selection=selection))
            paths.append(fold_path)
        caught_warnings = sorted(set(f"{warning.category.__name__}: {warning.message}" for warning in caught))
    predictions = pd.concat([pd.read_parquet(path) for path in paths], ignore_index=True)
    performance = []
    per_instrument = []
    for scheme, all_scheme in predictions.groupby("scheme", sort=False):
        baseline = all_scheme[all_scheme.model.eq("Median baseline")].set_index("operation_id")
        for name, part in all_scheme.groupby("model",sort=False):
            aligned = baseline.loc[part.operation_id]
            error = abs(part.predicted_volume_ul-part.programmed_volume_ul)
            row = dict(task_id=task_id,scheme=scheme,kind="regression",model=name,
                folds=part.fold.nunique(), **metrics(part,part.predicted_volume_ul.to_numpy(),part.nearest_training_level_ul.to_numpy()),
                **uncertainty(part,part.predicted_volume_ul.to_numpy(),aligned.predicted_volume_ul.to_numpy()))
            baseline_mae = metrics(part,aligned.predicted_volume_ul.to_numpy())["mae_ul"]
            row["baseline_mae_ul"] = baseline_mae
            row["mae_improvement_over_baseline_pct"] = 100*(baseline_mae-row["mae_ul"])/baseline_mae if baseline_mae else np.nan
            row["heldout_absolute_error_q95_ul"] = float(error.quantile(.95))
            performance.append(row)
            for host, subset in part.groupby("instrument_id",sort=False):
                per_instrument.append(dict(task_id=task_id,scheme=scheme,model=name,instrument_id=host,
                    **metrics(subset,subset.predicted_volume_ul.to_numpy(),subset.nearest_training_level_ul.to_numpy())))
    performance = pd.DataFrame(performance)
    performance.to_csv(output/"model_performance.csv",index=False)
    pd.DataFrame(folds).to_csv(output/"fold_performance.csv",index=False)
    pd.DataFrame(trials).to_csv(output/"nested_model_selections.csv",index=False)
    pd.DataFrame(per_instrument).to_csv(output/"per_instrument_performance.csv",index=False)
    selected, final_selection = choose_model(frame,x,y)
    final = fit_model(selected,x,y,training_weights(frame))
    final.update(version=VERSION,format_version=FORMAT_VERSION,task_id=task_id,kind="regression",
        features=PROFILE_COLUMNS,label_basis="programmed_nominal_volume_not_measured_delivery",
        actual_volume_prediction_validated=False,
        training_waveform_q01=np.quantile(x,.01,axis=0),training_waveform_q99=np.quantile(x,.99,axis=0))
    model_path = output/"nominal_volume_model.joblib"
    joblib.dump(final,model_path,compress=3)
    required = performance[performance.model.eq("Nested-selected procedure")]
    supported_schemes = set(required.loc[required.improvement_ci_low_pct.gt(0),"scheme"])
    deployable = {"grouped_run","unseen_instrument","chronological"}.issubset(supported_schemes)
    summary = dict(task_id=task_id, input_signature=signature, model_name=selected,
        path=str(model_path.relative_to(root)), sha256=sha256(model_path), kind="regression",
        train_waveforms=len(frame),physical_runs=frame.physical_run_id.nunique(),instruments=frame.instrument_id.nunique(),
        pipette=frame.pipette.iloc[0],operation=frame.operation.iloc[0],pressure_unit=frame.pressure_unit.iloc[0],
        liquid_class_fingerprint=frame.liquid_class_fingerprint.iloc[0],liquid_class_indices=sorted(int(v) for v in frame.liquid_class_index.unique()),
        volumes_ul=sorted(float(v) for v in frame.programmed_volume_ul.unique()),
        deployment_eligible=deployable,
        deployment_reason="all_three_validation_schemes_have_positive_paired_gain_lower_bound" if deployable else "insufficient_validation_or_uncertain_baseline_gain",
        elapsed_seconds=time.monotonic()-began,warnings=caught_warnings,
        final_model_selection=final_selection,
        artifact_sha256={path.name:sha256(path) for path in [output/"model_performance.csv",output/"fold_performance.csv",output/"nested_model_selections.csv",output/"per_instrument_performance.csv",model_path]})
    write_json(complete,summary)
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study",type=Path,required=True)
    parser.add_argument("--workers",type=int,default=8)
    args=parser.parse_args()
    root=args.study.resolve()
    prep=json.loads((root/"preparation_audit.json").read_text())
    if sha256(root/"all_audited_operations.parquet") != prep["artifact_sha256"]["all_audited_operations.parquet"]:
        raise ValueError("Prepared all-event data changed")
    coverage=pd.read_csv(root/"all_task_coverage.csv")
    tasks=coverage[coverage.trainable.eq(True)].sort_values("waveforms",ascending=False).task_id.tolist()
    code_hash=sha256(Path(__file__))
    (root/"train_all_qpm_volumes.executed.py").write_bytes(Path(__file__).read_bytes())
    began=time.monotonic()
    write_json(root/"training_status.json",dict(status="running",version=VERSION,tasks=len(tasks),completed_tasks=0,
        code_sha256=code_hash,started_utc=datetime.now(timezone.utc).isoformat()))
    results=[]
    with ProcessPoolExecutor(max_workers=args.workers,mp_context=multiprocessing.get_context("spawn")) as executor:
        futures={executor.submit(execute_task,str(root),task,code_hash):task for task in tasks}
        for future in as_completed(futures):
            result=future.result();results.append(result)
            print(f"Completed {len(results)}/{len(tasks)}: {result['task_id']} {result['pipette']} {result['operation']}; {result['train_waveforms']:,} waveforms; {result['elapsed_seconds']:.1f}s",flush=True)
            write_json(root/"training_status.json",dict(status="running",version=VERSION,tasks=len(tasks),completed_tasks=len(results),
                elapsed_seconds=time.monotonic()-began,code_sha256=code_hash))
    if sha256(Path(__file__)) != code_hash:
        raise ValueError("Training source changed while fitting")
    results=sorted(results,key=lambda row:row["task_id"])
    for filename in ["model_performance.csv","fold_performance.csv","nested_model_selections.csv","per_instrument_performance.csv"]:
        pd.concat([pd.read_csv(root/"tasks"/row["task_id"]/filename) for row in results],ignore_index=True).to_csv(root/filename,index=False)
    frame=pq.read_table(root/"all_audited_operations.parquet",columns=["task_id","physical_run_id","instrument_id","liquid_class_fingerprint","pipette","operation","pressure_unit","programmed_volume_ul",*CONTEXT_KEYS],use_threads=False).to_pandas()
    selected=set(tasks)
    frame=frame[frame.task_id.isin(selected)].copy()
    membership=frame[["task_id","physical_run_id","instrument_id"]].drop_duplicates()
    membership.to_parquet(root/"training_run_membership.parquet",index=False)
    contexts=frame.groupby(["task_id","pressure_unit",*CONTEXT_KEYS,"programmed_volume_ul"],sort=False).agg(
        physical_runs=("physical_run_id","nunique"),instruments=("instrument_id","nunique")).reset_index()
    contexts.to_parquet(root/"inference_context_scope.parquet",index=False)
    pd.DataFrame([{k:v for k,v in row.items() if k not in {"final_model_selection","warnings","artifact_sha256","input_signature","volumes_ul"}} for row in results]).to_csv(root/"trained_tasks.csv",index=False)
    log=dict(version=VERSION,format_version=FORMAT_VERSION,status="complete",completed_utc=datetime.now(timezone.utc).isoformat(),
        execution_seconds=time.monotonic()-began,random_seed=SEED,code_sha256=code_hash,
        preparation_audit_sha256=sha256(root/"preparation_audit.json"),input_audit=prep,
        models=results,actual_delivered_volume_labels=0,actual_volume_prediction_validated=False,
        training_policy="all unique audited operations in every task with >=16 physical runs and >=2 nominal levels; no waveform, run, volume-level or liquid-definition caps; no outcome filter",
        training_weighting="each physical run has equal total weight; each nominal level within a run has equal total weight",
        prediction_features="32 baseline-centred pressure-profile samples only; no operation index, volume command, instrument ID or geometry is a waveform-model feature",
        context_control="training-only weighted median by container/deck geometry and workflow stage; no command volume or volume-coded step label used as an input",
        validation="five grouped physical-run folds, all feasible held-out instruments, and strict acquisition-time newest20%; two-fold physical-run inner model-family selection",
        nominal_level_accuracy_definition="nearest nominal level observed in that fold's training data, applied to regression output; not a separately trained classifier",
        deployment_gate="all three schemes' physical-run-bootstrap paired improvement lower bound >0; exact context+nominal level must have >=8 training physical runs; target run must be absent from final-model training",
        model_settings={"Ridge":{"alpha":10.},"Elastic Net":{"alpha":.03,"l1_ratio":.5},"Extra Trees":{"n_estimators":32,"max_depth":8,"min_samples_leaf":8,"max_features":.7}},
        packages=dict(numpy=np.__version__,pandas=pd.__version__,sklearn=sklearn.__version__,scipy=scipy.__version__),
        warnings=["Nominal-command labels do not validate actual transferred volume or under/over-delivery.","32-point stored profiles are used; this is not full-rate debug re-extraction.","Event rows are not independent samples; all validation and uncertainty respect physical runs.","Raw sensor counts are not calibrated between instruments.","Context and workflow confounding may remain even when waveform prediction beats a global median.","Confidence intervals resample fixed held-out predictions, not the complete model-selection procedure."])
    write_json(root/"analysis_run_log.json",log)
    write_json(root/"training_status.json",dict(status="complete",version=VERSION,tasks=len(tasks),completed_tasks=len(results),
        elapsed_seconds=time.monotonic()-began,code_sha256=code_hash,deployment_eligible_tasks=sum(row["deployment_eligible"] for row in results)))
    print(json.dumps(json.loads((root/"training_status.json").read_text()),indent=2),flush=True)


if __name__ == "__main__":
    main()
