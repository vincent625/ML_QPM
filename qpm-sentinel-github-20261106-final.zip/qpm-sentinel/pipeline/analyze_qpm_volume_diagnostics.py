#!/usr/bin/env python3
"""Matched-volume QPM waveform diagnostic proof of concept."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from matplotlib.gridspec import GridSpec
from scipy.stats import spearmanr
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


PROJECT = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT / "qpm_diagnostics"
OUTPUT_DIR.mkdir(exist_ok=True)

RANDOM_SEED = 20260930
LIQUID_CLASS_INDEX = 55.0
LIQUID_CLASS_NAME = "lc_general_simple_surface_part_50uLps"
LIQUID_CLASS_CONFIG_FEATURE = (
    "liquid_class_common_tbl.lc_general_simple_surface_part_50u_lps_lq_num"
)
VOLUMES = [25, 50, 72, 90, 300]
COLORS = {
    25: "#264653",
    50: "#2A9D8F",
    72: "#E9C46A",
    90: "#F4A261",
    300: "#E76F51",
}


def load_cohort() -> pd.DataFrame:
    columns = [
        "observation_id",
        "physical_run_id",
        "instrument_id",
        "archive_id",
        "chip_lane",
        "run_start_time",
        "operation_id",
        "operation_index",
        "operation",
        "pipette",
        "programmed_volume_ul",
        "workflow_stage",
        "process_step",
        "loc",
        "pressure_unit",
        "qpm_profile",
        "wave_min",
        "wave_max",
        "wave_area_absolute",
        "wave_difference_noise",
        "wave_recovery_error",
    ]
    frame = pq.read_table(
        PROJECT / "qpm_operation_waveforms.parquet",
        columns=columns,
        filters=[
            ("liquid_class_index", "=", LIQUID_CLASS_INDEX),
            ("operation", "=", "aspirate"),
            ("pipette", "=", "PIP2"),
            ("qpm_available", "=", True),
        ],
    ).to_pandas()
    frame = frame[
        frame["workflow_stage"].eq("templating_started")
        & frame["process_step"].eq("dumping_57")
        & frame["loc"].eq("templating_solution_a11")
        & frame["programmed_volume_ul"].isin(VOLUMES)
    ].copy()

    configuration = pd.read_parquet(
        PROJECT / "csa_ml_dataset.parquet",
        columns=["observation_id", LIQUID_CLASS_CONFIG_FEATURE],
    )
    frame = frame.merge(configuration, on="observation_id", how="left")
    frame = frame[frame[LIQUID_CLASS_CONFIG_FEATURE].eq(LIQUID_CLASS_INDEX)].copy()
    frame["programmed_volume_ul"] = frame["programmed_volume_ul"].astype(int)
    frame = frame.sort_values(
        ["run_start_time", "observation_id", "operation_index"], kind="stable"
    ).reset_index(drop=True)
    if frame.empty:
        raise RuntimeError("No matched QPM waveforms passed the cohort definition")
    if set(frame["pressure_unit"].dropna().unique()) != {"raw_sensor_count_unresolved"}:
        raise RuntimeError("Unexpected QPM pressure units in selected cohort")
    return frame


def baseline_correct(frame: pd.DataFrame) -> np.ndarray:
    profiles = np.vstack(frame["qpm_profile"].map(lambda value: np.asarray(value, dtype=float)))
    baseline = np.median(profiles[:, :3], axis=1)
    return profiles - baseline[:, None]


def grouped_volume_predictions(
    x: np.ndarray, y: np.ndarray, groups: np.ndarray
) -> tuple[np.ndarray, list[tuple[np.ndarray, np.ndarray]]]:
    splitter = StratifiedGroupKFold(
        n_splits=5, shuffle=True, random_state=RANDOM_SEED
    )
    splits = list(splitter.split(x, y, groups))
    predictions = np.empty_like(y)
    for train, test in splits:
        model = make_pipeline(
            StandardScaler(),
            LogisticRegression(
                C=0.2,
                max_iter=3000,
                class_weight="balanced",
                random_state=RANDOM_SEED,
            ),
        )
        model.fit(x[train], y[train])
        predictions[test] = model.predict(x[test])
    return predictions, splits


def leave_one_instrument_out_predictions(
    x: np.ndarray, y: np.ndarray, instruments: np.ndarray
) -> tuple[np.ndarray, dict[str, dict[str, float]]]:
    predictions = np.empty_like(y)
    rows: dict[str, dict[str, float]] = {}
    for instrument in sorted(np.unique(instruments)):
        test = np.flatnonzero(instruments == instrument)
        train = np.flatnonzero(instruments != instrument)
        model = make_pipeline(
            StandardScaler(),
            LogisticRegression(
                C=0.2,
                max_iter=3000,
                class_weight="balanced",
                random_state=RANDOM_SEED,
            ),
        )
        model.fit(x[train], y[train])
        predictions[test] = model.predict(x[test])
        rows[str(instrument)] = {
            "n": int(len(test)),
            "accuracy": float(accuracy_score(y[test], predictions[test])),
            "balanced_accuracy": float(
                balanced_accuracy_score(y[test], predictions[test])
            ),
        }
    return predictions, rows


def cross_validated_anomaly_scores(
    x: np.ndarray,
    y: np.ndarray,
    instruments: np.ndarray,
    splits: list[tuple[np.ndarray, np.ndarray]],
) -> np.ndarray:
    scores = np.full(len(y), np.nan)
    for train, test in splits:
        for instrument in np.unique(instruments):
            for volume in VOLUMES:
                reference = train[
                    (instruments[train] == instrument) & (y[train] == volume)
                ]
                evaluate = test[
                    (instruments[test] == instrument) & (y[test] == volume)
                ]
                if len(reference) < 10 or not len(evaluate):
                    continue
                median = np.median(x[reference], axis=0)
                mad = 1.4826 * np.median(np.abs(x[reference] - median), axis=0)
                scale = np.maximum(mad, 5.0)
                scores[evaluate] = np.sqrt(
                    np.mean(((x[evaluate] - median) / scale) ** 2, axis=1)
                )
    if np.isnan(scores).any():
        raise RuntimeError("Some QPM waveforms did not receive an anomaly score")
    return scores


def reference_profile_table(frame: pd.DataFrame, x: np.ndarray) -> pd.DataFrame:
    rows: list[dict[str, float | int]] = []
    normalized_time = np.linspace(0, 100, x.shape[1])
    for volume in VOLUMES:
        values = x[frame["programmed_volume_ul"].to_numpy() == volume]
        for point, time in enumerate(normalized_time):
            rows.append(
                {
                    "programmed_volume_ul": volume,
                    "normalized_time_pct": float(time),
                    "n_waveforms": int(len(values)),
                    "median_sensor_change": float(np.median(values[:, point])),
                    "q25_sensor_change": float(np.quantile(values[:, point], 0.25)),
                    "q75_sensor_change": float(np.quantile(values[:, point], 0.75)),
                }
            )
    return pd.DataFrame(rows)


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        0.01,
        0.99,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=10,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.82, "pad": 1.2},
        zorder=20,
    )


def style_axis(ax: plt.Axes) -> None:
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(color="#D8E2DC", linewidth=0.55, alpha=0.65, zorder=0)


def make_figure(
    frame: pd.DataFrame,
    x: np.ndarray,
    grouped_predictions: np.ndarray,
    scores: np.ndarray,
    outcomes: pd.DataFrame,
    summary: dict[str, object],
) -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 7,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig = plt.figure(figsize=(183 / 25.4, 150 / 25.4), constrained_layout=True)
    gs = GridSpec(2, 2, figure=fig)
    axes = [fig.add_subplot(gs[row, col]) for row in range(2) for col in range(2)]
    time = np.linspace(0, 100, x.shape[1])

    ax = axes[0]
    volumes = frame["programmed_volume_ul"].to_numpy()
    for volume in VOLUMES:
        values = x[volumes == volume]
        median = np.median(values, axis=0)
        lower = np.quantile(values, 0.25, axis=0)
        upper = np.quantile(values, 0.75, axis=0)
        ax.fill_between(time, lower, upper, color=COLORS[volume], alpha=0.16, linewidth=0)
        ax.plot(
            time,
            median,
            color=COLORS[volume],
            linewidth=1.6,
            label=f"{volume} µL (n={len(values)})",
        )
    ax.axhline(0, color="#606C38", linewidth=0.7, linestyle="--")
    ax.set_xlabel("Normalized waveform time (%)")
    ax.set_ylabel("Change from initial baseline\n(raw sensor counts)")
    ax.set_title("Volume-specific aspiration waveforms", fontweight="bold")
    ax.legend(frameon=False, ncol=2, loc="lower left")
    style_axis(ax)
    add_panel_label(ax, "a")

    ax = axes[1]
    matrix = confusion_matrix(
        volumes, grouped_predictions, labels=VOLUMES, normalize="true"
    )
    image = ax.imshow(matrix, vmin=0, vmax=1, cmap="YlGnBu", aspect="auto")
    for row in range(matrix.shape[0]):
        for col in range(matrix.shape[1]):
            ax.text(
                col,
                row,
                f"{matrix[row, col] * 100:.0f}%",
                ha="center",
                va="center",
                color="white" if matrix[row, col] > 0.55 else "#24352A",
                fontsize=7,
                fontweight="bold" if row == col else "normal",
            )
    ax.set_xticks(range(len(VOLUMES)), VOLUMES)
    ax.set_yticks(range(len(VOLUMES)), VOLUMES)
    ax.set_xlabel("Predicted volume (µL)")
    ax.set_ylabel("Programmed volume (µL)")
    ax.set_title(
        "Waveform recovers commanded volume\n"
        f"held-out balanced accuracy {summary['grouped_balanced_accuracy'] * 100:.1f}%",
        fontweight="bold",
    )
    fig.colorbar(image, ax=ax, shrink=0.72, label="Row fraction")
    add_panel_label(ax, "b")

    ax = axes[2]
    outlier_index = int(np.argmax(scores))
    outlier = frame.iloc[outlier_index]
    same_reference = (
        frame["instrument_id"].eq(outlier["instrument_id"])
        & frame["programmed_volume_ul"].eq(outlier["programmed_volume_ul"])
        & ~frame["physical_run_id"].eq(outlier["physical_run_id"])
    ).to_numpy()
    reference = x[same_reference]
    median = np.median(reference, axis=0)
    lower = np.quantile(reference, 0.25, axis=0)
    upper = np.quantile(reference, 0.75, axis=0)
    ax.fill_between(time, lower, upper, color="#90BE6D", alpha=0.35, label="Instrument/volume IQR")
    ax.plot(time, median, color="#386641", linewidth=1.8, label="Reference median")
    ax.plot(time, x[outlier_index], color="#D62828", linewidth=1.6, label="Flagged waveform")
    ax.axhline(0, color="#606C38", linewidth=0.7, linestyle="--")
    ax.set_xlabel("Normalized waveform time (%)")
    ax.set_ylabel("Change from initial baseline\n(raw sensor counts)")
    ax.set_title(
        f"Example diagnostic flag: {int(outlier['programmed_volume_ul'])} µL\n"
        f"robust template distance {scores[outlier_index]:.1f}",
        fontweight="bold",
    )
    ax.legend(frameon=False, loc="lower left")
    style_axis(ax)
    add_panel_label(ax, "c")

    ax = axes[3]
    run_scores = (
        frame.assign(qpm_anomaly_score=scores)
        .groupby(["observation_id", "instrument_id"], as_index=False)
        .agg(max_qpm_anomaly_score=("qpm_anomaly_score", "max"))
        .merge(outcomes[["observation_id", "total_reads"]], on="observation_id", how="left")
        .dropna(subset=["total_reads"])
    )
    instrument_palette = ["#264653", "#2A9D8F", "#E9C46A", "#6D597A"]
    for color, (_, group) in zip(
        instrument_palette, run_scores.groupby("instrument_id", sort=True)
    ):
        ax.scatter(
            group["max_qpm_anomaly_score"],
            group["total_reads"] / 1e6,
            s=17,
            alpha=0.58,
            color=color,
            edgecolor="none",
            rasterized=True,
        )
    selected = run_scores[
        run_scores["observation_id"].eq(outlier["observation_id"])
    ]
    if not selected.empty:
        ax.scatter(
            selected["max_qpm_anomaly_score"],
            selected["total_reads"] / 1e6,
            marker="*",
            s=85,
            color="#D62828",
            edgecolor="black",
            linewidth=0.6,
            zorder=5,
            label="Panel c observation",
        )
        ax.legend(frameon=False, loc="upper right")
    outcome_rho = float(
        spearmanr(run_scores["max_qpm_anomaly_score"], run_scores["total_reads"]).statistic
    )
    ax.set_xscale("log")
    ax.set_xlabel("Maximum matched-operation anomaly score (log scale)")
    ax.set_ylabel("Total reads (millions)")
    ax.set_title(
        f"Not a stand-alone yield predictor\nSpearman ρ={outcome_rho:.2f}, n={len(run_scores)}",
        fontweight="bold",
    )
    style_axis(ax)
    add_panel_label(ax, "d")

    fig.suptitle(
        "QPM waveform diagnostics for one matched liquid-transfer operation",
        fontsize=12,
        fontweight="bold",
    )
    fig.text(
        0.5,
        -0.015,
        f"{LIQUID_CLASS_NAME}; PIP2 aspiration; templating/dumping_57; source templating_solution_a11. "
        "Pressure is in unresolved raw sensor counts, not calibrated pressure units.",
        ha="center",
        fontsize=6.5,
        color="#4F5D4F",
    )
    fig.savefig(
        OUTPUT_DIR / "qpm_lc55_volume_diagnostic.png",
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )


def main() -> None:
    frame = load_cohort()
    x = baseline_correct(frame)
    y = frame["programmed_volume_ul"].to_numpy(dtype=int)
    groups = frame["physical_run_id"].to_numpy()
    instruments = frame["instrument_id"].to_numpy()

    grouped_predictions, splits = grouped_volume_predictions(x, y, groups)
    loio_predictions, per_instrument = leave_one_instrument_out_predictions(
        x, y, instruments
    )
    anomaly_scores = cross_validated_anomaly_scores(
        x, y, instruments, splits
    )

    operation_scores = frame.drop(columns=["qpm_profile"]).copy()
    operation_scores["grouped_predicted_volume_ul"] = grouped_predictions
    operation_scores["loio_predicted_volume_ul"] = loio_predictions
    operation_scores["matched_template_anomaly_score"] = anomaly_scores
    operation_scores.to_csv(
        OUTPUT_DIR / "qpm_lc55_operation_scores.csv", index=False
    )

    references = reference_profile_table(frame, x)
    references.to_csv(
        OUTPUT_DIR / "qpm_lc55_reference_profiles.csv", index=False
    )

    confusion = pd.DataFrame(
        confusion_matrix(y, grouped_predictions, labels=VOLUMES, normalize="true"),
        index=[f"actual_{volume}" for volume in VOLUMES],
        columns=[f"predicted_{volume}" for volume in VOLUMES],
    )
    confusion.to_csv(OUTPUT_DIR / "qpm_lc55_grouped_confusion.csv")

    outcomes = pd.read_parquet(
        PROJECT / "multimodal_training_dataset.parquet",
        columns=[
            "observation_id",
            "total_reads",
            "mean_read_length_bp",
            "raw_read_accuracy_pct",
        ],
    )
    run_scores = (
        operation_scores.groupby(["observation_id", "physical_run_id", "instrument_id"], as_index=False)
        .agg(
            median_qpm_anomaly_score=("matched_template_anomaly_score", "median"),
            p95_qpm_anomaly_score=(
                "matched_template_anomaly_score",
                lambda values: float(np.quantile(values, 0.95)),
            ),
            max_qpm_anomaly_score=("matched_template_anomaly_score", "max"),
            matched_operation_count=("operation_id", "size"),
        )
        .merge(outcomes, on="observation_id", how="left")
    )
    run_scores.to_csv(OUTPUT_DIR / "qpm_lc55_run_scores.csv", index=False)

    correlations: dict[str, dict[str, float | int]] = {}
    for outcome in ["total_reads", "mean_read_length_bp", "raw_read_accuracy_pct"]:
        usable = run_scores[["max_qpm_anomaly_score", outcome]].dropna()
        correlations[outcome] = {
            "n": int(len(usable)),
            "spearman_rho": float(
                spearmanr(usable["max_qpm_anomaly_score"], usable[outcome]).statistic
            ),
        }

    summary: dict[str, object] = {
        "cohort_definition": {
            "liquid_class_index": LIQUID_CLASS_INDEX,
            "liquid_class_name": LIQUID_CLASS_NAME,
            "liquid_class_mapping_confirmed_per_observation": True,
            "operation": "aspirate",
            "pipette": "PIP2",
            "workflow_stage": "templating_started",
            "process_step": "dumping_57",
            "source_location": "templating_solution_a11",
            "programmed_volumes_ul": VOLUMES,
            "pressure_unit": "raw_sensor_count_unresolved",
        },
        "n_waveforms": int(len(frame)),
        "n_observations": int(frame["observation_id"].nunique()),
        "n_physical_runs": int(frame["physical_run_id"].nunique()),
        "n_instruments": int(frame["instrument_id"].nunique()),
        "volume_counts": {
            str(key): int(value)
            for key, value in frame["programmed_volume_ul"].value_counts().sort_index().items()
        },
        "grouped_accuracy": float(accuracy_score(y, grouped_predictions)),
        "grouped_balanced_accuracy": float(
            balanced_accuracy_score(y, grouped_predictions)
        ),
        "majority_class_accuracy": float(pd.Series(y).value_counts(normalize=True).max()),
        "leave_one_instrument_out_accuracy": float(
            accuracy_score(y, loio_predictions)
        ),
        "leave_one_instrument_out_balanced_accuracy": float(
            balanced_accuracy_score(y, loio_predictions)
        ),
        "leave_one_instrument_out_by_instrument": per_instrument,
        "anomaly_score_95th_percentile": float(np.quantile(anomaly_scores, 0.95)),
        "anomaly_score_99th_percentile": float(np.quantile(anomaly_scores, 0.99)),
        "outcome_correlations": correlations,
        "interpretation": (
            "Waveform shape reliably encodes the commanded operation and can support "
            "instrument- and volume-conditioned anomaly detection. It is not a calibrated "
            "pressure measurement or a stand-alone predictor of final sequencing yield."
        ),
    }
    (OUTPUT_DIR / "qpm_lc55_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    make_figure(
        frame,
        x,
        grouped_predictions,
        anomaly_scores,
        outcomes,
        summary,
    )


if __name__ == "__main__":
    main()
