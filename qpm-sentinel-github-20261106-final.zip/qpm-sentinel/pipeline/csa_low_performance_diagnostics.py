"""Guarded, offline CSA evidence for a low-performance run.

The frozen model's held-out component sensitivity is global model context, not
a local causal attribution. Case findings are descriptive comparisons against
strictly prior, protocol-compatible, outcome-qualified physical runs. No model
is fitted, instrument setting changed, or delivered-volume error inferred.
"""
from __future__ import annotations

import base64
from collections import Counter
import hashlib
import html
import io
import json
import os
from functools import lru_cache
from pathlib import Path, PurePosixPath
import re
import tarfile
from typing import Any
import zipfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from PIL import Image

from outcome_reference import SOURCES, load_policy, load_outcome_table, normalize
from csa_root_cause_hypotheses import build_root_cause_assessment, hypothesis_html

VERSION = "csa-low-performance-diagnostics-1.2.0-direction-checked-hypotheses"
ROOT = Path(__file__).resolve().parent
STUDY = Path(os.environ.get("QPM_CSA_MODEL_STUDY", ROOT.parent / "private_artifacts" / "outcome_models"))
MAX_MEMBER_BYTES = 24 * 1024 * 1024
MAX_READ_BYTES = 160 * 1024 * 1024
MAX_IMAGE_PIXELS = 50_000_000
MAX_IMAGES = 256
MAX_MEMBERS = 150_000
MINIMUM_RUNS = 8
TOP5_POLICY = dict(version="total-read-top-five-feature-policy-1.0.0", outcome="total_reads",
    model="elastic_net", validation_scheme="grouped", maximum_features=5,
    ranking="heldout_mae_increase_descending_then_feature_name", scope="global_model_reliance_not_local_cause",
    importance_unit="reads: held-out MAE increase after feature permutation",
    uncertainty="Exploratory between-outer-fold bootstrap; not a physical-run or intervention-effect confidence interval",
    per_feature_unseen_instrument_stability="not_established_by_this_ranking_table")
REFERENCE_IMAGE_COUNT = "rawtrace_reference_image_count"
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".tif", ".tiff", ".bmp"}
FORBIDDEN_FAMILIES = {"true_loading", "edge_effects", "lane_diagnostics", "reseq_diagnostics"}
FAMILY_NAMES = {
    "rawtrace": "RawTrace", "rawtrace_reseq": "RawTrace resequencing", "chip_diagnostics": "Chip diagnostics",
    "flowrate": "FlowRate", "bubbleplots": "Bubble plots", "autocal": "AutoCal",
    "nucstep_rendered": "Nucleotide-step spatial plots", "signal_histograms": "Signal histograms",
    "true_loading": "TrueLoading", "edge_effects": "EdgeEffects", "lane_diagnostics": "LaneDiagnostics",
    "reseq_diagnostics": "ReseqDiagnostics",
}
PIN_PREFIX = "plugin.chip_diagnostics.structured.results_offset_"
METRICS = {
    "plugin.rawtrace.image.pixel_median.std": dict(family="rawtrace", label="RawTrace image-median spread", unit="normalized rendered-image luminance", source_field="SD across image median grayscale luminance", interpretation="Rendered-image proxy; not direct signal amplitude or a physical waveform statistic"),
    "plugin.rawtrace.image.pixel_q90.std": dict(family="rawtrace", label="RawTrace image-q90 spread", unit="normalized rendered-image luminance", source_field="SD across image 90th-percentile grayscale luminance", interpretation="Rendered-image proxy; sensitive to rendering/layout and included images"),
    "plugin.rawtrace.image.entropy.std": dict(family="rawtrace", label="RawTrace image-entropy spread", unit="bits", source_field="SD across image grayscale entropy", interpretation="Rendered-image proxy; not calibrated noise or SNR"),
    PIN_PREFIX + "perc_pinned": dict(family="chip_diagnostics", label="Chip pinned pixels", unit="%", source_field="offset.PercPinned", interpretation="Original plugin-defined pixel-mask percentage; not global-chip pixel count"),
    PIN_PREFIX + "perc_pinned_low": dict(family="chip_diagnostics", label="Chip low-pinned pixels", unit="%", source_field="offset.PercPinnedLow", interpretation="Original low-pinned percentage in the plugin-defined mask"),
    PIN_PREFIX + "perc_pinned_high": dict(family="chip_diagnostics", label="Chip high-pinned pixels", unit="%", source_field="offset.PercPinnedHigh", interpretation="Original high-pinned percentage in the plugin-defined mask"),
}
RENDER_FIELDS = ["plugin.rawtrace.image." + suffix for suffix in
    ["aspect_ratio.mean", "aspect_ratio.std", "aspect_ratio.max", "frame_count.mean", "frame_count.std", "frame_count.max"]]
NATIVE_IMAGE_NAMES = {f"{base}.{region}{tail}.png" for region in ["inlet", "middle", "outlet"]
    for base, tail in [("keyBkgSub", ""), ("flowResidual", ".bead")]}
GUARDRAILS = [
    "Global permutation sensitivity describes a frozen model, not simple correlation, local attribution, percent read loss, causality, or an adjustable setting.",
    "Case comparisons are post-run diagnostic clues. Empirical 5th–95th percentiles are not confidence intervals or approved acceptance limits; outliers are not calibrated failure probabilities.",
    "Outcome-qualified peers are not independently certified fault-free controls. Recorded metadata does not verify sample input, concentration/spike amounts, lots, maintenance, or intended engineering changes.",
    "Strictly earlier recorded run starts are required; CSA-ready times are not independently verified. This is not a prospective forecasting result.",
    "Missing metrics, inadequate compatible history, unsupported image composition, and excluded fields are unresolved—not normal or healthy.",
    "No delivered-volume error, proven root cause, or automatic instrument-setting change is established by this section.",
]


def _safe(value: Any) -> Any:
    if isinstance(value, dict): return {str(k): _safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [_safe(v) for v in value]
    if isinstance(value, Path): return str(value)
    if isinstance(value, np.generic): return _safe(value.item())
    if isinstance(value, float) and not np.isfinite(value): return None
    return value


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


@lru_cache(maxsize=128)
def _stat_sha(path: str, size: int, mtime_ns: int, ctime_ns: int) -> str:
    # Cache only within this process and only while the full file stat is stable.
    return _sha(Path(path))


def _fingerprint(path: Path) -> str | None:
    path = Path(path).resolve()
    if not path.is_file(): return None
    s = path.stat()
    return _stat_sha(str(path), s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def _inventory_path(config: dict) -> Path:
    return Path(config.get("csa_diagnostic_plugin_inventory", ROOT / "update_results_20261027_gx8_v2/plugin_inventory/primary_archive_plugin_inventory.csv"))


def diagnostic_input_fingerprints(project: Path, config: dict) -> dict:
    """Shared batch/manual cache inputs, including deliberately absent sources."""
    project = Path(project)
    study = Path(config.get("csa_diagnostic_model_study", STUDY))
    paths = [Path(__file__), ROOT / "csa_root_cause_hypotheses.py", ROOT / "train_multimodal_csa.py", ROOT / "outcome_reference.py",
        ROOT / "qpm_reference_qualification.py", project / "csa_ml_dataset.parquet",
        project / "qpm_failure_examples/dna_rna_balance_by_run.csv",
        project / "qpm_failure_examples/dna_rna_barcode_counts.csv", project / "outcome_reference_policy.json",
        project / "reference_qualification_policy.json", study / "training_dataset.parquet",
        study / "component_importance.csv", study / "feature_rankings.csv",
        study / "specific_feature_details.csv", study / "feature_dictionary.csv", study / "model_training_log.json",
        study / "model_settings.json", study / "strict_policy_review.json", _inventory_path(config)]
    return {str(p.resolve()): _fingerprint(p) for p in paths}


def cache_artifacts_valid(manifest_path: Path) -> bool:
    """Reject stale source data/code or absent/changed generated artifacts."""
    path = Path(manifest_path)
    if path.is_dir(): path /= "csa_low_performance_manifest.json"
    try:
        result = json.loads(path.read_text())
        if result.get("version") != VERSION or not result.get("input_source_hashes"): return False
        for name, recorded in result["input_source_hashes"].items():
            if _fingerprint(Path(name)) != recorded: return False
        for name, recorded in result.get("output_artifact_hashes", {}).items():
            if _fingerprint(Path(name)) != recorded: return False
        for name in result.get("outputs", {}).values():
            if not Path(name).is_file(): return False
        return True
    except (OSError, ValueError, TypeError):
        return False


def _finite(value: Any) -> float | None:
    if isinstance(value, bool): return None
    try: result = float(value)
    except (TypeError, ValueError): return None
    return result if np.isfinite(result) else None


def _safe_member(name: str) -> str | None:
    if not name or "\\" in name or "\x00" in name or name.startswith("/"): return None
    path = PurePosixPath(name)
    if ".." in path.parts: return None
    return str(path).removeprefix("./")


def _family(name: str) -> str | None:
    parts = PurePosixPath(name).parts
    if not parts: return None
    # Known plugin roots only; never expose arbitrary patient/operator paths.
    for token in parts[:-1]:
        k = re.sub(r"[^a-z0-9]", "", token.lower())
        if k.startswith("rawtracereseq"): return "rawtrace_reseq"
        if k.startswith("rawtrace"): return "rawtrace"
        if k.startswith("chipdiagnostic"): return "chip_diagnostics"
        if k.startswith("trueloading"): return "true_loading"
        if k.startswith("edgeeffect"): return "edge_effects"
        if k.startswith("lanediagnostic"): return "lane_diagnostics"
        if k.startswith("reseqdiagnostic"): return "reseq_diagnostics"
        if k.startswith(("flowrate", "flowdata")): return "flowrate"
        if k.startswith("bubbleplot"): return "bubbleplots"
        if k.startswith("autocal"): return "autocal"
        if k.startswith("nucstepspatial"): return "nucstep_rendered"
        if k.startswith(("nikf", "signalhistogram")): return "signal_histograms"
    return None


def _members(path: Path):
    """Yield regular member handles only; never extract archive paths."""
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            for index, info in enumerate(archive.infolist()):
                if index >= MAX_MEMBERS: raise ValueError("CSA member-count safety bound exceeded")
                if info.is_dir(): continue
                # Unix symlinks are not regular archive data.
                if ((info.external_attr >> 16) & 0o170000) == 0o120000: continue
                with archive.open(info) as stream:
                    yield info.filename, info.file_size, stream
    else:
        with tarfile.open(path, "r|*") as archive:
            for index, info in enumerate(archive):
                if index >= MAX_MEMBERS: raise ValueError("CSA member-count safety bound exceeded")
                if not info.isfile(): continue
                stream = archive.extractfile(info)
                if stream is not None:
                    yield info.name, info.size, stream


def extract_diagnostics(archive_path: Path, output_dir: Path) -> dict:
    """Extract only allowlisted safe fields and exact native scientific images."""
    from train_multimodal_csa import image_descriptors
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    assets = output_dir / "csa_diagnostic_native_images"
    values, source_fields, warnings, native = {}, {}, [], []
    inventory = Counter()
    image_rows, chip_documents, total_bytes, raw_failures = [], [], 0, 0
    raw_counts = Counter()
    for original_name, size, stream in _members(Path(archive_path)):
        name = _safe_member(original_name)
        if name is None:
            warnings.append("Unsafe archive member name ignored; no archive path was extracted.")
            continue
        family = _family(name)
        if family is None:
            parts = PurePosixPath(name).parts
            # Never display arbitrary run/sample directory names. Only explicit
            # plugin roots get a hashed inventory entry, with no value parsing.
            for i, token in enumerate(parts[:-2]):
                if token.lower() == "plugins":
                    inventory["unvalidated_plugin_" + hashlib.sha256(parts[i + 1].encode()).hexdigest()[:12]] += 1
                    break
            continue
        inventory[family] += 1
        if family in FORBIDDEN_FAMILIES: continue
        suffix = PurePosixPath(name).suffix.lower()
        is_image = family in {"rawtrace", "rawtrace_reseq"} and suffix in IMAGE_EXTENSIONS
        is_chip = family == "chip_diagnostics" and PurePosixPath(name).name == "results.json"
        if not (is_image or is_chip): continue
        if size < 0 or size > MAX_MEMBER_BYTES:
            warnings.append(f"{FAMILY_NAMES[family]} member exceeded the bounded read size; metric coverage unresolved.")
            if is_image: raw_failures += 1
            continue
        if total_bytes + size > MAX_READ_BYTES: raise ValueError("CSA diagnostic selected-byte safety bound exceeded")
        data = stream.read(MAX_MEMBER_BYTES + 1)
        total_bytes += len(data)
        if len(data) > MAX_MEMBER_BYTES: raise ValueError("CSA diagnostic member read exceeded safety bound")
        if is_chip:
            try:
                obj = json.loads(data.decode("utf-8-sig"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                warnings.append("chipDiagnostics/results.json is malformed; chip metrics unresolved.")
                continue
            offset = obj.get("offset", {}) if isinstance(obj, dict) else {}
            if not isinstance(offset, dict):
                warnings.append("chipDiagnostics offset is not an object; chip metrics unresolved.")
                continue
            selected = {k: _finite(offset.get(k)) for k in ["PercPinned", "PercPinnedLow", "PercPinnedHigh", "PixelLow", "PixelHigh", "PixelCount", "PixelInRange"]}
            chip_documents.append(dict(member=name, sha256=hashlib.sha256(data).hexdigest(), fields=selected))
            continue
        raw_counts[family] += 1
        if raw_counts[family] > MAX_IMAGES: raise ValueError("RawTrace image-count safety bound exceeded")
        if family == "rawtrace_reseq": continue
        try:
            with Image.open(io.BytesIO(data)) as im:
                if im.width * im.height > MAX_IMAGE_PIXELS or getattr(im, "n_frames", 1) > 128:
                    raise ValueError("image dimensions/frame bound")
                descriptor = image_descriptors(data)
        except (OSError, ValueError, Image.DecompressionBombError):
            descriptor = {}
        if not descriptor:
            raw_failures += 1
            continue
        image_rows.append(dict(source_member=name, sha256=hashlib.sha256(data).hexdigest(), **descriptor))
        if PurePosixPath(name).name in NATIVE_IMAGE_NAMES and suffix == ".png" and len(native) < 6:
            assets.mkdir(exist_ok=True)
            dest = assets / f"rawtrace_native_{len(native):02d}.png"
            # Generated safe local name, never an archive-provided path.
            dest.write_bytes(data)
            native.append(dict(path=str(dest), relative_path=str(dest.relative_to(output_dir)), source_member=name,
                               sha256=hashlib.sha256(data).hexdigest(), interpretation="Original local-region RawTrace scientific plot; not a whole-chip loading estimate"))
    raw_status = "missing_rawtrace"
    if raw_counts["rawtrace_reseq"]:
        raw_status = "mixed_or_resequencing_rawtrace_excluded"
        warnings.append("RawTrace_Reseq imagery is present: aggregated image proxies are withheld because original and resequencing plots must not be mixed or silently aligned to one outcome.")
    elif raw_failures:
        raw_status = "incomplete_or_unsupported_rawtrace_composition"
        warnings.append("One or more RawTrace images were unparseable/oversized; proxy peer comparison is withheld.")
    elif len(image_rows) >= 2:
        raw_status = "available_image_proxy"
        for metric, field in [("pixel_median", "pixel_median"), ("pixel_q90", "pixel_q90"), ("entropy", "entropy")]:
            feature = f"plugin.rawtrace.image.{metric}.std"
            values[feature] = float(np.std([r[field] for r in image_rows]))
            source_fields[feature] = dict(source_file="rawTrace/* images", source_field=METRICS[feature]["source_field"], image_count=len(image_rows))
        for field in ["aspect_ratio", "frame_count"]:
            a = np.asarray([r[field] for r in image_rows])
            for suffix, fn in [("mean", np.mean), ("std", np.std), ("max", np.max)]:
                values[f"plugin.rawtrace.image.{field}.{suffix}"] = float(fn(a))
    elif image_rows:
        raw_status = "insufficient_rawtrace_images"
    chip_status = "missing_chip_diagnostics"
    chip_fields = {}
    if chip_documents:
        distinct = {r["sha256"] for r in chip_documents}
        if len(distinct) > 1:
            chip_status = "ambiguous_multiple_chip_results"
            warnings.append("Multiple distinct chipDiagnostics/results.json members; no chip percentage selected.")
        else:
            selected = chip_documents[0]
            chip_fields = selected["fields"]
            count, low, high, in_range = [chip_fields[k] for k in ["PixelCount", "PixelLow", "PixelHigh", "PixelInRange"]]
            denominator_ok = count is not None and count > 0 and low is not None and high is not None and low >= 0 and high >= 0 and low + high <= count
            if in_range is not None and denominator_ok:
                denominator_ok &= in_range >= 0 and np.isclose(in_range + low + high, count, rtol=1e-10)
            expected = {"PercPinned": 100 * (low + high) / count, "PercPinnedLow": 100 * low / count, "PercPinnedHigh": 100 * high / count} if denominator_ok else {}
            valid = {}
            for key, suffix in [("PercPinned", "perc_pinned"), ("PercPinnedLow", "perc_pinned_low"), ("PercPinnedHigh", "perc_pinned_high")]:
                value = chip_fields[key]
                if value is not None and 0 <= value <= 100 and key in expected and np.isclose(value, expected[key], rtol=1e-5, atol=1e-5):
                    feature = PIN_PREFIX + suffix
                    valid[feature] = value
                    source_fields[feature] = dict(source_file=selected["member"], source_field="offset." + key,
                        source_sha256=selected["sha256"], denominator_field="offset.PixelCount", denominator=count)
            values.update(valid)
            chip_status = "validated_original_percentage" if PIN_PREFIX + "perc_pinned" in valid else "invalid_or_unverified_chip_denominator"
            if chip_status != "validated_original_percentage": warnings.append("Original pinned percentage/PixelCount denominator could not be reconciled; chip percentages unresolved.")
    return dict(values=values, source_fields=source_fields, rawtrace_status=raw_status, rawtrace_images=len(image_rows),
        rawtrace_reseq_images=raw_counts["rawtrace_reseq"], image_composition=image_rows,
        chip_status=chip_status, chip_original_fields=chip_fields, native_images=native,
        plugin_counts=dict(inventory), selected_bytes_read=total_bytes, warnings=warnings)


def select_peer_measurements(table: pd.DataFrame, target_id: str, feature: str, target_value: float | None,
                             required_fields: list[str], *, composition: dict | None = None,
                             allow_cross_instrument: bool = True) -> tuple[dict, list[dict], list[dict]]:
    """Strict metadata/time/physical-run audit, then independent per-metric tiers."""
    target_rows = table[table.observation_id.eq(target_id)]
    if len(target_rows) != 1: raise ValueError("CSA diagnostic target must resolve uniquely")
    target = target_rows.iloc[0]
    required_fields = list(dict.fromkeys([*required_fields, *SOURCES, "panel_signature", "dna_barcode_count", "rna_barcode_count", "evaluated_lane_count"]))
    missing = [f for f in required_fields if f not in table or normalize(target.get(f)) is None]
    target_time = pd.to_datetime(target.run_start_time, utc=True, errors="coerce")
    base = dict(feature=feature, target_value=target_value, status="insufficient_compatible_measured_peers", reference_mode="none",
        reference_physical_runs=0, reference_instruments=0, peer_median=None, peer_q05=None, peer_q95=None,
        empirical_percentile=None, deviation="unresolved", peer_missing_observations=0, missing_target_fields=";".join(missing),
        time_policy="strictly_prior_recorded_start", interpretation="descriptive_peer_comparison_not_causal_or_calibrated_failure_probability")
    if target_value is None: base["status"] = "target_metric_unavailable"
    if missing: base["status"] = "missing_required_target_metadata"
    if pd.isna(target_time): base["status"] = "target_time_unresolved"
    audits, members = [], []
    candidates = table[~table.physical_run_id.eq(target.physical_run_id)].copy()
    for f in required_fields:
        if f not in candidates: candidates[f] = None
    times = pd.to_datetime(candidates.run_start_time, utc=True, errors="coerce")
    reasons = pd.Series("", index=candidates.index, dtype=object)
    for f in required_fields:
        matches = candidates[f].map(normalize).eq(normalize(target.get(f))) if f not in missing else pd.Series(False, index=candidates.index)
        reasons.loc[~matches] += f + ";"
    qualified = candidates.get("reference_eligible", pd.Series(False, index=candidates.index)).eq(True)
    time_ok = times.notna() & times.lt(target_time) if pd.notna(target_time) else pd.Series(False, index=candidates.index)
    measured = pd.to_numeric(candidates.get(feature, pd.Series(np.nan, index=candidates.index)), errors="coerce")
    valid_range = pd.Series(np.isfinite(measured), index=candidates.index)
    if METRICS.get(feature, {}).get("unit") == "%": valid_range &= measured.between(0, 100)
    measured = measured.where(valid_range)
    comp_ok = pd.Series(True, index=candidates.index)
    if composition is not None:
        for key, value in composition.items():
            peer = pd.to_numeric(candidates.get(key, pd.Series(np.nan, index=candidates.index)), errors="coerce")
            comp_ok &= pd.Series(np.isclose(peer, value, rtol=1e-6, atol=1e-8), index=candidates.index)
    mask = reasons.eq("") & qualified & time_ok & comp_ok
    candidates[feature] = measured
    for idx, r in candidates.iterrows():
        audits.append(dict(feature=feature, peer_observation_id=r.observation_id, peer_physical_run_id=r.physical_run_id,
            peer_instrument_id=r.instrument_id, peer_time=r.run_start_time, metadata_mismatches=reasons.loc[idx],
            qualified=bool(qualified.loc[idx]), strictly_prior=bool(time_ok.loc[idx]), render_signature_matches=bool(comp_ok.loc[idx]),
            metric_available=bool(pd.notna(measured.loc[idx])), metric_validation="finite_in_range" if bool(valid_range.loc[idx]) else "missing_nonfinite_or_impossible_value",
            eligible=bool(mask.loc[idx]), selected=False))
    compatible = candidates[mask]
    base["peer_missing_observations"] = int(compatible[feature].isna().sum())
    tiers = [("same_instrument_same_lane", compatible[compatible.instrument_id.eq(target.instrument_id) & compatible.chip_lane.astype(str).eq(str(target.chip_lane))]),
             ("same_instrument_all_lanes", compatible[compatible.instrument_id.eq(target.instrument_id)]),
             ("other_instruments", compatible[~compatible.instrument_id.eq(target.instrument_id)])]
    coverage = []
    for mode, group in tiers:
        if mode == "other_instruments" and not allow_cross_instrument:
            coverage.append("other_instruments:disabled_by_policy")
            continue
        available = group[group[feature].notna()].copy()
        values = available.groupby("physical_run_id")[feature].median()
        instruments = available.instrument_id.nunique()
        coverage.append(f"{mode}:{len(values)}runs/{instruments}instruments")
        if len(values) < MINIMUM_RUNS or (mode == "other_instruments" and instruments < 2): continue
        if target_value is None or missing or pd.isna(target_time): continue
        low, median, high = [float(values.quantile(q)) for q in [.05, .5, .95]]
        base.update(status="available", reference_mode=mode, reference_physical_runs=len(values), reference_instruments=int(instruments),
            peer_median=median, peer_q05=low, peer_q95=high,
            empirical_percentile=float(((values < target_value).sum() + .5 * (values == target_value).sum()) / len(values)),
            deviation="below_empirical_range" if target_value < low else "above_empirical_range" if target_value > high else "within_empirical_range")
        chosen_ids = set(available.observation_id)
        for a in audits: a["selected"] = a["peer_observation_id"] in chosen_ids
        for run_id, value in values.items():
            g = available[available.physical_run_id.eq(run_id)]
            members.append(dict(feature=feature, reference_mode=mode, peer_physical_run_id=run_id,
                value=float(value), contributing_observations="|".join(sorted(g.observation_id.astype(str))),
                instruments="|".join(sorted(g.instrument_id.astype(str))), vote_weight=1))
        break
    base["coverage_by_tier"] = ";".join(coverage)
    return base, members, audits


def _component_priority(path: Path) -> list[dict]:
    if not path.is_file(): return []
    data = pd.read_csv(path)
    selected = data[data.outcome.eq("total_reads") & data.validation_scheme.eq("chronological") & data.model.eq("elastic_net")]
    records = []
    for row in selected.sort_values("heldout_mae_increase", ascending=False).itertuples():
        component = str(row.component)
        if component.removeprefix("plugin:") in FORBIDDEN_FAMILIES: continue
        records.append(dict(component=component, heldout_mae_increase=float(row.heldout_mae_increase),
            validation="chronological_total_reads_elastic_net", support_status=row.support_status,
            interpretation="global_frozen_model_sensitivity_not_simple_correlation_or_local_cause"))
    return records


def _ranked_feature_priority(path: Path, maximum_features: int = 5) -> tuple[list[dict], dict]:
    """Read one predetermined held-out ranking; never select a model per case."""
    policy = {**TOP5_POLICY, "maximum_features": maximum_features, "source_file": str(path), "status": "unavailable"}
    count_name = {5: "five", 10: "ten"}.get(maximum_features, str(maximum_features))
    if not path.is_file():
        policy["reason"] = "Frozen individual-feature ranking file is unavailable; no component-name substitute is used."
        return [], policy
    try:
        frame = pd.read_csv(path)
        required = {"outcome", "model", "validation_scheme", "feature_name", "component", "tier", "heldout_mae_increase"}
        if not required.issubset(frame): raise ValueError("missing required ranking columns")
        selected = frame.loc[frame.outcome.eq("total_reads") & frame.model.eq("elastic_net") & frame.validation_scheme.eq("grouped")].copy()
        selected["heldout_mae_increase"] = pd.to_numeric(selected.heldout_mae_increase, errors="coerce")
        if selected.feature_name.duplicated().any(): raise ValueError("duplicate individual-feature ranking rows")
        if not np.isfinite(selected.heldout_mae_increase).all(): raise ValueError("nonfinite ranking importance")
        selected = selected.sort_values(["heldout_mae_increase", "feature_name"], ascending=[False, True]).head(maximum_features)
        if len(selected) != maximum_features: raise ValueError(f"fewer than {count_name} ranked individual features")
        forbidden = selected.tier.eq("D") | selected.component.astype(str).str.removeprefix("plugin:").isin(FORBIDDEN_FAMILIES)
        for family in FORBIDDEN_FAMILIES:
            forbidden |= selected.feature_name.astype(str).str.startswith("plugin." + family + ".")
        if forbidden.any(): raise ValueError(f"forbidden leakage family in the frozen top {count_name}; ranking policy mismatch")
    except (OSError, ValueError, KeyError, TypeError) as error:
        policy["reason"] = "Individual-feature ranking unresolved: " + str(error)
        return [], policy
    records = []
    for index, row in enumerate(selected.to_dict("records"), 1):
        records.append(dict(rank=index, feature_name=str(row["feature_name"]), component=str(row["component"]),
            tier=str(row["tier"]), model="elastic_net", validation_scheme="grouped", outcome="total_reads",
            heldout_mae_increase=float(row["heldout_mae_increase"]), importance_unit=TOP5_POLICY["importance_unit"],
            importance_ci_low=_finite(row.get("importance_ci_low")), importance_ci_high=_finite(row.get("importance_ci_high")),
            uncertainty_method=str(row.get("uncertainty_method", "not recorded")),
            outer_folds=_finite(row.get("outer_folds")), positive_folds=_finite(row.get("positive_folds")),
            selection_count=_finite(row.get("selection_count")),
            selection_frequency=_finite(row.get("selection_frequency")), support_status=str(row.get("support_status", "not recorded")),
            coefficient_positive_folds=_finite(row.get("coefficient_positive_folds")),
            coefficient_negative_folds=_finite(row.get("coefficient_negative_folds")),
            median_standardized_coefficient=_finite(row.get("median_standardized_coefficient")),
            conditional_direction=str(row.get("direction", "not recorded")),
            ml_source_file=str(row.get("source_file", "not recorded")), ml_source_field=str(row.get("source_field", "not recorded")),
            ranking_source_file=str(path), target_value=None, frozen_model_input_value=None,
            source_file=str(row.get("source_file", "not recorded")), source_field=str(row.get("source_field", "not recorded")),
            unit=str(row.get("unit", "source units unresolved")), case_status="unresolved_no_validated_metric_adapter",
            case_evidence="No supported case-level interpretation; global importance is not a local contribution.",
            local_interpretation_allowed=False))
    policy.update(status="available", features_returned=maximum_features, source_sha256=_fingerprint(path))
    return records, policy


def _top5_feature_priority(path: Path) -> tuple[list[dict], dict]:
    """Preserve the fixed five-feature report table and its public interface."""
    return _ranked_feature_priority(path, 5)


def _top5_case_evidence(rows: list[dict], metrics: list[dict], trigger: dict, fresh_values: dict,
                        fresh_sources: dict, frozen_target: dict) -> list[dict]:
    """Join only available guarded views; do not turn ambiguous counts into health."""
    compared = {r["feature"]: r for r in metrics}
    output = []
    ambiguous = {
        "plugin.chip_diagnostics.structured.results_offset_pixel_in_range.mean": (
            "Merged in-range pixel-count proxy", "offset.pixel_in_range / offset.PixelInRange (case-sensitive aliases merged)",
            "Global/subset count aliases were merged. Scope/denominator unresolved; not a percentage or validated chip-health metric."),
        "plugin.chip_diagnostics.structured.results_edge_metrics_pixels_n.std": (
            "Edge-region pixel-count spread", "edge_metrics.pixels_n (normalized count-field family)",
            "Spread of region pixel counts depends on region geometry. Not a validated damage, loading, or dropout measurement."),
    }
    for original in rows:
        row = dict(original)
        feature = row["feature_name"]
        row["frozen_model_input_value"] = _finite(frozen_target.get(feature))
        row["frozen_value_source"] = "Frozen training_dataset.parquet retrospective model input; not a fresh measurement" if row["frozen_model_input_value"] is not None else "Not available for this archive/observation"
        if feature in METRICS:
            definition = METRICS[feature]
            row.update(label=definition["label"], unit=definition["unit"], source_file=fresh_sources.get(feature, {}).get("source_file", "rawTrace/* images"), source_field=definition["source_field"])
            comparison = compared.get(feature, {})
            row["target_value"] = comparison.get("target_value", fresh_values.get(feature))
            row["case_status"] = comparison.get("status", "fresh_measurement_without_compatible_reference" if feature in fresh_values else "target_metric_unavailable")
            row["local_interpretation_allowed"] = row["case_status"] == "available"
            for key in ["peer_median", "peer_q05", "peer_q95", "reference_mode", "reference_physical_runs", "reference_instruments", "deviation"]:
                row[key] = comparison.get(key)
            row["case_evidence"] = (f"{comparison.get('deviation')}; {comparison.get('reference_physical_runs')} compatible earlier physical runs. " if row["local_interpretation_allowed"] else "Compatible measured-peer comparison unresolved. ") + definition["interpretation"] + "; not a cause or calibrated physical signal measurement."
        elif feature == "context.analyzed_lane_count":
            lane_count = _finite(trigger.get("chip_lane_read_criterion", {}).get("evaluated_lane_count"))
            row.update(label="Analyzed lane count", unit="analyzed lanes", target_value=lane_count,
                source_file="Reference qualification / recorded analyzed-lane scope", source_field="evaluated_lane_count",
                case_status="adjustment_context_not_root_cause" if lane_count is not None else "context_unavailable",
                case_evidence="Tier B adjustment: lane count changes the expected total-read scale and the absolute threshold. It is not a failure mechanism or a tunable recommendation.")
        elif feature in ambiguous:
            label, source_field, caveat = ambiguous[feature]
            row.update(label=label, unit="source-native pixel counts; scope unresolved", source_file="chipDiagnostics/results.json",
                source_field=source_field, case_status="interpretation_withheld_ambiguous_count_proxy", case_evidence=caveat)
        else:
            row["label"] = feature
        output.append(row)
    return output


def _reference_image_counts(path: Path) -> pd.DataFrame:
    """Image-extension counts from the audited per-archive inventory, not X."""
    columns = ["archive_id", "plugin_family", "extension", "file_count"]
    if not path.is_file():
        return pd.DataFrame(columns=["archive_id", REFERENCE_IMAGE_COUNT])
    records = pd.read_csv(path, usecols=columns, dtype={"archive_id": str})
    rows = records[records.plugin_family.eq("rawtrace") & records.extension.str.lower().isin(IMAGE_EXTENSIONS)].copy()
    rows["file_count"] = pd.to_numeric(rows.file_count, errors="coerce")
    rows = rows[rows.file_count.gt(0) & rows.file_count.le(MAX_IMAGES) & rows.file_count.mod(1).eq(0)]
    if rows.groupby(["archive_id", "extension"]).file_count.nunique().gt(1).any():
        raise ValueError("Reference image inventory contains inconsistent counts for one archive/extension")
    rows = rows.drop_duplicates(["archive_id", "extension"])
    counts = rows.groupby("archive_id", as_index=False).file_count.sum().rename(columns={"file_count": REFERENCE_IMAGE_COUNT})
    return counts[counts[REFERENCE_IMAGE_COUNT].between(2, MAX_IMAGES)]


def _investigation_hypotheses(metrics: list[dict]) -> list[dict]:
    clues = []
    pinned = next((m for m in metrics if m["feature"] == PIN_PREFIX + "perc_pinned"), {})
    if pinned.get("status") == "available" and pinned.get("deviation") == "above_empirical_range":
        clues.append(dict(view="chip_diagnostics", evidence="Original pinned-pixel percentage is above comparable prior runs.",
            review="Review plugin pixel masks, offset calibration and usable pixel distribution; verify scope/denominator in original results.json.",
            limitation="Does not establish damaged wells, a loading defect, or the number of reads lost."))
    if any(m["family"] == "rawtrace" and m["status"] == "available" and m["deviation"] != "within_empirical_range" for m in metrics):
        clues.append(dict(view="rawtrace", evidence="One or more rendered RawTrace image-spread proxies are outside comparable prior ranges.",
            review="Inspect original inlet/middle/outlet key-background-subtracted and flow-residual plots and their axes; check rendering/content compatibility first.",
            limitation="A rendered proxy is not direct amplitude, SNR, pressure, delivered volume, or a proven fluidic cause."))
    if not clues:
        clues.append(dict(view="unresolved", evidence="No supported outlying view currently explains this run's low performance.",
            review="Review QPM evidence, sample/input quality, library preparation, calibration and maintenance records with an assay/instrument expert.",
            limitation="Normal-range available metrics and missing views do not certify normal operation or exclude an unmeasured failure."))
    return clues


def _embed(path: Path) -> str:
    return "data:image/png;base64," + base64.b64encode(path.read_bytes()).decode()


def _peer_box_statistics(values: np.ndarray) -> dict:
    """Draw the exact interpolated percentiles used by the diagnostic table.

    boxplot(whis=(5,95)) snaps whiskers to observed values. That can place
    an in-range target outside the drawn whisker for a small peer cohort.
    """
    low, q1, median, q3, high = np.quantile(values, [.05, .25, .5, .75, .95])
    return dict(whislo=float(low), q1=float(q1), med=float(median),
                q3=float(q3), whishi=float(high), fliers=[])


def _plot(output_dir: Path, metrics: list[dict], members: list[dict], priority: list[dict]) -> list[str]:
    # Plot only supplied saved/model and case measurements; never fit a model.
    outputs = []
    with plt.rc_context({"font.family": "DejaVu Sans", "font.size": 8, "axes.spines.top": False,
                         "axes.spines.right": False, "pdf.fonttype": 42, "svg.fonttype": "none"}):
        fig, ax = plt.subplots(figsize=(7.2, 3.0), layout="constrained")
        rows = priority[:8]
        if rows:
            names = [r["component"].replace("plugin:", "").replace("_", " ") for r in rows]
            values = [r["heldout_mae_increase"] / 1e6 for r in rows]
            ax.barh(range(len(rows)), values, color="#457B9D")
            ax.set_yticks(range(len(rows)), names); ax.invert_yaxis()
            ax.set_xlabel("Held-out MAE increase after shuffling (M reads)")
        else:
            ax.text(.5, .5, "Frozen model priority unavailable", ha="center", transform=ax.transAxes); ax.set_axis_off()
        ax.set_title("Global total-read model dependence — not this run's causal explanation", loc="left", fontsize=9)
        path = output_dir / "csa_diagnostic_component_priority.png"
        fig.savefig(path, dpi=180); plt.close(fig); outputs.append(str(path))
        selected = [m for m in metrics if m["status"] == "available"]
        if selected:
            fig, axes = plt.subplots(len(selected), 1, figsize=(7.2, max(2.2, 1.7 * len(selected))), layout="constrained", squeeze=False)
            fig.suptitle("Diamond: target · gray points: prior runs · box: IQR · whiskers: exact 5th–95th%", fontsize=8)
            for ax, metric in zip(axes.flat, selected):
                values = np.asarray([m["value"] for m in members if m["feature"] == metric["feature"]])
                ax.bxp([_peer_box_statistics(values)], positions=[0], orientation="horizontal", showfliers=False,
                    patch_artist=True, boxprops=dict(facecolor="#E8F3EF", edgecolor="#7F8B84"), medianprops=dict(color="#264653"))
                ax.scatter(values, np.zeros(len(values)), s=9, color="#7F8B84", alpha=.45)
                ax.scatter([metric["target_value"]], [0], marker="D", color="#C65A36", s=35, zorder=4)
                ax.set_yticks([]); ax.set_xlabel(metric["unit"])
                ax.set_title(f"{metric['label']} · {metric['deviation']} · n={metric['reference_physical_runs']} physical runs", loc="left", fontsize=8)
            path = output_dir / "csa_diagnostic_peer_comparison.png"
            fig.savefig(path, dpi=180); plt.close(fig); outputs.append(str(path))
    return outputs


def build_low_performance_diagnostics(project: Path, observation_id: str, archive_path: Path,
                                      output_dir: Path, trigger: dict, config: dict) -> dict:
    project, output_dir, archive_path = Path(project), Path(output_dir), Path(archive_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = output_dir / "csa_low_performance_manifest.json"
    result = dict(version=VERSION, status="not_triggered", observation_id=observation_id, triggered=False,
        summary="No low-performance trigger; multimodal CSA investigation not requested for this scope.",
        metrics=[], component_priority=[], plugin_inventory=[], native_images=[], warnings=[],
        top5_ml_metrics=[], top5_ml_policy={**TOP5_POLICY, "status": "not_requested"},
        root_cause_contributors=[], root_cause_ranking_policy={**TOP5_POLICY, "maximum_features": 10, "status": "not_requested"},
        guardrails=list(GUARDRAILS), outputs={}, manifest_path=str(manifest_path),
        input_source_hashes=diagnostic_input_fingerprints(project, config),
        models_retrained=False, instrument_settings_changed=False, missing_is_normal=False)
    triggered = bool(trigger.get("below_chip_lane_read_criterion") or trigger.get("low_outcomes"))
    result["triggered"] = triggered
    fresh_values, fresh_sources, frozen_target_values = {}, {}, {}
    def finish():
        if triggered and result["status"] != "disabled":
            result["top5_ml_metrics"] = _top5_case_evidence(result["top5_ml_metrics"], result["metrics"], trigger,
                fresh_values, fresh_sources, frozen_target_values)
            csv = output_dir / "csa_diagnostic_top5_ml_metrics.csv"
            table = pd.DataFrame(_safe(result["top5_ml_metrics"]))
            if table.empty: table = pd.DataFrame(columns=["rank", "feature_name", "heldout_mae_increase", "case_status"])
            table.to_csv(csv, index=False)
            result["outputs"]["csa_diagnostic_top5_ml_metrics"] = str(csv)
        result["root_cause_assessment"] = build_root_cause_assessment(
            result["metrics"], result["root_cause_contributors"], trigger,
            enabled=result["status"] != "disabled")
        result["root_cause_assessment"]["ranking_policy"] = result["root_cause_ranking_policy"]
        assessment_path = output_dir / "csa_root_cause_assessment.json"
        assessment_path.write_text(json.dumps(_safe(result["root_cause_assessment"]), indent=2, allow_nan=False))
        result["outputs"]["csa_root_cause_assessment"] = str(assessment_path)
        csv = output_dir / "csa_root_cause_contributors.csv"
        assessed_rows = [*result["root_cause_assessment"].get("contributor_assessments", []),
                         *result["root_cause_assessment"].get("supplemental_assessments", [])]
        assessed_table = pd.DataFrame(_safe(assessed_rows))
        if assessed_table.empty:
            assessed_table = pd.DataFrame(columns=["feature_name", "assessment_status", "target_value", "peer_q05", "peer_q95"])
        assessed_table.to_csv(csv, index=False)
        result["outputs"]["csa_root_cause_contributors"] = str(csv)
        result["outputs"]["manifest"] = str(manifest_path)
        result["output_artifact_hashes"] = {str(Path(p).resolve()): _fingerprint(Path(p))
            for p in [*result["outputs"].values(), *(r["path"] for r in result["native_images"])]
            if Path(p) != manifest_path and Path(p).is_file()}
        manifest_path.write_text(json.dumps(_safe(result), indent=2))
        return _safe(result)
    if not config.get("enable_csa_low_performance_diagnostics", True):
        result.update(status="disabled", summary="Multimodal CSA investigation is explicitly disabled; low performance is not thereby resolved.")
        return finish()
    if not triggered: return finish()
    result["status"] = "unresolved"
    study = Path(config.get("csa_diagnostic_model_study", STUDY))
    result["top5_ml_metrics"], result["top5_ml_policy"] = _top5_feature_priority(study / "feature_rankings.csv")
    result["root_cause_contributors"], result["root_cause_ranking_policy"] = _ranked_feature_priority(study / "feature_rankings.csv", 10)
    if result["root_cause_ranking_policy"]["status"] != "available":
        result["warnings"].append(result["root_cause_ranking_policy"].get("reason", "Top-ten hypothesis ranking unavailable."))
    if result["top5_ml_policy"]["status"] != "available":
        result["warnings"].append(result["top5_ml_policy"].get("reason", "Top-five ML metrics unavailable."))
    result["input_source_hashes"][str(archive_path.resolve())] = _fingerprint(archive_path)
    try:
        extracted = extract_diagnostics(archive_path, output_dir)
    except (OSError, ValueError, tarfile.TarError, zipfile.BadZipFile) as error:
        result["summary"] = "Optional CSA diagnostic view could not be parsed safely; QPM analysis may continue independently."
        result["warnings"].append("CSA diagnostic parse/safety failure: " + type(error).__name__ + ". No diagnostic normality or cause inferred.")
        result["parse_error"] = dict(type=type(error).__name__, status="unresolved_not_silently_ignored")
        return finish()
    result["native_images"] = extracted["native_images"]
    fresh_values, fresh_sources = extracted["values"], extracted["source_fields"]
    result["warnings"].extend(extracted["warnings"])
    result["target_source_status"] = {k: extracted[k] for k in ["rawtrace_status", "rawtrace_images", "rawtrace_reseq_images", "chip_status", "chip_original_fields"]}
    result["rawtrace_source_image_manifest"] = extracted["image_composition"]
    study = Path(config.get("csa_diagnostic_model_study", STUDY))
    feature_path, component_path = study / "training_dataset.parquet", study / "component_importance.csv"
    if component_path.is_file():
        result["input_source_hashes"][str(component_path)] = _sha(component_path)
    result["component_priority"] = _component_priority(component_path)
    for family in [*FAMILY_NAMES, *sorted(set(extracted["plugin_counts"]) - set(FAMILY_NAMES))]:
        n = extracted["plugin_counts"].get(family, 0)
        if family in FORBIDDEN_FAMILIES: status = "excluded_leakage_review"
        elif family in {"rawtrace", "chip_diagnostics"}: status = extracted["rawtrace_status" if family == "rawtrace" else "chip_status"]
        elif family == "rawtrace_reseq": status = "not_mixed_with_primary_rawtrace"
        else: status = "present_no_validated_case_metric_adapter" if n else "not_present"
        result["plugin_inventory"].append(dict(family=family, label=FAMILY_NAMES.get(family, "Unrecognized plugin family (hashed root " + family.removeprefix("unvalidated_plugin_") + ")"), members=n, status=status,
            interpretation="Inventory presence alone is not evidence of a cause or normal operation"))
    result["excluded_fields"] = [dict(feature="results_offset_pixel_in_range.mean", reason="case-sensitive global/subset count aliases merge; not a physical percentage"),
        dict(feature="results_edge_metrics_pixels_n.std", reason="region-count/geometry mixture; not a validated chip-damage metric")]
    policy = load_policy(project, config.get("outcome_reference_policy_overrides"))
    policy["time_policy"] = "prior_only"
    policy["minimum_physical_runs"] = MINIMUM_RUNS
    policy["require_outcome_qualified_reference"] = True
    policy["require_fields"] = list(dict.fromkeys([*policy["require_fields"], *SOURCES, "panel_signature", "dna_barcode_count", "rna_barcode_count"]))
    result["peer_policy"] = policy
    if not feature_path.is_file():
        result["warnings"].append("Frozen diagnostic-feature study unavailable: native images retained, but empirical metric comparisons unresolved.")
        result["summary"] = "Native CSA evidence extracted; compatible reference feature bank unavailable."
        return finish()
    schema = set(pq.read_schema(feature_path).names)
    top5_features = [row["feature_name"] for row in result["top5_ml_metrics"]]
    columns = [c for c in dict.fromkeys(["observation_id", "archive_id", *METRICS, *RENDER_FIELDS, *top5_features]) if c in schema]
    features = pd.read_parquet(feature_path, columns=columns)
    if features.observation_id.duplicated().any(): raise ValueError("Frozen diagnostic features have duplicate observation IDs")
    result["input_source_hashes"][str(feature_path)] = _sha(feature_path)
    table = load_outcome_table(project, policy)
    for path in [project / "csa_ml_dataset.parquet", project / "qpm_failure_examples/dna_rna_balance_by_run.csv",
                 project / "qpm_failure_examples/dna_rna_barcode_counts.csv", project / "outcome_reference_policy.json",
                 project / "reference_qualification_policy.json", ROOT / "qpm_reference_qualification.py"]:
        if path.is_file(): result["input_source_hashes"][str(path)] = _sha(path)
    overlap = table.observation_id.isin(features.observation_id)
    result["feature_bank_overlap"] = dict(project_observations=len(table), frozen_feature_observations=len(features), shared_observations=int(overlap.sum()))
    if "archive_id" in features: features = features.rename(columns={"archive_id": "frozen_feature_archive_id"})
    table = table.merge(features, on="observation_id", how="left", validate="one_to_one")
    if "frozen_feature_archive_id" in table:
        wrong_archive = table.frozen_feature_archive_id.notna() & table.frozen_feature_archive_id.ne(table.archive_id)
        table.loc[wrong_archive, [c for c in METRICS if c in table]] = np.nan
        result["feature_bank_overlap"]["archive_identity_mismatch_observations"] = int(wrong_archive.sum())
    counts = _reference_image_counts(_inventory_path(config))
    table = table.merge(counts, on="archive_id", how="left", validate="many_to_one")
    records, members, audit = [], [], []
    target_training = features[features.observation_id.eq(observation_id)]
    target_archive = table.loc[table.observation_id.eq(observation_id), "archive_id"]
    if (len(target_training) == 1 and len(target_archive) == 1
            and target_training.iloc[0].get("frozen_feature_archive_id") == target_archive.iloc[0]):
        frozen_target_values = target_training.iloc[0].to_dict()
    composition = {k: extracted["values"][k] for k in RENDER_FIELDS if k in extracted["values"]}
    if len(composition) == len(RENDER_FIELDS): composition[REFERENCE_IMAGE_COUNT] = extracted["rawtrace_images"]
    result["rawtrace_reference_count_source"] = str(_inventory_path(config))
    result["warnings"].append("RawTrace peer compatibility requires matching image-extension counts from the audited archive inventory plus image aspect-ratio/frame-count summaries, not exact per-image manifests; equal signatures do not verify identical plot layout/content. Image proxies are descriptive triage only.")
    for feature, definition in METRICS.items():
        value = extracted["values"].get(feature)
        source = extracted["source_fields"].get(feature, {})
        target_problem = None
        if definition["family"] == "rawtrace" and len(composition) != len(RENDER_FIELDS) + 1:
            value = None; target_problem = extracted["rawtrace_status"]
        if len(target_training) == 1 and value is not None:
            old = _finite(target_training.iloc[0].get(feature))
            if old is not None and not np.isclose(old, value, rtol=1e-6, atol=1e-8):
                target_problem = "fresh_vs_frozen_metric_mismatch"
                value = None
                result["warnings"].append(f"Fresh source and frozen feature disagree for {definition['label']}; comparison withheld.")
        comparison, member_rows, audit_rows = select_peer_measurements(table, observation_id, feature, value,
            policy["require_fields"] + policy["extra_match_columns"],
            composition=composition if definition["family"] == "rawtrace" else None,
            allow_cross_instrument=bool(policy.get("allow_cross_instrument", True)))
        if target_problem: comparison["status"] = target_problem
        comparison.update(definition, **source)
        records.append(comparison); members.extend(member_rows); audit.extend(audit_rows)
    result["metrics"] = records
    result["peer_audit_rows"] = len(audit)
    result["reference_vote_policy"] = "one_median_vote_per_physical_run_target_and_siblings_excluded"
    measured = [r for r in records if r["status"] == "available"]
    outliers = [r for r in measured if r["deviation"] != "within_empirical_range"]
    result["status"] = "diagnostic_clues_found" if outliers else "no_outlier_in_available_views" if measured else "unresolved"
    result["summary"] = (f"{len(measured)}/{len(records)} allowlisted metrics have adequate compatible history; "
        f"{len(outliers)} fall outside empirical peer ranges. These are diagnostic clues, not proven causes; missing views remain unresolved.")
    result["investigation_hypotheses"] = _investigation_hypotheses(records)
    for name, data in [("csa_diagnostic_metrics.csv", records), ("csa_diagnostic_peer_members.csv", members),
                       ("csa_diagnostic_peer_audit.csv", audit), ("csa_diagnostic_component_priority.csv", result["component_priority"]),
                       ("csa_diagnostic_plugin_inventory.csv", result["plugin_inventory"])]:
        path = output_dir / name
        pd.DataFrame(_safe(data)).to_csv(path, index=False)
        result["outputs"][name.removesuffix(".csv")] = str(path)
    result["plot_files"] = _plot(output_dir, records, members, result["component_priority"])
    for path in result["plot_files"]: result["outputs"][Path(path).stem] = path
    return finish()


def top5_metrics_html(result: dict) -> str:
    """Display model reliance and guarded per-case evidence in separate columns."""
    esc = lambda value: html.escape(str(value), quote=True)
    policy = result.get("top5_ml_policy", {})
    rows = result.get("top5_ml_metrics", [])
    page = "<div id='top-five-total-read-ml-metrics'><h3>Top five individual total-read ML metrics</h3>"
    page += "<p>The fixed global ranking uses held-out <strong>physical-run-grouped Elastic Net</strong> feature permutation importance, not five plugin-group names. Importance is the increase in held-out MAE after shuffling one feature. It is not this run's read loss, a correlation coefficient, an intervention effect, or proof of a cause. Correlated features can split or mask importance.</p>"
    if policy.get("status") != "available" or len(rows) != 5:
        return page + f"<p><strong>Ranking unresolved:</strong> {esc(policy.get('reason', 'Five supported individual-feature ranking records were not available. No substitute ranking or causal explanation is manufactured.'))}</p></div>"
    page += "<p>Intervals below are exploratory bootstrap intervals across outer folds—not physical-run or causal-effect confidence intervals. Individual-feature rank stability on unseen instruments has not been established by this table.</p>"
    page += "<div style='overflow-x:auto'><table class='data-table'><thead><tr><th>Rank</th><th>Individual feature / component</th><th>Global held-out importance</th><th>This run / source units</th><th>Case-specific evidence and limits</th><th>Source</th></tr></thead><tbody>"
    for record in rows:
        importance = record["heldout_mae_increase"] / 1e6
        importance_text = f"{importance:.3f}M reads MAE increase"
        low, high = record.get("importance_ci_low"), record.get("importance_ci_high")
        if low is not None and high is not None:
            importance_text += f"; exploratory fold interval {low / 1e6:.3f}–{high / 1e6:.3f}M"
        if record.get("outer_folds") is not None and record.get("positive_folds") is not None:
            importance_text += f"; positive in {int(record['positive_folds'])}/{int(record['outer_folds'])} outer folds"
        value = record.get("target_value")
        value_text = "Unresolved / withheld" if value is None else f"{value:.6g}"
        value_text += "; " + str(record.get("unit", "units unresolved"))
        if record.get("frozen_model_input_value") is not None:
            value_text += f". Retrospective model input: {record['frozen_model_input_value']:.6g}; not a new measurement."
        feature_html = f"<strong>{esc(record.get('label', record['feature_name']))}</strong><br><code>{esc(record['feature_name'])}</code><br>{esc(record['component'])}; Tier {esc(record['tier'])}"
        source = (f"Current source: {record.get('source_file', 'unresolved')}: {record.get('source_field', 'unresolved')}. "
                  f"Recorded ML feature provenance: {record.get('ml_source_file', 'unresolved')}: {record.get('ml_source_field', 'unresolved')}.")
        page += f"<tr><td>{record['rank']}</td><td style='max-width:290px;overflow-wrap:anywhere'>{feature_html}</td><td>{esc(importance_text)}</td><td>{esc(value_text)}</td><td><strong>{esc(record.get('case_status'))}</strong><br>{esc(record.get('case_evidence'))}</td><td style='max-width:230px;overflow-wrap:anywhere'>{esc(source)}</td></tr>"
    page += "</tbody></table></div><p><strong>Interpretation policy:</strong> analyzed lane count is Tier B adjustment, not a failure cause. Merged in-range counts and edge-region pixel counts remain uninterpretable as chip-health or loading percentages; they are listed because the frozen model used them, not endorsed as mechanisms. Separate validated pinned-pixel measurements below are additional evidence, not replacements for these ranked features.</p>"
    page += "<p><a href='csa_diagnostic_top5_ml_metrics.csv'>Exact top-five ML feature records and case-coverage CSV</a></p></div>"
    return page


def html_section(result: dict) -> str:
    """Self-contained HTML: native images and summary figures are embedded."""
    esc = lambda value: html.escape(str(value), quote=True)
    page = f"<section id='csa-low-performance-diagnostics'><h2>Part 2 — Total-read ML metrics and CSA evidence</h2><p><strong>Status:</strong> {esc(result.get('status', 'unresolved'))}. {esc(result.get('summary', ''))}</p>"
    page += "<p><strong>Global model evidence and this run's clues are separate.</strong> Chip diagnostics, RawTrace and context were leading total-read model components. Permutation effects are not simple correlations, per-run contributions, or causal shares of lost reads.</p>"
    if not result.get("triggered") or result.get("status") == "disabled": return page + "</section>"
    page += hypothesis_html(result.get("root_cause_assessment", {}))
    page += top5_metrics_html(result)
    source_status = result.get("target_source_status", {})
    if source_status:
        page += f"<p><strong>Target source coverage:</strong> RawTrace {esc(source_status.get('rawtrace_status'))} ({esc(source_status.get('rawtrace_images'))} parsed primary images; {esc(source_status.get('rawtrace_reseq_images'))} resequencing images); chip diagnostics {esc(source_status.get('chip_status'))}.</p>"
    page += "<div class='guard'><ul>" + "".join(f"<li>{esc(w)}</li>" for w in result.get("guardrails", GUARDRAILS)) + "</ul></div>"
    columns = [("label", "Metric"), ("target_value", "Target"), ("unit", "Unit"), ("peer_median", "Peer median"),
        ("peer_q05", "Peer 5th"), ("peer_q95", "Peer 95th"), ("reference_physical_runs", "Runs"),
        ("reference_mode", "Reference"), ("status", "Coverage"), ("deviation", "Descriptive finding")]
    page += "<h3>Case-specific measurements</h3><div style='overflow-x:auto'><table><thead><tr>" + "".join(f"<th>{label}</th>" for _, label in columns) + "</tr></thead><tbody>"
    for record in result.get("metrics", []):
        def fmt(value):
            if value is None: return "Unresolved / not available"
            return f"{value:.5g}" if isinstance(value, (float, int)) else str(value)
        page += "<tr>" + "".join(f"<td>{esc(fmt(record.get(key)))}</td>" for key, _ in columns) + "</tr>"
    page += "</tbody></table></div>"
    page += "<details><summary>Why a metric is testable or unresolved</summary><ul>"
    for metric in result.get("metrics", []):
        page += f"<li>{esc(metric.get('label'))}: missing required target metadata = {esc(metric.get('missing_target_fields') or 'none')}; per-tier measured coverage = {esc(metric.get('coverage_by_tier') or 'not available')}; compatible observations missing this metric = {esc(metric.get('peer_missing_observations'))}. Strictly prior runs only; each metric independently requires at least eight physical runs.</li>"
    page += "</ul></details>"
    page += "<h3>What to inspect next</h3><ul>"
    for clue in result.get("investigation_hypotheses", []):
        page += f"<li><strong>{esc(clue['evidence'])}</strong> {esc(clue['review'])} <em>{esc(clue['limitation'])}</em></li>"
    page += "</ul>"
    for path in result.get("plot_files", []):
        path = Path(path)
        if path.is_file(): page += f"<img style='max-width:100%;height:auto' src='{_embed(path)}' alt='{esc(path.stem)}'>"
    page += "<h3>Original RawTrace plots</h3><p>Original native images are local-region diagnostics. Inspect their shown axes; rendered-image proxy scores do not directly measure signal amplitude, SNR, physical loading, or transferred volume.</p>"
    images = result.get("native_images", [])
    if not images: page += "<p>Native RawTrace plots unavailable in this CSA. Missing is not normal.</p>"
    for image in images:
        path = Path(image["path"])
        if path.is_file():
            page += f"<figure style='display:inline-block;max-width:46%;vertical-align:top'><img style='width:100%;height:auto' src='{_embed(path)}' alt='Original RawTrace scientific plot'><figcaption>{esc(image['source_member'])}</figcaption></figure>"
    page += "<h3>Plugin coverage and exclusions</h3><ul>"
    for item in result.get("plugin_inventory", []):
        page += f"<li>{esc(item['label'])}: {item['members']} recognized archive members; {esc(item['status'])}.</li>"
    page += "</ul><p>TrueLoading, EdgeEffects, LaneDiagnostics and ReseqDiagnostics remain quarantined from model-based explanations. Merged in-range counts and numeric edge-region counts are not used as health percentages. Other present plugins without a validated case-metric adapter are not silently treated as normal. Unknown roots under an explicit plugins directory are inventoried as hashed names only; arbitrary archive directories are neither parsed nor claimed as covered.</p>"
    if result.get("warnings"):
        page += "<h3>Coverage and interpretation warnings</h3><ul>" + "".join(f"<li>{esc(w)}</li>" for w in result["warnings"]) + "</ul>"
    page += "<p><a href='csa_low_performance_manifest.json'>CSA diagnostic manifest and exact provenance</a></p></section>"
    return page
