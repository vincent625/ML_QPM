#!/usr/bin/env python3
"""Clone unchanged reference populations and pin a validated all-QPM model study."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import html
import json
from pathlib import Path
import shutil

from audit_expanded_reference_bank import regression_tests, activate
from build_qualified_reference_bank import nominal_registry
from qpm_reference_bank import MANIFEST, file_sha256

VERSION="all-qpm-volume-plugin-release-1.0.0"


def write(path,record):
    path.write_text(json.dumps(record,indent=2))


def release(source,output,study):
    source,output,study=[p.resolve() for p in [source,output,study]]
    if source==output or output.exists():raise ValueError("Preserve previous bank; new snapshot path must not exist")
    old=json.loads((source/MANIFEST).read_text())
    assert old["validation_status"]=="passed"
    for name,record in old["artifacts"].items():assert file_sha256(source/name)==record["sha256"]
    registry=nominal_registry(study)
    report=json.loads((study/"report_validation.json").read_text())
    assert report["status"]=="passed" and report["artifact_validation_sha256"]==registry["artifact_validation_sha256"]
    for name,value in report["artifact_sha256"].items():assert file_sha256(study/name)==value
    shutil.copytree(source,output)
    if (output/"nominal_model_registration.json").exists():
        shutil.copy2(output/"nominal_model_registration.json",output/"nominal_model_registration.json.inherited")
    write(output/"qpm_nominal_volume_model.json",registry)
    for name in ["reference_bank_validation.json","reference_bank_regression_tests.json","reference_bank_report.html"]:
        shutil.copy2(source/name,output/(name+".inherited"))
    # Run the current code tests before sealing or activating this new snapshot.
    regression_tests(output)
    tests=json.loads((output/"reference_bank_regression_tests.json").read_text())
    replaced={"qpm_nominal_volume_model.json","reference_bank_regression_tests.json","reference_bank_validation.json"}
    unchanged=[name for name in old["artifacts"] if name not in replaced]
    checks=dict(parent_artifact_hashes_verified=True,unchanged_reference_populations=all(file_sha256(output/name)==old["artifacts"][name]["sha256"] for name in unchanged),
        model_study_validated=True,current_software_regressions_passed=tests["status"]=="passed",
        no_settings_modified=True,actual_delivered_volume_prediction_not_validated=True)
    validation=dict(status="passed" if all(checks.values()) else "failed",version=VERSION,checks=checks,
        parent_bank=str(source),parent_manifest_sha256=file_sha256(source/MANIFEST),
        inherited_population_validation_sha256=file_sha256(output/"reference_bank_validation.json.inherited"),
        model_registry=registry,qualified_reference_population=old["qualification_summary"],
        tests_run=tests["tests_run"],validated_utc=datetime.now(timezone.utc).isoformat())
    write(output/"reference_bank_validation.json",validation)
    write(output/"all_qpm_volume_release.json",dict(version=VERSION,parent_bank=str(source),parent_manifest_sha256=file_sha256(source/MANIFEST),
        model_registry=registry,reference_populations_and_cutoffs_unchanged=True,source_collection_not_modified=True))
    manifest={**old,"bank_id":output.name,"version":VERSION,"parent_bank":str(source),
        "parent_manifest_sha256":file_sha256(source/MANIFEST),"created_utc":datetime.now(timezone.utc).isoformat(),
        "validation_status":validation["status"],"nominal_volume_study":str(study)}
    names=list(old["artifacts"])+["all_qpm_volume_release.json"]
    manifest["artifacts"]={name:dict(size_bytes=(output/name).stat().st_size,sha256=file_sha256(output/name)) for name in names}
    write(output/MANIFEST,manifest)
    write(output/"nominal_model_registration.json",dict(previous_manifest_sha256=file_sha256(source/MANIFEST),
        manifest_sha256=file_sha256(output/MANIFEST),registry=registry,reference_tables_unchanged=True,no_settings_modified=True))
    (output/"reference_bank_report.html").write_text(f'''<!doctype html><html><head><meta charset="utf-8"><title>All-QPM model release</title></head><body style="font:16px system-ui;color:#264653;max-width:1100px;margin:32px auto"><h1>New QPM nominal-volume model registry</h1><p>{html.escape(output.name)} · validation {validation['status']}</p><p>The historical waveform populations, read cutoffs and barcode screening are unchanged from the parent. This release replaces the narrow volume-model registry with the full audited-operation study.</p><p><a href="{html.escape(str(study/'qpm_all_volume_report.html'))}">Open complete volume-model study</a> · <a href="reference_bank_validation.json">Release validation</a> · <a href="reference_bank_report.html.inherited">Original reference population audit</a></p><p>Nominal-volume signatures are not independent measurements of delivered volume. No instrument setting is modified.</p></body></html>''')
    assert validation["status"]=="passed"
    print(json.dumps(dict(bank=str(output),status=validation["status"],reference_populations_unchanged=True,tests_run=tests["tests_run"])),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source",type=Path,required=True);p.add_argument("--output",type=Path,required=True);p.add_argument("--study",type=Path,required=True)
    p.add_argument("--activate-project",type=Path)
    args=p.parse_args();release(args.source,args.output,args.study)
    if args.activate_project:activate(args.output,args.activate_project)
