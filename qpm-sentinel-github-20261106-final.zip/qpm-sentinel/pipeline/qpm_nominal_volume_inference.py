"""Strictly scoped nominal-command recognition; never transfer metrology.

This optional interface does not enable the dropout plugin's actual-volume
claims. Saved models must originate from the local validated retraining study.
"""
from __future__ import annotations

import hashlib
import io
import json
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from qpm_trace_quality import er72_mask


@lru_cache(maxsize=4)
def _study_artifacts(study_path: str, artifact_signatures: tuple) -> dict:
    """One immutable snapshot per manifest/cohort/performance file signature."""
    study = Path(study_path)
    log_bytes = (study / "analysis_run_log.json").read_bytes()
    validation_bytes = (study / "artifact_validation.json").read_bytes()
    validation = json.loads(validation_bytes)
    if validation.get("status") != "passed":
        raise ValueError("study_artifacts_not_validated")
    cohort_bytes = (study / "training_cohort.parquet").read_bytes()
    performance_bytes = (study / "model_performance.csv").read_bytes()
    for name, content in [("analysis_run_log.json", log_bytes), ("training_cohort.parquet", cohort_bytes),
                          ("model_performance.csv", performance_bytes)]:
        if validation.get("artifact_sha256", {}).get(name) != hashlib.sha256(content).hexdigest():
            raise ValueError("nominal_study_artifact_hash_mismatch")
    training = pd.read_parquet(io.BytesIO(cohort_bytes))
    context_fields = ["pressure_unit", "container_geometry_fingerprint", "deck_geometry_fingerprint", "command_settings_fingerprint"]
    contexts, run_ids = {}, {}
    for task, group in training.groupby("task_id"):
        run_ids[task] = set(group.physical_run_id)
        columns = context_fields + ["programmed_volume_ul"]
        contexts[task] = set(tuple(row[:-1]) + (round(float(row[-1]), 3),)
                             for row in group[columns].dropna().itertuples(index=False, name=None))
    return dict(log=json.loads(log_bytes), performance=pd.read_csv(io.BytesIO(performance_bytes)),
                contexts=contexts, run_ids=run_ids, context_fields=context_fields, payloads={},
                log_sha256=hashlib.sha256(log_bytes).hexdigest(),
                validation_sha256=hashlib.sha256(validation_bytes).hexdigest())


class NominalVolumeRecognizer:
    """Batch interface: load/verify study once, then reuse scoped model payloads."""
    def __init__(self, study: Path, *, expected_log_sha256: str | None = None,
                 expected_validation_sha256: str | None = None):
        self.study = Path(study).resolve()
        self.all_operations_recognizer = None
        self.all_operations_format = False
        if json.loads((self.study / "analysis_run_log.json").read_text()).get("format_version") == "all-operations-nominal-v1":
            from qpm_all_volume_inference import AllQPMNominalRecognizer
            self.all_operations_recognizer = AllQPMNominalRecognizer(self.study,
                expected_log_sha256=expected_log_sha256,
                expected_validation_sha256=expected_validation_sha256)
            self.artifacts = self.all_operations_recognizer.artifacts
            self.all_operations_format = True
            return
        names = ["analysis_run_log.json", "artifact_validation.json", "training_cohort.parquet", "model_performance.csv"]
        signatures = []
        for name in names:
            info = (self.study / name).stat()
            signatures.append((name, info.st_mtime_ns, info.st_size))
        self.artifacts = _study_artifacts(str(self.study), tuple(signatures))
        for supplied, actual in [(expected_log_sha256, self.artifacts["log_sha256"]),
                                 (expected_validation_sha256, self.artifacts["validation_sha256"])]:
            if supplied is not None and supplied != actual:
                raise ValueError("nominal_volume_study_registry_hash_mismatch")

    def predict(self, operation: dict, *, kind: str = "regression") -> dict:
        if self.all_operations_recognizer is not None:
            return self.all_operations_recognizer.predict(operation, kind=kind)
        return predict_nominal_volume(self.study, operation, kind=kind, _artifacts=self.artifacts)

    def predict_many(self, operations, *, kind: str = "regression") -> list[dict]:
        if self.all_operations_recognizer is not None:
            return self.all_operations_recognizer.predict_many(operations, kind=kind)
        return [self.predict(operation, kind=kind) for operation in operations]


def predict_nominal_volume(study: Path, operation: dict, *, kind: str = "regression", _artifacts: dict | None = None) -> dict:
    """Recognize an in-scope nominal command from one audited 32-point curve.

    `operation` contains qpm_profile, liquid_class_index/fingerprint, operation,
    pipette, programmed_volume_ul, pressure_unit, physical_run_id and verified
    command/quality/context fields. Unknown/out-of-scope/in-sample cases abstain.
    """
    result = dict(status="unavailable", actual_volume_prediction_validated=False,
                  measured_transfer_deficit_ul=None, label_basis="nominal_command_not_measured_delivery")
    if kind not in {"classification", "regression"}:
        return {**result, "reason": "unknown_model_kind"}
    if er72_mask(pd.DataFrame([operation])).iloc[0]:
        return {**result, "reason": "Er72_operation_or_retry_excluded"}
    if (str(operation.get("qpm_waveform_eligible", "")).lower() not in {"true", "1", "1.0"}
            or operation.get("qpm_trace_quality_status") != "checked_no_er72"):
        return {**result, "reason": "trace_quality_unverified"}
    if operation.get("command_context_status") != "command_verified":
        return {**result, "reason": "command_context_unverified"}
    try:
        task_id = f"lc{int(operation['liquid_class_index'])}_{operation['operation']}"
        wave = np.asarray(operation["qpm_profile"], dtype=float)
    except (KeyError, ValueError, TypeError):
        return {**result, "reason": "invalid_operation_metadata"}
    if wave.shape != (32,) or not np.isfinite(wave).all():
        return {**result, "reason": "invalid_32_point_waveform"}
    study = Path(study)
    try:
        artifacts = _artifacts if _artifacts is not None else NominalVolumeRecognizer(study).artifacts
    except (OSError, ValueError, KeyError):
        return {**result, "reason": "study_artifacts_not_validated"}
    log = artifacts["log"]
    if log.get("format_version") == "all-operations-nominal-v1":
        from qpm_all_volume_inference import AllQPMNominalRecognizer
        recognizer = AllQPMNominalRecognizer.__new__(AllQPMNominalRecognizer)
        recognizer.study, recognizer.artifacts = Path(study), artifacts
        return recognizer.predict(operation, kind=kind)
    candidate = [row for row in log["models"] if row["task_id"] == task_id and row["kind"] == kind]
    if len(candidate) != 1:
        return {**result, "reason": "liquid_class_operation_outside_validated_study"}
    record = candidate[0]
    path = study / record["path"]
    key = (task_id, kind)
    if key not in artifacts["payloads"]:
        model_bytes = path.read_bytes()
        if hashlib.sha256(model_bytes).hexdigest() != record["sha256"]:
            return {**result, "reason": "model_hash_mismatch"}
        # Trusted local payload only; decode exactly the bytes just hashed.
        artifacts["payloads"][key] = joblib.load(io.BytesIO(model_bytes))
    payload = artifacts["payloads"][key]
    cohort = payload["cohort"]
    if operation.get("pipette") != cohort["pipette"] or operation.get("liquid_class_fingerprint") != cohort["liquid_class_fingerprint"]:
        return {**result, "reason": "pipette_or_full_liquid_class_definition_mismatch"}
    try:
        volume = float(operation["programmed_volume_ul"])
    except (KeyError, TypeError, ValueError):
        return {**result, "reason": "missing_nominal_volume_scope"}
    if not any(np.isclose(volume, value) for value in cohort["volumes_ul"]):
        return {**result, "reason": "nominal_volume_level_not_validated_no_interpolation_or_extrapolation"}
    if not operation.get("physical_run_id"):
        return {**result, "reason": "missing_physical_run_identity"}
    if operation.get("physical_run_id") in artifacts["run_ids"].get(task_id, set()):
        return {**result, "reason": "target_physical_run_present_in_model_training_use_heldout_predictions"}
    context = artifacts["context_fields"]
    for key in context:
        if not operation.get(key):
            return {**result, "reason": f"missing_{key}"}
    context_key = tuple(operation[key] for key in context) + (round(volume, 3),)
    if context_key not in artifacts["contexts"].get(task_id, set()):
        return {**result, "reason": "nominal_volume_unit_geometry_or_command_settings_combination_outside_training_scope"}
    performance = artifacts["performance"]
    measure = "balanced_accuracy" if kind == "classification" else "mae_ul"
    baseline = "Majority baseline" if kind == "classification" else "Median baseline"
    for scheme in ["grouped_run", "unseen_instrument", "chronological"]:
        table = performance[performance.task_id.eq(task_id) & performance.kind.eq(kind) & performance.scheme.eq(scheme)]
        selected = table[table.model.eq("Nested-selected procedure")]
        control = table[table.model.eq(baseline)]
        if len(selected) != 1 or len(control) != 1:
            return {**result, "reason": f"missing_{scheme}_validation"}
        selected_value, control_value = selected.iloc[0][measure], control.iloc[0][measure]
        if not np.isfinite(selected_value) or not np.isfinite(control_value):
            return {**result, "reason": f"nonfinite_{scheme}_validation"}
        gain = selected_value - control_value
        if not np.isfinite(gain):
            return {**result, "reason": f"nonfinite_{scheme}_validation"}
        if (gain <= 0 if kind == "classification" else gain >= 0):
            return {**result, "reason": f"no_baseline_improvement_in_{scheme}"}
    x = (wave - np.median(wave[:3])).reshape(1, -1)
    if "estimator" in payload:
        value = float(payload["estimator"].predict(x)[0])
    elif payload["model_name"] == "Robust template":
        values = np.unique(payload["training_commanded_volumes"])
        scores = []
        for level in values:
            members = payload["training_profiles"][payload["training_commanded_volumes"] == level]
            median = np.median(members, axis=0)
            scale = np.maximum(1.4826 * np.median(np.abs(members - median), axis=0), 5.)
            scores.append(np.sqrt(np.mean(((x - median) / scale) ** 2)))
        value = float(values[np.argmin(scores)])
    else:
        return {**result, "reason": "optional_distance_model_inference_not_enabled"}
    if not np.isfinite(value) or not min(cohort["volumes_ul"]) <= value <= max(cohort["volumes_ul"]):
        return {**result, "reason": "predicted_nominal_equivalent_outside_observed_range"}
    return {**result, "status": "nominal_recognition_only", "nominal_equivalent_volume_ul": value,
            "model_name": payload["model_name"], "task_id": task_id,
            "reason": "not_an_independent_measurement_of_delivered_volume_or_transfer_error"}
