#!/usr/bin/env python3
"""Auditable, fail-closed outcome qualification for historical QPM references.

The threshold applies to the lanes represented by one retained CSA's canonical
BaseCaller total, not to every physically active lane.  No totals are added
across archives: a combined-lane export and its sibling/reanalysis exports are
never independent evidence or extra reads.  Qualification is a user-defined
screen, not a declaration that an instrument or sample is fault-free.

This module is deliberately read-only unless ``write_qualification`` is called
explicitly.  In particular, loading a frozen reference bank does not alter it.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from typing import Any

import numpy as np
import pandas as pd

VERSION = "qpm-outcome-qualified-reference-1.1.0-gx8"
POLICY_FILENAME = "reference_qualification_policy.json"
TABLE_FILENAME = "csa_reference_qualification.csv"
MANIFEST_FILENAME = "csa_reference_qualification_manifest.json"
CHIP_COLUMN = "ion_params_00.chip_info_chip_type"
DEFAULT_POLICY = {
    "policy_version": "user-chip-lane-qualified-reference-20261027-1.1",
    "minimum_reads_per_lane": {"GX5": 12_500_000, "GX7": 25_000_000, "GX8": 25_000_000, "GX9": 50_000_000},
    "dropout_ratio_to_material_median": 0.15,
    "partial_imbalance_ratio_to_material_median": 0.40,
    "absolute_dropout_read_floor": 100.0,
    "overrepresentation_ratio_to_survivor_median": 2.5,
    "minimum_barcodes_per_present_material": 2,
    "require_all_known_sibling_observations_to_qualify": True,
}
CLASSIFIER_KEYS = (
    "dropout_ratio_to_material_median", "partial_imbalance_ratio_to_material_median",
    "absolute_dropout_read_floor", "overrepresentation_ratio_to_survivor_median",
)
_READONLY_CACHE: dict[tuple, tuple[pd.DataFrame, dict]] = {}


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_policy(project: Path | None = None, overrides: dict | None = None) -> dict:
    policy = {**DEFAULT_POLICY, "minimum_reads_per_lane": dict(DEFAULT_POLICY["minimum_reads_per_lane"])}
    if project is not None:
        path = Path(project) / POLICY_FILENAME
        if path.is_file():
            # An explicit frozen threshold map is authoritative in its
            # entirety. Do not inject newly approved chips into an old bank's
            # policy when interpreting its historical qualification results.
            policy.update(json.loads(path.read_text()))
    if overrides:
        policy.update(overrides)
    if set(policy) - set(DEFAULT_POLICY):
        raise ValueError("Unknown reference qualification policy fields")
    for chip, minimum in policy["minimum_reads_per_lane"].items():
        if chip not in {"GX5", "GX7", "GX8", "GX9"} or not np.isfinite(minimum) or minimum <= 0:
            raise ValueError("Invalid chip read criterion")
    minimum = policy["minimum_barcodes_per_present_material"]
    if isinstance(minimum, bool) or not isinstance(minimum, int) or minimum < 2:
        raise ValueError("At least two barcodes per present material are required to assess imbalance")
    if not (0 < policy["dropout_ratio_to_material_median"] <
            policy["partial_imbalance_ratio_to_material_median"] < 1):
        raise ValueError("Invalid material-aware barcode ratios")
    if policy["absolute_dropout_read_floor"] < 0 or policy["overrepresentation_ratio_to_survivor_median"] <= 1:
        raise ValueError("Invalid absolute or high-imbalance threshold")
    return policy


def normalize_chip_type(value: Any) -> str | None:
    if value is None or pd.isna(value):
        return None
    token = re.sub(r"[\s_-]+", "", str(value).upper())
    match = re.fullmatch(r"(?:GENEXUS)?GX([0-9]+)(?:V\d+(?:\.\d+)*)?", token)
    return f"GX{match[1]}" if match else None


def lane_tokens(value: Any) -> tuple[int, ...] | None:
    """Interpret an explicit analyzed-lane token; never infer from active lanes."""
    if value is None or pd.isna(value) or isinstance(value, (bool, np.bool_)):
        return None
    text = str(value).strip()
    # Pandas can serialize a numeric single-lane field as 1.0.
    if re.fullmatch(r"[1-4]\.0", text):
        text = text[:-2]
    match = re.fullmatch(r"(?:ChipLane|lane)?([1-4](?:_[1-4])*)", text, re.I)
    if not match:
        return None
    values = tuple(int(part) for part in match[1].split("_"))
    return tuple(sorted(values)) if len(values) == len(set(values)) else None


def _known_bool(values: pd.Series) -> pd.Series:
    tokens = values.astype(str).str.strip().str.lower()
    return tokens.map({"true": True, "1": True, "yes": True,
                       "false": False, "0": False, "no": False}).astype("boolean")


def classify_barcode_outcomes(barcodes: pd.DataFrame, config: dict | None = None) -> pd.DataFrame:
    """The plugin's exact DNA/RNA outcome algorithm, without positional mapping.

    This helper is also suitable for the plugin so screening and displayed
    barcode labels cannot acquire different definitions.  Supplied legacy
    ``apparent_dropout`` labels are never trusted as the full imbalance screen.
    """
    policy = {**DEFAULT_POLICY, **{k: v for k, v in (config or {}).items() if k in CLASSIFIER_KEYS}}
    # Callers often concatenate material/observation tables while retaining
    # overlapping pandas indices. Classification writes must remain row-local.
    target = barcodes.reset_index(drop=True).copy()
    for name, default in {"observation_id": "", "is_control": pd.NA,
                          "material_type": "UNKNOWN", "read_count": np.nan}.items():
        if name not in target:
            target[name] = default
    target["is_control"] = _known_bool(target["is_control"])
    target["read_count"] = pd.to_numeric(target["read_count"], errors="coerce")
    target.loc[~np.isfinite(target["read_count"]) | target["read_count"].lt(0), "read_count"] = np.nan
    target["material_type"] = target["material_type"].fillna("UNKNOWN").astype(str).str.upper().str.strip()
    target["outcome_class"] = "unresolved"
    target.loc[target["is_control"].fillna(False), "outcome_class"] = "control"
    target["relative_to_material_median"] = np.nan
    target["dropout_threshold_reads"] = np.nan
    target["apparent_dropout"] = False
    usable = (target["is_control"].eq(False).fillna(False) &
              target["material_type"].isin(["DNA", "RNA"]) & target["read_count"].notna())
    for _, group in target[usable].groupby(["observation_id", "material_type"], sort=False):
        median = float(group["read_count"].median())
        threshold = max(float(policy["absolute_dropout_read_floor"]),
                        float(policy["dropout_ratio_to_material_median"]) * median)
        partial = float(policy["partial_imbalance_ratio_to_material_median"]) * median
        target.loc[group.index, "relative_to_material_median"] = group["read_count"] / median if median > 0 else np.nan
        target.loc[group.index, "dropout_threshold_reads"] = threshold
        target.loc[group.index, "outcome_class"] = "surviving"
        nonlow = group.loc[group["read_count"].ge(max(threshold, partial)), "read_count"]
        high_reference = float(nonlow.median()) if len(nonlow) else np.nan
        if np.isfinite(high_reference) and high_reference > 0:
            high = group["read_count"] > float(policy["overrepresentation_ratio_to_survivor_median"]) * high_reference
            target.loc[group.index[high], "outcome_class"] = "overrepresented"
        target.loc[group.index[group["read_count"] < partial], "outcome_class"] = "partial_imbalance"
        dropout = group.index[group["read_count"] < threshold]
        target.loc[dropout, "outcome_class"] = "dropout"
        target.loc[dropout, "apparent_dropout"] = True
    target["path_status"] = np.where(
        target["outcome_class"].isin(["dropout", "partial_imbalance", "overrepresented"]), "failed",
        np.where(target["outcome_class"].eq("surviving"), "survivor", "unresolved"))
    return target


def _barcode_screen(group: pd.DataFrame, policy: dict) -> dict:
    if group.empty:
        return dict(noncontrol_barcode_count=0, dropout_barcode_count=0, partial_imbalance_barcode_count=0,
                    overrepresented_barcode_count=0, unresolved_barcode_count=0,
                    barcode_screen_status="unresolved", barcode_screen_reasons="no_planned_barcode_rows")
    known_control = group["is_control"].fillna(False)
    samples = group[~known_control]
    reasons = []
    if not len(samples):
        reasons.append("no_noncontrol_samples")
    if samples["is_control"].isna().any():
        reasons.append("unknown_control_status")
    unknown_material = ~samples["material_type"].isin(["DNA", "RNA"])
    if unknown_material.any():
        reasons.append("unknown_sample_material")
    if samples["read_count"].isna().any():
        reasons.append("missing_or_invalid_sample_read_counts")
    key = "planned_order" if "planned_order" in samples else "barcode_id" if "barcode_id" in samples else None
    if key and samples[key].duplicated().any():
        reasons.append("duplicate_planned_barcode_rows")
    for material, rows in samples[samples["material_type"].isin(["DNA", "RNA"])].groupby("material_type"):
        if len(rows) < policy["minimum_barcodes_per_present_material"]:
            reasons.append(f"{material.lower()}_imbalance_not_assessable_fewer_than_two_samples")
    counts = {kind: int(samples["outcome_class"].eq(kind).sum())
              for kind in ["dropout", "partial_imbalance", "overrepresented", "unresolved"]}
    failed = bool(sum(counts[k] for k in ["dropout", "partial_imbalance", "overrepresented"]))
    if failed:
        reasons.append("sample_dropout_or_imbalance")
    return dict(noncontrol_barcode_count=len(samples), dropout_barcode_count=counts["dropout"],
                partial_imbalance_barcode_count=counts["partial_imbalance"],
                overrepresented_barcode_count=counts["overrepresented"],
                unresolved_barcode_count=counts["unresolved"],
                barcode_screen_status="failed" if failed else "unresolved" if reasons else "passed",
                barcode_screen_reasons=";".join(dict.fromkeys(reasons)))


def build_reference_qualification(core: pd.DataFrame, barcodes: pd.DataFrame,
                                  policy: dict | None = None) -> pd.DataFrame:
    """Return one auditable qualification row per retained CSA observation.

    Bad/missing sibling observations veto the *historical physical run*, but do
    not change the target's own absolute low-read flag.  Cross-instrument and
    same-instrument references must both use ``reference_eligible``; target
    profiles must not be filtered by this field.
    """
    policy = load_policy(overrides=policy)
    required = {"observation_id", "physical_run_id", "chip_lane", "total_reads"}
    if not required <= set(core):
        raise ValueError("Core dataset lacks required qualification identifiers or outcomes")
    if core["observation_id"].duplicated().any() or core["observation_id"].isna().any():
        raise ValueError("Qualification requires unique nonmissing observation IDs")
    classified = classify_barcode_outcomes(barcodes, policy)
    groups = {key: rows for key, rows in classified.groupby("observation_id", sort=False)}
    rows = []
    for _, record in core.iterrows():
        chip = normalize_chip_type(record.get(CHIP_COLUMN, record.get("chip_type")))
        lanes = lane_tokens(record.get("chip_lane"))
        scope = record.get("analysis_lane_scope")
        scope = str(scope).strip().lower() if pd.notna(scope) else None
        expected_scope = "combined_multilane" if lanes and len(lanes) > 1 else "single_lane"
        scope_conflict = bool(scope not in {None, "", expected_scope})
        valid_scope = bool(lanes and not scope_conflict)
        reads = pd.to_numeric(pd.Series([record.get("total_reads")]), errors="coerce").iloc[0]
        valid_reads = bool(pd.notna(reads) and np.isfinite(reads) and reads >= 0)
        minimum = policy["minimum_reads_per_lane"].get(chip)
        threshold = minimum * len(lanes) if minimum is not None and valid_scope else np.nan
        criterion_known = bool(np.isfinite(threshold) and valid_reads)
        low = bool(reads < threshold) if criterion_known else pd.NA
        screen = _barcode_screen(groups.get(record["observation_id"], classified.iloc[:0]), policy)
        reasons = []
        if chip is None:
            reasons.append("unresolved_chip_type")
        elif minimum is None:
            reasons.append("chip_type_without_user_approved_read_criterion")
        if not lanes:
            reasons.append("unresolved_analyzed_lane_scope")
        if scope_conflict:
            reasons.append("conflicting_analysis_lane_scope")
        if not valid_reads:
            reasons.append("missing_or_invalid_total_reads")
        if criterion_known and low:
            reasons.append("below_chip_lane_total_read_criterion")
        if screen["barcode_screen_reasons"]:
            reasons.extend(screen["barcode_screen_reasons"].split(";"))
        local_pass = criterion_known and not low and screen["barcode_screen_status"] == "passed"
        failed = (criterion_known and low) or screen["barcode_screen_status"] == "failed"
        physical = record.get("physical_run_id")
        if pd.isna(physical) or str(physical).strip() == "":
            reasons.append("unresolved_physical_run_id")
            local_pass = False
        rows.append(dict(
            observation_id=record["observation_id"], physical_run_id=physical,
            archive_id=record.get("archive_id"), instrument_id=record.get("instrument_id"),
            chip_lane=record.get("chip_lane"), chip_type=chip,
            evaluated_lane_tokens="_".join(map(str, lanes)) if lanes else "",
            evaluated_lane_count=len(lanes) if valid_scope else np.nan,
            analysis_lane_scope=scope or (expected_scope if lanes else "unresolved"),
            analyzed_lane_scope_source="retained_CSA_analyzed_lane_token",
            scope_validation="analysis_token_only_not_full_run_active_lanes" if valid_scope else "unresolved",
            numerator_scope_note="One retained CSA canonical total over its analyzed lanes; active physical-run lanes may differ; no cross-archive sums.",
            total_reads_value=float(reads) if valid_reads else np.nan,
            total_reads_source_file=record.get("total_reads__source_file", "canonical_retained_dataset"),
            total_reads_source_field=record.get("total_reads__source_field", "total_reads"),
            total_reads_threshold=threshold,
            reads_fraction_of_threshold=float(reads / threshold) if criterion_known else np.nan,
            total_read_criterion_status="below_threshold" if criterion_known and low else "passed" if criterion_known else "unresolved",
            low_performance_trigger=low, **screen,
            observation_reference_eligible=bool(local_pass),
            observation_qualification_status="passed" if local_pass else "failed" if failed else "unresolved",
            observation_qualification_reasons=";".join(dict.fromkeys(reasons)),
            qualification_policy_version=policy["policy_version"], qualification_code_version=VERSION,
        ))
    result = pd.DataFrame(rows)
    if result.empty:
        return result
    result["low_performance_trigger"] = result["low_performance_trigger"].astype("boolean")
    result["reference_eligible"] = result["observation_reference_eligible"]
    result["qualification_status"] = result["observation_qualification_status"]
    result["qualification_reasons"] = result["observation_qualification_reasons"]
    result["known_physical_run_observations"] = 1
    result["physical_run_scope_notes"] = "Only retained, available observation scopes are known; missing uncollected lanes are not certified."
    for _, group in result.groupby("physical_run_id", dropna=False, sort=False):
        result.loc[group.index, "known_physical_run_observations"] = len(group)
        veto = []
        if group["chip_type"].dropna().nunique() > 1:
            veto.append("conflicting_chip_types_within_physical_run")
        # Identical positive totals on disjoint lane exports may be duplicated
        # whole-run values. Never silently count them as independent numerators.
        for _, identical in group[group.total_reads_value.gt(0)].groupby("total_reads_value"):
            sets = [set(lane_tokens(v) or ()) for v in identical.chip_lane]
            if any(a and b and a.isdisjoint(b) for i, a in enumerate(sets) for b in sets[i + 1:]):
                reason = "identical_total_reads_on_disjoint_lane_scopes_unresolved"
                veto.append(reason)
                # A suspected whole-run numerator repeated in separate lane
                # exports is not a passing per-lane outcome either.  Retain
                # the original value for audit, but withhold its absolute call.
                indices = identical.index
                result.loc[indices, "total_read_criterion_status"] = "unresolved"
                result.loc[indices, "low_performance_trigger"] = pd.NA
                result.loc[indices, "reads_fraction_of_threshold"] = np.nan
                result.loc[indices, "scope_validation"] = "unresolved_duplicated_total_read_numerator_on_disjoint_scopes"
                result.loc[indices, "observation_reference_eligible"] = False
                status = np.where(result.loc[indices, "barcode_screen_status"].eq("failed"), "failed", "unresolved")
                result.loc[indices, "observation_qualification_status"] = status
                result.loc[indices, "qualification_status"] = status
                for idx in indices:
                    result.loc[idx, "observation_qualification_reasons"] = ";".join(filter(None, [result.loc[idx, "observation_qualification_reasons"], reason]))
        group = result.loc[group.index]
        if (policy["require_all_known_sibling_observations_to_qualify"] and len(group) > 1
                and not group.observation_reference_eligible.all()):
            if group.observation_qualification_status.eq("failed").any():
                veto.append("physical_run_has_failed_sibling_observation")
            if group.observation_qualification_status.eq("unresolved").any():
                veto.append("physical_run_has_unresolved_sibling_observation")
        if veto:
            result.loc[group.index, "reference_eligible"] = False
            for idx in group.index:
                result.loc[idx, "qualification_reasons"] = ";".join(dict.fromkeys(filter(None, [*result.loc[idx, "observation_qualification_reasons"].split(";"), *veto])))
                if result.loc[idx, "qualification_status"] == "passed":
                    result.loc[idx, "qualification_status"] = "excluded_by_physical_run_guard"
    return result


def qualification_summary(table: pd.DataFrame) -> dict:
    if table.empty:
        return {"observations": 0, "reference_eligible_observations": 0, "reference_eligible_physical_runs": 0}
    eligible = table[table.reference_eligible]
    return {
        "observations": len(table),
        "physical_runs": int(table.physical_run_id.nunique()),
        "reference_eligible_observations": len(eligible),
        "reference_eligible_physical_runs": int(eligible.physical_run_id.nunique()),
        "reference_eligible_instruments": int(eligible.instrument_id.nunique()),
        "below_chip_lane_read_criterion": int(table.low_performance_trigger.fillna(False).sum()),
        "unresolved_chip_lane_read_criterion": int(table.low_performance_trigger.isna().sum()),
        "sample_dropout_or_imbalance_observations": int(table.barcode_screen_status.eq("failed").sum()),
        "unresolved_barcode_screen_observations": int(table.barcode_screen_status.eq("unresolved").sum()),
        "qualification_status_counts": {str(k): int(v) for k, v in table.qualification_status.value_counts().items()},
        "chip_type_counts": {str(k): int(v) for k, v in table.chip_type.value_counts(dropna=False).items()},
    }


def load_reference_qualification(project: Path, overrides: dict | None = None) -> tuple[pd.DataFrame, dict]:
    """Read inputs and build qualification; never modify a bank or a target view."""
    project = Path(project)
    policy = load_policy(project, overrides)
    core_path = project / "csa_ml_dataset.parquet"
    bars_path = project / "qpm_failure_examples" / "dna_rna_barcode_counts.csv"
    policy_hash = hashlib.sha256(_json(policy).encode()).hexdigest()
    def signature(path: Path) -> tuple:
        if not path.is_file():
            return (str(path.absolute()), None, None)
        status = path.stat()
        return (str(path.absolute()), status.st_size, status.st_mtime_ns)
    cache_key = (VERSION, signature(core_path), signature(bars_path), policy_hash)
    if cache_key in _READONLY_CACHE:
        table, metadata = _READONLY_CACHE[cache_key]
        # Callers may annotate their target view. Never let that annotation
        # mutate the cached historical qualification of another diagnostic.
        return table.copy(deep=True), json.loads(json.dumps(metadata))
    core = pd.read_parquet(core_path)
    barcodes = pd.read_csv(bars_path) if bars_path.is_file() else pd.DataFrame()
    frame = build_reference_qualification(core, barcodes, policy)
    metadata = {
        "version": VERSION, "policy": policy,
        "policy_sha256": policy_hash,
        "input_sha256": {"csa_ml_dataset.parquet": file_sha256(core_path),
                         "dna_rna_barcode_counts.csv": file_sha256(bars_path) if bars_path.is_file() else None},
        "code_sha256": file_sha256(Path(__file__)),
        "summary": qualification_summary(frame),
        "scope_warning": "Thresholds are evaluated on each retained CSA's analyzed lanes. Physical-run active lanes are not substituted and archived totals are never summed.",
        "interpretation": "User-defined outcome-qualified historical reference, not confirmed fault-free controls. Applies only to historical references, never to whether a target can be diagnosed or to predictive-model training inclusion.",
        "created_utc": datetime.now(timezone.utc).isoformat(),
    }
    if len(_READONLY_CACHE) >= 4:
        _READONLY_CACHE.pop(next(iter(_READONLY_CACHE)))
    _READONLY_CACHE[cache_key] = (frame.copy(deep=True), json.loads(json.dumps(metadata)))
    return frame, metadata


def write_qualification(output: Path, table: pd.DataFrame, metadata: dict) -> None:
    """Explicit writer for a new versioned bank/report directory only."""
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    temporary = output / (TABLE_FILENAME + ".partial")
    table.to_csv(temporary, index=False)
    temporary.replace(output / TABLE_FILENAME)
    metadata = {**metadata, "table_sha256": file_sha256(output / TABLE_FILENAME)}
    temporary = output / (MANIFEST_FILENAME + ".partial")
    temporary.write_text(json.dumps(metadata, indent=2, allow_nan=False))
    temporary.replace(output / MANIFEST_FILENAME)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    table, metadata = load_reference_qualification(args.project)
    write_qualification(args.output, table, metadata)
    print(json.dumps(metadata["summary"], indent=2))


if __name__ == "__main__":
    main()
