"""Low-outcome triggers, physical-reference shared-path scans, and volume proxies.

Volume labels in the existing ML study are commanded volumes, not independently
measured aspiration/dispense volumes. Never expose a proxy as delivered volume.
"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from qpm_trace_quality import QUALITY_FIELDS, eligible_waveforms

VERSION = "qpm-diagnostic-extensions-1.3.0-all-qpm-volume"


def diagnostic_trigger(lineage: pd.DataFrame, outcomes: pd.DataFrame, config: dict,
                       read_criterion: dict | None = None) -> dict:
    samples = lineage.loc[~lineage["is_control"]]
    dropout = bool(samples["outcome_class"].eq("dropout").any())
    imbalance = bool(samples["outcome_class"].isin(["partial_imbalance", "overrepresented"]).any())
    low = []
    for row in outcomes.to_dict("records"):
        boundary = row.get("reference_q05") if config["low_performance_reference"] == "q05" else row.get("reference_median")
        value = row.get("target_value")
        if row.get("status") == "available" and pd.notna(value) and pd.notna(boundary) and value < boundary:
            low.append(row["outcome"])
    reasons = (["barcode_dropout"] if dropout else []) + (["barcode_imbalance"] if imbalance else [])
    if low:
        reasons.append("low_peer_relative_performance")
    criterion = read_criterion or {"qualification_status": "not_evaluated",
                                   "low_performance_trigger": False}
    # This absolute, user-specified criterion does not depend on finding any
    # protocol peers. Missing chip/lane/outcome information is not a pass.
    low_flag = criterion.get("low_performance_trigger", False)
    absolute_low = bool(low_flag) if pd.notna(low_flag) else False
    if absolute_low:
        reasons.append("below_chip_lane_total_read_criterion")
    return {"run_qpm": bool(reasons), "reasons": reasons, "low_outcomes": low,
            "has_dropout": dropout, "has_imbalance": imbalance,
            "below_chip_lane_read_criterion": absolute_low,
            "chip_lane_read_criterion": criterion,
            "performance_boundary": config["low_performance_reference"],
            "missing_outcome_reference_is_not_normal": bool(outcomes["status"].ne("available").any())}


def shared_reference_scan(scores: pd.DataFrame, config: dict) -> pd.DataFrame:
    """Label physical-reference scores without inheriting outcome-peer filters."""
    scores = eligible_waveforms(scores)
    if scores.empty:
        return pd.DataFrame(columns=["operation_id", "operation_index", "operation", "pipette", "programmed_volume_ul",
                                     "liquid_class_index", "workflow_stage", "process_step", "location", "matched_reference_level",
                                     "reference_physical_runs", "qpm_shape_score", "qpm_anomaly_percentile",
                                     "outside_90pct_envelope_fraction", "reference_time_policy", "container_geometry_name",
                                     "liquid_class_name", "evidence_role", "interpretation"])
    scores = scores.sort_values("operation_index").reset_index(drop=True)
    evidence = scores[["operation_id", "operation_index", "operation", "pipette", "programmed_volume_ul", "liquid_class_index",
                       "workflow_stage", "process_step", "location", "matched_reference_level", "reference_physical_runs",
                       "qpm_shape_score", "qpm_anomaly_percentile", "outside_90pct_envelope_fraction",
                       "reference_time_policy", "container_geometry_name", "liquid_class_name"]
                      + [key for key in QUALITY_FIELDS if key in scores]].copy()
    positive = (evidence["qpm_anomaly_percentile"].ge(config["shared_reference_minimum_percentile"])
                & evidence["outside_90pct_envelope_fraction"].ge(config["shared_reference_minimum_outside_fraction"]))
    evidence["evidence_role"] = np.where(positive, "later_reference_anomaly", "not_reference_positive")
    if positive.any():
        evidence.loc[evidence.index[positive][0], "evidence_role"] = "earliest_reference_deviation"
    evidence["interpretation"] = "exploratory_reference_only_not_barcode_selective_not_causal"
    return evidence


def _dtw_predict(x_train: np.ndarray, y_train: np.ndarray, queries: np.ndarray) -> np.ndarray:
    """Rectangular version of the existing radius-3, weighted DTW 5-NN model."""
    output = []
    for query in queries:
        previous = np.full((len(x_train), len(query) + 1), np.inf)
        previous[:, 0] = 0
        for i in range(1, len(query) + 1):
            current = np.full_like(previous, np.inf)
            for j in range(max(1, i - 3), min(len(query), i + 3) + 1):
                cost = (x_train[:, j - 1] - query[i - 1]) ** 2
                current[:, j] = cost + np.minimum(np.minimum(previous[:, j], current[:, j - 1]), previous[:, j - 1])
            previous = current
        distances = np.sqrt(previous[:, len(query)] / len(query))
        nearest = np.argsort(distances)[:5]
        weights = 1 / np.maximum(distances[nearest], 1e-6)
        votes = {volume: float(weights[y_train[nearest] == volume].sum()) for volume in np.unique(y_train)}
        output.append(max(votes, key=lambda volume: (votes[volume], -volume)))
    return np.asarray(output, dtype=float)


def add_volume_proxies(project: Path, operations: pd.DataFrame, target_id: str,
                       config: dict) -> tuple[pd.DataFrame, dict]:
    """Infer supported *waveform-equivalent commanded* volume only.

    Hash-pinned registries support their separately validated waveform scope.
    Legacy aggregate classifiers are not silently restored for corrected labels.
    No direction or delta may be presented as measured over/under delivery.
    """
    frame = operations.copy()
    for column in ["waveform_equivalent_volume_ul", "equivalent_volume_delta_ul", "equivalent_volume_delta_pct",
                   "aggregate_validation_accuracy", "aggregate_validation_mae_ul"]:
        frame[column] = np.nan
    frame["volume_proxy_status"] = "not_evaluated"
    frame["volume_proxy_model"] = "none"
    frame["volume_proxy_task_id"] = "none"
    frame["volume_proxy_context_training_runs"] = np.nan
    frame["volume_proxy_direction"] = "unresolved"
    frame["volume_proxy_validation_mae_ul"] = np.nan
    frame["volume_proxy_within_10pct_agreement"] = np.nan
    frame["volume_proxy_level_assignment_accuracy"] = np.nan
    frame["volume_proxy_outside_training_envelope_fraction"] = np.nan
    frame["volume_proxy_error_scale_relation"] = "unresolved"
    frame["delivered_volume_status"] = "not_identifiable_without_measured_volume_calibration"
    metadata = {"version": VERSION, "label_basis": "programmed_volume_not_measured_delivery",
                "inference_scope": "single_operation_exploratory_aggregate_model_domain_transfer",
                "selection_basis": "previous_posthoc_leave_one_instrument_out_classifier_comparison",
                "training_policy": "prior_only_exclude_target_physical_run", "models": [],
                "warning": "No continuous-volume calibration, delivered-volume error, or individual-operation accuracy has been established."}
    if frame.empty or not config["enable_volume_proxy"]:
        return frame, metadata
    registry = project / "qpm_nominal_volume_model.json"
    if registry.is_file():
        # A trusted local, hash-pinned study can recognize the nominal command
        # of a disjoint, fully in-scope operation. This is NOT a transfer-volume
        # measurement and is never used to establish the cause of a failure.
        from qpm_nominal_volume_inference import NominalVolumeRecognizer
        metadata.update(inference_scope="audited_single_waveform_nominal_recognition_only",
                        selection_basis="nested_physical_run_model_family_selection",
                        training_policy="retrospective_training_target_physical_run_must_be_disjoint",
                        actual_delivered_volume_validated=False, registry_sha256=hashlib.sha256(registry.read_bytes()).hexdigest())
        metadata["warning"] = "Retrained QPM models recognize nominal programmed-volume signatures only. A mismatch is not a measured over/under-transfer amount; unsupported settings, in-training target runs and failed validation abstain."
        try:
            selected = json.loads(registry.read_text())
            recognizer = NominalVolumeRecognizer(Path(selected["study_path"]),
                expected_log_sha256=selected["analysis_run_log_sha256"],
                expected_validation_sha256=selected["artifact_validation_sha256"])
            metadata["study_path"] = selected["study_path"]
            metadata["format_version"] = recognizer.artifacts.get("log", {}).get("format_version", "legacy_nominal_single_operation")
            metadata["attempted_operations"] = len(frame)
            metadata["target_operation_scope"] = "all_quality_cleared_target_operations_from_raw_profiles"
            pending_indices, pending_operations = [], []
            for index, row in frame.iterrows():
                operation = row.to_dict()
                value = operation.get("observed_profile", operation.get("qpm_profile"))
                try:
                    operation["qpm_profile"] = ast.literal_eval(value) if isinstance(value, str) else value
                except (SyntaxError, ValueError, TypeError):
                    frame.loc[index, "volume_proxy_status"] = "withheld_invalid_waveform"
                    continue
                pending_indices.append(index)
                pending_operations.append(operation)
            predictions = (recognizer.predict_many(pending_operations)
                if getattr(recognizer, "all_operations_format", False) is True
                else [recognizer.predict(operation) for operation in pending_operations])
            if len(predictions) != len(pending_indices):
                raise ValueError("nominal_batch_prediction_count_mismatch")
            for index, prediction in zip(pending_indices, predictions):
                frame.loc[index, "volume_proxy_status"] = prediction["status"] + ":" + prediction.get("reason", "")
                if prediction["status"] != "nominal_recognition_only":
                    continue
                value = prediction["nominal_equivalent_volume_ul"]
                nominal = float(frame.loc[index, "programmed_volume_ul"])
                frame.loc[index, "waveform_equivalent_volume_ul"] = value
                frame.loc[index, "equivalent_volume_delta_ul"] = value - nominal
                frame.loc[index, "equivalent_volume_delta_pct"] = (value - nominal) / nominal * 100
                frame.loc[index, "volume_proxy_model"] = prediction["model_name"]
                frame.loc[index, "volume_proxy_task_id"] = prediction.get("task_id", "legacy_scoped_task")
                frame.loc[index, "volume_proxy_context_training_runs"] = prediction.get("exact_context_training_physical_runs", np.nan)
                frame.loc[index, "volume_proxy_direction"] = ("lower_nominal_signature" if value < nominal else
                    "higher_nominal_signature" if value > nominal else "nominal_signature_match")
                mae = prediction.get("validation_mae_ul", np.nan)
                frame.loc[index, "volume_proxy_validation_mae_ul"] = mae
                frame.loc[index, "aggregate_validation_mae_ul"] = mae
                frame.loc[index, "volume_proxy_within_10pct_agreement"] = prediction.get("validation_within_10pct", np.nan)
                frame.loc[index, "volume_proxy_level_assignment_accuracy"] = prediction.get("validation_nominal_level_accuracy", np.nan)
                frame.loc[index, "volume_proxy_outside_training_envelope_fraction"] = prediction.get("waveform_outside_training_98pct_fraction", np.nan)
                if np.isfinite(mae):
                    frame.loc[index, "volume_proxy_error_scale_relation"] = ("within_heldout_MAE_scale" if abs(value-nominal) <= mae
                        else "larger_than_heldout_MAE_not_proof_of_delivery_error")
            metadata["predicted_operations"] = int(frame.waveform_equivalent_volume_ul.notna().sum())
            metadata["status_counts"] = frame.volume_proxy_status.value_counts().to_dict()
        except (ValueError, KeyError, TypeError, OSError) as exc:
            # Never restore the old, mislabelled LC models after an invalid
            # registry or an incompletely validated new study.
            frame["volume_proxy_status"] = "withheld_invalid_nominal_model_registry"
            frame["waveform_equivalent_volume_ul"] = np.nan
            frame["equivalent_volume_delta_ul"] = np.nan
            frame["equivalent_volume_delta_pct"] = np.nan
            frame["volume_proxy_direction"] = "unresolved"
            frame["volume_proxy_model"] = "none"
            frame["volume_proxy_task_id"] = "none"
            frame["volume_proxy_context_training_runs"] = np.nan
            for field in ["volume_proxy_validation_mae_ul", "aggregate_validation_mae_ul", "volume_proxy_within_10pct_agreement",
                          "volume_proxy_level_assignment_accuracy", "volume_proxy_outside_training_envelope_fraction"]:
                frame[field] = np.nan
            frame["volume_proxy_error_scale_relation"] = "unresolved"
            metadata["registry_error"] = type(exc).__name__
        return frame, metadata
    if "command_context_status" in frame:
        # The old classifiers were trained on inherited LC metadata. Some GD
        # commands use a different LC: those labels must be audited/retrained
        # before transferring a classifier to command-corrected operations.
        frame["volume_proxy_status"] = "withheld_legacy_liquid_class_training_labels_unverified"
        metadata["warning"] += " Existing volume classifiers used legacy inherited liquid-class labels; predictions are withheld pending command-label audit and revalidation."
        return frame, metadata
    import compare_qpm_classes_operations as comparison
    from compare_qpm_models import estimator_factory
    comparison.PROJECT = project
    registry = project / "qpm_class_operation_comparison" / "qpm_class_operation_best_models.csv"
    validation_path = project / "qpm_class_operation_comparison" / "qpm_class_operation_predictions.csv"
    if not registry.is_file() or not validation_path.is_file():
        frame["volume_proxy_status"] = "validation_registry_unavailable"
        metadata["warning"] += " Prior model-validation registry missing; all volume proxies withheld."
        return frame, metadata
    metadata["model_selection_and_validation_sha256"] = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in [registry, validation_path]
    }
    best = pd.read_csv(registry)
    validation = pd.read_csv(validation_path)
    table = pd.read_parquet(project / "csa_ml_dataset.parquet", columns=["observation_id", "physical_run_id", "run_start_time"])
    target_rows = table[table["observation_id"].eq(target_id)]
    if len(target_rows) != 1:
        raise ValueError("Volume proxy target must resolve uniquely")
    target = target_rows.iloc[0]
    target_time = pd.to_datetime(target["run_start_time"], utc=True, errors="coerce")
    for (liquid_class, operation, pipette), group in frame.groupby(["liquid_class_index", "operation", "pipette"], dropna=False):
        selected = best[best["liquid_class_index"].eq(liquid_class) & best["operation"].eq(operation)]
        if selected.empty or pipette != "PIP2":
            frame.loc[group.index, "volume_proxy_status"] = "unsupported_liquid_class_operation_or_pipette"
            continue
        winner = selected.iloc[0]
        volumes = [int(value) for value in winner["volumes_ul"].split(";")]
        supported = group[group["programmed_volume_ul"].isin(volumes)]
        frame.loc[group.index, "volume_proxy_model"] = winner["model"]
        frame.loc[group.index, "volume_proxy_status"] = "programmed_volume_not_in_validated_levels"
        if supported.empty:
            continue
        training, _, _ = comparison.load_task(int(liquid_class), str(operation))
        dates = pd.to_datetime(training["run_start_time"], utc=True, errors="coerce")
        training = training[~training["physical_run_id"].eq(target["physical_run_id"]) & dates.lt(target_time)].copy()
        counts = training.groupby("programmed_volume_ul")["physical_run_id"].nunique()
        if any(counts.get(volume, 0) < config["minimum_volume_training_runs_per_level"] for volume in volumes):
            frame.loc[supported.index, "volume_proxy_status"] = "insufficient_prior_volume_training_runs"
            continue
        profiles = []
        good_indices = []
        for index, row in supported.iterrows():
            value = row["observed_profile"]
            profile = np.asarray(ast.literal_eval(value) if isinstance(value, str) else value, dtype=float)
            if len(profile) == 32 and np.isfinite(profile).all():
                profiles.append(profile - np.median(profile[:3]))
                good_indices.append(index)
            else:
                frame.loc[index, "volume_proxy_status"] = "invalid_waveform"
        if not profiles:
            continue
        x_train = comparison.baseline_correct(training)
        y_train = training["programmed_volume_ul"].to_numpy(int)
        queries = np.vstack(profiles)
        if winner["model"] == "DTW 5-NN":
            prediction = _dtw_predict(x_train, y_train, queries)
        else:
            model = estimator_factory(winner["model"])
            model.fit(x_train, y_train)
            prediction = model.predict(queries).astype(float)
        nominal = frame.loc[good_indices, "programmed_volume_ul"].to_numpy(float)
        frame.loc[good_indices, "waveform_equivalent_volume_ul"] = prediction
        frame.loc[good_indices, "equivalent_volume_delta_ul"] = prediction - nominal
        frame.loc[good_indices, "equivalent_volume_delta_pct"] = (prediction - nominal) / nominal * 100
        frame.loc[good_indices, "volume_proxy_direction"] = np.where(prediction < nominal, "under_volume_like", np.where(prediction > nominal, "over_volume_like", "nominal_volume_like"))
        frame.loc[good_indices, "volume_proxy_status"] = "exploratory_single_operation_not_delivery_estimate"
        errors = validation[(validation["task_id"] == winner["task_id"]) & (validation["model"] == winner["model"])
                            & (validation["validation_scheme"] == "leave_one_instrument_out")
                            & ~validation["physical_run_id"].eq(target["physical_run_id"])]
        mae = float((errors["predicted_volume_ul"] - errors["programmed_volume_ul"]).abs().mean())
        frame.loc[good_indices, "aggregate_validation_accuracy"] = winner["accuracy"]
        frame.loc[good_indices, "aggregate_validation_mae_ul"] = mae
        metadata["models"].append({"task": winner["task_id"], "model": winner["model"], "supported_volumes_ul": volumes,
                                   "prior_training_physical_runs": int(training["physical_run_id"].nunique()),
                                   "prior_training_profiles": len(training), "aggregate_validation_accuracy": float(winner["accuracy"]),
                                   "aggregate_validation_mae_ul": mae})
    return frame, metadata


def volume_annotation(group: pd.DataFrame) -> str:
    if "waveform_equivalent_volume_ul" not in group:
        return "ML volume: not evaluated"
    usable = group[group["waveform_equivalent_volume_ul"].notna()]
    if usable.empty:
        statuses = sorted(group["volume_proxy_status"].dropna().unique())
        reason = "LC/operation/PIP unsupported" if any("unsupported" in status for status in statuses) else "volume/training not validated"
        return f"ML volume: withheld ({reason})"
    predicted = float(usable["waveform_equivalent_volume_ul"].median())
    delta = float(usable["equivalent_volume_delta_ul"].median())
    qualifier = f"Median of {len(usable)} individual signatures" if len(usable) > 1 else "Nominal-signature proxy"
    note = f"{qualifier}: {predicted:.1f} µL; Δ {delta:+.1f} µL vs command"
    if "aggregate_validation_mae_ul" in usable and usable.aggregate_validation_mae_ul.notna().any():
        note += f"\nTask held-out MAE {float(usable.aggregate_validation_mae_ul.median()):.1f} µL (not an individual CI)"
    return note + "\nNOT measured delivered volume or transfer error"
