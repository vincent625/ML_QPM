#!/usr/bin/env python3
"""Leakage-guarded multimodal diagnostic models from Genexus CSA archives.

The pipeline extracts per-operation QPM waves from CSA/debug, every vacuum-log
step, spatial NucStep measurements, lib-prep telemetry, and numeric/visual
descriptors from plugin results.  It predicts run outcomes only as a post-run
diagnostic exercise.  It does not treat diagnostic importance as evidence that
an instrument setting should be changed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import io
import json
import math
import os
import re
import sys
import tarfile
import time
import warnings
import zipfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, BinaryIO, Iterable, Iterator

import joblib
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from qpm_trace_quality import TraceQualityTracker
from PIL import Image, ImageSequence
from scipy import stats
from scipy.fft import dct
from sklearn.base import clone
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.feature_selection import SelectPercentile, VarianceThreshold, f_regression
from sklearn.impute import SimpleImputer
from sklearn.linear_model import ElasticNet
from sklearn.compose import TransformedTargetRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


SEED = 20260925
VERSION = "csa-multimodal-diagnostic-1.2-command-context"
PROFILE_POINTS = 32
SEQUENCE_POINTS = 16
MAX_PLUGIN_MEMBER_BYTES = 10_000_000
PALETTE = {
    "forest": "#31572c", "leaf": "#4f772d", "moss": "#90a955",
    "sand": "#e9c46a", "clay": "#bc6c25", "water": "#457b9d",
    "ink": "#253237", "mist": "#f4f1de", "rose": "#b56576",
}

SPATIAL_RE = re.compile(
    r"^CSA/outputs/SigProcActor-00/block_X(?P<x>\d+)_Y(?P<y>\d+)/"
    r"NucStep/NucStep_(?P<location>inlet|middle|outlet)_step\.txt$", re.I,
)
PIP_OP_RE = re.compile(r"\bin PIP\.(Aspirate|Dispense) id\s*=\s*(\d+) vol\s*=\s*([-+\d.]+)", re.I)
LIQUID_CLASS_RE = re.compile(r"\b(?:Aspirate|Dispense):\s*cgi=(\d+)\s+dgi=(\d+)\s+lci=(\d+)", re.I)
SEND_RE = re.compile(r"PipSndV1 id:(\d+),pipCmd:(GA|GD|RX)id(\d+)(.*)", re.I)
RX_RE = re.compile(r"pipette recv id\s*=\s*(\d+),\s*ret\s*=\s*RXid(\d+)rx([-+\d]+)\s+(.+)$", re.I)
COMPLETE_RE = re.compile(r"\b(Aspirate|Dispense): totalTime\s*=\s*([-+\d.]+).*?elapsedTime\s*=\s*([-+\d.]+)", re.I)
PROCESS_RE = re.compile(r"#Process\s+(.+?)(?:\.|$)", re.I)
EXP_DETAIL_RE = re.compile(r"ExpDetail:\s*(.+?)\s*$", re.I)
RAW_ACCURACY_RE = re.compile(
    r"raw[\s_\-]*read[\s_\-]*accuracy[^\d]{0,40}(\d+(?:\.\d+)?)\s*%?", re.I,
)
TARGET_LEAKAGE_RE = re.compile(
    r"(?:total|final|library)[_\s.-]*reads?|mean[_\s.-]*read[_\s.-]*length|"
    r"raw[_\s.-]*read[_\s.-]*accuracy|aq20[_\s.-]*mean[_\s.-]*read[_\s.-]*length|"
    r"read[_\s.-]*count|num[_\s.-]*reads?|read[_\s.-]*length[_\s.-]*hist|"
    r"q20[_\s.-]*mean[_\s.-]*read|q20[_\s.-]*mrl|read[_\s.-]*density|"
    r"read[_\s.-]*bead|rl[_\s.-]*histogram|read[_\s.-]*(?:len|length)|"
    r"q20[_\s.-]*bases?|(?:total|num)[_\s.-]*bases?|base[_\s.-]*count|"
    r"(?:mapped|filtered|valid|bcmatch)[_\s.-]*reads?|ionstats[_\s.-]*alignment|"
    r"(?:^|[_./-])rra(?:[_./-]|$)", re.I,
)
# Some CSA/plugin fields use product-specific names rather than the public
# outcome labels.  These are still direct outcome values or deterministic
# derivatives and must not enter a diagnostic predictor.
OUTCOME_PROXY_RE = re.compile(
    r"(?:^|[._/-])(?:lib[_-]?valid|full[_-]?num[_-]?reads?|num[_-]?reads?|"
    r"reads?|q\d+[_-]?reads?|aq\d+[_-]?reads?)(?:[._/-]|$)|"
    r"(?:^|[._/-])(?:base[_-]?details|qv[_-]?histogram|"
    r"read[_-]?group[_-]?metrics)(?:[._/-]|$)|"
    r"key[^.]*count[_-]?array|"
    r"(?:^|[._/-])(?:q\d+[_-]?num[_-]?bases?|num[_-]?bases?|"
    r"total[_-]?bases?|base[_-]?count)(?:[._/-]|$)|"
    r"(?:raw|local)[._/-]*accuracy|"
    r"(?:aq\d+|q\d+|nomatch)[^./]*[._/-]length|"
    r"read[^./]*[._/-]length|length[^./]*[._/-]read",
    re.I,
)
SENSITIVE_RE = re.compile(
    r"password|passwd|credential|secret|token|api[_-]?key|patient|operator|"
    r"username|network|hostname|ip[_-]?address|serial[_-]?number", re.I,
)
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".tif", ".tiff", ".bmp"}
STRUCTURED_EXTENSIONS = {".json", ".csv"}
TEXT_EXTENSIONS = {".txt", ".html", ".htm", ".svg", ".log"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def stable_id(*parts: Any, prefix: str = "") -> str:
    text = "|".join("" if x is None else str(x) for x in parts)
    return prefix + hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:16]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalize_name(value: Any, max_length: int = 90) -> str:
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(value))
    text = re.sub(r"[^a-zA-Z0-9]+", "_", text).strip("_").lower()
    text = re.sub(r"\d{4,}", "n", text)
    if len(text) > max_length:
        text = text[:70] + "_" + hashlib.sha1(text.encode()).hexdigest()[:12]
    return text or "unnamed"


def safe_float(value: Any) -> float:
    try:
        result = float(str(value).strip())
        return result if np.isfinite(result) else np.nan
    except (TypeError, ValueError):
        return np.nan


def quantile(values: np.ndarray, q: float) -> float:
    clean = np.asarray(values, dtype=float)
    clean = clean[np.isfinite(clean)]
    return float(np.quantile(clean, q)) if len(clean) else np.nan


def vector_features(values: Iterable[float], prefix: str) -> dict[str, float]:
    clean = np.asarray(list(values), dtype=float)
    clean = clean[np.isfinite(clean)]
    if not len(clean):
        return {}
    result = {
        f"{prefix}.count": float(len(clean)),
        f"{prefix}.mean": float(np.mean(clean)),
        f"{prefix}.std": float(np.std(clean)),
        f"{prefix}.min": float(np.min(clean)),
        f"{prefix}.max": float(np.max(clean)),
        f"{prefix}.q10": quantile(clean, .10),
        f"{prefix}.median": quantile(clean, .50),
        f"{prefix}.q90": quantile(clean, .90),
    }
    return result


def resample(values: Iterable[float], points: int) -> np.ndarray:
    y = np.asarray(list(values), dtype=float)
    y = y[np.isfinite(y)]
    if not len(y):
        return np.full(points, np.nan)
    if len(y) == 1:
        return np.repeat(y[0], points)
    return np.interp(np.linspace(0, 1, points), np.linspace(0, 1, len(y)), y)


def waveform_features(samples: list[float]) -> tuple[dict[str, float], np.ndarray]:
    y = np.asarray(samples, dtype=float)
    y = y[np.isfinite(y)]
    if not len(y):
        return {}, np.full(PROFILE_POINTS, np.nan)
    profile = resample(y, PROFILE_POINTS)
    window = max(2, min(5, len(y) // 5))
    baseline = float(np.median(y[:window]))
    centered = profile - baseline
    scale = float(np.quantile(centered, .75) - np.quantile(centered, .25))
    if scale < 1e-9:
        scale = float(np.std(centered))
    shape = centered / scale if scale >= 1e-9 else centered
    coeff = dct(np.nan_to_num(shape), norm="ortho")[:8]
    dy = np.diff(y)
    features = {
        "wave_n_points": float(len(y)),
        "wave_start": float(np.median(y[:window])),
        "wave_end": float(np.median(y[-window:])),
        "wave_mean": float(np.mean(y)),
        "wave_std": float(np.std(y)),
        "wave_min": float(np.min(y)),
        "wave_max": float(np.max(y)),
        "wave_q05": quantile(y, .05),
        "wave_q95": quantile(y, .95),
        "wave_amplitude": float(np.max(y) - np.min(y)),
        "wave_area_signed": float(np.trapezoid(profile, np.linspace(0, 1, len(profile)))),
        "wave_area_absolute": float(np.trapezoid(np.abs(centered), np.linspace(0, 1, len(profile)))),
        "wave_largest_drop": float(np.min(dy)) if len(dy) else 0.0,
        "wave_largest_rise": float(np.max(dy)) if len(dy) else 0.0,
        "wave_difference_noise": float(np.std(dy)) if len(dy) else 0.0,
        "wave_recovery_error": float(abs(np.median(y[-window:]) - baseline)),
        "wave_peak_position": float(np.argmax(np.abs(centered)) / max(len(centered) - 1, 1)),
    }
    for index, value in enumerate(coeff):
        features[f"wave_dct_{index}"] = float(value)
    return features, profile


def line_timestamp(line: str, year: int) -> str:
    match = re.match(r"^([A-Z][a-z]{2})\s+(\d{1,2})\s+(\d{2}:\d{2}:\d{2})", line)
    if not match:
        return ""
    try:
        value = datetime.strptime(f"{year} {match.group(1)} {match.group(2)} {match.group(3)}", "%Y %b %d %H:%M:%S")
        return value.replace(tzinfo=timezone.utc).isoformat().replace("+00:00", "Z")
    except ValueError:
        return ""


def parse_send_context(tail: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in re.findall(r"(?:^|,)(tip|loc|vol|hgt|lql|tubB):([^,\s]+)", tail, re.I):
        normalized = {"tubB": "tube_bottom"}.get(key, key.lower())
        if normalized in {"vol", "hgt", "lql", "tube_bottom"}:
            result[normalized] = safe_float(value)
        else:
            result[normalized] = normalize_name(value)
    return result


def finalize_operation(operation: dict[str, Any], rows: list[dict[str, Any]], compact: bool = False) -> None:
    if not operation:
        return
    samples = operation.pop("_samples", [])
    features, profile = ({}, resample(samples, PROFILE_POINTS)) if compact else waveform_features(samples)
    operation.update(features)
    operation["qpm_available"] = bool(samples)
    if not compact:
        operation["qpm_samples"] = [float(x) for x in samples]
    operation["qpm_profile"] = [float(x) for x in profile] if len(samples) else []
    rows.append(operation)


def parse_qpm_stream(handle: BinaryIO, base: dict[str, Any], *, compact: bool = False,
                     quality_stats: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    pending: dict[int, dict[str, Any]] = {}
    last_liquid_class: dict[str, Any] = {}
    workflow_stage = "unresolved"
    process_step = "unresolved"
    operation_index = 0
    trace_quality = TraceQualityTracker()
    year = pd.to_datetime(base.get("run_start_time"), utc=True, errors="coerce").year
    if not np.isfinite(year):
        year = 2000
    # Tar stream members are deliberately non-seekable; decode one raw line at
    # a time instead of wrapping them in TextIOWrapper (which asks seekable()).
    for raw_line in iter(handle.readline, b""):
        line = raw_line.decode("utf-8", "replace")
        trace_quality.feed(line)
        exp = EXP_DETAIL_RE.search(line)
        if exp:
            workflow_stage = normalize_name(exp.group(1))
        proc = PROCESS_RE.search(line)
        if proc:
            process_step = normalize_name(proc.group(1))
        liquid = LIQUID_CLASS_RE.search(line)
        if liquid:
            last_liquid_class = {
                "container_geometry_index": safe_float(liquid.group(1)),
                "deck_geometry_index": safe_float(liquid.group(2)),
                "liquid_class_index": safe_float(liquid.group(3)),
            }
        op_match = PIP_OP_RE.search(line)
        if op_match:
            operation_name = op_match.group(1).lower()
            pipette_number = int(op_match.group(2))
            if pipette_number in pending:
                finalize_operation(pending.pop(pipette_number), rows, compact)
            operation_index += 1
            pending[pipette_number] = {
                **base,
                "operation_id": stable_id(base["archive_id"], operation_index, prefix="qpmop_"),
                "operation_index": operation_index,
                "operation": operation_name,
                "pipette": f"PIP{pipette_number}",
                "programmed_volume_ul": safe_float(op_match.group(3)),
                "event_time": line_timestamp(line, int(year)),
                "workflow_stage": workflow_stage,
                "process_step": process_step,
                "source_file": "CSA/debug",
                "pressure_unit": "raw_sensor_count_unresolved",
                "parse_confidence": "high",
                **last_liquid_class,
                "_samples": [],
            }
            continue
        send = SEND_RE.search(line)
        if send:
            pipette_number = int(send.group(1))
            command = send.group(2).upper()
            if command in {"GA", "GD"} and pipette_number in pending:
                operation = pending[pipette_number]
                expected = "aspirate" if command == "GA" else "dispense"
                if operation.get("operation") == expected:
                    operation["command_id"] = send.group(3)
                    operation.update(parse_send_context(send.group(4)))
                    # Dispense does not always emit a separate cgi/dgi/lci log.
                    # The actual GA/GD payload is authoritative; never carry
                    # aspiration metadata into a differently configured GD.
                    fields = dict(re.findall(r"([a-z]{2})([-+]?\d+)", send.group(4).split(",", 1)[0].lower()))
                    for code, column in [("ge", "container_geometry_index"),
                                         ("go", "deck_geometry_index"),
                                         ("lq", "liquid_class_index")]:
                        if code in fields:
                            operation[f"legacy_inherited_{column}"] = operation.get(column)
                            operation[column] = safe_float(fields[code])
                    operation["configuration_context_source"] = "actual_GA_GD_command" if all(code in fields for code in ["ge", "go", "lq"]) else "unresolved_inherited_context"
        complete = COMPLETE_RE.search(line)
        if complete:
            operation_name = complete.group(1).lower()
            candidates = [x for x in pending.values() if x.get("operation") == operation_name]
            if candidates:
                operation = max(candidates, key=lambda x: x.get("operation_index", -1))
                operation["total_time"] = safe_float(complete.group(2))
                operation["elapsed_time_s"] = safe_float(complete.group(3))
        rx = RX_RE.search(line)
        if rx:
            pipette_number = int(rx.group(1))
            if pipette_number in pending:
                operation = pending.pop(pipette_number)
                operation["rx_command_id"] = rx.group(2)
                operation["rx_header"] = safe_float(rx.group(3))
                samples = [safe_float(x) for x in re.findall(r"[-+]?\d+(?:\.\d+)?", rx.group(4))]
                operation["_samples"] = [x for x in samples if np.isfinite(x)]
                finalize_operation(operation, rows, compact)
    for operation in sorted(pending.values(), key=lambda x: x.get("operation_index", -1)):
        finalize_operation(operation, rows, compact)
    quality = {(r['operation_index'], r['pipette']): r for r in trace_quality.annotations()}
    for row in rows:
        row.update(quality[(row['operation_index'], row['pipette'])])
    if quality_stats is not None:
        quality_stats.update(er72_responses=trace_quality.er72_responses,
                             unmatched_er72_responses=trace_quality.unmatched_er72_responses,
                             er72_operations=sum(r['qpm_has_er72'] for r in quality.values()))
    return rows


def qpm_run_features(rows: list[dict[str, Any]]) -> dict[str, float]:
    if not rows:
        return {}
    frame = pd.DataFrame(rows).sort_values("operation_index", kind="stable")
    output: dict[str, float] = {
        "qpm.all.operation_count": float(len(frame)),
        "qpm.all.wave_count": float(frame["qpm_available"].sum()),
        "qpm.all.wave_coverage": float(frame["qpm_available"].mean()),
    }
    metrics = [
        "programmed_volume_ul", "elapsed_time_s", "rx_header", "wave_n_points",
        "wave_start", "wave_end", "wave_mean", "wave_std", "wave_min", "wave_max",
        "wave_q05", "wave_q95", "wave_amplitude", "wave_area_signed",
        "wave_area_absolute", "wave_largest_drop", "wave_largest_rise",
        "wave_difference_noise", "wave_recovery_error", "wave_peak_position",
        *[f"wave_dct_{i}" for i in range(8)],
    ]
    sequence_metrics = [
        "wave_mean", "wave_std", "wave_min", "wave_max", "wave_amplitude",
        "wave_area_absolute", "wave_difference_noise", "wave_recovery_error",
        *[f"wave_dct_{i}" for i in range(1, 5)],
    ]
    for (operation, pipette), group in frame.groupby(["operation", "pipette"], dropna=False):
        tag = f"qpm.{normalize_name(operation)}.{normalize_name(pipette)}"
        output[f"{tag}.operation_count"] = float(len(group))
        output[f"{tag}.wave_coverage"] = float(group["qpm_available"].mean())
        for metric in metrics:
            if metric in group:
                output.update(vector_features(pd.to_numeric(group[metric], errors="coerce"), f"{tag}.{metric}"))
        wave_group = group[group["qpm_available"].astype(bool)]
        for metric in sequence_metrics:
            if metric not in wave_group or wave_group[metric].notna().sum() < 2:
                continue
            values = resample(pd.to_numeric(wave_group[metric], errors="coerce"), SEQUENCE_POINTS)
            for index, value in enumerate(values):
                output[f"{tag}.sequence.{metric}.{index:02d}"] = float(value)
    return output


def parse_spatial_bytes(data: bytes, match: re.Match[str], base: dict[str, Any], source: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in data.decode("utf-8-sig", "replace").splitlines():
        fields = line.strip().split()
        if len(fields) < 3:
            continue
        flow = safe_float(fields[0])
        value = safe_float(fields[2])
        nucleotide = fields[1].upper()
        if np.isfinite(flow) and np.isfinite(value) and nucleotide in {"A", "C", "G", "T"}:
            rows.append({
                **base, "block_x": int(match.group("x")), "block_y": int(match.group("y")),
                "location": match.group("location").lower(), "flow_index": int(flow),
                "nucleotide": nucleotide, "step_height": float(value),
                "unit": "signal_unit_unresolved", "source_file": source,
            })
    return rows


def spatial_run_features(rows: list[dict[str, Any]]) -> dict[str, float]:
    if not rows:
        return {}
    frame = pd.DataFrame(rows)
    output: dict[str, float] = {
        "nucstep.all.row_count": float(len(frame)),
        "nucstep.all.block_count": float(frame[["block_x", "block_y"]].drop_duplicates().shape[0]),
    }
    for (location, nucleotide), group in frame.groupby(["location", "nucleotide"]):
        tag = f"nucstep.{location}.{nucleotide.lower()}"
        output.update(vector_features(group["step_height"], f"{tag}.signal"))
        block = group.groupby(["block_x", "block_y"], as_index=False)["step_height"].mean()
        if len(block) >= 4:
            for axis in ("block_x", "block_y"):
                if block[axis].nunique() >= 2:
                    output[f"{tag}.spatial_slope_{axis[-1]}"] = float(np.polyfit(block[axis], block["step_height"], 1)[0])
            output[f"{tag}.between_block_std"] = float(block["step_height"].std(ddof=0))
        flow_group = group.groupby("flow_index", as_index=False)["step_height"].mean().sort_values("flow_index")
        for index, value in enumerate(resample(flow_group["step_height"], 8)):
            output[f"{tag}.flow_profile.{index:02d}"] = float(value)
    for nucleotide, group in frame.groupby("nucleotide"):
        means = group.groupby("location")["step_height"].mean()
        if {"inlet", "outlet"}.issubset(means.index):
            output[f"nucstep.gradient.{nucleotide.lower()}.outlet_minus_inlet"] = float(means["outlet"] - means["inlet"])
        if {"inlet", "middle", "outlet"}.issubset(means.index):
            output[f"nucstep.gradient.{nucleotide.lower()}.curvature"] = float(means["inlet"] - 2 * means["middle"] + means["outlet"])
    return output


def libprep_features(data: bytes) -> dict[str, float]:
    try:
        frame = pd.read_csv(io.BytesIO(data), low_memory=False)
    except Exception:
        return {}
    if frame.empty:
        return {}
    output: dict[str, float] = {"libprep.all.row_count": float(len(frame))}
    time_column = next((x for x in frame.columns if normalize_name(x) in {"time", "timestamp"}), None)
    if time_column:
        times = pd.to_datetime(frame[time_column], utc=True, errors="coerce")
        if times.notna().sum() >= 2:
            output["libprep.all.duration_hours"] = float((times.max() - times.min()).total_seconds() / 3600)
    for column in frame.columns:
        if column == time_column or SENSITIVE_RE.search(str(column)):
            continue
        values = pd.to_numeric(frame[column], errors="coerce")
        if values.notna().sum() < 3:
            continue
        tag = f"libprep.{normalize_name(column)}"
        output.update(vector_features(values, tag))
        clean = values.dropna().to_numpy(dtype=float)
        output[f"{tag}.start"] = float(np.median(clean[: min(3, len(clean))]))
        output[f"{tag}.end"] = float(np.median(clean[-min(3, len(clean)):]))
        if len(clean) >= 3:
            output[f"{tag}.normalized_slope"] = float(np.polyfit(np.linspace(0, 1, len(clean)), clean, 1)[0])
    return output


def flatten_numeric_json(value: Any, path: str = "", limit: int = 1500) -> list[tuple[str, float]]:
    rows: list[tuple[str, float]] = []
    stack: list[tuple[str, Any]] = [(path, value)]
    while stack and len(rows) < limit:
        current_path, current = stack.pop()
        if isinstance(current, dict):
            for key, child in list(current.items())[::-1]:
                stack.append((f"{current_path}.{normalize_name(key)}".strip("."), child))
        elif isinstance(current, list):
            numeric = np.asarray([safe_float(x) for x in current], dtype=float) if current else np.asarray([])
            numeric = numeric[np.isfinite(numeric)]
            if len(numeric):
                for suffix, number in (
                    ("count", len(numeric)), ("mean", np.mean(numeric)), ("std", np.std(numeric)),
                    ("min", np.min(numeric)), ("max", np.max(numeric)),
                    ("q10", np.quantile(numeric, .1)), ("median", np.median(numeric)),
                    ("q90", np.quantile(numeric, .9)),
                ):
                    rows.append((f"{current_path}.array_{suffix}", float(number)))
            elif len(current) <= 30:
                for index, child in reversed(list(enumerate(current))):
                    stack.append((f"{current_path}.item_{index}", child))
        elif isinstance(current, (int, float)) and not isinstance(current, bool) and np.isfinite(current):
            rows.append((current_path or "value", float(current)))
    return rows


def image_descriptors(data: bytes) -> dict[str, float]:
    try:
        image = Image.open(io.BytesIO(data))
        frames = []
        for index, frame in enumerate(ImageSequence.Iterator(image)):
            if index not in {0, max(getattr(image, "n_frames", 1) // 2, 0), max(getattr(image, "n_frames", 1) - 1, 0)}:
                continue
            arr = np.asarray(frame.convert("L").resize((32, 32)), dtype=float) / 255.0
            frames.append(arr)
        if not frames:
            return {}
        arr = np.mean(frames, axis=0)
        hist, _ = np.histogram(arr, bins=32, range=(0, 1), density=False)
        probabilities = hist / max(hist.sum(), 1)
        entropy = -np.sum(probabilities[probabilities > 0] * np.log2(probabilities[probabilities > 0]))
        gx = np.diff(arr, axis=1)
        gy = np.diff(arr, axis=0)
        center = arr[8:24, 8:24]
        edge = np.concatenate([arr[:6].ravel(), arr[-6:].ravel(), arr[:, :6].ravel(), arr[:, -6:].ravel()])
        return {
            "pixel_mean": float(arr.mean()), "pixel_std": float(arr.std()),
            "pixel_q10": quantile(arr.ravel(), .1), "pixel_median": quantile(arr.ravel(), .5),
            "pixel_q90": quantile(arr.ravel(), .9), "entropy": float(entropy),
            "gradient_x": float(np.mean(np.abs(gx))), "gradient_y": float(np.mean(np.abs(gy))),
            "center_minus_edge": float(center.mean() - edge.mean()),
            "frame_count": float(getattr(image, "n_frames", 1)),
            "aspect_ratio": float(image.width / max(image.height, 1)),
        }
    except Exception:
        return {}


def plugin_family(name: str) -> str:
    lower = name.lower()
    if "rawtrace" in lower or "raw_trace" in lower:
        return "rawtrace"
    if "flowrate" in lower or "flow_rate" in lower or "flow-data" in lower or "flow_data" in lower:
        return "flowrate"
    if "bubbleplot" in lower:
        return "bubbleplots"
    if "nucstepspatial" in lower:
        return "nucstep_rendered"
    if "lane_diagnostic" in lower:
        return "lane_diagnostics"
    if "true_loading" in lower:
        return "true_loading"
    if "edgeeffect" in lower:
        return "edge_effects"
    if "autocal" in lower:
        return "autocal"
    if "chipdiagnostic" in lower:
        return "chip_diagnostics"
    if "nikf" in lower or "signalhistogram" in lower:
        return "signal_histograms"
    return normalize_name(name.split("/", 1)[0])


def safe_plugin_basename(name: str) -> str:
    stem = Path(name).stem
    stem = re.sub(r"20\d{6,}", "date", stem)
    stem = re.sub(r"\d{4,}", "n", stem)
    return normalize_name(stem, max_length=60)


def plugin_member_features(
    name: str, data: bytes, size: int,
    values: dict[str, list[float]], inventory: dict[tuple[str, str], dict[str, Any]],
    exclusions: list[dict[str, Any]], accuracy_candidates: list[dict[str, Any]],
) -> None:
    family = plugin_family(name)
    suffix = Path(name).suffix.lower()
    key = (family, suffix or "none")
    record = inventory.setdefault(key, {"plugin_family": family, "extension": suffix or "none", "file_count": 0, "total_bytes": 0})
    record["file_count"] += 1
    record["total_bytes"] += int(size)
    values[f"plugin.{family}.inventory.file_count"].append(1.0)
    values[f"plugin.{family}.inventory.total_bytes"].append(float(size))
    lower_name = name.lower()
    target_named = bool(TARGET_LEAKAGE_RE.search(lower_name))
    if target_named:
        exclusions.append({"source_file": name, "feature": "entire_member", "reason": "target_revealing_filename"})
        return
    base = safe_plugin_basename(name)
    if suffix == ".json":
        try:
            obj = json.loads(data.decode("utf-8-sig", "replace"))
            for field, number in flatten_numeric_json(obj):
                combined = f"{base}.{field}"
                if TARGET_LEAKAGE_RE.search(combined) or SENSITIVE_RE.search(combined):
                    exclusions.append({"source_file": name, "feature": combined, "reason": "target_or_sensitive_field"})
                    continue
                values[f"plugin.{family}.structured.{normalize_name(combined)}"].append(number)
        except Exception:
            values[f"plugin.{family}.parse.json_failure_count"].append(1.0)
    elif suffix == ".csv":
        try:
            frame = pd.read_csv(io.BytesIO(data), low_memory=False, nrows=200000)
            for column in list(frame.columns)[:250]:
                combined = f"{base}.{column}"
                if TARGET_LEAKAGE_RE.search(combined) or SENSITIVE_RE.search(combined):
                    exclusions.append({"source_file": name, "feature": combined, "reason": "target_or_sensitive_field"})
                    continue
                numeric = pd.to_numeric(frame[column], errors="coerce").dropna().to_numpy(dtype=float)
                if len(numeric) < 2:
                    continue
                tag = f"plugin.{family}.structured.{normalize_name(combined)}"
                for suffix_name, number in (
                    ("count", len(numeric)), ("mean", np.mean(numeric)), ("std", np.std(numeric)),
                    ("min", np.min(numeric)), ("max", np.max(numeric)),
                    ("q10", np.quantile(numeric, .1)), ("median", np.median(numeric)),
                    ("q90", np.quantile(numeric, .9)),
                ):
                    values[f"{tag}.{suffix_name}"].append(float(number))
        except Exception:
            values[f"plugin.{family}.parse.csv_failure_count"].append(1.0)
    elif suffix in IMAGE_EXTENSIONS:
        descriptors = image_descriptors(data)
        for field, number in descriptors.items():
            values[f"plugin.{family}.image.{field}"].append(number)
    elif suffix in TEXT_EXTENSIONS:
        text = data.decode("utf-8-sig", "replace")
        values[f"plugin.{family}.text.line_count"].append(float(text.count("\n") + 1))
        values[f"plugin.{family}.text.warning_count"].append(float(len(re.findall(r"\bwarn(?:ing)?\b", text, re.I))))
        values[f"plugin.{family}.text.error_count"].append(float(len(re.findall(r"\berror\b|\bfailed\b", text, re.I))))


def aggregate_plugin_values(values: dict[str, list[float]]) -> dict[str, float]:
    output: dict[str, float] = {}
    for feature, numbers in values.items():
        clean = np.asarray(numbers, dtype=float)
        clean = clean[np.isfinite(clean)]
        if not len(clean):
            continue
        if feature.endswith("file_count"):
            output[feature] = float(np.sum(clean))
        elif feature.endswith("total_bytes"):
            output[feature] = float(np.sum(clean))
        elif len(clean) == 1:
            output[feature] = float(clean[0])
        else:
            output[f"{feature}.mean"] = float(np.mean(clean))
            output[f"{feature}.std"] = float(np.std(clean))
            output[f"{feature}.max"] = float(np.max(clean))
    return output


def parse_lane_raw_accuracy(name: str, data: bytes, chip_lane: Any) -> dict[str, Any] | None:
    """Extract the lane-specific mean from the explicitly labeled local-RRA table."""
    if not name.lower().endswith("lane_diagnostics/lane_diagnostics.html"):
        return None
    text = data.decode("utf-8-sig", "replace")
    section = re.search(
        r"Raw Read Accuracy\s*\[Local\](.*?)(?:</table>|Key Signal)",
        text, re.I | re.S,
    )
    if not section:
        return None
    mean_row = re.search(r"<td[^>]*>\s*Mean\s*</td>(.*?)</tr>", section.group(1), re.I | re.S)
    if not mean_row:
        return None
    cells = re.findall(r"<td[^>]*>(.*?)</td>", mean_row.group(1), re.I | re.S)
    values = [re.sub(r"<[^>]+>", "", html.unescape(cell)).strip() for cell in cells]
    lane_match = re.search(r"(\d+)", str(chip_lane))
    if not lane_match:
        return None
    lane_index = int(lane_match.group(1)) - 1
    if lane_index < 0 or lane_index >= len(values):
        return None
    value = safe_float(values[lane_index])
    if not np.isfinite(value) or not (0 <= value <= 100):
        return None
    return {
        "source_file": name,
        "source_field": f"Raw Read Accuracy [Local] / Mean / Lane {lane_index + 1}",
        "value": float(value),
        "selection_status": "selected_plugin_outcome",
    }


def wanted_member(name: str, size: int) -> bool:
    clean = name.replace("\\", "/")
    lower = clean.lower()
    if lower == "csa/debug" or lower == "csa/libprep_log.csv" or SPATIAL_RE.match(clean):
        return True
    if clean.startswith("CSA/"):
        return False
    suffix = Path(clean).suffix.lower()
    return size <= MAX_PLUGIN_MEMBER_BYTES and suffix in IMAGE_EXTENSIONS | STRUCTURED_EXTENSIONS | TEXT_EXTENSIONS


def iter_members(path: Path) -> Iterator[tuple[str, int, BinaryIO]]:
    with path.open("rb") as signature_handle:
        signature = signature_handle.read(8)
    if signature.startswith((b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")):
        with zipfile.ZipFile(path) as archive:
            for entry in archive.infolist():
                if entry.is_dir() or not wanted_member(entry.filename, entry.file_size):
                    continue
                with archive.open(entry) as handle:
                    yield entry.filename, entry.file_size, handle
        return
    with tarfile.open(path, "r|*") as archive:
        for entry in archive:
            if not entry.isfile() or not wanted_member(entry.name, entry.size):
                continue
            handle = archive.extractfile(entry)
            if handle is None:
                continue
            with handle:
                yield entry.name, entry.size, handle


def extract_archive(record: dict[str, Any]) -> dict[str, Any]:
    base = {key: record.get(key, "") for key in (
        "observation_id", "physical_run_id", "instrument_id", "archive_id", "chip_lane", "run_start_time"
    )}
    qpm_rows: list[dict[str, Any]] = []
    spatial_rows: list[dict[str, Any]] = []
    libprep: dict[str, float] = {}
    plugin_values: dict[str, list[float]] = defaultdict(list)
    plugin_inventory: dict[tuple[str, str], dict[str, Any]] = {}
    exclusions: list[dict[str, Any]] = []
    accuracy_candidates: list[dict[str, Any]] = []
    parse_warnings: list[str] = []
    try:
        for name, size, handle in iter_members(Path(record["local_path"])):
            clean = name.replace("\\", "/")
            lower = clean.lower()
            if lower == "csa/debug":
                qpm_rows.extend(parse_qpm_stream(handle, base))
                continue
            data = handle.read(MAX_PLUGIN_MEMBER_BYTES + 1 if not SPATIAL_RE.match(clean) else size + 1)
            if lower == "csa/libprep_log.csv":
                libprep.update(libprep_features(data))
                continue
            spatial_match = SPATIAL_RE.match(clean)
            if spatial_match:
                spatial_rows.extend(parse_spatial_bytes(data, spatial_match, base, clean))
                continue
            raw_accuracy = parse_lane_raw_accuracy(clean, data, base.get("chip_lane"))
            if raw_accuracy:
                accuracy_candidates.append(raw_accuracy)
            plugin_member_features(clean, data, size, plugin_values, plugin_inventory, exclusions, accuracy_candidates)
    except Exception as exc:
        parse_warnings.append(f"{type(exc).__name__}: {exc}")
    features = {}
    features.update(qpm_run_features(qpm_rows))
    features.update(spatial_run_features(spatial_rows))
    features.update(libprep)
    features.update(aggregate_plugin_values(plugin_values))
    inventory_rows = [{**base, **value} for value in plugin_inventory.values()]
    for row in exclusions:
        row.update(base)
    for row in accuracy_candidates:
        row.update(base)
    return {
        "base": base, "features": features, "qpm_rows": qpm_rows,
        "spatial_rows": spatial_rows, "plugin_inventory": inventory_rows,
        "exclusions": exclusions, "accuracy_candidates": accuracy_candidates,
        "warnings": parse_warnings,
    }


def extract_cached(record: dict[str, Any], cache_dir: Path, refresh: bool) -> dict[str, Any]:
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = cache_dir / f"{record['archive_id']}.joblib"
    key = f"{VERSION}|{record.get('sha256', '')}"
    if path.exists() and not refresh:
        try:
            cached = joblib.load(path)
            if cached.get("key") == key:
                return cached["result"]
        except Exception:
            pass
    result = extract_archive(record)
    joblib.dump({"key": key, "result": result}, path, compress=3)
    return result


def primary_archives(project: Path) -> pd.DataFrame:
    duplicates = pd.read_csv(project / "duplicate_archives.csv", dtype={"archive_id": str})
    manifest = pd.read_csv(project / "csa_transfer_manifest.csv", dtype={"archive_id": str})
    dataset = pd.read_parquet(project / "csa_ml_dataset.parquet", columns=[
        "observation_id", "physical_run_id", "instrument_id", "chip_lane",
        "run_start_time", "archive_id", "total_reads", "mean_read_length_bp",
        "raw_read_accuracy_pct",
    ])
    for frame in (duplicates, manifest, dataset):
        frame["archive_id"] = frame["archive_id"].astype(str)
    primary_mask = duplicates["retained_primary"].astype(str).str.lower().isin({"true", "1", "yes"})
    retained = duplicates[primary_mask].copy()
    dataset_for_merge = dataset.drop(columns=["chip_lane"], errors="ignore")
    retained = retained.merge(dataset_for_merge, on=["archive_id", "observation_id", "physical_run_id"], how="inner")
    retained = retained.merge(
        manifest[["archive_id", "local_path", "sha256", "container_format", "size_bytes"]],
        on="archive_id", how="inner",
    )
    retained = retained.sort_values(["run_start_time", "physical_run_id", "chip_lane"], kind="stable")
    return retained.reset_index(drop=True)


def write_result_parquets(results: list[dict[str, Any]], project: Path) -> tuple[int, int]:
    qpm_path = project / "qpm_operation_waveforms.parquet"
    spatial_path = project / "nucstep_all_spatial_blocks.parquet"
    for output_path, key in ((qpm_path, "qpm_rows"), (spatial_path, "spatial_rows")):
        column_order: list[str] = []
        for result in results:
            for row in result[key]:
                for column in row:
                    if column not in column_order:
                        column_order.append(column)
        if key == "qpm_rows":
            list_columns = {"qpm_samples", "qpm_profile"}
            bool_columns = {"qpm_available"}
            integer_columns = {"operation_index"}
            string_columns = {
                "observation_id", "physical_run_id", "instrument_id", "archive_id", "chip_lane",
                "run_start_time", "operation_id", "operation", "pipette", "event_time",
                "workflow_stage", "process_step", "source_file", "pressure_unit", "parse_confidence",
                "command_id", "tip", "loc", "rx_command_id",
            }
        else:
            list_columns, bool_columns = set(), set()
            integer_columns = {"block_x", "block_y", "flow_index"}
            string_columns = {
                "observation_id", "physical_run_id", "instrument_id", "archive_id", "chip_lane",
                "run_start_time", "location", "nucleotide", "unit", "source_file",
            }
        fields = []
        for column in column_order:
            if column in list_columns:
                dtype = pa.list_(pa.float64())
            elif column in bool_columns:
                dtype = pa.bool_()
            elif column in integer_columns:
                dtype = pa.int64()
            elif column in string_columns:
                dtype = pa.string()
            else:
                dtype = pa.float64()
            fields.append(pa.field(column, dtype))
        schema = pa.schema(fields)
        writer: pq.ParquetWriter | None = None
        for result in results:
            rows = result[key]
            if not rows:
                continue
            frame = pd.DataFrame(rows).reindex(columns=column_order)
            arrays = []
            for field in schema:
                if field.name in list_columns:
                    values = frame[field.name].map(lambda x: x if isinstance(x, list) else [])
                elif field.name in string_columns:
                    values = frame[field.name].map(lambda x: None if pd.isna(x) else str(x))
                elif field.name in bool_columns:
                    values = frame[field.name].fillna(False).astype(bool)
                elif field.name in integer_columns:
                    values = pd.to_numeric(frame[field.name], errors="coerce").astype("Int64")
                else:
                    values = pd.to_numeric(frame[field.name], errors="coerce")
                arrays.append(pa.array(values, type=field.type, from_pandas=True))
            table = pa.Table.from_arrays(arrays, schema=schema)
            if writer is None:
                writer = pq.ParquetWriter(output_path, schema, compression="zstd")
            writer.write_table(table)
        if writer is not None:
            writer.close()
        elif output_path.exists():
            output_path.unlink()
    return (
        sum(len(result["qpm_rows"]) for result in results),
        sum(len(result["spatial_rows"]) for result in results),
    )


def vacuum_wide(project: Path, observations: set[str]) -> pd.DataFrame:
    use = ["observation_id", "feature_name", "value", "source_file", "classification"]
    pieces = []
    for chunk in pd.read_csv(project / "templating_vacuum_step_features.csv", usecols=use, chunksize=100000, low_memory=False):
        selected = chunk[
            chunk["observation_id"].astype(str).isin(observations)
            & chunk["source_file"].astype(str).str.contains("vacuum_log.csv", case=False, regex=False)
        ].copy()
        selected["value"] = pd.to_numeric(selected["value"], errors="coerce")
        selected = selected.dropna(subset=["value"])
        if not selected.empty:
            pieces.append(selected[["observation_id", "feature_name", "value"]])
    if not pieces:
        return pd.DataFrame({"observation_id": sorted(observations)})
    long = pd.concat(pieces, ignore_index=True)
    wide = long.pivot_table(index="observation_id", columns="feature_name", values="value", aggfunc="median")
    wide.columns = [f"vacuum.{normalize_name(x, 120)}" for x in wide.columns]
    return wide.reset_index()


def existing_csa_features(project: Path, metadata: pd.DataFrame) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    policy = pd.read_csv(project / "feature_policy.csv", low_memory=False)
    eligible = policy[
        policy["modeling_eligible"].astype(str).str.lower().eq("true")
        & policy["actionability_tier"].isin(["A", "B", "C"])
    ].copy()
    available = pd.read_parquet(project / "csa_ml_dataset.parquet").columns
    eligible = eligible[eligible["feature_name"].isin(available)]
    columns = ["observation_id", *eligible["feature_name"].tolist()]
    source = pd.read_parquet(project / "csa_ml_dataset.parquet", columns=columns)
    output_data: dict[str, Any] = {"observation_id": source["observation_id"].astype(str).to_numpy()}
    dictionary: list[dict[str, Any]] = []
    policy_map = eligible.set_index("feature_name")
    for feature in eligible["feature_name"]:
        row = policy_map.loc[feature]
        if row["data_type"] == "numeric":
            name = f"csa.{normalize_name(feature, 130)}"
            output_data[name] = pd.to_numeric(source[feature], errors="coerce").to_numpy()
            dictionary.append({"feature_name": name, "component": "csa_structured", "source": row["source_file"], "tier": row["actionability_tier"]})
        else:
            values = source[feature].map(lambda x: np.nan if pd.isna(x) else str(x))
            levels = sorted(x for x in values.dropna().unique() if (values == x).sum() >= 2)
            for index, level in enumerate(levels[:25]):
                name = f"csa.{normalize_name(feature, 105)}.level_{index:02d}"
                output_data[name] = (values == level).astype(float).to_numpy()
                dictionary.append({"feature_name": name, "component": "csa_structured", "source": row["source_file"], "tier": row["actionability_tier"]})
    return pd.DataFrame(output_data), dictionary


def component_for_feature(feature: str) -> str:
    if feature.startswith("qpm."):
        return "qpm_debug"
    if feature.startswith("vacuum."):
        return "vacuum_steps"
    if feature.startswith("nucstep."):
        return "nucstep_spatial"
    if feature.startswith("libprep."):
        return "libprep_telemetry"
    if feature.startswith("csa."):
        return "csa_structured"
    if feature.startswith("plugin."):
        parts = feature.split(".")
        return f"plugin:{parts[1]}" if len(parts) > 1 else "plugin:other"
    return "other"


def build_feature_matrix(
    project: Path, retained: pd.DataFrame, results: list[dict[str, Any]],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    metadata_columns = [
        "observation_id", "physical_run_id", "instrument_id", "chip_lane", "run_start_time",
        "archive_id", "total_reads", "mean_read_length_bp", "raw_read_accuracy_pct",
    ]
    matrix = retained[metadata_columns].drop_duplicates("observation_id").copy()
    accuracy_rows = [row for result in results for row in result["accuracy_candidates"] if row.get("selection_status") == "selected_plugin_outcome"]
    if accuracy_rows:
        accuracy_frame = pd.DataFrame(accuracy_rows).sort_values(["observation_id", "source_file"], kind="stable")
        accuracy_map = accuracy_frame.drop_duplicates("observation_id").set_index("observation_id")["value"]
        plugin_values = matrix["observation_id"].map(accuracy_map)
        matrix["raw_read_accuracy_pct"] = pd.to_numeric(matrix["raw_read_accuracy_pct"], errors="coerce").combine_first(pd.to_numeric(plugin_values, errors="coerce"))
    extracted = pd.DataFrame([
        {"observation_id": result["base"]["observation_id"], **result["features"]}
        for result in results
    ])
    if not extracted.empty:
        matrix = matrix.merge(extracted, on="observation_id", how="left")
    vacuum = vacuum_wide(project, set(matrix["observation_id"].astype(str)))
    matrix = matrix.merge(vacuum, on="observation_id", how="left")
    csa, dictionary = existing_csa_features(project, matrix)
    matrix = matrix.merge(csa, on="observation_id", how="left")
    feature_columns = [x for x in matrix.columns if x not in metadata_columns]
    for feature in feature_columns:
        matrix[feature] = pd.to_numeric(matrix[feature], errors="coerce").astype("float32")
    exclusion_rows = []
    retained_features = []
    for feature in feature_columns:
        support = int(matrix[feature].notna().sum())
        reason = ""
        structured_result = feature.startswith(("plugin.", "csa."))
        if structured_result and (
            TARGET_LEAKAGE_RE.search(feature) or OUTCOME_PROXY_RE.search(feature)
        ):
            reason = "outcome_derived_or_target_revealing_plugin_metric"
        elif support < 5:
            reason = "observed_in_fewer_than_five_run_lane_observations"
        elif matrix[feature].nunique(dropna=True) <= 1:
            reason = "constant_feature"
        if reason:
            exclusion_rows.append({
                "feature_name": feature, "component": component_for_feature(feature),
                "observed_observations": support, "reason": reason,
            })
        else:
            retained_features.append(feature)
    pd.DataFrame(exclusion_rows).to_csv(project / "multimodal_sparse_feature_exclusions.csv", index=False)
    matrix = matrix[metadata_columns + retained_features].copy()
    feature_columns = retained_features
    existing_names = {row["feature_name"] for row in dictionary}
    for feature in feature_columns:
        if feature not in existing_names:
            dictionary.append({
                "feature_name": feature, "component": component_for_feature(feature),
                "source": feature.split(".", 1)[0], "tier": "C",
            })
    dictionary_frame = pd.DataFrame(dictionary).drop_duplicates("feature_name")
    dictionary_frame = dictionary_frame[dictionary_frame["feature_name"].isin(feature_columns)].reset_index(drop=True)
    return matrix, dictionary_frame


def stable_f_regression(x: Any, y: Any) -> tuple[np.ndarray, np.ndarray]:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        scores, pvalues = f_regression(x, y)
    return np.nan_to_num(scores), np.nan_to_num(pvalues, nan=1.0)


def make_pipeline(model_name: str) -> tuple[Any, dict[str, list[Any]]]:
    if model_name == "elastic_net":
        model = ElasticNet(max_iter=30000, random_state=SEED)
        grid = {
            "regressor__select__percentile": [5],
            "regressor__model__alpha": [.01, .1, 1.0],
            "regressor__model__l1_ratio": [.5],
        }
    elif model_name == "extra_trees":
        model = ExtraTreesRegressor(n_estimators=200, random_state=SEED, n_jobs=1)
        grid = {
            "select__percentile": [5], "model__max_depth": [5, None],
            "model__min_samples_leaf": [3], "model__max_features": ["sqrt"],
        }
    else:
        raise ValueError(model_name)
    steps: list[tuple[str, Any]] = [
        ("impute", SimpleImputer(strategy="median", add_indicator=True, keep_empty_features=False)),
        ("variance", VarianceThreshold()),
        ("select", SelectPercentile(score_func=stable_f_regression, percentile=25)),
    ]
    if model_name == "elastic_net":
        steps.append(("scale", StandardScaler()))
    steps.append(("model", model))
    pipeline = Pipeline(steps)
    if model_name == "elastic_net":
        # Scale y using training-fold statistics. This makes one regularization
        # grid meaningful for read counts, read length, and accuracy without
        # allowing held-out outcome values into preprocessing.
        return TransformedTargetRegressor(
            regressor=pipeline, transformer=StandardScaler()
        ), grid
    return pipeline, grid


def validation_splits(frame: pd.DataFrame, scheme: str) -> list[tuple[np.ndarray, np.ndarray, str]]:
    groups = frame["physical_run_id"].astype(str).to_numpy()
    if scheme == "grouped":
        cv = GroupKFold(n_splits=min(5, len(np.unique(groups))))
        return [(tr, te, f"group_fold_{i+1}") for i, (tr, te) in enumerate(cv.split(frame, groups=groups))]
    if scheme == "leave_one_instrument_out":
        output = []
        for instrument in sorted(frame["instrument_id"].dropna().unique()):
            test = np.flatnonzero(frame["instrument_id"].to_numpy() == instrument)
            train = np.flatnonzero(frame["instrument_id"].to_numpy() != instrument)
            if len(test) >= 2 and len(train) >= 20:
                output.append((train, test, f"heldout_{instrument}"))
        return output
    dates = pd.to_datetime(frame["run_start_time"], utc=True, errors="coerce")
    group_dates = pd.DataFrame({"group": groups, "date": dates}).groupby("group")["date"].min().dropna().sort_values()
    count = max(1, int(math.ceil(len(group_dates) * .2)))
    test_groups = set(group_dates.index[-count:])
    test = np.flatnonzero(np.isin(groups, list(test_groups)))
    train = np.flatnonzero(~np.isin(groups, list(test_groups)))
    return [(train, test, "newest_20pct_physical_runs")] if len(test) >= 2 and len(train) >= 20 else []


def fit_nested(
    pipeline: Any, grid: dict[str, list[Any]], x: pd.DataFrame, y: pd.Series,
    groups: pd.Series, warning_rows: list[str], label: str,
) -> Any:
    if groups.nunique() >= 3 and len(y) >= 20:
        search = GridSearchCV(
            pipeline, grid, scoring="neg_mean_absolute_error",
            cv=GroupKFold(n_splits=min(3, groups.nunique())), n_jobs=1,
            refit=True, error_score=np.nan,
        )
        try:
            search.fit(x, y, groups=groups)
            return search.best_estimator_
        except Exception as exc:
            warning_rows.append(f"{label}: inner search fallback: {exc}")
    fitted = clone(pipeline)
    fitted.fit(x, y)
    return fitted


def metric_values(observed: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    rho = stats.spearmanr(observed, predicted).statistic if len(observed) >= 3 and len(np.unique(predicted)) > 1 else np.nan
    return {
        "mae": float(mean_absolute_error(observed, predicted)),
        "rmse": float(math.sqrt(mean_squared_error(observed, predicted))),
        "r2": float(r2_score(observed, predicted)) if len(observed) >= 2 else np.nan,
        "predicted_observed_spearman": float(rho) if np.isfinite(rho) else np.nan,
    }


def run_models(
    matrix: pd.DataFrame, dictionary: pd.DataFrame, permutation_repeats: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, list[str], list[dict[str, Any]]]:
    metadata = {
        "observation_id", "physical_run_id", "instrument_id", "chip_lane", "run_start_time",
        "archive_id", "total_reads", "mean_read_length_bp", "raw_read_accuracy_pct",
    }
    features = [x for x in matrix.columns if x not in metadata]
    component_map = dictionary.set_index("feature_name")["component"].to_dict()
    components = sorted(set(component_map.get(x, "other") for x in features))
    prediction_rows: list[dict[str, Any]] = []
    importance_rows: list[dict[str, Any]] = []
    standalone_rows: list[dict[str, Any]] = []
    warnings_out: list[str] = []
    skipped: list[dict[str, Any]] = []
    rng = np.random.default_rng(SEED)
    for target in ("total_reads", "mean_read_length_bp", "raw_read_accuracy_pct"):
        valid = pd.to_numeric(matrix[target], errors="coerce").notna()
        frame = matrix.loc[valid].reset_index(drop=True)
        if len(frame) < 20 or frame["physical_run_id"].nunique() < 10:
            skipped.append({"outcome": target, "usable_n": int(len(frame)), "reason": "fewer_than_20_labels_or_10_physical_runs"})
            continue
        x = frame[features].astype(float)
        y = pd.to_numeric(frame[target], errors="coerce")
        for scheme in ("grouped", "leave_one_instrument_out", "chronological"):
            for train, test, fold in validation_splits(frame, scheme):
                median = float(y.iloc[train].median())
                baseline = np.repeat(median, len(test))
                for index, prediction in zip(test, baseline):
                    prediction_rows.append({
                        "outcome": target, "validation_scheme": scheme, "validation_fold": fold,
                        "model": "median_baseline", "observation_id": frame.loc[index, "observation_id"],
                        "physical_run_id": frame.loc[index, "physical_run_id"],
                        "instrument_id": frame.loc[index, "instrument_id"], "observed": float(y.loc[index]),
                        "predicted": float(prediction), "residual": float(y.loc[index] - prediction),
                    })
                for model_name in ("elastic_net", "extra_trees"):
                    pipeline, grid = make_pipeline(model_name)
                    label = f"{target}/{scheme}/{fold}/{model_name}"
                    try:
                        fitted = fit_nested(
                            pipeline, grid, x.iloc[train], y.iloc[train],
                            frame.loc[train, "physical_run_id"], warnings_out, label,
                        )
                        predictions = fitted.predict(x.iloc[test])
                    except Exception as exc:
                        warnings_out.append(f"{label}: {type(exc).__name__}: {exc}")
                        continue
                    for index, prediction in zip(test, predictions):
                        prediction_rows.append({
                            "outcome": target, "validation_scheme": scheme, "validation_fold": fold,
                            "model": model_name, "observation_id": frame.loc[index, "observation_id"],
                            "physical_run_id": frame.loc[index, "physical_run_id"],
                            "instrument_id": frame.loc[index, "instrument_id"], "observed": float(y.loc[index]),
                            "predicted": float(prediction), "residual": float(y.loc[index] - prediction),
                        })
                    if scheme == "grouped" and model_name == "extra_trees":
                        baseline_mae = mean_absolute_error(y.iloc[test], predictions)
                        for component in components:
                            columns = [c for c in features if component_map.get(c, "other") == component]
                            if not columns:
                                continue
                            deltas = []
                            for _ in range(permutation_repeats):
                                shuffled = x.iloc[test].copy()
                                order = rng.permutation(len(shuffled))
                                shuffled.loc[:, columns] = shuffled[columns].iloc[order].to_numpy()
                                permuted = fitted.predict(shuffled)
                                deltas.append(mean_absolute_error(y.iloc[test], permuted) - baseline_mae)
                            importance_rows.append({
                                "outcome": target, "validation_fold": fold, "model": model_name,
                                "component": component, "feature_count": len(columns),
                                "heldout_mae_increase": float(np.mean(deltas)),
                                "repeat_std": float(np.std(deltas, ddof=1)) if len(deltas) > 1 else 0.0,
                                "test_n": len(test),
                            })
        grouped_splits = validation_splits(frame, "grouped")
        for component in components:
            component_columns = [c for c in features if component_map.get(c, "other") == component]
            if not component_columns:
                continue
            subset = x[component_columns]
            for train, test, fold in grouped_splits:
                pipeline, _ = make_pipeline("extra_trees")
                pipeline.set_params(select__percentile=100, model__max_depth=5, model__min_samples_leaf=4, model__max_features="sqrt")
                try:
                    pipeline.fit(subset.iloc[train], y.iloc[train])
                    prediction = pipeline.predict(subset.iloc[test])
                    metrics = metric_values(y.iloc[test].to_numpy(), prediction)
                    standalone_rows.append({
                        "outcome": target, "component": component, "validation_fold": fold,
                        "test_n": len(test), "feature_count": len(component_columns), **metrics,
                    })
                except Exception as exc:
                    warnings_out.append(f"standalone/{target}/{component}/{fold}: {exc}")
    predictions = pd.DataFrame(prediction_rows)
    performance_rows = []
    if not predictions.empty:
        for keys, group in predictions.groupby(["outcome", "validation_scheme", "model"], sort=True):
            performance_rows.append({
                "outcome": keys[0], "validation_scheme": keys[1], "model": keys[2],
                "n_observations": len(group), "n_physical_runs": group["physical_run_id"].nunique(),
                "instrument_coverage": group["instrument_id"].nunique(),
                **metric_values(group["observed"].to_numpy(), group["predicted"].to_numpy()),
            })
    performance = pd.DataFrame(performance_rows)
    if not performance.empty:
        baselines = performance[performance["model"] == "median_baseline"][["outcome", "validation_scheme", "mae"]].rename(columns={"mae": "baseline_mae"})
        performance = performance.merge(baselines, on=["outcome", "validation_scheme"], how="left")
        performance["mae_improvement_over_baseline"] = performance["baseline_mae"] - performance["mae"]
        performance["beats_baseline"] = performance["mae_improvement_over_baseline"] > 0
    return performance, predictions, pd.DataFrame(importance_rows), pd.DataFrame(standalone_rows), warnings_out, skipped


def summarize_component_importance(importance: pd.DataFrame) -> pd.DataFrame:
    if importance.empty:
        return importance
    rows = []
    rng = np.random.default_rng(SEED)
    for (outcome, component), group in importance.groupby(["outcome", "component"], sort=True):
        values = group["heldout_mae_increase"].to_numpy(dtype=float)
        boots = np.asarray([np.mean(rng.choice(values, size=len(values), replace=True)) for _ in range(1000)])
        rows.append({
            "outcome": outcome, "component": component, "folds": len(values),
            "feature_count": int(group["feature_count"].max()),
            "heldout_mae_increase_mean": float(np.mean(values)),
            "heldout_mae_increase_ci_low": float(np.quantile(boots, .025)),
            "heldout_mae_increase_ci_high": float(np.quantile(boots, .975)),
            "positive_fold_fraction": float(np.mean(values > 0)),
        })
    return pd.DataFrame(rows).sort_values(["outcome", "heldout_mae_increase_mean"], ascending=[True, False])


def html_table(frame: pd.DataFrame, columns: list[str], limit: int = 30) -> str:
    if frame.empty:
        return "<p>No results.</p>"
    display = frame[[x for x in columns if x in frame]].head(limit).copy()
    for column in display.select_dtypes(include=["number"]).columns:
        display[column] = display[column].map(lambda x: "" if pd.isna(x) else f"{x:,.4g}")
    return display.to_html(index=False, escape=True, classes="data")


def render_report(
    project: Path, retained: pd.DataFrame, matrix: pd.DataFrame, dictionary: pd.DataFrame,
    qpm_count: int, spatial_count: int, inventory: pd.DataFrame, exclusions: pd.DataFrame,
    accuracy: pd.DataFrame, performance: pd.DataFrame, component_summary: pd.DataFrame,
    standalone: pd.DataFrame, skipped: list[dict[str, Any]], warnings_out: list[str],
) -> None:
    coverage_rows = []
    for component, group in dictionary.groupby("component"):
        columns = [x for x in group["feature_name"] if x in matrix]
        coverage_rows.append({
            "component": component, "feature_count": len(columns),
            "observations_with_any_data": int(matrix[columns].notna().any(axis=1).sum()) if columns else 0,
            "median_feature_missingness": float(matrix[columns].isna().mean().median()) if columns else np.nan,
        })
    coverage = pd.DataFrame(coverage_rows).sort_values("feature_count", ascending=False)
    plugin_summary = inventory.groupby("plugin_family", as_index=False).agg(
        archives=("archive_id", "nunique"), files=("file_count", "sum"), bytes=("total_bytes", "sum")
    ).sort_values("files", ascending=False) if not inventory.empty else pd.DataFrame()
    skipped_frame = pd.DataFrame(skipped)
    warning_html = "".join(f"<li>{html.escape(str(x))}</li>" for x in warnings_out[:50]) or "<li>None</li>"
    html_text = f"""<!doctype html><html><head><meta charset="utf-8"><title>CSA multimodal diagnostic model</title>
<style>
body{{font-family:Arial,sans-serif;background:{PALETTE['mist']};color:{PALETTE['ink']};margin:0}}
main{{max-width:1250px;margin:auto;padding:28px}} h1,h2{{color:{PALETTE['forest']}}}
.card{{background:white;border-left:6px solid {PALETTE['moss']};padding:16px;margin:14px 0;border-radius:8px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}}
.metric{{font-size:1.7rem;color:{PALETTE['clay']}}} table.data{{border-collapse:collapse;width:100%;font-size:.84rem}}
table.data th,table.data td{{border-bottom:1px solid #ccd5ae;padding:6px;text-align:left}} table.data th{{background:#dde5b6}}
.warning{{border-left-color:{PALETTE['rose']}}} code{{background:#edf1e8;padding:2px 4px}}
</style></head><body><main>
<h1>CSA multimodal diagnostic model</h1>
<div class="card"><strong>Interpretation boundary.</strong> These are post-run diagnostic models. QPM, vacuum, NucStep, lib-prep telemetry, and plugin outputs occur during or after processing. Their importance can identify useful monitoring signals, but cannot justify changing instrument settings.</div>
<div class="grid">
<div class="card"><div class="metric">{len(retained):,}</div>retained run/lane observations</div>
<div class="card"><div class="metric">{retained['physical_run_id'].nunique():,}</div>physical runs</div>
<div class="card"><div class="metric">{qpm_count:,}</div>aspiration/dispense operations</div>
<div class="card"><div class="metric">{spatial_count:,}</div>NucStep spatial rows</div>
<div class="card"><div class="metric">{matrix.shape[1]-9:,}</div>numeric training features</div>
</div>
<h2>Outcome availability</h2>
{html_table(pd.DataFrame([{'outcome':y,'usable_n':int(matrix[y].notna().sum()),'unique_values':int(matrix[y].nunique(dropna=True))} for y in ['total_reads','mean_read_length_bp','raw_read_accuracy_pct']]), ['outcome','usable_n','unique_values'])}
<h2>Component coverage</h2>{html_table(coverage,['component','feature_count','observations_with_any_data','median_feature_missingness'],60)}
<h2>Held-out model performance</h2>{html_table(performance,['outcome','validation_scheme','model','n_observations','mae','rmse','r2','predicted_observed_spearman','baseline_mae','mae_improvement_over_baseline','beats_baseline'],50)}
<h2>Main component contribution</h2>
<p>Positive values mean shuffling the entire component worsened held-out MAE. Components with confidence intervals crossing zero or inconsistent folds are not stable contributors.</p>
{html_table(component_summary,['outcome','component','feature_count','heldout_mae_increase_mean','heldout_mae_increase_ci_low','heldout_mae_increase_ci_high','positive_fold_fraction'],80)}
<h2>Component-only grouped validation</h2>{html_table(standalone.groupby(['outcome','component'],as_index=False).agg(mae=('mae','mean'),rmse=('rmse','mean'),r2=('r2','mean'),spearman=('predicted_observed_spearman','mean'),folds=('validation_fold','nunique')).sort_values(['outcome','mae']) if not standalone.empty else standalone,['outcome','component','folds','mae','rmse','r2','spearman'],80)}
<h2>Plugin inventory</h2>{html_table(plugin_summary,['plugin_family','archives','files','bytes'],80)}
<h2>Leakage and privacy exclusions</h2><p>{len(exclusions):,} plugin fields or members were excluded because their names directly revealed an outcome or indicated sensitive data.</p>{html_table(exclusions,['source_file','feature','reason'],30)}
<h2>Raw-read-accuracy search</h2><p>Exact text matches are reported for provenance review only; no proxy outcome is substituted.</p>{html_table(accuracy,['archive_id','source_file','source_field','value'],30)}
<h2>Skipped outcomes</h2>{html_table(skipped_frame,['outcome','usable_n','reason'])}
<h2>Limitations</h2><ul>
<li>Only four instruments were represented because two collection targets were unreachable.</li>
<li>Plugin image descriptors are compact visual summaries, not deep-learning embeddings.</li>
<li>QPM RX values remain in unresolved sensor counts; no undocumented conversion to pressure units was applied.</li>
<li>Multiple correlated plugin families can divide permutation importance, so component-only results are shown alongside joint-model importance.</li>
<li>Models are observational and diagnostic, not causal or actionable.</li></ul>
<div class="card warning"><h2>Warnings</h2><ul>{warning_html}</ul></div>
</main></body></html>"""
    (project / "multimodal_diagnostic_report.html").write_text(html_text, encoding="utf-8")


def main() -> int:
    warnings.filterwarnings("ignore", message="Skipping features without any observed values")
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, default=Path("."))
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--refresh-cache", action="store_true")
    parser.add_argument("--extract-only", action="store_true")
    parser.add_argument("--reuse-long-tables", action="store_true")
    parser.add_argument("--permutation-repeats", type=int, default=5)
    args = parser.parse_args()
    project = args.project.resolve()
    started = time.time()
    retained = primary_archives(project)
    if args.limit:
        retained = retained.head(args.limit).copy()
    records = retained.to_dict("records")
    print(f"Extracting {len(records)} retained run/lane archives with {args.jobs} workers", flush=True)
    results = joblib.Parallel(n_jobs=max(1, args.jobs), prefer="processes", verbose=10)(
        joblib.delayed(extract_cached)(record, project / ".multimodal_cache", args.refresh_cache)
        for record in records
    )
    for index, result in enumerate(results, 1):
        print(
            f"[{index:03d}/{len(results)}] {result['base']['archive_id']}: "
            f"qpm={len(result['qpm_rows'])}, spatial={len(result['spatial_rows'])}, "
            f"features={len(result['features'])}", flush=True,
        )
    if args.reuse_long_tables and (project / "qpm_operation_waveforms.parquet").exists() and (project / "nucstep_all_spatial_blocks.parquet").exists():
        qpm_count = sum(len(result["qpm_rows"]) for result in results)
        spatial_count = sum(len(result["spatial_rows"]) for result in results)
    else:
        qpm_count, spatial_count = write_result_parquets(results, project)
    inventory = pd.DataFrame([row for result in results for row in result["plugin_inventory"]])
    exclusions = pd.DataFrame([row for result in results for row in result["exclusions"]])
    accuracy = pd.DataFrame([row for result in results for row in result["accuracy_candidates"]])
    matrix, dictionary = build_feature_matrix(project, retained, results)
    matrix.to_parquet(project / "multimodal_training_dataset.parquet", index=False)
    matrix.to_csv(project / "multimodal_training_dataset.csv", index=False)
    dictionary.to_csv(project / "multimodal_feature_dictionary.csv", index=False)
    inventory.to_csv(project / "multimodal_plugin_inventory.csv", index=False)
    exclusions.to_csv(project / "multimodal_leakage_exclusions.csv", index=False)
    accuracy.to_csv(project / "multimodal_raw_accuracy_candidates.csv", index=False)
    warnings_out = [f"{result['base']['archive_id']}: {warning}" for result in results for warning in result["warnings"]]
    if args.extract_only:
        performance = predictions = importance = standalone = pd.DataFrame()
        component_summary = pd.DataFrame()
        skipped = [{"outcome": "all", "usable_n": 0, "reason": "models_skipped_by_extract_only"}]
    else:
        print(f"Training multimodal models with {matrix.shape[1]-9} features", flush=True)
        performance, predictions, importance, standalone, model_warnings, skipped = run_models(
            matrix, dictionary, args.permutation_repeats,
        )
        warnings_out.extend(model_warnings)
        component_summary = summarize_component_importance(importance)
    performance.to_csv(project / "multimodal_model_performance.csv", index=False)
    predictions.to_csv(project / "multimodal_heldout_predictions.csv", index=False)
    importance.to_csv(project / "multimodal_component_importance_folds.csv", index=False)
    component_summary.to_csv(project / "multimodal_component_importance.csv", index=False)
    standalone.to_csv(project / "multimodal_component_standalone_performance.csv", index=False)
    render_report(
        project, retained, matrix, dictionary, qpm_count, spatial_count, inventory,
        exclusions, accuracy, performance, component_summary, standalone, skipped, warnings_out,
    )
    run_log = {
        "status": "complete", "version": VERSION, "started_utc": datetime.fromtimestamp(started, timezone.utc).isoformat(),
        "finished_utc": utc_now(), "execution_seconds": time.time() - started, "random_seed": SEED,
        "archives": len(retained), "physical_runs": int(retained["physical_run_id"].nunique()),
        "qpm_operations": qpm_count, "spatial_rows": spatial_count,
        "training_features": int(matrix.shape[1] - 9),
        "outcome_counts": {y: int(matrix[y].notna().sum()) for y in ("total_reads", "mean_read_length_bp", "raw_read_accuracy_pct")},
        "validation": ["GroupKFold physical_run_id", "leave-one-instrument-out", "chronological newest 20%"],
        "models": ["training-fold median", "ElasticNet", "constrained ExtraTrees"],
        "feature_selection": "fold-local imputation, missingness indicators, variance filter, F-score selection",
        "component_importance": "joint held-out component permutation plus component-only grouped validation",
        "input_archive_hashes": dict(zip(retained["archive_id"].astype(str), retained["sha256"].astype(str))),
        "code_sha256": sha256_file(Path(__file__)), "warnings": warnings_out, "skipped_outcomes": skipped,
    }
    (project / "multimodal_training_run_log.json").write_text(json.dumps(run_log, indent=2), encoding="utf-8")
    print(json.dumps({k: run_log[k] for k in ("archives", "physical_runs", "qpm_operations", "spatial_rows", "training_features", "outcome_counts", "execution_seconds")}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
